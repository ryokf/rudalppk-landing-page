from datetime import datetime, timezone

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.dependencies import Principal, get_principal
from app.core.pqc_backend import (
    ML_DSA_SPECS,
    ML_KEM_SPECS,
    get_pqc_backend_catalog,
    get_pqc_backend_info,
    run_pqc_benchmark,
    simulate_quantum_rsa_attack,
)
from app.models.conversation import Conversation
from app.models.device import Device
from app.models.identity import Identity
from app.models.message import Message
from app.models.organization import Organization
from app.models.pqc_artifact import PqcAuditLog, SignedArtifact

router = APIRouter(
    prefix="/api/v1/perisai/lab",
    tags=["PERISAI-Lab (Quantum Simulation & Audit)"],
)


class QuantumSimulationRequest(BaseModel):
    rsa_modulus_n: int = Field(default=3233, ge=15, le=65535)
    public_exponent_e: int = Field(default=17, ge=3, le=65537)
    sample_message: int = Field(default=42, ge=2, le=10000)
    compare_kem_alg: str = Field(
        default="ML-KEM-768",
        pattern=r"^ML-KEM-(512|768|1024)$",
    )
    compare_dsa_alg: str = Field(
        default="ML-DSA-65",
        pattern=r"^ML-DSA-(44|65|87)$",
    )


@router.get("/specs")
async def get_nist_pqc_specs(
    principal: Principal = Depends(get_principal),
):
    """Return NIST FIPS 203 (ML-KEM-512/768/1024) and FIPS 204 (ML-DSA-44/65/87) specifications."""
    return {
        "success": True,
        "data": {
            "ml_kem": ML_KEM_SPECS,
            "ml_dsa": ML_DSA_SPECS,
            "recommended_defaults": {
                "kem": "ML-KEM-768",
                "dsa": "ML-DSA-65",
            },
            "backend": get_pqc_backend_info(),
        },
        "error": None,
    }


@router.get("/backends")
async def get_pqc_backend_status(
    principal: Principal = Depends(get_principal),
):
    """Report the configured PQC backend and whether it is standards-conformant."""
    return {
        "success": True,
        "data": get_pqc_backend_catalog(),
        "error": None,
    }


@router.post("/simulate-rsa")
async def run_quantum_rsa_simulation(
    payload: QuantumSimulationRequest,
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    """Run bounded local Shor's & QUBO quantum attack simulation on small test RSA vs PQC."""
    result = simulate_quantum_rsa_attack(
        rsa_modulus_n=payload.rsa_modulus_n,
        public_exponent_e=payload.public_exponent_e,
        sample_message=payload.sample_message,
        compare_kem_alg=payload.compare_kem_alg,
        compare_dsa_alg=payload.compare_dsa_alg,
    )

    actor = "Field Agent"
    if principal.is_admin and principal.admin:
        actor = f"Admin: {principal.admin.display_name}"
    elif principal.is_device and principal.identity:
        actor = f"Agent: {principal.identity.display_name or 'Device'}"

    audit = PqcAuditLog(
        organization_id=principal.organization_id,
        event_type="QUANTUM_SIMULATION_RUN",
        algorithm=f"{payload.compare_kem_alg}+{payload.compare_dsa_alg}",
        status="RSA_BROKEN_PQC_SAFE" if result["attack_success"] else "COMPLETED",
        actor_name=actor,
        target_id=f"RSA-N={payload.rsa_modulus_n}",
        details_json=(
            f'{{"rsa_n": {payload.rsa_modulus_n}, '
            f'"factors": {result["shor_simulation"]["recovered_factors"]}, '
            f'"kem": "{payload.compare_kem_alg}", "dsa": "{payload.compare_dsa_alg}"}}'
        ),
    )
    db.add(audit)
    await db.commit()

    return {
        "success": True,
        "data": result,
        "error": None,
    }


@router.get("/audit")
async def audit_organization_pqc_readiness(
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    """Scan organization fleet, keys, messages, and signed artifacts for PQC readiness (LAB-005, LAB-007)."""
    org_id = principal.organization_id
    backend_info = get_pqc_backend_info()

    organization = None
    if org_id is not None:
        organization = (
            await db.execute(
                select(Organization).where(Organization.organization_id == org_id)
            )
        ).scalar_one_or_none()

    identities = (
        await db.execute(
            select(Identity).where(Identity.organization_id == org_id)
        )
    ).scalars().all()
    identity_ids = [i.identity_id for i in identities]
    identity_map = {i.identity_id: i for i in identities}

    devices: list[Device] = []
    if identity_ids:
        devices = (
            await db.execute(
                select(Device).where(Device.identity_id.in_(identity_ids))
            )
        ).scalars().all()

    active_devices = [d for d in devices if d.status == "active"]
    pqc_ready_devices = [
        d
        for d in active_devices
        if d.pqc_kem_public_key and d.pqc_dsa_public_key
    ]
    legacy_only_devices = [
        d
        for d in active_devices
        if not (d.pqc_kem_public_key and d.pqc_dsa_public_key)
    ]

    kem_distribution = {"ML-KEM-512": 0, "ML-KEM-768": 0, "ML-KEM-1024": 0}
    dsa_distribution = {"ML-DSA-44": 0, "ML-DSA-65": 0, "ML-DSA-87": 0}
    device_findings = []

    for d in active_devices:
        ident = identity_map.get(d.identity_id)
        has_pqc = bool(d.pqc_kem_public_key and d.pqc_dsa_public_key)
        if has_pqc:
            kem_distribution[d.pqc_kem_alg] = kem_distribution.get(d.pqc_kem_alg, 0) + 1
            dsa_distribution[d.pqc_dsa_alg] = dsa_distribution.get(d.pqc_dsa_alg, 0) + 1
        device_findings.append(
            {
                "device_id": str(d.device_id),
                "device_name": d.device_name,
                "agent_name": ident.display_name if ident else "Unknown",
                "classical_kex": "X25519 (Active)",
                "classical_auth": "Ed25519 (Active)",
                "pqc_kem_alg": d.pqc_kem_alg if has_pqc else "NONE (Legacy Only)",
                "pqc_dsa_alg": d.pqc_dsa_alg if has_pqc else "NONE (Legacy Only)",
                "quantum_ready": has_pqc and backend_info["is_fips_203_204"],
                "risk_level": (
                    "LOW (FIPS 203/204 PQC Protected)"
                    if has_pqc and backend_info["is_fips_203_204"]
                    else "HIGH (Keys present but active backend is not FIPS 203/204)"
                    if has_pqc
                    else "HIGH (Vulnerable to Harvest-Now-Decrypt-Later)"
                ),
                "recommendation": (
                    f"Keys present ({d.pqc_kem_alg} + {d.pqc_dsa_alg}); "
                    f"active backend '{backend_info['name']}' "
                    f"(FIPS 203/204: {backend_info['is_fips_203_204']})"
                    if has_pqc
                    else "Segera putar (rotate) kunci PQC perangkat ke ML-KEM-768/1024 & ML-DSA-65/87"
                ),
            }
        )

    # Inspect recent messages in organization conversations for Hybrid v2 adoption
    conversations = (
        await db.execute(
            select(Conversation.conversation_id).where(
                Conversation.organization_id == org_id
            )
        )
    ).scalars().all()

    total_messages = 0
    hybrid_pqc_messages = 0
    if conversations:
        recent_msgs = (
            await db.execute(
                select(Message.ciphertext)
                .where(Message.conversation_id.in_(conversations))
                .order_by(Message.created_at.desc())
                .limit(200)
            )
        ).scalars().all()
        total_messages = len(recent_msgs)
        for payload_bytes in recent_msgs:
            # Message.ciphertext is stored as raw bytes (the UTF-8 envelope
            # JSON after Base64-decoding at ingest).
            try:
                payload_str = (
                    payload_bytes.decode("utf-8", errors="ignore")
                    if isinstance(payload_bytes, (bytes, bytearray))
                    else str(payload_bytes or "")
                )
            except Exception:
                payload_str = ""
            if (
                '"v":2' in payload_str
                or '"v": 2' in payload_str
                or "mlkem" in payload_str.lower()
                or "pqc_kem_ct" in payload_str
            ):
                hybrid_pqc_messages += 1

    signed_artifacts_count = len(
        (
            await db.execute(
                select(SignedArtifact.artifact_id).where(
                    SignedArtifact.organization_id == org_id,
                    SignedArtifact.status == "active",
                )
            )
        ).scalars().all()
    )

    readiness_score = (
        round((len(pqc_ready_devices) / len(active_devices)) * 100, 1)
        if active_devices
        else 100.0
    )

    return {
        "success": True,
        "data": {
            "audited_at": datetime.now(timezone.utc).isoformat(),
            "organization_name": organization.organization_name
            if organization
            else "Tactical Organization",
            "backend": backend_info,
            "organization_policy": {
                "default_kem_alg": organization.pqc_kem_alg
                if organization
                else "ML-KEM-768",
                "default_dsa_alg": organization.pqc_dsa_alg
                if organization
                else "ML-DSA-65",
            },
            "summary": {
                "total_identities": len(identities),
                "active_devices": len(active_devices),
                "pqc_ready_devices": len(pqc_ready_devices),
                "legacy_vulnerable_devices": len(legacy_only_devices),
                "backend_fips_203_204": backend_info["is_fips_203_204"],
                "backend_fips_validated": backend_info["fips_validated"],
                "readiness_score_percent": readiness_score,
                "sampled_messages": total_messages,
                "hybrid_pqc_messages": hybrid_pqc_messages,
                "active_signed_artifacts": signed_artifacts_count,
            },
            "algorithm_distribution": {
                "ml_kem": kem_distribution,
                "ml_dsa": dsa_distribution,
            },
            "legacy_vulnerability_matrix": [
                {
                    "algorithm": "RSA-2048 / RSA-4096",
                    "usage": "Legacy Key Transport & Signatures",
                    "quantum_threat": "Shor's Algorithm (Period Finding / QFT)",
                    "status": "CRITICAL - BROKEN BY CRQC",
                    "perisai_replacement": "ML-KEM-768 / ML-DSA-65 (FIPS 203 & 204)",
                },
                {
                    "algorithm": "X25519 (Standalone ECDH)",
                    "usage": "SAD v1.0/v2.0 Classical E2EE Key Exchange",
                    "quantum_threat": "Discrete Log on Elliptic Curves via Shor's Algorithm (HNDL Risk)",
                    "status": "HIGH RISK IF STANDALONE",
                    "perisai_replacement": "Hybrid X25519 + ML-KEM-(512/768/1024) + HKDF-SHA256",
                },
                {
                    "algorithm": "Ed25519 (Standalone Signature)",
                    "usage": "SAD v2.0 Device Challenge-Response",
                    "quantum_threat": "Quantum Forgery of Command & Device Auth",
                    "status": "MEDIUM-HIGH RISK IF STANDALONE",
                    "perisai_replacement": "Dual-Signature Ed25519 + ML-DSA-(44/65/87)",
                },
                {
                    "algorithm": "AES-256-GCM & SHA-256",
                    "usage": "Payload AEAD & Transcript Hashing",
                    "quantum_threat": "Grover's Algorithm (Quadratic Speedup Only -> 128-bit Quantum Security)",
                    "status": "QUANTUM SAFE",
                    "perisai_replacement": "Retained in PERISAI-Vault & Hybrid Envelope v2",
                },
            ],
            "device_findings": device_findings,
        },
        "error": None,
    }


@router.post("/benchmark")
async def benchmark_pqc_algorithms(
    principal: Principal = Depends(get_principal),
):
    """Benchmark NIST ML-KEM (512, 768, 1024) and ML-DSA (44, 65, 87) latency and sizes."""
    return {
        "success": True,
        "data": run_pqc_benchmark(),
        "error": None,
    }
