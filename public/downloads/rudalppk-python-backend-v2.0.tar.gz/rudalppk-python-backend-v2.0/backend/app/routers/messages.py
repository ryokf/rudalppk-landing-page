import base64
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import selectinload

from app.core.database import get_db
from app.core.dependencies import get_current_device
from app.models.device import Device
from app.models.identity import Identity
from app.models.conversation import Conversation, ConversationMember
from app.models.message import Message, DeliveryReceipt
from app.schemas.message import MessageCreate, ReceiptUpdate
from app.services.relay_manager import relay_manager

router = APIRouter(
    prefix="/api/v1/messages",
    tags=["Messaging"],
)


async def _identity_for(db: AsyncSession, device: Device) -> Identity:
    identity = (
        await db.execute(
            select(Identity).where(Identity.identity_id == device.identity_id)
        )
    ).scalar_one_or_none()

    if not identity:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "IDENTITY_NOT_FOUND",
                "message": "Identity associated with this device was not found",
            },
        )
    return identity


async def _authorize_conversation(
    db: AsyncSession,
    device: Device,
    conversation_id: uuid.UUID,
    identity: Identity | None = None,
) -> tuple[Conversation, ConversationMember]:
    identity = identity or await _identity_for(db, device)

    stmt = (
        select(Conversation)
        .where(Conversation.conversation_id == conversation_id)
        .options(selectinload(Conversation.members))
    )
    conversation = (await db.execute(stmt)).scalar_one_or_none()

    if not conversation:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "CONVERSATION_NOT_FOUND",
                "message": "Conversation not found",
            },
        )

    # Organization isolation. Legacy conversations without an organization are
    # only reachable by legacy identities that also have no organization.
    if conversation.organization_id != identity.organization_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "ORGANIZATION_ISOLATION",
                "message": "This conversation belongs to another organization",
            },
        )

    membership = next(
        (
            member
            for member in conversation.members
            if member.identity_id == identity.identity_id
            and member.left_at is None
        ),
        None,
    )
    if not membership:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "NOT_A_MEMBER",
                "message": "You are not an active member of this conversation",
            },
        )

    return conversation, membership


@router.post("")
@router.post("/")
async def submit_message(
    payload: MessageCreate,
    current_device: Device = Depends(get_current_device),
    db: AsyncSession = Depends(get_db),
):
    """Submit an E2EE encrypted message (ciphertext only)."""
    identity = await _identity_for(db, current_device)
    conversation, _ = await _authorize_conversation(
        db, current_device, payload.conversation_id, identity
    )

    server_epoch = int(conversation.key_epoch or 1)
    if conversation.conversation_type == "group":
        if payload.key_epoch != server_epoch:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail={
                    "code": "KEY_EPOCH_STALE",
                    "message": (
                        "Group key epoch is stale. Refresh the group and re-send "
                        "with the current key epoch"
                    ),
                    "details": {"current_key_epoch": server_epoch},
                },
            )

    try:
        ciphertext_bytes = base64.b64decode(payload.ciphertext)
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "INVALID_REQUEST",
                "message": "Ciphertext must be valid Base64 string",
            },
        )

    message = Message(
        conversation_id=payload.conversation_id,
        sender_device_id=current_device.device_id,
        client_message_id=payload.client_message_id,
        protocol_version=payload.protocol_version,
        key_epoch=server_epoch,
        message_type=payload.message_type,
        ciphertext=ciphertext_bytes,
    )

    try:
        db.add(message)
        await db.flush()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "code": "DUPLICATE_MESSAGE",
                "message": "A message with this client_message_id has already been processed",
            },
        )

    other_members = [
        member.identity_id
        for member in conversation.members
        if member.identity_id != identity.identity_id and member.left_at is None
    ]

    recipient_device_ids = []
    if other_members:
        devices_stmt = select(Device.device_id).where(
            Device.identity_id.in_(other_members),
            Device.status == "active",
        )
        recipient_device_ids = list(
            (await db.execute(devices_stmt)).scalars().all()
        )

        for recipient_device_id in recipient_device_ids:
            db.add(
                DeliveryReceipt(
                    message_id=message.message_id,
                    recipient_device_id=recipient_device_id,
                    delivery_status="pending",
                )
            )

    await db.commit()
    await db.refresh(message)

    if recipient_device_ids:
        await relay_manager.notify_devices(
            device_ids=recipient_device_ids,
            event="message_available",
            data={
                "message_id": str(message.message_id),
                "conversation_id": str(message.conversation_id),
                "sender_device_id": str(message.sender_device_id),
                "key_epoch": message.key_epoch,
                "created_at": message.created_at.isoformat(),
            },
        )

    return {
        "success": True,
        "data": {
            "message_id": str(message.message_id),
            "status": "accepted",
            "key_epoch": message.key_epoch,
            "created_at": message.created_at.isoformat(),
        },
        "error": None,
    }


@router.get("/pending")
async def get_pending_messages(
    current_device: Device = Depends(get_current_device),
    db: AsyncSession = Depends(get_db),
):
    """Retrieve all pending messages waiting to be delivered to this device."""
    stmt = (
        select(Message, DeliveryReceipt)
        .join(DeliveryReceipt, Message.message_id == DeliveryReceipt.message_id)
        .where(
            DeliveryReceipt.recipient_device_id == current_device.device_id,
            DeliveryReceipt.delivery_status == "pending",
        )
        .order_by(Message.created_at.asc())
    )
    rows = (await db.execute(stmt)).all()

    messages_data = []
    for msg, receipt in rows:
        messages_data.append(
            {
                "message_id": str(msg.message_id),
                "conversation_id": str(msg.conversation_id),
                "sender_device_id": str(msg.sender_device_id),
                "client_message_id": str(msg.client_message_id),
                "protocol_version": msg.protocol_version,
                "key_epoch": msg.key_epoch,
                "message_type": msg.message_type,
                "ciphertext": base64.b64encode(msg.ciphertext).decode("utf-8"),
                "created_at": msg.created_at.isoformat(),
            }
        )

    return {
        "success": True,
        "data": messages_data,
        "error": None,
    }


@router.get("/conversation/{conversation_id}")
async def get_conversation_messages(
    conversation_id: uuid.UUID,
    limit: int = 50,
    current_device: Device = Depends(get_current_device),
    db: AsyncSession = Depends(get_db),
):
    """Retrieve recent encrypted messages in a conversation."""
    identity = await _identity_for(db, current_device)
    await _authorize_conversation(
        db, current_device, conversation_id, identity
    )

    rows = (
        await db.execute(
            select(Message)
            .where(Message.conversation_id == conversation_id)
            .order_by(Message.created_at.desc())
            .limit(limit)
        )
    ).scalars().all()

    messages_data = [
        {
            "message_id": str(msg.message_id),
            "conversation_id": str(msg.conversation_id),
            "sender_device_id": str(msg.sender_device_id),
            "client_message_id": str(msg.client_message_id),
            "protocol_version": msg.protocol_version,
            "key_epoch": msg.key_epoch,
            "message_type": msg.message_type,
            "ciphertext": base64.b64encode(msg.ciphertext).decode("utf-8"),
            "created_at": msg.created_at.isoformat(),
        }
        for msg in reversed(rows)
    ]

    return {
        "success": True,
        "data": messages_data,
        "error": None,
    }


async def _update_receipt(
    db: AsyncSession,
    device: Device,
    message_id: uuid.UUID,
    status: str,
) -> DeliveryReceipt:
    receipt = (
        await db.execute(
            select(DeliveryReceipt).where(
                DeliveryReceipt.message_id == message_id,
                DeliveryReceipt.recipient_device_id == device.device_id,
            )
        )
    ).scalar_one_or_none()

    if not receipt:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "RECEIPT_NOT_FOUND",
                "message": "Delivery receipt not found for this device",
            },
        )

    now = datetime.now(timezone.utc)
    receipt.delivery_status = status
    if status == "delivered" and not receipt.delivered_at:
        receipt.delivered_at = now
    elif status == "read":
        if not receipt.delivered_at:
            receipt.delivered_at = now
        receipt.read_at = now

    return receipt


@router.post("/{message_id}/ack")
async def acknowledge_message(
    message_id: uuid.UUID,
    payload: ReceiptUpdate | None = None,
    current_device: Device = Depends(get_current_device),
    db: AsyncSession = Depends(get_db),
):
    """Acknowledge delivery/read status for a message."""
    status = payload.delivery_status if payload else "delivered"
    receipt = await _update_receipt(db, current_device, message_id, status)
    await db.commit()

    return {
        "success": True,
        "data": {
            "receipt_id": str(receipt.receipt_id),
            "message_id": str(receipt.message_id),
            "delivery_status": receipt.delivery_status,
        },
        "error": None,
    }


@router.post("/{message_id}/receipt")
async def update_receipt(
    message_id: uuid.UUID,
    payload: ReceiptUpdate,
    current_device: Device = Depends(get_current_device),
    db: AsyncSession = Depends(get_db),
):
    """Update delivery receipt status (delivered or read)."""
    receipt = await _update_receipt(
        db, current_device, message_id, payload.delivery_status
    )
    await db.commit()

    return {
        "success": True,
        "data": {
            "receipt_id": str(receipt.receipt_id),
            "message_id": str(receipt.message_id),
            "delivery_status": receipt.delivery_status,
        },
        "error": None,
    }


@router.delete("/{message_id}")
async def delete_message(
    message_id: uuid.UUID,
    current_device: Device = Depends(get_current_device),
    db: AsyncSession = Depends(get_db),
):
    """Delete a message (only sender device permitted)."""
    message = (
        await db.execute(
            select(Message).where(Message.message_id == message_id)
        )
    ).scalar_one_or_none()

    if not message:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "MESSAGE_NOT_FOUND",
                "message": "Message not found",
            },
        )

    if message.sender_device_id != current_device.device_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "FORBIDDEN",
                "message": "Only sender device can delete this message",
            },
        )

    await db.delete(message)
    await db.commit()

    return {
        "success": True,
        "data": {"message_id": str(message_id), "status": "deleted"},
        "error": None,
    }
