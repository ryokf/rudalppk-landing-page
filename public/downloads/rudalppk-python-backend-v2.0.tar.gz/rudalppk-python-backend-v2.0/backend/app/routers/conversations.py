import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import aliased, selectinload

from app.core.database import get_db
from app.core.dependencies import Principal, get_principal
from app.models.conversation import Conversation, ConversationMember
from app.models.device import Device
from app.models.identity import Identity
from app.schemas.conversation import (
    ConversationCreate,
    DirectConversationCreate,
)
from app.services.relay_manager import relay_manager

router = APIRouter(
    prefix="/api/v1/conversations",
    tags=["Personal Conversations"],
)


def _require_device(principal: Principal) -> tuple[uuid.UUID, uuid.UUID | None]:
    if not principal.is_device or principal.identity_id is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "DEVICE_REQUIRED",
                "message": "Only a field-agent device can use personal chat",
            },
        )
    return principal.identity_id, principal.organization_id


async def _load_org_identity(
    db: AsyncSession,
    organization_id: uuid.UUID | None,
    identity_id: uuid.UUID,
    *,
    include_devices: bool = True,
) -> Identity:
    if organization_id is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "ORGANIZATION_REQUIRED",
                "message": "Personal chat requires an organization account",
            },
        )

    stmt = select(Identity).where(
        Identity.identity_id == identity_id,
        Identity.organization_id == organization_id,
    )
    identity = (await db.execute(stmt)).scalar_one_or_none()

    if not identity:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "USER_NOT_FOUND",
                "message": "User not found in this organization",
            },
        )

    if identity.status != "active":
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "code": "USER_NOT_ACTIVE",
                "message": f"User is {identity.status} and cannot be contacted",
            },
        )

    return identity


async def _active_member_ids(
    db: AsyncSession,
    conversation: Conversation,
) -> list[uuid.UUID]:
    members = [member for member in conversation.members if member.left_at is None]
    return [member.identity_id for member in members]


async def _conversation_data(
    db: AsyncSession,
    conversation: Conversation,
    my_identity_id: uuid.UUID,
) -> dict:
    member_ids = await _active_member_ids(db, conversation)
    identities: dict[uuid.UUID, Identity] = {}
    devices_by_identity: dict[uuid.UUID, list[Device]] = {}

    if member_ids:
        identities = {
            identity.identity_id: identity
            for identity in (
                await db.execute(
                    select(Identity).where(Identity.identity_id.in_(member_ids))
                )
            ).scalars().all()
        }
        devices = (
            await db.execute(
                select(Device).where(
                    Device.identity_id.in_(member_ids),
                    Device.status == "active",
                )
            )
        ).scalars().all()
        for device in devices:
            devices_by_identity.setdefault(device.identity_id, []).append(device)

    members_data = []
    for member in sorted(
        [item for item in conversation.members if item.left_at is None],
        key=lambda item: item.joined_at,
    ):
        identity = identities.get(member.identity_id)
        members_data.append(
            {
                "identity_id": str(member.identity_id),
                "display_name": identity.display_name if identity else None,
                "public_identity": identity.public_identity if identity else None,
                "member_role": member.member_role,
                "joined_at": member.joined_at.isoformat(),
                "devices": [
                    {
                        "device_id": str(device.device_id),
                        "device_name": device.device_name,
                        "public_device_key": device.public_device_key,
                        "pqc_kem_alg": device.pqc_kem_alg,
                        "pqc_kem_public_key": device.pqc_kem_public_key,
                        "pqc_dsa_alg": device.pqc_dsa_alg,
                        "pqc_dsa_public_key": device.pqc_dsa_public_key,
                    }
                    for device in devices_by_identity.get(member.identity_id, [])
                ],
            }
        )

    peer = next(
        (
            item
            for item in members_data
            if item["identity_id"] != str(my_identity_id)
        ),
        None,
    )

    return {
        "conversation_id": str(conversation.conversation_id),
        "conversation_type": conversation.conversation_type,
        "title": conversation.title,
        "key_epoch": conversation.key_epoch,
        "created_at": conversation.created_at.isoformat(),
        "members": members_data,
        "peer": peer,
    }


async def _find_direct_conversation(
    db: AsyncSession,
    organization_id: uuid.UUID | None,
    my_identity_id: uuid.UUID,
    peer_identity_id: uuid.UUID,
) -> Conversation | None:
    member_a = aliased(ConversationMember)
    member_b = aliased(ConversationMember)

    stmt = (
        select(Conversation)
        .join(member_a, member_a.conversation_id == Conversation.conversation_id)
        .join(member_b, member_b.conversation_id == Conversation.conversation_id)
        .where(
            Conversation.conversation_type == "direct",
            Conversation.organization_id == organization_id,
            member_a.identity_id == my_identity_id,
            member_a.left_at.is_(None),
            member_b.identity_id == peer_identity_id,
            member_b.left_at.is_(None),
        )
        .options(selectinload(Conversation.members))
    )
    return (await db.execute(stmt)).scalars().first()


async def _get_or_create_direct(
    db: AsyncSession,
    organization_id: uuid.UUID | None,
    my_identity_id: uuid.UUID,
    peer_identity_id: uuid.UUID,
) -> tuple[Conversation, bool]:
    conversation = await _find_direct_conversation(
        db, organization_id, my_identity_id, peer_identity_id
    )
    if conversation:
        return conversation, False

    conversation = Conversation(
        organization_id=organization_id,
        conversation_type="direct",
        title=None,
        key_epoch=1,
    )
    db.add(conversation)
    await db.flush()

    now = datetime.now(timezone.utc)
    db.add(
        ConversationMember(
            conversation_id=conversation.conversation_id,
            identity_id=my_identity_id,
            member_role="member",
            joined_at=now,
        )
    )
    db.add(
        ConversationMember(
            conversation_id=conversation.conversation_id,
            identity_id=peer_identity_id,
            member_role="member",
            joined_at=now,
        )
    )
    await db.commit()

    stmt = (
        select(Conversation)
        .where(Conversation.conversation_id == conversation.conversation_id)
        .options(selectinload(Conversation.members))
    )
    reloaded = (await db.execute(stmt)).scalar_one()
    return reloaded, True


async def _notify_peer_started(
    db: AsyncSession,
    peer_identity_id: uuid.UUID,
) -> None:
    device_ids = (
        await db.execute(
            select(Device.device_id).where(
                Device.identity_id == peer_identity_id,
                Device.status == "active",
            )
        )
    ).scalars().all()
    if device_ids:
        await relay_manager.notify_devices(
            device_ids=list(device_ids),
            event="conversation_started",
            data={},
        )


@router.post("/direct")
async def create_or_get_direct_conversation(
    payload: DirectConversationCreate,
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    """Create or return the personal conversation with another organization member."""
    my_identity_id, organization_id = _require_device(principal)

    if payload.peer_identity_id == my_identity_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "INVALID_REQUEST",
                "message": "A personal conversation requires two different members",
            },
        )

    peer = await _load_org_identity(
        db, organization_id, payload.peer_identity_id
    )
    conversation, created = await _get_or_create_direct(
        db, organization_id, my_identity_id, peer.identity_id
    )

    if created:
        await _notify_peer_started(db, peer.identity_id)

    return {
        "success": True,
        "data": await _conversation_data(db, conversation, my_identity_id),
        "error": None,
    }


@router.get("/direct")
async def list_direct_conversations(
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    """List all personal conversations where the caller is an active member."""
    my_identity_id, organization_id = _require_device(principal)

    stmt = (
        select(Conversation)
        .join(
            ConversationMember,
            ConversationMember.conversation_id == Conversation.conversation_id,
        )
        .where(
            Conversation.conversation_type == "direct",
            Conversation.organization_id == organization_id,
            ConversationMember.identity_id == my_identity_id,
            ConversationMember.left_at.is_(None),
        )
        .options(selectinload(Conversation.members))
        .order_by(Conversation.created_at.desc())
    )
    conversations = (await db.execute(stmt)).scalars().all()

    return {
        "success": True,
        "data": [
            await _conversation_data(db, conversation, my_identity_id)
            for conversation in conversations
        ],
        "error": None,
    }


# Kept as an alias so existing clients continue to work.
@router.get("")
@router.get("/")
async def list_conversations_alias(
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    return await list_direct_conversations(principal=principal, db=db)


@router.post("")
@router.post("/")
async def create_conversation(
    payload: ConversationCreate,
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    """Backward-compatible conversation creation. Groups use /groups."""
    my_identity_id, organization_id = _require_device(principal)

    if payload.conversation_type == "group":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "USE_GROUPS_ENDPOINT",
                "message": "Groups must be created through /api/v1/groups",
            },
        )

    member_ids = set(payload.members)
    member_ids.add(my_identity_id)
    if len(member_ids) != 2:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "INVALID_REQUEST",
                "message": "A personal conversation must have exactly two members",
            },
        )

    peer_identity_id = next(iter(member_ids - {my_identity_id}))
    peer = await _load_org_identity(
        db, organization_id, peer_identity_id
    )
    conversation, created = await _get_or_create_direct(
        db, organization_id, my_identity_id, peer.identity_id
    )
    if created:
        await _notify_peer_started(db, peer.identity_id)

    return {
        "success": True,
        "data": await _conversation_data(db, conversation, my_identity_id),
        "error": None,
    }


@router.get("/{conversation_id}")
async def get_conversation_detail(
    conversation_id: uuid.UUID,
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    my_identity_id, organization_id = _require_device(principal)

    stmt = (
        select(Conversation)
        .where(Conversation.conversation_id == conversation_id)
        .options(selectinload(Conversation.members))
    )
    conversation = (await db.execute(stmt)).scalar_one_or_none()

    if (
        not conversation
        or conversation.conversation_type != "direct"
        or conversation.organization_id != organization_id
    ):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "CONVERSATION_NOT_FOUND",
                "message": "Personal conversation not found",
            },
        )

    member = next(
        (
            item
            for item in conversation.members
            if item.identity_id == my_identity_id and item.left_at is None
        ),
        None,
    )
    if not member:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "NOT_A_MEMBER",
                "message": "You are not an active member of this conversation",
            },
        )

    return {
        "success": True,
        "data": await _conversation_data(db, conversation, my_identity_id),
        "error": None,
    }
