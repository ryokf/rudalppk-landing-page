from app.routers import (
    identity,
    auth,
    devices,
    contacts,
    conversations,
    messages,
    media,
    relay,
    activation,
    organization,
    directory,
    groups,
)

__all__ = [
    "identity",
    "auth",
    "devices",
    "contacts",
    "conversations",
    "messages",
    "media",
    "relay",
    "activation",
    "organization",
    "directory",
    "groups",
]
