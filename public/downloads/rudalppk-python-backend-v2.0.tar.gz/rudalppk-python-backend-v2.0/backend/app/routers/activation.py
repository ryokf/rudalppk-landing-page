import hashlib
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.pqc_backend import (
    ml_dsa_keygen,
    ml_kem_keygen,
    normalize_dsa_alg,
    normalize_kem_alg,
)
from app.core.security import validate_identity_proof
from app.models.device import Device
from app.models.identity import Identity
from app.models.organization import Organization, UserCredential
from app.schemas.activation import ActivationCompleteRequest, ActivationVerifyRequest
from app.services.credentials import hash_activation_code

router = APIRouter(
    prefix="/api/v1/activation",
    tags=["Account Activation"],
)


async def _load_credential_for_update(
    db: AsyncSession,
    code: str,
) -> UserCredential:
    credential_hash = hash_activation_code(code)
    stmt = (
        select(UserCredential)
        .where(UserCredential.credential_hash == credential_hash)
        .with_for_update()
    )
    credential = (await db.execute(stmt)).scalar_one_or_none()

    if not credential:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "INVALID_ACTIVATION_CODE",
                "message": "Activation code is invalid",
            },
        )

    now = datetime.now(timezone.utc)
    if credential.consumed_at is not None:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "code": "ACTIVATION_CODE_USED",
                "message": "Activation code has already been used",
            },
        )
    if credential.revoked_at is not None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "ACTIVATION_CODE_REVOKED",
                "message": "Activation code has been revoked",
            },
        )
    if credential.expires_at < now:
        raise HTTPException(
            status_code=status.HTTP_410_GONE,
            detail={
                "code": "ACTIVATION_CODE_EXPIRED",
                "message": "Activation code has expired",
            },
        )

    return credential


async def _load_pending_account(
    db: AsyncSession,
    credential: UserCredential,
) -> tuple[Identity, Organization]:
    identity = (
        await db.execute(
            select(Identity).where(Identity.identity_id == credential.identity_id)
        )
    ).scalar_one_or_none()

    if not identity:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "IDENTITY_NOT_FOUND",
                "message": "The account for this activation code no longer exists",
            },
        )

    if identity.status != "pending":
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "code": "ACCOUNT_NOT_PENDING",
                "message": f"Account is {identity.status} and cannot be activated",
            },
        )

    organization = (
        await db.execute(
            select(Organization).where(
                Organization.organization_id == identity.organization_id
            )
        )
    ).scalar_one_or_none()

    if not organization:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "ORGANIZATION_NOT_FOUND",
                "message": "The account is not linked to an organization",
            },
        )

    if organization.status != "active":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "ORGANIZATION_INACTIVE",
                "message": "The organization is not active",
            },
        )

    return identity, organization


@router.post("/verify")
async def verify_activation_code(
    payload: ActivationVerifyRequest,
    db: AsyncSession = Depends(get_db),
):
    credential = await _load_credential_for_update(db, payload.code)
    identity, organization = await _load_pending_account(db, credential)
    await db.commit()

    return {
        "success": True,
        "data": {
            "identity_id": str(identity.identity_id),
            "display_name": identity.display_name,
            "organization_id": str(organization.organization_id),
            "organization_name": organization.organization_name,
            "pqc_kem_alg": organization.pqc_kem_alg,
            "pqc_dsa_alg": organization.pqc_dsa_alg,
            "account_status": identity.status,
            "expires_at": credential.expires_at.isoformat(),
        },
        "error": None,
    }


@router.post("/complete")
async def complete_activation(
    payload: ActivationCompleteRequest,
    db: AsyncSession = Depends(get_db),
):
    credential = await _load_credential_for_update(db, payload.code)
    identity, organization = await _load_pending_account(db, credential)

    try:
        public_identity = validate_identity_proof(
            payload.identity_fingerprint,
            payload.auth_public_key,
        )
        kem_alg = normalize_kem_alg(payload.pqc_kem_alg or organization.pqc_kem_alg)
        dsa_alg = normalize_dsa_alg(payload.pqc_dsa_alg or organization.pqc_dsa_alg)
    except ValueError as exc:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "INVALID_IDENTITY_PROOF",
                "message": str(exc),
            },
        )

    # Ensure the derived identity/fingerprint is not already claimed by another
    # account. The pending placeholder is unique, so it cannot collide.
    collision_stmt = select(Identity.identity_id).where(
        (Identity.public_identity == public_identity)
        | (Identity.identity_fingerprint == payload.identity_fingerprint.lower()),
        Identity.identity_id != identity.identity_id,
    )
    collision = (await db.execute(collision_stmt)).scalars().first()
    if collision:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "code": "IDENTITY_ALREADY_ACTIVE",
                "message": "This cryptographic identity is already registered",
            },
        )

    now = datetime.now(timezone.utc)

    identity.public_identity = public_identity
    identity.identity_fingerprint = payload.identity_fingerprint.lower()
    identity.status = "active"
    identity.activated_at = now

    kem_pub = payload.pqc_kem_public_key
    if not kem_pub:
        kem_seed = hashlib.sha256(
            f"PERISAI-ACTIVATE-KEM|{payload.public_device_key}|{kem_alg}".encode("utf-8")
        ).digest()
        kem_pub = ml_kem_keygen(kem_alg, seed=kem_seed)["public_key"]

    dsa_pub = payload.pqc_dsa_public_key
    if not dsa_pub:
        dsa_seed = hashlib.sha256(
            f"PERISAI-ACTIVATE-DSA|{payload.auth_public_key}|{dsa_alg}".encode("utf-8")
        ).digest()
        dsa_pub = ml_dsa_keygen(dsa_alg, seed=dsa_seed)["public_key"]

    device = Device(
        identity_id=identity.identity_id,
        device_name=payload.device_name,
        public_device_key=payload.public_device_key,
        auth_public_key=payload.auth_public_key,
        pqc_kem_alg=kem_alg,
        pqc_kem_public_key=kem_pub,
        pqc_dsa_alg=dsa_alg,
        pqc_dsa_public_key=dsa_pub,
    )
    db.add(device)

    credential.consumed_at = now

    try:
        await db.commit()
        await db.refresh(device)
    except IntegrityError:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "code": "IDENTITY_ALREADY_ACTIVE",
                "message": "This cryptographic identity is already registered",
            },
        )

    return {
        "success": True,
        "data": {
            "identity_id": str(identity.identity_id),
            "device_id": str(device.device_id),
            "public_identity": identity.public_identity,
            "identity_fingerprint": identity.identity_fingerprint,
            "display_name": identity.display_name,
            "account_status": identity.status,
            "organization_id": str(organization.organization_id),
            "organization_name": organization.organization_name,
            "pqc_kem_alg": device.pqc_kem_alg,
            "pqc_dsa_alg": device.pqc_dsa_alg,
        },
        "error": None,
    }
