import uuid
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select, or_
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import get_db
from app.core.dependencies import (
    Principal,
    get_current_admin,
    get_principal,
    require_organization_owner,
    require_system_admin,
)
from app.core.security import (
    create_admin_access_token,
    hash_password,
    verify_password,
)
from app.models.conversation import Conversation, ConversationMember
from app.models.device import Device
from app.models.identity import Identity
from app.models.organization import Organization, OrganizationAdmin, UserCredential
from app.schemas.organization import (
    AdminCreate,
    AdminLoginRequest,
    AdminUpdate,
    FieldAgentCreate,
    FieldAgentUpdate,
    OrganizationCreate,
    OrganizationUpdate,
)
from app.services.credentials import generate_activation_code, hash_activation_code
from app.services.group_service import (
    active_members,
    bump_key_epoch,
    ensure_group_admin,
    load_conversation,
    notify_membership_changed,
    record_event,
)

router = APIRouter(
    prefix="/api/v1/organizations",
    tags=["Organizations"],
)


def _admin_data(admin: OrganizationAdmin) -> dict:
    return {
        "admin_id": str(admin.admin_id),
        "organization_id": str(admin.organization_id),
        "email": admin.email,
        "display_name": admin.display_name,
        "role": admin.role,
        "status": admin.status,
        "created_at": admin.created_at.isoformat(),
        "last_login_at": admin.last_login_at.isoformat() if admin.last_login_at else None,
    }


def _organization_data(organization: Organization) -> dict:
    return {
        "organization_id": str(organization.organization_id),
        "organization_name": organization.organization_name,
        "status": organization.status,
        "pqc_kem_alg": organization.pqc_kem_alg,
        "pqc_dsa_alg": organization.pqc_dsa_alg,
        "created_at": organization.created_at.isoformat(),
    }


def _identity_data(
    identity: Identity,
    devices: list[Device],
    credential: UserCredential | None = None,
) -> dict:
    active_devices = [device for device in devices if device.status == "active"]
    pqc_devices = [
        device
        for device in active_devices
        if device.pqc_kem_public_key and device.pqc_dsa_public_key
    ]
    return {
        "identity_id": str(identity.identity_id),
        "organization_id": str(identity.organization_id) if identity.organization_id else None,
        "display_name": identity.display_name,
        "public_identity": identity.public_identity,
        "identity_fingerprint": identity.identity_fingerprint,
        "status": identity.status,
        "created_at": identity.created_at.isoformat(),
        "activated_at": identity.activated_at.isoformat() if identity.activated_at else None,
        "device_count": len(devices),
        "active_device_count": len(active_devices),
        "pqc_device_count": len(pqc_devices),
        "credential": {
            "credential_id": str(credential.credential_id),
            "expires_at": credential.expires_at.isoformat(),
            "consumed_at": credential.consumed_at.isoformat() if credential.consumed_at else None,
            "revoked_at": credential.revoked_at.isoformat() if credential.revoked_at else None,
            "created_at": credential.created_at.isoformat(),
        }
        if credential
        else None,
    }


def _device_data(device: Device) -> dict:
    return {
        "device_id": str(device.device_id),
        "device_name": device.device_name,
        "status": device.status,
        "pqc_kem_alg": device.pqc_kem_alg,
        "pqc_kem_public_key": device.pqc_kem_public_key,
        "pqc_dsa_alg": device.pqc_dsa_alg,
        "pqc_dsa_public_key": device.pqc_dsa_public_key,
        "registered_at": device.registered_at.isoformat(),
        "revoked_at": device.revoked_at.isoformat() if device.revoked_at else None,
    }


async def _get_organization(
    db: AsyncSession,
    organization_id: uuid.UUID,
) -> Organization:
    organization = (
        await db.execute(
            select(Organization).where(
                Organization.organization_id == organization_id
            )
        )
    ).scalar_one_or_none()
    if not organization:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "ORGANIZATION_NOT_FOUND",
                "message": "Organization not found",
            },
        )
    return organization


async def _load_agent_in_org(
    db: AsyncSession,
    admin: OrganizationAdmin,
    identity_id: uuid.UUID,
) -> Identity:
    identity = (
        await db.execute(
            select(Identity).where(
                Identity.identity_id == identity_id,
                Identity.organization_id == admin.organization_id,
            )
        )
    ).scalar_one_or_none()

    if not identity:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "USER_NOT_FOUND",
                "message": "User not found in this organization",
            },
        )
    return identity


async def _revoke_identity_access(
    db: AsyncSession,
    identity: Identity,
    actor: OrganizationAdmin,
) -> None:
    """Revoke credentials, devices and conversation memberships immediately."""
    now = datetime.now(timezone.utc)

    identity.status = "revoked"

    devices = (
        await db.execute(
            select(Device).where(Device.identity_id == identity.identity_id)
        )
    ).scalars().all()
    for device in devices:
        if device.status == "active":
            device.status = "revoked"
            device.revoked_at = now

    credentials = (
        await db.execute(
            select(UserCredential).where(
                UserCredential.identity_id == identity.identity_id,
                UserCredential.consumed_at.is_(None),
                UserCredential.revoked_at.is_(None),
            )
        )
    ).scalars().all()
    for credential in credentials:
        credential.revoked_at = now

    memberships = (
        await db.execute(
            select(ConversationMember).where(
                ConversationMember.identity_id == identity.identity_id,
                ConversationMember.left_at.is_(None),
            )
        )
    ).scalars().all()

    touched_groups: dict[uuid.UUID, str] = {}
    for membership in memberships:
        conversation = await load_conversation(db, membership.conversation_id)
        if not conversation:
            continue

        membership.left_at = now
        bump_key_epoch(conversation)
        record_event(
            db,
            conversation,
            "account_revoked",
            identity_id=identity.identity_id,
            actor_type="admin",
            actor_id=actor.admin_id,
        )
        await ensure_group_admin(
            db,
            conversation,
            excluding_identity_id=identity.identity_id,
        )
        if conversation.conversation_type == "group":
            touched_groups[conversation.conversation_id] = conversation.conversation_id

    for conversation_id in touched_groups:
        conversation = await load_conversation(db, conversation_id)
        if conversation:
            await notify_membership_changed(db, conversation)


# ---------------------------------------------------------------------------
# System-level organization creation
# ---------------------------------------------------------------------------

@router.post("")
@router.post("/")
async def create_organization(
    payload: OrganizationCreate,
    _: None = Depends(require_system_admin),
    db: AsyncSession = Depends(get_db),
):
    existing_admin = (
        await db.execute(
            select(OrganizationAdmin).where(
                OrganizationAdmin.email == payload.admin_email.lower()
            )
        )
    ).scalar_one_or_none()
    if existing_admin:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "code": "EMAIL_ALREADY_REGISTERED",
                "message": "An administrator with this email already exists",
            },
        )

    organization = Organization(organization_name=payload.organization_name.strip())
    db.add(organization)
    await db.flush()

    admin = OrganizationAdmin(
        organization_id=organization.organization_id,
        email=payload.admin_email.lower(),
        display_name=payload.admin_display_name.strip(),
        password_hash=hash_password(payload.admin_password),
        role="owner",
        status="active",
    )
    db.add(admin)
    await db.commit()
    await db.refresh(organization)
    await db.refresh(admin)

    token, expires_in = create_admin_access_token(
        admin_id=str(admin.admin_id),
        organization_id=str(organization.organization_id),
        role=admin.role,
    )

    return {
        "success": True,
        "data": {
            "organization": _organization_data(organization),
            "admin": _admin_data(admin),
            "access_token": token,
            "token_type": "bearer",
            "expires_in": expires_in,
        },
        "error": None,
    }


@router.post("/auth/login")
async def admin_login(
    payload: AdminLoginRequest,
    db: AsyncSession = Depends(get_db),
):
    admin = (
        await db.execute(
            select(OrganizationAdmin).where(
                OrganizationAdmin.email == payload.email.lower()
            )
        )
    ).scalar_one_or_none()

    if not admin or not verify_password(payload.password, admin.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={
                "code": "INVALID_CREDENTIALS",
                "message": "Email or password is incorrect",
            },
        )

    if admin.status != "active":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "ADMIN_INACTIVE",
                "message": "Administrator account is not active",
            },
        )

    organization = await _get_organization(db, admin.organization_id)
    if organization.status != "active":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "ORGANIZATION_INACTIVE",
                "message": "Organization is not active",
            },
        )

    admin.last_login_at = datetime.now(timezone.utc)
    await db.commit()

    token, expires_in = create_admin_access_token(
        admin_id=str(admin.admin_id),
        organization_id=str(organization.organization_id),
        role=admin.role,
    )

    return {
        "success": True,
        "data": {
            "access_token": token,
            "token_type": "bearer",
            "expires_in": expires_in,
            "admin": _admin_data(admin),
            "organization": _organization_data(organization),
        },
        "error": None,
    }


# ---------------------------------------------------------------------------
# Current organization / administrator profile
# ---------------------------------------------------------------------------

@router.get("/me")
async def get_my_organization(
    admin: OrganizationAdmin = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    organization = await _get_organization(db, admin.organization_id)

    user_count = len(
        (
            await db.execute(
                select(Identity.identity_id).where(
                    Identity.organization_id == admin.organization_id
                )
            )
        ).scalars().all()
    )
    group_count = len(
        (
            await db.execute(
                select(Conversation.conversation_id)
                .join(
                    ConversationMember,
                    ConversationMember.conversation_id
                    == Conversation.conversation_id,
                )
                .where(
                    Conversation.conversation_type == "group",
                    Conversation.organization_id == admin.organization_id,
                    ConversationMember.left_at.is_(None),
                )
                .distinct()
            )
        ).scalars().all()
    )

    return {
        "success": True,
        "data": {
            "organization": _organization_data(organization),
            "admin": _admin_data(admin),
            "user_count": user_count,
            "group_count": group_count,
        },
        "error": None,
    }


@router.patch("/me")
async def update_my_organization(
    payload: OrganizationUpdate,
    principal: Principal = Depends(require_organization_owner),
    db: AsyncSession = Depends(get_db),
):
    organization = await _get_organization(db, principal.organization_id)
    if payload.organization_name is not None:
        organization.organization_name = payload.organization_name.strip()
    if payload.pqc_kem_alg is not None:
        organization.pqc_kem_alg = payload.pqc_kem_alg
    if payload.pqc_dsa_alg is not None:
        organization.pqc_dsa_alg = payload.pqc_dsa_alg
    await db.commit()
    await db.refresh(organization)

    return {
        "success": True,
        "data": {"organization": _organization_data(organization)},
        "error": None,
    }


# ---------------------------------------------------------------------------
# Administrator management
# ---------------------------------------------------------------------------

@router.get("/admins")
async def list_admins(
    admin: OrganizationAdmin = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    admins = (
        await db.execute(
            select(OrganizationAdmin)
            .where(OrganizationAdmin.organization_id == admin.organization_id)
            .order_by(OrganizationAdmin.created_at.asc())
        )
    ).scalars().all()

    return {
        "success": True,
        "data": [_admin_data(item) for item in admins],
        "error": None,
    }


@router.post("/admins")
async def create_admin(
    payload: AdminCreate,
    principal: Principal = Depends(require_organization_owner),
    db: AsyncSession = Depends(get_db),
):
    existing = (
        await db.execute(
            select(OrganizationAdmin).where(
                OrganizationAdmin.email == payload.email.lower()
            )
        )
    ).scalar_one_or_none()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "code": "EMAIL_ALREADY_REGISTERED",
                "message": "An administrator with this email already exists",
            },
        )

    admin = OrganizationAdmin(
        organization_id=principal.organization_id,
        email=payload.email.lower(),
        display_name=payload.display_name.strip(),
        password_hash=hash_password(payload.password),
        role=payload.role,
        status="active",
    )
    db.add(admin)
    await db.commit()
    await db.refresh(admin)

    return {
        "success": True,
        "data": _admin_data(admin),
        "error": None,
    }


@router.patch("/admins/{admin_id}")
async def update_admin(
    admin_id: uuid.UUID,
    payload: AdminUpdate,
    principal: Principal = Depends(require_organization_owner),
    db: AsyncSession = Depends(get_db),
):
    admin = (
        await db.execute(
            select(OrganizationAdmin).where(
                OrganizationAdmin.admin_id == admin_id,
                OrganizationAdmin.organization_id == principal.organization_id,
            )
        )
    ).scalar_one_or_none()

    if not admin:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "ADMIN_NOT_FOUND",
                "message": "Administrator not found in this organization",
            },
        )

    if payload.display_name is not None:
        admin.display_name = payload.display_name.strip()
    if payload.status is not None:
        admin.status = payload.status
    if payload.password is not None:
        admin.password_hash = hash_password(payload.password)

    await db.commit()
    await db.refresh(admin)

    return {
        "success": True,
        "data": _admin_data(admin),
        "error": None,
    }


# ---------------------------------------------------------------------------
# Field-agent user management
# ---------------------------------------------------------------------------

@router.get("/users")
async def list_organization_users(
    status_filter: str | None = None,
    search: str | None = None,
    admin: OrganizationAdmin = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    stmt = select(Identity).where(
        Identity.organization_id == admin.organization_id
    )
    if status_filter:
        stmt = stmt.where(Identity.status == status_filter)
    if search:
        pattern = f"%{search.strip()}%"
        stmt = stmt.where(
            or_(
                Identity.display_name.ilike(pattern),
                Identity.public_identity.ilike(pattern),
                Identity.identity_fingerprint.ilike(pattern),
            )
        )
    stmt = stmt.order_by(Identity.created_at.desc())

    identities = (await db.execute(stmt)).scalars().all()
    identity_ids = [identity.identity_id for identity in identities]

    devices_by_identity: dict[uuid.UUID, list[Device]] = {}
    credentials_by_identity: dict[uuid.UUID, UserCredential] = {}

    if identity_ids:
        devices = (
            await db.execute(
                select(Device).where(Device.identity_id.in_(identity_ids))
            )
        ).scalars().all()
        for device in devices:
            devices_by_identity.setdefault(device.identity_id, []).append(device)

        credentials = (
            await db.execute(
                select(UserCredential)
                .where(UserCredential.identity_id.in_(identity_ids))
                .order_by(UserCredential.created_at.desc())
            )
        ).scalars().all()
        for credential in credentials:
            credentials_by_identity.setdefault(credential.identity_id, credential)

    return {
        "success": True,
        "data": [
            _identity_data(
                identity,
                devices_by_identity.get(identity.identity_id, []),
                credentials_by_identity.get(identity.identity_id),
            )
            for identity in identities
        ],
        "error": None,
    }


@router.post("/users")
async def create_field_agent(
    payload: FieldAgentCreate,
    admin: OrganizationAdmin = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    placeholder = uuid.uuid4().hex
    identity = Identity(
        organization_id=admin.organization_id,
        display_name=payload.display_name.strip(),
        public_identity=f"PENDING_{placeholder}",
        identity_fingerprint=f"pending-{placeholder}",
        status="pending",
        provisioned_by_admin_id=admin.admin_id,
    )
    db.add(identity)

    try:
        await db.commit()
        await db.refresh(identity)
    except IntegrityError:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "code": "USER_CREATION_FAILED",
                "message": "Could not create the user account",
            },
        )

    return {
        "success": True,
        "data": _identity_data(identity, []),
        "error": None,
    }


@router.get("/users/{identity_id}")
async def get_organization_user(
    identity_id: uuid.UUID,
    admin: OrganizationAdmin = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    identity = await _load_agent_in_org(db, admin, identity_id)

    devices = (
        await db.execute(
            select(Device).where(Device.identity_id == identity.identity_id)
        )
    ).scalars().all()
    credentials = (
        await db.execute(
            select(UserCredential)
            .where(UserCredential.identity_id == identity.identity_id)
            .order_by(UserCredential.created_at.desc())
        )
    ).scalars().all()

    data = _identity_data(
        identity,
        devices,
        credentials[0] if credentials else None,
    )
    data["devices"] = [_device_data(device) for device in devices]
    data["credentials"] = [
        {
            "credential_id": str(credential.credential_id),
            "expires_at": credential.expires_at.isoformat(),
            "consumed_at": credential.consumed_at.isoformat() if credential.consumed_at else None,
            "revoked_at": credential.revoked_at.isoformat() if credential.revoked_at else None,
            "created_at": credential.created_at.isoformat(),
        }
        for credential in credentials
    ]

    return {
        "success": True,
        "data": data,
        "error": None,
    }


@router.patch("/users/{identity_id}")
async def update_organization_user(
    identity_id: uuid.UUID,
    payload: FieldAgentUpdate,
    admin: OrganizationAdmin = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    identity = await _load_agent_in_org(db, admin, identity_id)

    if payload.display_name is not None:
        identity.display_name = payload.display_name.strip()

    if payload.status is not None:
        requested = payload.status
        current = identity.status

        if requested == current:
            pass
        elif requested == "revoked":
            await _revoke_identity_access(db, identity, admin)
        elif requested == "suspended":
            if current == "revoked":
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail={
                        "code": "ACCOUNT_REVOKED",
                        "message": "A revoked account cannot be suspended again",
                    },
                )
            identity.status = "suspended"
        elif requested == "active":
            if current not in {"suspended"}:
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail={
                        "code": "ACTIVATION_REQUIRED",
                        "message": "Pending accounts must be activated by the field agent; revoked accounts cannot be reactivated",
                    },
                )
            identity.status = "active"
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "code": "INVALID_STATUS",
                    "message": "Unsupported account status",
                },
            )

    await db.commit()
    await db.refresh(identity)

    devices = (
        await db.execute(
            select(Device).where(Device.identity_id == identity.identity_id)
        )
    ).scalars().all()

    return {
        "success": True,
        "data": _identity_data(identity, devices),
        "error": None,
    }


@router.post("/users/{identity_id}/credentials")
async def issue_activation_credential(
    identity_id: uuid.UUID,
    admin: OrganizationAdmin = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    identity = await _load_agent_in_org(db, admin, identity_id)

    if identity.status != "pending":
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "code": "ACCOUNT_NOT_PENDING",
                "message": "Activation credentials can only be issued for pending accounts",
            },
        )

    now = datetime.now(timezone.utc)

    previous = (
        await db.execute(
            select(UserCredential).where(
                UserCredential.identity_id == identity.identity_id,
                UserCredential.consumed_at.is_(None),
                UserCredential.revoked_at.is_(None),
            )
        )
    ).scalars().all()
    for credential in previous:
        credential.revoked_at = now

    code = generate_activation_code()
    credential = UserCredential(
        identity_id=identity.identity_id,
        credential_hash=hash_activation_code(code),
        expires_at=now + timedelta(hours=settings.activation_credential_expiry_hours),
        created_by_admin_id=admin.admin_id,
    )
    db.add(credential)
    await db.commit()
    await db.refresh(credential)

    return {
        "success": True,
        "data": {
            "credential_id": str(credential.credential_id),
            "identity_id": str(identity.identity_id),
            "display_name": identity.display_name,
            "activation_code": code,
            "expires_at": credential.expires_at.isoformat(),
        },
        "error": None,
    }


@router.post("/users/{identity_id}/revoke")
async def revoke_organization_user(
    identity_id: uuid.UUID,
    admin: OrganizationAdmin = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    identity = await _load_agent_in_org(db, admin, identity_id)
    await _revoke_identity_access(db, identity, admin)
    await db.commit()
    await db.refresh(identity)

    return {
        "success": True,
        "data": {
            "identity_id": str(identity.identity_id),
            "status": identity.status,
        },
        "error": None,
    }
