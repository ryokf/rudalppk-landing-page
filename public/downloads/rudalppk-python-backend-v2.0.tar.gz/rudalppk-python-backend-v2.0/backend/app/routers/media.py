import uuid
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import get_db
from app.core.dependencies import get_current_device
from app.models.device import Device
from app.models.media import MediaObject
from app.schemas.media import MediaUploadRequest, MediaCompleteRequest

router = APIRouter(
    prefix="/api/v1/media",
    tags=["Encrypted Media"]
)


@router.post("/upload-url")
async def request_media_upload_url(
    payload: MediaUploadRequest,
    current_device: Device = Depends(get_current_device),
    db: AsyncSession = Depends(get_db)
):
    """
    Request authorization to upload encrypted media (e.g. encrypted Opus voice note).
    Returns object storage reference and upload URL for SeaweedFS S3.
    """
    media_id = uuid.uuid4()
    storage_ref = f"{settings.s3_bucket_name}/encrypted-media/{current_device.identity_id}/{media_id}.bin"

    # Pre-register media object in DB
    media = MediaObject(
        media_id=media_id,
        storage_reference=storage_ref,
        content_type=payload.content_type,
        file_size=payload.file_size
    )
    db.add(media)
    await db.commit()

    # Upload URL pointing to SeaweedFS S3 API endpoint
    upload_url = f"{settings.s3_public_url}/{storage_ref}"

    return {
        "success": True,
        "data": {
            "media_id": str(media_id),
            "storage_reference": storage_ref,
            "upload_url": upload_url,
            "content_type": payload.content_type,
            "expires_in": 300
        },
        "error": None
    }


@router.post("/complete")
async def complete_media_upload(
    payload: MediaCompleteRequest,
    current_device: Device = Depends(get_current_device),
    db: AsyncSession = Depends(get_db)
):
    """Confirm media upload completion and optionally link to an encrypted message."""
    stmt = select(MediaObject).where(MediaObject.media_id == payload.media_id)
    media = (await db.execute(stmt)).scalar_one_or_none()

    if not media:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"code": "MEDIA_NOT_FOUND", "message": "Media object not found"}
        )

    if payload.message_id:
        media.message_id = payload.message_id
        await db.commit()

    return {
        "success": True,
        "data": {
            "media_id": str(media.media_id),
            "status": "ready",
            "storage_reference": media.storage_reference
        },
        "error": None
    }


@router.get("/{media_id}/download-url")
async def request_media_download_url(
    media_id: uuid.UUID,
    current_device: Device = Depends(get_current_device),
    db: AsyncSession = Depends(get_db)
):
    """Request authorization to download ciphertext of encrypted media."""
    stmt = select(MediaObject).where(MediaObject.media_id == media_id)
    media = (await db.execute(stmt)).scalar_one_or_none()

    if not media:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"code": "MEDIA_NOT_FOUND", "message": "Media object not found"}
        )

    download_url = f"{settings.s3_public_url}/{media.storage_reference}"

    return {
        "success": True,
        "data": {
            "media_id": str(media.media_id),
            "download_url": download_url,
            "storage_reference": media.storage_reference,
            "content_type": media.content_type,
            "file_size": media.file_size,
            "expires_in": 300
        },
        "error": None
    }
