import base64
import hashlib
import json
import os
import uuid
from datetime import datetime, timezone

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import get_db
from app.core.dependencies import Principal, get_principal
from app.core.pqc_backend import (
    ML_DSA_SPECS,
    ML_KEM_SPECS,
    PqcOperationUnsupported,
    ml_dsa_keygen,
    ml_dsa_sign,
    ml_dsa_verify,
    ml_kem_decapsulate,
    ml_kem_encapsulate,
    ml_kem_keygen,
)
from app.models.conversation import Conversation, ConversationMember
from app.models.device import Device
from app.models.identity import Identity
from app.models.organization import OrganizationAdmin
from app.models.pqc_artifact import PqcAuditLog, SignedArtifact

router = APIRouter(
    prefix="/api/v1/perisai/sign",
    tags=["PERISAI-Sign (ML-DSA & ML-KEM File Protection)"],
)


class SignArtifactCreate(BaseModel):
    artifact_type: str = Field(
        default="command_instruction",
        pattern=r"^(command_instruction|firmware_package|field_report)$",
    )
    title: str = Field(..., min_length=1, max_length=200)
    content_text: str = Field(default="", max_length=200000)
    algorithm: str = Field(
        default="ML-DSA-65",
        pattern=r"^ML-DSA-(44|65|87)$",
    )
    kem_algorithm: str | None = Field(
        default="ML-KEM-768",
        pattern=r"^ML-KEM-(512|768|1024)$",
    )
    # Recipient Targeting & Per-Agent ML-KEM Binding
    recipient_scope: str = Field(
        default="all",
        pattern=r"^(all|agent|group)$",
    )
    recipient_identity_id: uuid.UUID | None = None
    recipient_group_id: uuid.UUID | None = None
    recipient_display_name: str | None = Field(default=None, max_length=160)
    encrypt_for_recipient: bool = Field(default=True)
    # Optional fields for Command Instruction
    classification: str | None = Field(default="RAHASIA", max_length=40)
    target_unit: str | None = Field(default="Semua Unit Lapangan", max_length=120)
    # Optional fields for Firmware Package / Encrypted File
    device_model: str | None = Field(default=None, max_length=120)
    firmware_version: str | None = Field(default=None, max_length=60)
    file_name: str | None = Field(default=None, max_length=255)
    file_mime: str | None = Field(default=None, max_length=120)
    file_data_b64: str | None = None
    encrypt_with_kem: bool = Field(default=False)
    content_hash_sha256: str | None = Field(default=None, max_length=128)
    signature_b64: str | None = None
    signer_public_key_b64: str | None = None
    metadata_json: str | None = None


class VerifyArtifactRequest(BaseModel):
    artifact_id: uuid.UUID | None = None
    algorithm: str | None = Field(
        default=None,
        pattern=r"^ML-DSA-(44|65|87)$",
    )
    # Required for detached (artifact_id-less) verification: the signature is
    # computed over these values, so they must be supplied to rebuild the
    # canonical message exactly.
    artifact_type: str | None = Field(
        default=None,
        pattern=r"^(command_instruction|firmware_package|field_report)$",
    )
    title: str | None = Field(default=None, max_length=200)
    content_text: str | None = None
    content_hash_sha256: str | None = None
    file_data_b64: str | None = None
    signature_b64: str | None = None
    signer_public_key_b64: str | None = None


class DecryptArtifactRequest(BaseModel):
    kem_secret_key_b64: str = Field(..., min_length=16)


class DecryptAgentArtifactRequest(BaseModel):
    kem_secret_key_b64: str | None = None


def _derive_admin_dsa_keypair(admin_id: uuid.UUID, algorithm: str) -> dict:
    seed = hashlib.sha256(
        f"PERISAI-ADMIN-DSA|{settings.jwt_secret_key}|{admin_id}|{algorithm}".encode(
            "utf-8"
        )
    ).digest()
    return ml_dsa_keygen(algorithm, seed=seed)


def _derive_agent_kem_keypair(
    identity: Identity,
    device: Device | None,
    kem_alg: str,
) -> tuple[dict, str]:
    """Derive deterministic ML-KEM keypair for an agent's active device (or fallback identity)."""
    if device is not None and device.public_device_key:
        seed = hashlib.sha256(
            f"PERISAI-ACTIVATE-KEM|{device.public_device_key}|{kem_alg}".encode("utf-8")
        ).digest()
        return ml_kem_keygen(kem_alg, seed=seed), "device"
    seed = hashlib.sha256(
        f"PERISAI-IDENTITY-KEM|{identity.identity_id}|{kem_alg}".encode("utf-8")
    ).digest()
    return ml_kem_keygen(kem_alg, seed=seed), "identity"


def _extract_raw_payload_bytes(
    payload: SignArtifactCreate,
    default_file_name: str,
    require_non_empty_text: bool = True,
) -> tuple[bytes, str, str, bool]:
    """Extract raw bytes, filename, MIME type, and whether payload is a text command."""
    is_text_cmd = not bool(payload.file_data_b64)
    if payload.file_data_b64:
        try:
            raw_bytes = base64.b64decode(payload.file_data_b64)
        except Exception:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "code": "INVALID_FILE_BASE64",
                    "message": "File data Base64 tidak valid",
                },
            )
        return (
            raw_bytes,
            payload.file_name or default_file_name,
            payload.file_mime or "application/octet-stream",
            is_text_cmd,
        )

    if require_non_empty_text and not payload.content_text.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "EMPTY_CONTENT",
                "message": "Isi instruksi atau konten tidak boleh kosong",
            },
        )
    return (
        payload.content_text.encode("utf-8"),
        payload.file_name or default_file_name,
        payload.file_mime or "text/plain",
        is_text_cmd,
    )


def _kem_unwrap_aes_key(
    kem_ciphertext_b64: str,
    kem_secret_key_b64: str,
    kem_alg: str,
    wrap_nonce_b64: str,
    wrapped_aes_key_b64: str,
    aad: bytes,
) -> bytes:
    """Decapsulate ML-KEM secret and unwrap a 256-bit group AES key."""
    shared_secret_raw = ml_kem_decapsulate(
        kem_ciphertext_b64, kem_secret_key_b64, kem_alg
    )
    shared_secret_bytes = (
        base64.b64decode(shared_secret_raw)
        if isinstance(shared_secret_raw, str)
        else shared_secret_raw
    )
    wrap_key = hashlib.sha256(
        b"PERISAI-GROUP-WRAP|" + shared_secret_bytes
    ).digest()
    return AESGCM(wrap_key).decrypt(
        base64.b64decode(wrap_nonce_b64),
        base64.b64decode(wrapped_aes_key_b64),
        aad,
    )


def _kem_decrypt_payload(
    meta: dict,
    title_clean: str,
    kem_alg: str,
    dsa_alg: str,
    kem_secret_key_b64: str,
    target_envelope: dict | None = None,
) -> bytes:
    """Decapsulate ML-KEM secret (single-key or group-envelope) and decrypt AES-256-GCM payload."""
    aad = f"PERISAI-KEM-FILE|{title_clean}|{kem_alg}|{dsa_alg}".encode("utf-8")
    if target_envelope is not None:
        aes_key = _kem_unwrap_aes_key(
            target_envelope["kem_ciphertext_b64"],
            kem_secret_key_b64,
            kem_alg,
            target_envelope["wrap_nonce_b64"],
            target_envelope["wrapped_aes_key_b64"],
            aad,
        )
    else:
        shared_secret_raw = ml_kem_decapsulate(
            meta["kem_ciphertext_b64"],
            kem_secret_key_b64,
            kem_alg,
        )
        shared_secret_bytes = (
            base64.b64decode(shared_secret_raw)
            if isinstance(shared_secret_raw, str)
            else shared_secret_raw
        )
        aes_key = hashlib.sha256(
            b"PERISAI-FILE-AES256|" + shared_secret_bytes
        ).digest()
    nonce = base64.b64decode(meta["aes_nonce_b64"])
    ciphertext_bytes = base64.b64decode(meta["aes_ciphertext_b64"])
    return AESGCM(aes_key).decrypt(nonce, ciphertext_bytes, aad)


def _artifact_dict(item: SignedArtifact, include_KeyBundle: dict | None = None) -> dict:
    spec = ML_DSA_SPECS.get(item.algorithm, ML_DSA_SPECS["ML-DSA-65"])
    meta_summary = {}
    if item.metadata_json:
        try:
            raw_meta = json.loads(item.metadata_json)
            if isinstance(raw_meta, dict):
                # Exclude heavy base64 blobs from list summary
                meta_summary = {
                    k: v
                    for k, v in raw_meta.items()
                    if k
                    not in (
                        "file_data_b64",
                        "aes_ciphertext_b64",
                        "recipient_envelopes",
                    )
                }
                if isinstance(raw_meta.get("recipient_envelopes"), dict):
                    meta_summary["recipient_envelope_ids"] = list(
                        raw_meta["recipient_envelopes"].keys()
                    )
                meta_summary["has_binary_payload"] = bool(
                    raw_meta.get("file_data_b64") or raw_meta.get("aes_ciphertext_b64")
                )
        except Exception:
            meta_summary = {}

    res = {
        "artifact_id": str(item.artifact_id),
        "organization_id": str(item.organization_id) if item.organization_id else None,
        "artifact_type": item.artifact_type,
        "title": item.title,
        "content_text": item.content_text,
        "content_hash_sha256": item.content_hash_sha256,
        "algorithm": item.algorithm,
        "nist_standard": spec["standard"],
        "security_category": spec["nist_category"],
        "signature_b64": item.signature_b64,
        "signer_type": item.signer_type,
        "signer_id": str(item.signer_id),
        "signer_display_name": item.signer_display_name,
        "signer_public_key_b64": item.signer_public_key_b64,
        "metadata_json": item.metadata_json,
        "meta": meta_summary,
        "status": item.status,
        "created_at": item.created_at.isoformat(),
        "revoked_at": item.revoked_at.isoformat() if item.revoked_at else None,
    }
    if include_KeyBundle is not None:
        res["decryption_key_bundle"] = include_KeyBundle
    return res


def _audit_dict(log: PqcAuditLog) -> dict:
    return {
        "log_id": str(log.log_id),
        "organization_id": str(log.organization_id) if log.organization_id else None,
        "event_type": log.event_type,
        "algorithm": log.algorithm,
        "status": log.status,
        "actor_name": log.actor_name,
        "target_id": log.target_id,
        "details_json": log.details_json,
        "created_at": log.created_at.isoformat(),
    }


def _actor_label(principal: Principal) -> str:
    if principal.is_admin and principal.admin:
        return f"Admin: {principal.admin.display_name} ({principal.admin.email})"
    if principal.is_device and principal.identity:
        name = principal.identity.display_name or principal.identity.identity_fingerprint
        dev_name = principal.device.device_name if principal.device else "Device"
        return f"Agent: {name} [{dev_name}]"
    return "Unknown Actor"


@router.get("/artifacts")
async def list_signed_artifacts(
    artifact_type: str | None = None,
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    """List signed command instructions, firmware packages, and field reports."""
    stmt = select(SignedArtifact).where(
        SignedArtifact.organization_id == principal.organization_id
    )
    if artifact_type:
        stmt = stmt.where(SignedArtifact.artifact_type == artifact_type)
    stmt = stmt.order_by(SignedArtifact.created_at.desc()).limit(100)
    rows = (await db.execute(stmt)).scalars().all()

    return {
        "success": True,
        "data": [_artifact_dict(row) for row in rows],
        "error": None,
    }


@router.post("/artifacts")
async def create_signed_artifact(
    payload: SignArtifactCreate,
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    """Sign and publish an artifact (Command Text, OT/IoT Firmware Binary, or ML-KEM Encrypted Document)."""
    if principal.organization_id is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "ORGANIZATION_REQUIRED",
                "message": "Organization context is required for PERISAI-Sign",
            },
        )

    title_clean = payload.title.strip()
    meta_dict: dict = {}
    if payload.metadata_json:
        try:
            meta_dict = json.loads(payload.metadata_json)
        except Exception:
            meta_dict = {}

    decryption_key_bundle: dict | None = None
    content_text_to_store = payload.content_text

    # Resolve target recipient (Broadcast vs Specific Agent vs Specific Group)
    recipient_scope = payload.recipient_scope or "all"
    recipient_identity: Identity | None = None
    recipient_device: Device | None = None
    recipient_group: Conversation | None = None
    recipient_label = (
        payload.recipient_display_name
        or payload.target_unit
        or "Semua Unit Lapangan (Broadcast)"
    )

    if recipient_scope == "agent" and payload.recipient_identity_id is not None:
        recipient_identity = (
            await db.execute(
                select(Identity).where(
                    Identity.identity_id == payload.recipient_identity_id,
                    Identity.organization_id == principal.organization_id,
                )
            )
        ).scalar_one_or_none()
        if not recipient_identity:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={
                    "code": "RECIPIENT_AGENT_NOT_FOUND",
                    "message": "Agen penerima tidak ditemukan di organisasi ini",
                },
            )
        recipient_device = (
            await db.execute(
                select(Device)
                .where(
                    Device.identity_id == recipient_identity.identity_id,
                    Device.status == "active",
                )
                .order_by(Device.registered_at.desc())
            )
        ).scalars().first()
        recipient_label = recipient_identity.display_name or "Agen Lapangan"
    elif recipient_scope == "group" and payload.recipient_group_id is not None:
        recipient_group = (
            await db.execute(
                select(Conversation).where(
                    Conversation.conversation_id == payload.recipient_group_id,
                    Conversation.organization_id == principal.organization_id,
                )
            )
        ).scalar_one_or_none()
        if not recipient_group:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={
                    "code": "RECIPIENT_GROUP_NOT_FOUND",
                    "message": "Grup penerima tidak ditemukan di organisasi ini",
                },
            )
        if recipient_group.title:
            recipient_label = recipient_group.title

    meta_dict.update(
        {
            "recipient_scope": recipient_scope,
            "recipient_identity_id": (
                str(recipient_identity.identity_id) if recipient_identity else None
            ),
            "recipient_device_id": (
                str(recipient_device.device_id) if recipient_device else None
            ),
            "recipient_group_id": (
                str(payload.recipient_group_id) if payload.recipient_group_id else None
            ),
            "recipient_display_name": recipient_label,
        }
    )

    # -------------------------------------------------------------------------
    # GROUP-BOUND MULTI-RECIPIENT ML-KEM ENCRYPTION
    # -------------------------------------------------------------------------
    if (
        recipient_scope == "group"
        and recipient_group is not None
        and (payload.encrypt_for_recipient or payload.encrypt_with_kem)
        and payload.artifact_type in ("command_instruction", "field_report")
    ):
        kem_alg = payload.kem_algorithm or "ML-KEM-768"
        if kem_alg not in ML_KEM_SPECS:
            kem_alg = "ML-KEM-768"

        member_rows = (
            await db.execute(
                select(Identity)
                .join(
                    ConversationMember,
                    ConversationMember.identity_id == Identity.identity_id,
                )
                .where(
                    ConversationMember.conversation_id == recipient_group.conversation_id,
                    ConversationMember.left_at.is_(None),
                )
            )
        ).scalars().all()
        if not member_rows:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "code": "GROUP_HAS_NO_MEMBERS",
                    "message": (
                        f"Grup '{recipient_label}' belum memiliki anggota agen. "
                        "Tambahkan minimal 1 anggota di menu Grup terlebih dahulu, atau pilih Broadcast / Spesifik Agen."
                    ),
                },
            )

        raw_bytes, file_name, file_mime, is_text_cmd = _extract_raw_payload_bytes(
            payload,
            f"komando-grup-{recipient_label}.txt" if not payload.file_data_b64 else "dokumen-grup.bin",
            require_non_empty_text=True,
        )
        plaintext_sha256 = hashlib.sha256(raw_bytes).hexdigest().lower()

        aes_key = os.urandom(32)
        nonce = os.urandom(12)
        aad = f"PERISAI-KEM-FILE|{title_clean}|{kem_alg}|{payload.algorithm}".encode("utf-8")
        ciphertext_bytes = AESGCM(aes_key).encrypt(nonce, raw_bytes, aad)
        ciphertext_b64 = base64.b64encode(ciphertext_bytes).decode("ascii")
        content_hash = hashlib.sha256(ciphertext_bytes).hexdigest().lower()

        recipient_envelopes: dict = {}
        for m_ident in member_rows:
            m_dev = (
                await db.execute(
                    select(Device)
                    .where(
                        Device.identity_id == m_ident.identity_id,
                        Device.status == "active",
                    )
                    .order_by(Device.registered_at.desc())
                )
            ).scalars().first()
            m_kp, m_src = _derive_agent_kem_keypair(m_ident, m_dev, kem_alg)
            if m_dev is not None and not m_dev.pqc_kem_public_key:
                m_dev.pqc_kem_alg = kem_alg
                m_dev.pqc_kem_public_key = m_kp["public_key"]

            m_encap = ml_kem_encapsulate(m_kp["public_key"], kem_alg)
            wrap_key = hashlib.sha256(
                b"PERISAI-GROUP-WRAP|" + base64.b64decode(m_encap["shared_secret"])
            ).digest()
            wrap_nonce = os.urandom(12)
            wrapped_aes = AESGCM(wrap_key).encrypt(wrap_nonce, aes_key, aad)
            recipient_envelopes[str(m_ident.identity_id)] = {
                "display_name": m_ident.display_name or "Agen",
                "kem_key_source": m_src,
                "kem_ciphertext_b64": m_encap["ciphertext"],
                "wrap_nonce_b64": base64.b64encode(wrap_nonce).decode("ascii"),
                "wrapped_aes_key_b64": base64.b64encode(wrapped_aes).decode("ascii"),
            }

        if is_text_cmd:
            content_text_to_store = (
                f"🔒 [TERENKRIPSI KHUSUS GRUP: {recipient_label} ({len(member_rows)} Anggota) • {kem_alg} + AES-256-GCM] "
                f"Perintah dienkripsi dengan AES-256-GCM dan dibungkus menggunakan Public Key {kem_alg} masing-masing anggota grup '{recipient_label}'."
            )
            mode_label = "group_encrypted_command"
        else:
            content_text_to_store = (
                f"🔒 [FILE RAHASIA KHUSUS GRUP: {recipient_label} ({len(member_rows)} Anggota) • {kem_alg} + AES-256-GCM] "
                f"File: {file_name} ({len(raw_bytes)} bytes)"
            )
            mode_label = "pqc_encrypted_file"

        meta_dict.update(
            {
                "mode": mode_label,
                "is_text_command": is_text_cmd,
                "bound_to_agent_kem": True,
                "bound_to_group_kem": True,
                "encrypted_with_kem": True,
                "kem_algorithm": kem_alg,
                "recipient_envelopes": recipient_envelopes,
                "recipient_envelope_ids": list(recipient_envelopes.keys()),
                "aes_nonce_b64": base64.b64encode(nonce).decode("ascii"),
                "aes_ciphertext_b64": ciphertext_b64,
                "file_name": file_name,
                "file_mime": file_mime,
                "file_size": len(raw_bytes),
                "plaintext_sha256": plaintext_sha256,
                "classification": payload.classification or "SANGAT RAHASIA",
                "target_unit": f"Grup Khusus: {recipient_label}",
                "notes": "" if is_text_cmd else (payload.content_text or ""),
            }
        )

    # -------------------------------------------------------------------------
    # AGENT-BOUND ML-KEM ENCRYPTION (Command Text or File locked to Specific Agent)
    # -------------------------------------------------------------------------
    elif (
        recipient_scope == "agent"
        and recipient_identity is not None
        and (payload.encrypt_for_recipient or payload.encrypt_with_kem)
        and payload.artifact_type in ("command_instruction", "field_report")
    ):
        kem_alg = payload.kem_algorithm or (
            recipient_device.pqc_kem_alg
            if (recipient_device and recipient_device.pqc_kem_alg in ML_KEM_SPECS)
            else "ML-KEM-768"
        )
        if kem_alg not in ML_KEM_SPECS:
            kem_alg = "ML-KEM-768"

        raw_bytes, file_name, file_mime, is_text_cmd = _extract_raw_payload_bytes(
            payload,
            f"komando-{recipient_label}.txt" if not payload.file_data_b64 else "dokumen-agen.bin",
            require_non_empty_text=True,
        )
        plaintext_sha256 = hashlib.sha256(raw_bytes).hexdigest().lower()

        # Derive / load target agent's ML-KEM keypair
        kem_kp, kem_source = _derive_agent_kem_keypair(
            recipient_identity, recipient_device, kem_alg
        )
        if recipient_device is not None and not recipient_device.pqc_kem_public_key:
            recipient_device.pqc_kem_alg = kem_alg
            recipient_device.pqc_kem_public_key = kem_kp["public_key"]

        # Encapsulate shared secret using target agent's ML-KEM Public Key
        encap = ml_kem_encapsulate(kem_kp["public_key"], kem_alg)
        shared_secret_bytes = base64.b64decode(encap["shared_secret"])
        aes_key = hashlib.sha256(
            b"PERISAI-FILE-AES256|" + shared_secret_bytes
        ).digest()
        nonce = os.urandom(12)
        aad = f"PERISAI-KEM-FILE|{title_clean}|{kem_alg}|{payload.algorithm}".encode(
            "utf-8"
        )
        ciphertext_bytes = AESGCM(aes_key).encrypt(nonce, raw_bytes, aad)
        ciphertext_b64 = base64.b64encode(ciphertext_bytes).decode("ascii")

        content_hash = hashlib.sha256(ciphertext_bytes).hexdigest().lower()
        if is_text_cmd:
            content_text_to_store = (
                f"🔒 [TERENKRIPSI KHUSUS AGEN: {recipient_label} • {kem_alg} + AES-256-GCM] "
                f"Instruksi komando dikunci secara kriptografis menggunakan Public Key {kem_alg} "
                f"milik {recipient_label}. Hanya perangkat {recipient_label} yang dapat mendekripsi isi perintah ini."
            )
            mode_label = "agent_encrypted_command"
        else:
            content_text_to_store = (
                f"🔒 [FILE RAHASIA KHUSUS AGEN: {recipient_label} • {kem_alg} + AES-256-GCM] "
                f"File: {file_name} ({len(raw_bytes)} bytes) • Dikunci khusus untuk perangkat {recipient_label}."
            )
            mode_label = "pqc_encrypted_file"

        meta_dict.update(
            {
                "mode": mode_label,
                "is_text_command": is_text_cmd,
                "bound_to_agent_kem": True,
                "kem_key_source": kem_source,
                "encrypted_with_kem": True,
                "kem_algorithm": kem_alg,
                "kem_public_key_b64": kem_kp["public_key"],
                "kem_ciphertext_b64": encap["ciphertext"],
                "aes_nonce_b64": base64.b64encode(nonce).decode("ascii"),
                "aes_ciphertext_b64": ciphertext_b64,
                "file_name": file_name,
                "file_mime": file_mime,
                "file_size": len(raw_bytes),
                "plaintext_sha256": plaintext_sha256,
                "classification": payload.classification or "SANGAT RAHASIA",
                "target_unit": f"Agen Khusus: {recipient_label}",
                "notes": "" if is_text_cmd else (payload.content_text or ""),
            }
        )

        decryption_key_bundle = {
            "file_name": file_name,
            "recipient_display_name": recipient_label,
            "recipient_identity_id": str(recipient_identity.identity_id),
            "bound_to_agent_kem": True,
            "kem_algorithm": kem_alg,
            "dsa_algorithm": payload.algorithm,
            "kem_secret_key_b64": kem_kp["secret_key"],
            "kem_public_key_b64": kem_kp["public_key"],
            "plaintext_sha256": plaintext_sha256,
            "ciphertext_sha256": content_hash,
        }

    # -------------------------------------------------------------------------
    # MODE 3: Encrypted File/Document (ML-KEM-512/768/1024 + AES-256-GCM + ML-DSA-44/65/87)
    # -------------------------------------------------------------------------
    elif payload.encrypt_with_kem or (
        payload.artifact_type == "field_report" and payload.file_data_b64
    ):
        kem_alg = payload.kem_algorithm or "ML-KEM-768"
        if kem_alg not in ML_KEM_SPECS:
            kem_alg = "ML-KEM-768"

        raw_bytes, file_name, file_mime, _ = _extract_raw_payload_bytes(
            payload,
            "dokumen-rahasia.bin" if payload.file_data_b64 else "laporan-intelijen.txt",
            require_non_empty_text=False,
        )

        plaintext_sha256 = hashlib.sha256(raw_bytes).hexdigest().lower()

        # 1. Generate ML-KEM keypair for this encrypted file
        kem_kp = ml_kem_keygen(kem_alg)
        # 2. Encapsulate shared secret using ML-KEM Public Key
        encap = ml_kem_encapsulate(kem_kp["public_key"], kem_alg)
        shared_secret_bytes = base64.b64decode(encap["shared_secret"])
        # 3. Derive 256-bit AES key from ML-KEM shared secret
        aes_key = hashlib.sha256(
            b"PERISAI-FILE-AES256|" + shared_secret_bytes
        ).digest()
        nonce = os.urandom(12)
        aad = f"PERISAI-KEM-FILE|{title_clean}|{kem_alg}|{payload.algorithm}".encode(
            "utf-8"
        )
        ciphertext_bytes = AESGCM(aes_key).encrypt(nonce, raw_bytes, aad)
        ciphertext_b64 = base64.b64encode(ciphertext_bytes).decode("ascii")

        # 4. Compute SHA-256 over the encrypted ciphertext (to sign with ML-DSA)
        content_hash = hashlib.sha256(ciphertext_bytes).hexdigest().lower()
        content_text_to_store = (
            f"🔒 [TERENKRIPSI {kem_alg} + AES-256-GCM] File: {file_name} "
            f"({len(raw_bytes)} bytes) • Catatan: {payload.content_text or '-'}"
        )

        meta_dict.update(
            {
                "mode": "pqc_encrypted_file",
                "encrypted_with_kem": True,
                "kem_algorithm": kem_alg,
                "kem_public_key_b64": kem_kp["public_key"],
                "kem_ciphertext_b64": encap["ciphertext"],
                "aes_nonce_b64": base64.b64encode(nonce).decode("ascii"),
                "aes_ciphertext_b64": ciphertext_b64,
                "file_name": file_name,
                "file_mime": file_mime,
                "file_size": len(raw_bytes),
                "plaintext_sha256": plaintext_sha256,
                "notes": payload.content_text or "",
            }
        )

        decryption_key_bundle = {
            "file_name": file_name,
            "kem_algorithm": kem_alg,
            "dsa_algorithm": payload.algorithm,
            "kem_secret_key_b64": kem_kp["secret_key"],
            "kem_public_key_b64": kem_kp["public_key"],
            "plaintext_sha256": plaintext_sha256,
            "ciphertext_sha256": content_hash,
        }

    # -------------------------------------------------------------------------
    # MODE 2: OT / IoT Firmware Binary Package (Upload Binary File + ML-DSA Sign)
    # -------------------------------------------------------------------------
    elif payload.artifact_type == "firmware_package" and payload.file_data_b64:
        try:
            raw_bytes = base64.b64decode(payload.file_data_b64)
        except Exception:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "code": "INVALID_FILE_BASE64",
                    "message": "File firmware Base64 tidak valid",
                },
            )
        file_name = payload.file_name or "firmware-update.bin"
        file_mime = payload.file_mime or "application/octet-stream"
        dev_model = payload.device_model or "OT-DEVICE-GENERIC"
        fw_ver = payload.firmware_version or "v1.0.0"

        content_hash = hashlib.sha256(raw_bytes).hexdigest().lower()
        content_text_to_store = (
            f"📦 [FIRMWARE OT/IoT: {dev_model} • {fw_ver}] File: {file_name} "
            f"({len(raw_bytes)} bytes) • {payload.content_text or 'Release resmi'}"
        )
        meta_dict.update(
            {
                "mode": "firmware_binary",
                "encrypted_with_kem": False,
                "device_model": dev_model,
                "firmware_version": fw_ver,
                "file_name": file_name,
                "file_mime": file_mime,
                "file_size": len(raw_bytes),
                "file_data_b64": payload.file_data_b64,
                "release_notes": payload.content_text or "",
            }
        )

    # -------------------------------------------------------------------------
    # MODE 1: Command Instruction Text (or legacy text-only submission)
    # -------------------------------------------------------------------------
    else:
        if not payload.content_text.strip():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "code": "EMPTY_CONTENT",
                    "message": "Isi instruksi atau file tidak boleh kosong",
                },
            )
        computed_hash = hashlib.sha256(
            payload.content_text.encode("utf-8")
        ).hexdigest()
        content_hash = (payload.content_hash_sha256 or computed_hash).lower()
        if content_hash != computed_hash.lower():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "code": "CONTENT_HASH_MISMATCH",
                    "message": "Provided SHA-256 hash does not match content_text",
                },
            )
        meta_dict.update(
            {
                "mode": "command_text",
                "encrypted_with_kem": False,
                "classification": payload.classification or "RAHASIA",
                "target_unit": payload.target_unit or "Semua Unit Lapangan",
            }
        )

    canonical_msg = (
        f"PERISAI-SIGN-V1|{payload.artifact_type}|{title_clean}|{content_hash}".encode(
            "utf-8"
        )
    )

    if principal.is_admin and principal.admin is not None:
        signer_type = "admin"
        signer_id = principal.admin.admin_id
        signer_name = f"{principal.admin.display_name} (Command HQ)"
        if payload.signature_b64 and payload.signer_public_key_b64:
            pub_b64 = payload.signer_public_key_b64
            sig_b64 = payload.signature_b64
        else:
            kp = _derive_admin_dsa_keypair(principal.admin.admin_id, payload.algorithm)
            pub_b64 = kp["public_key"]
            sig_b64 = ml_dsa_sign(
                canonical_msg,
                kp["secret_key"],
                payload.algorithm,
            )
    elif principal.is_device and principal.identity is not None and principal.device is not None:
        signer_type = "device"
        signer_id = principal.device.device_id
        signer_name = (
            f"{principal.identity.display_name or 'Field Agent'} "
            f"({principal.device.device_name})"
        )
        if payload.signature_b64 and payload.signer_public_key_b64:
            pub_b64 = payload.signer_public_key_b64
            sig_b64 = payload.signature_b64
        else:
            seed = hashlib.sha256(
                f"PERISAI-DEVICE-DSA|{principal.device.device_id}|{payload.algorithm}".encode(
                    "utf-8"
                )
            ).digest()
            kp = ml_dsa_keygen(payload.algorithm, seed=seed)
            pub_b64 = kp["public_key"]
            sig_b64 = ml_dsa_sign(
                canonical_msg,
                kp["secret_key"],
                payload.algorithm,
            )
    else:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "UNAUTHORIZED_SIGNER",
                "message": "Only organization admins or active field devices can sign artifacts",
            },
        )

    # Verify ML-DSA signature before persisting
    is_valid = ml_dsa_verify(canonical_msg, sig_b64, pub_b64, payload.algorithm)
    if not is_valid:
        audit = PqcAuditLog(
            organization_id=principal.organization_id,
            event_type="ARTIFACT_SIGN_REJECTED",
            algorithm=payload.algorithm,
            status="INVALID_SIGNATURE",
            actor_name=_actor_label(principal),
            target_id=title_clean,
            details_json=f'{{"reason": "ML-DSA verification failed on publish", "hash": "{content_hash}"}}',
        )
        db.add(audit)
        await db.commit()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "INVALID_PQC_SIGNATURE",
                "message": f"{payload.algorithm} signature verification failed",
            },
        )

    artifact = SignedArtifact(
        organization_id=principal.organization_id,
        artifact_type=payload.artifact_type,
        title=title_clean,
        content_text=content_text_to_store,
        content_hash_sha256=content_hash,
        algorithm=payload.algorithm,
        signature_b64=sig_b64,
        signer_type=signer_type,
        signer_id=signer_id,
        signer_display_name=signer_name,
        signer_public_key_b64=pub_b64,
        metadata_json=json.dumps(meta_dict),
        status="active",
    )
    db.add(artifact)
    await db.flush()

    if decryption_key_bundle is not None:
        decryption_key_bundle["artifact_id"] = str(artifact.artifact_id)
        decryption_key_bundle["title"] = artifact.title

    event_label = (
        "FILE_ENCRYPTED_AND_SIGNED"
        if meta_dict.get("encrypted_with_kem")
        else (
            "FIRMWARE_BINARY_SIGNED"
            if meta_dict.get("mode") == "firmware_binary"
            else "COMMAND_SIGNED"
        )
    )
    alg_label = (
        f"{meta_dict.get('kem_algorithm')} + {payload.algorithm}"
        if meta_dict.get("encrypted_with_kem")
        else payload.algorithm
    )

    audit = PqcAuditLog(
        organization_id=principal.organization_id,
        event_type=event_label,
        algorithm=alg_label,
        status="VALID",
        actor_name=_actor_label(principal),
        target_id=str(artifact.artifact_id),
        details_json=json.dumps(
            {
                "title": artifact.title,
                "type": artifact.artifact_type,
                "mode": meta_dict.get("mode"),
                "sha256": content_hash,
            }
        ),
    )
    db.add(audit)
    await db.commit()
    await db.refresh(artifact)

    return {
        "success": True,
        "data": _artifact_dict(artifact, include_KeyBundle=decryption_key_bundle),
        "error": None,
    }


@router.post("/verify")
async def verify_signed_artifact(
    payload: VerifyArtifactRequest,
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    """Verify an ML-DSA (44/65/87) signed artifact (text or uploaded binary file) and log audit trail."""
    artifact: SignedArtifact | None = None
    if payload.artifact_id is not None:
        artifact = (
            await db.execute(
                select(SignedArtifact).where(
                    SignedArtifact.artifact_id == payload.artifact_id,
                    SignedArtifact.organization_id == principal.organization_id,
                )
            )
        ).scalar_one_or_none()
        if not artifact:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={
                    "code": "ARTIFACT_NOT_FOUND",
                    "message": "Signed artifact not found in this organization",
                },
            )

    algorithm = payload.algorithm or (artifact.algorithm if artifact else "ML-DSA-65")
    # Detached verification must use the same title/type that were signed.
    title = artifact.title if artifact else (payload.title or "Ad-hoc Verification")
    artifact_type = (
        artifact.artifact_type if artifact else (payload.artifact_type or "command_instruction")
    )

    # Determine content hash to verify (supports uploaded binary file, tampered text, or stored hash)
    if payload.file_data_b64 is not None:
        try:
            uploaded_bytes = base64.b64decode(payload.file_data_b64)
        except Exception:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "code": "INVALID_FILE_BASE64",
                    "message": "File Base64 yang diunggah untuk verifikasi tidak valid",
                },
            )
        tested_hash = hashlib.sha256(uploaded_bytes).hexdigest().lower()
    elif payload.content_text is not None:
        tested_hash = (
            hashlib.sha256(payload.content_text.encode("utf-8")).hexdigest().lower()
        )
    elif payload.content_hash_sha256 is not None:
        tested_hash = payload.content_hash_sha256.lower()
    elif artifact is not None:
        tested_hash = artifact.content_hash_sha256.lower()
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "MISSING_CONTENT",
                "message": "Provide artifact_id, file_data_b64, or content_text to verify",
            },
        )

    pub_b64 = payload.signer_public_key_b64 or (
        artifact.signer_public_key_b64 if artifact else ""
    )
    sig_b64 = payload.signature_b64 or (artifact.signature_b64 if artifact else "")

    canonical_msg = (
        f"PERISAI-SIGN-V1|{artifact_type}|{title.strip()}|{tested_hash}".encode("utf-8")
    )

    # Check signer revocation status (SIG-006)
    signer_revoked = False
    revocation_reason = None
    if artifact is not None:
        if artifact.status == "revoked":
            signer_revoked = True
            revocation_reason = "Artifact certificate has been explicitly revoked"
        elif artifact.signer_type == "device":
            dev = (
                await db.execute(
                    select(Device).where(Device.device_id == artifact.signer_id)
                )
            ).scalar_one_or_none()
            if not dev or dev.status != "active":
                signer_revoked = True
                revocation_reason = "Signer device has been revoked or deactivated"
            else:
                ident = (
                    await db.execute(
                        select(Identity).where(Identity.identity_id == dev.identity_id)
                    )
                ).scalar_one_or_none()
                if not ident or ident.status != "active":
                    signer_revoked = True
                    revocation_reason = f"Signer identity is {ident.status if ident else 'missing'}"
        elif artifact.signer_type == "admin":
            adm = (
                await db.execute(
                    select(OrganizationAdmin).where(
                        OrganizationAdmin.admin_id == artifact.signer_id
                    )
                )
            ).scalar_one_or_none()
            if not adm or adm.status != "active":
                signer_revoked = True
                revocation_reason = "Signer administrator account is no longer active"

    hash_matches_original = (
        True
        if artifact is None
        else (tested_hash == artifact.content_hash_sha256.lower())
    )
    crypto_valid = ml_dsa_verify(canonical_msg, sig_b64, pub_b64, algorithm)

    overall_valid = crypto_valid and hash_matches_original and not signer_revoked
    if signer_revoked:
        verdict = "REVOKED_SIGNER"
        verdict_message = revocation_reason or "Signer or artifact is revoked"
    elif not hash_matches_original or not crypto_valid:
        verdict = "TAMPERED_OR_INVALID"
        verdict_message = (
            "PERINGATAN INTEGRITAS: Tanda tangan ML-DSA tidak cocok atau payload telah "
            "dimodifikasi (1-bit tamper detected). Instruksi wajib ditolak!"
        )
    else:
        verdict = "VALID"
        verdict_message = (
            f"Otentik & Utuh — Terverifikasi dengan {algorithm} (NIST FIPS 204)"
        )

    audit = PqcAuditLog(
        organization_id=principal.organization_id,
        event_type="SIGNATURE_VERIFY",
        algorithm=algorithm,
        status=verdict,
        actor_name=_actor_label(principal),
        target_id=str(artifact.artifact_id) if artifact else "ad-hoc",
        details_json=(
            f'{{"title": "{title}", "crypto_valid": {str(crypto_valid).lower()}, '
            f'"hash_matches": {str(hash_matches_original).lower()}, '
            f'"signer_revoked": {str(signer_revoked).lower()}}}'
        ),
    )
    db.add(audit)
    await db.commit()

    spec = ML_DSA_SPECS.get(algorithm, ML_DSA_SPECS["ML-DSA-65"])
    return {
        "success": True,
        "data": {
            "verified": overall_valid,
            "verdict": verdict,
            "message": verdict_message,
            "algorithm": algorithm,
            "nist_standard": spec["standard"],
            "security_category": spec["nist_category"],
            "crypto_signature_valid": crypto_valid,
            "content_hash_matches": hash_matches_original,
            "signer_revoked": signer_revoked,
            "tested_sha256": tested_hash,
            "expected_sha256": artifact.content_hash_sha256 if artifact else tested_hash,
            "signer_display_name": artifact.signer_display_name if artifact else "External",
            "verified_at": datetime.now(timezone.utc).isoformat(),
        },
        "error": None,
    }


@router.post("/artifacts/{artifact_id}/revoke")
async def revoke_signed_artifact(
    artifact_id: uuid.UUID,
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    """Revoke a signed artifact so future verifications reject it (SIG-006)."""
    artifact = (
        await db.execute(
            select(SignedArtifact).where(
                SignedArtifact.artifact_id == artifact_id,
                SignedArtifact.organization_id == principal.organization_id,
            )
        )
    ).scalar_one_or_none()

    if not artifact:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "ARTIFACT_NOT_FOUND",
                "message": "Signed artifact not found",
            },
        )

    is_owner_signer = (
        principal.is_device
        and principal.device is not None
        and artifact.signer_id == principal.device.device_id
    )
    if not principal.is_admin and not is_owner_signer:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "FORBIDDEN",
                "message": "Only an organization administrator or original signer can revoke this artifact",
            },
        )

    artifact.status = "revoked"
    artifact.revoked_at = datetime.now(timezone.utc)

    audit = PqcAuditLog(
        organization_id=principal.organization_id,
        event_type="ARTIFACT_REVOKED",
        algorithm=artifact.algorithm,
        status="REVOKED",
        actor_name=_actor_label(principal),
        target_id=str(artifact.artifact_id),
        details_json=f'{{"title": "{artifact.title}"}}',
    )
    db.add(audit)
    await db.commit()
    await db.refresh(artifact)

    return {
        "success": True,
        "data": _artifact_dict(artifact),
        "error": None,
    }


@router.post("/artifacts/{artifact_id}/decrypt")
async def decrypt_encrypted_artifact(
    artifact_id: uuid.UUID,
    payload: DecryptArtifactRequest,
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    """Decrypt an ML-KEM + AES-256-GCM encrypted artifact after verifying its ML-DSA signature."""
    artifact = (
        await db.execute(
            select(SignedArtifact).where(
                SignedArtifact.artifact_id == artifact_id,
                SignedArtifact.organization_id == principal.organization_id,
            )
        )
    ).scalar_one_or_none()

    if not artifact:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "ARTIFACT_NOT_FOUND",
                "message": "Artefak tidak ditemukan di organisasi ini",
            },
        )

    if artifact.status == "revoked":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "ARTIFACT_REVOKED",
                "message": "Sertifikat artefak ini telah dicabut (REVOKED) dan tidak boleh dibuka!",
            },
        )

    meta: dict = {}
    if artifact.metadata_json:
        try:
            meta = json.loads(artifact.metadata_json)
        except Exception:
            meta = {}

    if not meta.get("encrypted_with_kem") or not meta.get("aes_ciphertext_b64"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "NOT_ENCRYPTED_ARTIFACT",
                "message": "Artefak ini tidak dienkripsi dengan ML-KEM",
            },
        )

    if meta.get("bound_to_group_kem") and not meta.get("kem_ciphertext_b64"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "GROUP_ENVELOPE_USE_AGENT_DECRYPT",
                "message": "Artefak grup menggunakan amplop ML-KEM per-anggota; gunakan tombol Dekripsi Agen/Grup.",
            },
        )

    kem_alg = meta.get("kem_algorithm", "ML-KEM-768")
    dsa_alg = artifact.algorithm

    # 1. Verify ML-DSA signature over ciphertext hash first
    canonical_msg = (
        f"PERISAI-SIGN-V1|{artifact.artifact_type}|{artifact.title.strip()}|{artifact.content_hash_sha256.lower()}".encode(
            "utf-8"
        )
    )
    sig_ok = ml_dsa_verify(
        canonical_msg,
        artifact.signature_b64,
        artifact.signer_public_key_b64,
        dsa_alg,
    )
    if not sig_ok:
        audit = PqcAuditLog(
            organization_id=principal.organization_id,
            event_type="FILE_DECRYPT_REJECTED",
            algorithm=f"{kem_alg} + {dsa_alg}",
            status="TAMPERED_SIGNATURE",
            actor_name=_actor_label(principal),
            target_id=str(artifact.artifact_id),
            details_json='{"reason": "ML-DSA signature verification failed before decryption"}',
        )
        db.add(audit)
        await db.commit()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "SIGNATURE_INVALID",
                "message": f"Segel tanda tangan {dsa_alg} tidak valid! File ditolak.",
            },
        )

    # 2. Decapsulate ML-KEM ciphertext using the user-supplied ML-KEM Secret Key
    try:
        plaintext_bytes = _kem_decrypt_payload(
            meta,
            artifact.title.strip(),
            kem_alg,
            dsa_alg,
            payload.kem_secret_key_b64.strip(),
        )
    except (InvalidTag, ValueError, Exception):
        audit = PqcAuditLog(
            organization_id=principal.organization_id,
            event_type="FILE_DECRYPT_REJECTED",
            algorithm=f"{kem_alg} + {dsa_alg}",
            status="INVALID_KEM_KEY",
            actor_name=_actor_label(principal),
            target_id=str(artifact.artifact_id),
            details_json=f'{{"title": "{artifact.title}", "reason": "Wrong ML-KEM secret key"}}',
        )
        db.add(audit)
        await db.commit()
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "INVALID_DECRYPTION_KEY",
                "message": (
                    f"DEKRIPSI GAGAL: Kunci Privat {kem_alg} tidak cocok! "
                    "Hanya pemegang kunci ML-KEM yang sah yang dapat membuka file ini."
                ),
            },
        )

    audit = PqcAuditLog(
        organization_id=principal.organization_id,
        event_type="FILE_DECRYPTED",
        algorithm=f"{kem_alg} + {dsa_alg}",
        status="VALID",
        actor_name=_actor_label(principal),
        target_id=str(artifact.artifact_id),
        details_json=json.dumps(
            {
                "title": artifact.title,
                "file_name": meta.get("file_name"),
                "plaintext_sha256": meta.get("plaintext_sha256"),
            }
        ),
    )
    db.add(audit)
    await db.commit()

    decrypted_text_preview = None
    if meta.get("is_text_command") or (meta.get("file_mime") or "").startswith("text/"):
        try:
            decrypted_text_preview = plaintext_bytes.decode("utf-8")
        except Exception:
            decrypted_text_preview = None

    return {
        "success": True,
        "data": {
            "artifact_id": str(artifact.artifact_id),
            "title": artifact.title,
            "file_name": meta.get("file_name", "decrypted-file.bin"),
            "file_mime": meta.get("file_mime", "application/octet-stream"),
            "file_size": len(plaintext_bytes),
            "file_data_b64": base64.b64encode(plaintext_bytes).decode("ascii"),
            "decrypted_text": decrypted_text_preview,
            "is_text_command": bool(meta.get("is_text_command")),
            "kem_algorithm": kem_alg,
            "dsa_algorithm": dsa_alg,
            "plaintext_sha256": hashlib.sha256(plaintext_bytes).hexdigest().lower(),
            "message": f"File/komando berhasil didekripsi dengan {kem_alg} dan terverifikasi {dsa_alg}.",
        },
        "error": None,
    }


@router.post("/artifacts/{artifact_id}/decrypt-agent")
async def decrypt_agent_bound_artifact(
    artifact_id: uuid.UUID,
    payload: DecryptAgentArtifactRequest,
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    """Decrypt a command or file bound to a specific agent's ML-KEM keypair using the authenticated agent's device key."""
    artifact = (
        await db.execute(
            select(SignedArtifact).where(
                SignedArtifact.artifact_id == artifact_id,
                SignedArtifact.organization_id == principal.organization_id,
            )
        )
    ).scalar_one_or_none()

    if not artifact:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "ARTIFACT_NOT_FOUND",
                "message": "Artefak tidak ditemukan di organisasi ini",
            },
        )

    if artifact.status == "revoked":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "ARTIFACT_REVOKED",
                "message": "Sertifikat komando/artefak ini telah dicabut (REVOKED) dan ditolak!",
            },
        )

    meta: dict = {}
    if artifact.metadata_json:
        try:
            meta = json.loads(artifact.metadata_json)
        except Exception:
            meta = {}

    if not meta.get("encrypted_with_kem") or not meta.get("aes_ciphertext_b64"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "NOT_ENCRYPTED_ARTIFACT",
                "message": "Artefak ini tidak dienkripsi dengan ML-KEM",
            },
        )

    if meta.get("bound_to_group_kem") and not meta.get("kem_ciphertext_b64"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "GROUP_ENVELOPE_USE_AGENT_DECRYPT",
                "message": "Artefak grup menggunakan amplop ML-KEM per-anggota; gunakan tombol Dekripsi Agen/Grup.",
            },
        )

    kem_alg = meta.get("kem_algorithm", "ML-KEM-768")
    dsa_alg = artifact.algorithm
    recipient_id_str = meta.get("recipient_identity_id")
    recipient_name = meta.get("recipient_display_name") or "Agen Target"

    # 1. Verify ML-DSA signature over ciphertext hash first
    canonical_msg = (
        f"PERISAI-SIGN-V1|{artifact.artifact_type}|{artifact.title.strip()}|{artifact.content_hash_sha256.lower()}".encode(
            "utf-8"
        )
    )
    sig_ok = ml_dsa_verify(
        canonical_msg,
        artifact.signature_b64,
        artifact.signer_public_key_b64,
        dsa_alg,
    )
    if not sig_ok:
        audit = PqcAuditLog(
            organization_id=principal.organization_id,
            event_type="AGENT_KEM_DECRYPT_DENIED",
            algorithm=f"{kem_alg} + {dsa_alg}",
            status="TAMPERED_SIGNATURE",
            actor_name=_actor_label(principal),
            target_id=str(artifact.artifact_id),
            details_json='{"reason": "ML-DSA signature verification failed before agent decryption"}',
        )
        db.add(audit)
        await db.commit()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "SIGNATURE_INVALID",
                "message": f"Segel tanda tangan {dsa_alg} tidak valid! Komando ditolak.",
            },
        )

    # 2. Resolve single-agent vs group multi-recipient envelope & secret key
    aad = f"PERISAI-KEM-FILE|{artifact.title.strip()}|{kem_alg}|{dsa_alg}".encode(
        "utf-8"
    )
    envelopes = meta.get("recipient_envelopes")
    is_group_bound = bool(meta.get("bound_to_group_kem") and isinstance(envelopes, dict))
    is_unauthorized_agent = False

    target_envelope: dict | None = None
    envelope_identity_id: str | None = None

    if is_group_bound:
        if not envelopes:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "code": "EMPTY_GROUP_ENVELOPES",
                    "message": "Tidak ada amplop kunci anggota grup pada artefak ini",
                },
            )
        if principal.is_device and principal.identity is not None:
            my_id = str(principal.identity.identity_id)
            if my_id in envelopes:
                target_envelope = envelopes[my_id]
                envelope_identity_id = my_id
            else:
                is_unauthorized_agent = True
                envelope_identity_id, target_envelope = next(iter(envelopes.items()))
        elif principal.is_admin:
            envelope_identity_id, target_envelope = next(iter(envelopes.items()))
        else:
            is_unauthorized_agent = True
            envelope_identity_id, target_envelope = next(iter(envelopes.items()))
    else:
        if (
            principal.is_device
            and principal.identity is not None
            and recipient_id_str
            and str(principal.identity.identity_id) != str(recipient_id_str)
        ):
            is_unauthorized_agent = True

    key_source = (
        target_envelope.get("kem_key_source", "device")
        if target_envelope
        else meta.get("kem_key_source", "device")
    )
    resolved_ident_id = envelope_identity_id or recipient_id_str

    if payload.kem_secret_key_b64:
        kem_secret_key_b64 = payload.kem_secret_key_b64.strip()
    elif is_unauthorized_agent:
        audit = PqcAuditLog(
            organization_id=principal.organization_id,
            event_type="AGENT_KEM_DECRYPT_DENIED",
            algorithm=f"{kem_alg} + {dsa_alg}",
            status="UNAUTHORIZED_AGENT_KEY",
            actor_name=_actor_label(principal),
            target_id=str(artifact.artifact_id),
            details_json=json.dumps(
                {
                    "title": artifact.title,
                    "intended_recipient": recipient_name,
                    "reason": "Authenticated device is not an authorized recipient",
                }
            ),
        )
        db.add(audit)
        await db.commit()
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "AGENT_KEM_DECRYPT_DENIED",
                "message": (
                    f"AKSES DITOLAK ({kem_alg}): "
                    f"Komando ini dikunci khusus untuk '{recipient_name}'."
                ),
            },
        )
    elif principal.is_device and principal.identity is not None:
        if key_source == "identity":
            kp, _ = _derive_agent_kem_keypair(principal.identity, None, kem_alg)
        else:
            kp, _ = _derive_agent_kem_keypair(
                principal.identity, principal.device, kem_alg
            )
        kem_secret_key_b64 = kp["secret_key"]
    elif principal.is_admin and resolved_ident_id:
        # Admin previewing decryption for the target agent or group member
        target_ident = (
            await db.execute(
                select(Identity).where(
                    Identity.identity_id == uuid.UUID(resolved_ident_id),
                    Identity.organization_id == principal.organization_id,
                )
            )
        ).scalar_one_or_none()
        target_dev = None
        if target_ident and key_source != "identity":
            target_dev = (
                await db.execute(
                    select(Device)
                    .where(
                        Device.identity_id == target_ident.identity_id,
                        Device.status == "active",
                    )
                    .order_by(Device.registered_at.desc())
                )
            ).scalars().first()
        if not target_ident:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={
                    "code": "RECIPIENT_MISSING",
                    "message": "Identitas agen penerima tidak ditemukan",
                },
            )
        kp, _ = _derive_agent_kem_keypair(target_ident, target_dev, kem_alg)
        kem_secret_key_b64 = kp["secret_key"]
    else:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "AGENT_KEY_REQUIRED",
                "message": "Kunci privat ML-KEM perangkat agen diperlukan untuk mendekripsi komando ini",
            },
        )

    # 3. Perform FIPS 203 ML-KEM Decapsulation + AES-256-GCM Decryption
    try:
        plaintext_bytes = _kem_decrypt_payload(
            meta,
            artifact.title.strip(),
            kem_alg,
            dsa_alg,
            kem_secret_key_b64,
            target_envelope=target_envelope if is_group_bound else None,
        )
    except (InvalidTag, ValueError, Exception):
        audit = PqcAuditLog(
            organization_id=principal.organization_id,
            event_type="AGENT_KEM_DECRYPT_DENIED",
            algorithm=f"{kem_alg} + {dsa_alg}",
            status="UNAUTHORIZED_AGENT_KEY",
            actor_name=_actor_label(principal),
            target_id=str(artifact.artifact_id),
            details_json=json.dumps(
                {
                    "title": artifact.title,
                    "intended_recipient": recipient_name,
                    "reason": "ML-KEM decapsulation implicit rejection — AES-256-GCM InvalidTag",
                }
            ),
        )
        db.add(audit)
        await db.commit()
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "AGENT_KEM_DECRYPT_DENIED",
                "message": (
                    f"AKSES DITOLAK SECARA KRIPTOGRAFIS ({kem_alg}): "
                    f"Komando ini dikunci khusus dengan Public Key {kem_alg} milik '{recipient_name}'. "
                    "Kunci privat perangkat lain menghasilkan Implicit Rejection (FIPS 203) sehingga payload AES-256-GCM gagal dibuka!"
                ),
            },
        )

    decrypted_text = None
    try:
        decrypted_text = plaintext_bytes.decode("utf-8")
    except Exception:
        decrypted_text = None

    audit = PqcAuditLog(
        organization_id=principal.organization_id,
        event_type="AGENT_KEM_DECRYPT_SUCCESS",
        algorithm=f"{kem_alg} + {dsa_alg}",
        status="VALID",
        actor_name=_actor_label(principal),
        target_id=str(artifact.artifact_id),
        details_json=json.dumps(
            {
                "title": artifact.title,
                "recipient_display_name": recipient_name,
                "plaintext_sha256": meta.get("plaintext_sha256"),
            }
        ),
    )
    db.add(audit)
    await db.commit()

    return {
        "success": True,
        "data": {
            "artifact_id": str(artifact.artifact_id),
            "title": artifact.title,
            "recipient_display_name": recipient_name,
            "recipient_identity_id": recipient_id_str,
            "is_text_command": bool(meta.get("is_text_command", True)),
            "decrypted_text": decrypted_text,
            "file_name": meta.get("file_name", "komando.txt"),
            "file_mime": meta.get("file_mime", "text/plain"),
            "file_size": len(plaintext_bytes),
            "file_data_b64": base64.b64encode(plaintext_bytes).decode("ascii"),
            "kem_algorithm": kem_alg,
            "dsa_algorithm": dsa_alg,
            "plaintext_sha256": hashlib.sha256(plaintext_bytes).hexdigest().lower(),
            "message": (
                f"Berhasil didekripsi menggunakan Kunci Privat {kem_alg} perangkat {recipient_name} "
                f"& terverifikasi segel {dsa_alg}!"
            ),
        },
        "error": None,
    }


@router.get("/artifacts/{artifact_id}/download-firmware")
async def download_firmware_artifact(
    artifact_id: uuid.UUID,
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    """Download an ML-DSA signed OT/IoT firmware binary after verifying integrity."""
    artifact = (
        await db.execute(
            select(SignedArtifact).where(
                SignedArtifact.artifact_id == artifact_id,
                SignedArtifact.organization_id == principal.organization_id,
            )
        )
    ).scalar_one_or_none()

    if not artifact or artifact.status == "revoked":
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "FIRMWARE_UNAVAILABLE",
                "message": "Paket firmware tidak ditemukan atau sertifikat telah dicabut",
            },
        )

    meta: dict = {}
    if artifact.metadata_json:
        try:
            meta = json.loads(artifact.metadata_json)
        except Exception:
            meta = {}

    if not meta.get("file_data_b64"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "NO_BINARY_PAYLOAD",
                "message": "Artefak ini tidak memiliki payload file biner",
            },
        )

    return {
        "success": True,
        "data": {
            "artifact_id": str(artifact.artifact_id),
            "title": artifact.title,
            "device_model": meta.get("device_model", "OT-DEVICE"),
            "firmware_version": meta.get("firmware_version", "v1.0"),
            "file_name": meta.get("file_name", "firmware.bin"),
            "file_mime": meta.get("file_mime", "application/octet-stream"),
            "file_size": meta.get("file_size", 0),
            "file_data_b64": meta.get("file_data_b64"),
            "sha256": artifact.content_hash_sha256,
            "algorithm": artifact.algorithm,
        },
        "error": None,
    }


@router.get("/audit-logs")
async def list_sign_audit_logs(
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    """Return PQC signature and verification audit logs (SIG-005)."""
    stmt = (
        select(PqcAuditLog)
        .where(PqcAuditLog.organization_id == principal.organization_id)
        .order_by(PqcAuditLog.created_at.desc())
        .limit(100)
    )
    rows = (await db.execute(stmt)).scalars().all()
    return {
        "success": True,
        "data": [_audit_dict(row) for row in rows],
        "error": None,
    }
