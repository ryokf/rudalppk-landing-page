import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.config import settings
from app.core.database import get_db
from app.core.dependencies import Principal, get_principal
from app.models.conversation import Conversation, ConversationMember
from app.models.device import Device
from app.models.identity import Identity
from app.schemas.group import GroupCreate, GroupMemberAdd, GroupUpdate
from app.services.group_service import (
    active_members,
    actor_fields,
    bump_key_epoch,
    ensure_group_admin,
    find_membership,
    load_conversation,
    notify_membership_changed,
    record_event,
    require_group_access,
)

router = APIRouter(
    prefix="/api/v1/groups",
    tags=["Groups"],
)


async def _load_org_member(
    db: AsyncSession,
    organization_id: uuid.UUID | None,
    identity_id: uuid.UUID,
) -> Identity:
    if organization_id is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "ORGANIZATION_REQUIRED",
                "message": "Group management requires an organization account",
            },
        )

    identity = (
        await db.execute(
            select(Identity).where(
                Identity.identity_id == identity_id,
                Identity.organization_id == organization_id,
            )
        )
    ).scalar_one_or_none()

    if not identity:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "USER_NOT_FOUND",
                "message": "User not found in this organization",
            },
        )

    if identity.status != "active":
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "code": "USER_NOT_ACTIVE",
                "message": f"User is {identity.status} and cannot join a group",
            },
        )

    return identity


async def _devices_for_members(
    db: AsyncSession,
    identity_ids: list[uuid.UUID],
) -> dict[uuid.UUID, list[Device]]:
    if not identity_ids:
        return {}
    devices = (
        await db.execute(
            select(Device).where(
                Device.identity_id.in_(identity_ids),
                Device.status == "active",
            )
        )
    ).scalars().all()

    by_identity: dict[uuid.UUID, list[Device]] = {}
    for device in devices:
        by_identity.setdefault(device.identity_id, []).append(device)
    return by_identity


async def _group_summary(
    db: AsyncSession,
    conversation: Conversation,
    *,
    include_devices: bool = False,
) -> dict:
    members = active_members(conversation)
    member_ids = [member.identity_id for member in members]

    identities: dict[uuid.UUID, Identity] = {}
    if member_ids:
        rows = (
            await db.execute(
                select(Identity).where(Identity.identity_id.in_(member_ids))
            )
        ).scalars().all()
        identities = {identity.identity_id: identity for identity in rows}

    devices_by_identity = (
        await _devices_for_members(db, member_ids) if include_devices else {}
    )

    members_data = []
    for member in sorted(members, key=lambda item: item.joined_at):
        identity = identities.get(member.identity_id)
        data = {
            "identity_id": str(member.identity_id),
            "display_name": identity.display_name if identity else None,
            "public_identity": identity.public_identity if identity else None,
            "member_role": member.member_role,
            "joined_at": member.joined_at.isoformat(),
        }
        if include_devices:
            data["devices"] = [
                {
                    "device_id": str(device.device_id),
                    "device_name": device.device_name,
                    "public_device_key": device.public_device_key,
                    "pqc_kem_alg": device.pqc_kem_alg,
                    "pqc_kem_public_key": device.pqc_kem_public_key,
                    "pqc_dsa_alg": device.pqc_dsa_alg,
                    "pqc_dsa_public_key": device.pqc_dsa_public_key,
                }
                for device in devices_by_identity.get(member.identity_id, [])
            ]
        members_data.append(data)

    return {
        "conversation_id": str(conversation.conversation_id),
        "conversation_type": conversation.conversation_type,
        "title": conversation.title,
        "organization_id": str(conversation.organization_id)
        if conversation.organization_id
        else None,
        "key_epoch": conversation.key_epoch,
        "created_at": conversation.created_at.isoformat(),
        "member_count": len(members),
        "members": members_data,
    }


@router.post("")
@router.post("/")
async def create_group(
    payload: GroupCreate,
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    """Create a same-organization group.

    Field agents become the group administrator. Organization administrators may
    create a group on behalf of an agent by providing group_admin_identity_id.
    """
    if principal.organization_id is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "ORGANIZATION_REQUIRED",
                "message": "Group creation requires an organization account",
            },
        )

    if principal.is_device and not settings.allow_agent_group_creation:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "GROUP_CREATION_DISABLED",
                "message": "Field agents cannot create groups in this organization",
            },
        )

    if principal.is_admin:
        if payload.group_admin_identity_id is None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "code": "GROUP_ADMIN_REQUIRED",
                    "message": "Choose an active member to administer this group",
                },
            )
        group_admin_id = payload.group_admin_identity_id
        await _load_org_member(db, principal.organization_id, group_admin_id)
    else:
        group_admin_id = principal.identity_id
        if group_admin_id is None:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "code": "DEVICE_REQUIRED",
                    "message": "A field-agent device session is required",
                },
            )

    requested_members = {
        member_id
        for member_id in payload.members
        if member_id != group_admin_id
    }

    for member_id in requested_members:
        await _load_org_member(db, principal.organization_id, member_id)

    now = datetime.now(timezone.utc)
    conversation = Conversation(
        organization_id=principal.organization_id,
        conversation_type="group",
        title=payload.title.strip(),
        key_epoch=1,
    )
    db.add(conversation)
    await db.flush()

    db.add(
        ConversationMember(
            conversation_id=conversation.conversation_id,
            identity_id=group_admin_id,
            member_role="admin",
            joined_at=now,
        )
    )
    for member_id in requested_members:
        db.add(
            ConversationMember(
                conversation_id=conversation.conversation_id,
                identity_id=member_id,
                member_role="member",
                joined_at=now,
            )
        )

    await db.flush()
    await db.refresh(conversation)
    conversation = await load_conversation(db, conversation.conversation_id)
    assert conversation is not None

    record_event(
        db,
        conversation,
        "group_created",
        identity_id=group_admin_id,
        actor_type="admin" if principal.is_admin else "identity",
        actor_id=principal.admin.admin_id if principal.is_admin and principal.admin else principal.identity_id,
    )

    await db.commit()
    conversation = await load_conversation(db, conversation.conversation_id)
    assert conversation is not None
    await notify_membership_changed(db, conversation)

    return {
        "success": True,
        "data": await _group_summary(db, conversation, include_devices=True),
        "error": None,
    }


@router.get("")
@router.get("/")
async def list_groups(
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    if principal.organization_id is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "ORGANIZATION_REQUIRED",
                "message": "Group access requires an organization account",
            },
        )

    stmt = (
        select(Conversation)
        .where(
            Conversation.conversation_type == "group",
            Conversation.organization_id == principal.organization_id,
        )
        .options(selectinload(Conversation.members))
        .order_by(Conversation.created_at.desc())
    )

    if principal.is_device:
        stmt = stmt.join(
            ConversationMember,
            ConversationMember.conversation_id == Conversation.conversation_id,
        ).where(
            ConversationMember.identity_id == principal.identity_id,
            ConversationMember.left_at.is_(None),
        )

    conversations = (await db.execute(stmt)).unique().scalars().all()

    return {
        "success": True,
        "data": [
            await _group_summary(db, conversation) for conversation in conversations
        ],
        "error": None,
    }


@router.get("/{conversation_id}")
async def get_group_detail(
    conversation_id: uuid.UUID,
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    conversation, _ = await require_group_access(db, conversation_id, principal)
    return {
        "success": True,
        "data": await _group_summary(db, conversation, include_devices=True),
        "error": None,
    }


@router.get("/{conversation_id}/members")
async def list_group_members(
    conversation_id: uuid.UUID,
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    conversation, _ = await require_group_access(db, conversation_id, principal)
    data = await _group_summary(db, conversation, include_devices=True)
    return {
        "success": True,
        "data": data["members"],
        "error": None,
    }


@router.patch("/{conversation_id}")
async def update_group(
    conversation_id: uuid.UUID,
    payload: GroupUpdate,
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    conversation, _ = await require_group_access(
        db, conversation_id, principal, require_manage=True
    )

    if payload.title is not None:
        conversation.title = payload.title.strip()
        actor_type, actor_id = actor_fields(principal)
        record_event(
            db,
            conversation,
            "title_updated",
            identity_id=None,
            actor_type=actor_type,
            actor_id=actor_id,
        )

    await db.commit()
    conversation = await load_conversation(db, conversation_id)
    assert conversation is not None

    return {
        "success": True,
        "data": await _group_summary(db, conversation),
        "error": None,
    }


@router.post("/{conversation_id}/members")
async def add_group_member(
    conversation_id: uuid.UUID,
    payload: GroupMemberAdd,
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    conversation, _ = await require_group_access(
        db, conversation_id, principal, require_manage=True
    )

    target = await _load_org_member(
        db, conversation.organization_id, payload.identity_id
    )

    existing = (
        await db.execute(
            select(ConversationMember).where(
                ConversationMember.conversation_id == conversation_id,
                ConversationMember.identity_id == target.identity_id,
            )
        )
    ).scalar_one_or_none()

    now = datetime.now(timezone.utc)
    if existing and existing.left_at is None:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "code": "ALREADY_MEMBER",
                "message": "User is already an active member of this group",
            },
        )

    if existing:
        existing.left_at = None
        existing.member_role = payload.member_role
        existing.joined_at = now
    else:
        db.add(
            ConversationMember(
                conversation_id=conversation_id,
                identity_id=target.identity_id,
                member_role=payload.member_role,
                joined_at=now,
            )
        )

    actor_type, actor_id = actor_fields(principal)
    bump_key_epoch(conversation)
    record_event(
        db,
        conversation,
        "member_added",
        identity_id=target.identity_id,
        actor_type=actor_type,
        actor_id=actor_id,
    )

    await db.commit()
    conversation = await load_conversation(db, conversation_id)
    assert conversation is not None
    await notify_membership_changed(db, conversation)

    return {
        "success": True,
        "data": {
            **await _group_summary(db, conversation),
            "key_epoch": conversation.key_epoch,
        },
        "error": None,
    }


@router.patch("/{conversation_id}/members/{identity_id}")
async def update_group_member_role(
    conversation_id: uuid.UUID,
    identity_id: uuid.UUID,
    payload: GroupMemberAdd,
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    conversation, _ = await require_group_access(
        db, conversation_id, principal, require_manage=True
    )

    membership = find_membership(conversation, identity_id)
    if not membership:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "MEMBER_NOT_FOUND",
                "message": "User is not an active member of this group",
            },
        )

    membership.member_role = payload.member_role
    actor_type, actor_id = actor_fields(principal)
    record_event(
        db,
        conversation,
        "role_updated",
        identity_id=identity_id,
        actor_type=actor_type,
        actor_id=actor_id,
    )
    await ensure_group_admin(db, conversation)

    await db.commit()
    conversation = await load_conversation(db, conversation_id)
    assert conversation is not None

    return {
        "success": True,
        "data": await _group_summary(db, conversation),
        "error": None,
    }


async def _remove_member(
    db: AsyncSession,
    conversation_id: uuid.UUID,
    identity_id: uuid.UUID,
    principal: Principal,
) -> dict:
    conversation, _ = await require_group_access(db, conversation_id, principal)

    removing_self = (
        principal.is_device and principal.identity_id == identity_id
    )

    if not removing_self:
        conversation, _ = await require_group_access(
            db, conversation_id, principal, require_manage=True
        )

    membership = find_membership(conversation, identity_id)
    if not membership:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "MEMBER_NOT_FOUND",
                "message": "User is not an active member of this group",
            },
        )

    membership.left_at = datetime.now(timezone.utc)
    actor_type, actor_id = actor_fields(principal)
    bump_key_epoch(conversation)
    record_event(
        db,
        conversation,
        "member_left" if removing_self else "member_removed",
        identity_id=identity_id,
        actor_type=actor_type,
        actor_id=actor_id,
    )
    await ensure_group_admin(db, conversation, excluding_identity_id=identity_id)

    await db.commit()
    conversation = await load_conversation(db, conversation_id)
    assert conversation is not None
    await notify_membership_changed(db, conversation)

    return {
        "success": True,
        "data": {
            "conversation_id": str(conversation_id),
            "identity_id": str(identity_id),
            "status": "member_left" if removing_self else "member_removed",
            "key_epoch": conversation.key_epoch,
        },
        "error": None,
    }


@router.delete("/{conversation_id}/members/{identity_id}")
async def remove_group_member(
    conversation_id: uuid.UUID,
    identity_id: uuid.UUID,
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    return await _remove_member(db, conversation_id, identity_id, principal)


@router.post("/{conversation_id}/leave")
async def leave_group(
    conversation_id: uuid.UUID,
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    if not principal.is_device or principal.identity_id is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "DEVICE_REQUIRED",
                "message": "Only a field-agent device can leave a group",
            },
        )
    return await _remove_member(
        db, conversation_id, principal.identity_id, principal
    )
