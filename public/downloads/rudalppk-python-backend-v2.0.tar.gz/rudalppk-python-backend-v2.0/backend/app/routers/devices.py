import hashlib
import uuid
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select, and_
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.dependencies import Principal, get_current_device, get_principal
from app.core.pqc_backend import (
    ml_dsa_keygen,
    ml_kem_keygen,
    normalize_dsa_alg,
    normalize_kem_alg,
)
from app.models.device import Device
from app.models.identity import Identity
from app.models.prekey import DevicePrekey
from app.schemas.device import DevicePqcKeyUpdate
from app.schemas.prekey import PrekeyBatchUpload

router = APIRouter(
    prefix="/api/v1/devices",
    tags=["Devices & Prekeys"]
)


@router.get("")
@router.get("/")
async def list_my_devices(
    current_device: Device = Depends(get_current_device),
    db: AsyncSession = Depends(get_db)
):
    """List all registered devices belonging to the authenticated identity."""
    stmt = select(Device).where(Device.identity_id == current_device.identity_id)
    result = await db.execute(stmt)
    devices = result.scalars().all()

    return {
        "success": True,
        "data": [
            {
                "device_id": str(d.device_id),
                "device_name": d.device_name,
                "public_device_key": d.public_device_key,
                "auth_public_key": d.auth_public_key,
                "pqc_kem_alg": d.pqc_kem_alg,
                "pqc_kem_public_key": d.pqc_kem_public_key,
                "pqc_dsa_alg": d.pqc_dsa_alg,
                "pqc_dsa_public_key": d.pqc_dsa_public_key,
                "status": d.status,
                "registered_at": d.registered_at.isoformat(),
                "revoked_at": d.revoked_at.isoformat() if d.revoked_at else None,
                "is_current": d.device_id == current_device.device_id
            }
            for d in devices
        ],
        "error": None
    }


@router.post("/{device_id}/revoke")
async def revoke_device(
    device_id: uuid.UUID,
    current_device: Device = Depends(get_current_device),
    db: AsyncSession = Depends(get_db)
):
    """Revoke a lost or compromised device belonging to the same identity."""
    stmt = select(Device).where(
        Device.device_id == device_id,
        Device.identity_id == current_device.identity_id
    )
    result = await db.execute(stmt)
    target_device = result.scalar_one_or_none()

    if not target_device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "DEVICE_NOT_FOUND",
                "message": "Device not found for this identity"
            }
        )

    target_device.status = "revoked"
    target_device.revoked_at = datetime.now(timezone.utc)
    await db.commit()

    return {
        "success": True,
        "data": {
            "device_id": str(target_device.device_id),
            "status": "revoked",
            "revoked_at": target_device.revoked_at.isoformat()
        },
        "error": None
    }


@router.patch("/me/pqc-keys")
@router.post("/me/pqc-keys")
async def update_my_device_pqc_keys(
    payload: DevicePqcKeyUpdate,
    current_device: Device = Depends(get_current_device),
    db: AsyncSession = Depends(get_db),
):
    """Register or rotate NIST PQC keys for the authenticated device."""
    return await update_device_pqc_keys(
        device_id=current_device.device_id,
        payload=payload,
        current_device=current_device,
        db=db,
    )


@router.patch("/{device_id}/pqc-keys")
@router.post("/{device_id}/pqc-keys")
async def update_device_pqc_keys(
    device_id: uuid.UUID,
    payload: DevicePqcKeyUpdate,
    current_device: Device = Depends(get_current_device),
    db: AsyncSession = Depends(get_db),
):
    """Register or rotate NIST PQC keys (ML-KEM-512/768/1024 & ML-DSA-44/65/87) for the current device."""
    if current_device.device_id != device_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "FORBIDDEN",
                "message": "Cannot update PQC keys for another device",
            },
        )

    try:
        kem_alg = normalize_kem_alg(payload.pqc_kem_alg)
        dsa_alg = normalize_dsa_alg(payload.pqc_dsa_alg)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"code": "INVALID_PQC_ALGORITHM", "message": str(exc)},
        )

    kem_pub = payload.pqc_kem_public_key
    if not kem_pub:
        kem_seed = hashlib.sha256(
            f"PERISAI-ACTIVATE-KEM|{current_device.public_device_key}|{kem_alg}".encode("utf-8")
        ).digest()
        kem_pub = ml_kem_keygen(kem_alg, seed=kem_seed)["public_key"]

    dsa_pub = payload.pqc_dsa_public_key
    if not dsa_pub:
        dsa_seed = hashlib.sha256(
            f"PERISAI-ACTIVATE-DSA|{current_device.auth_public_key}|{dsa_alg}".encode("utf-8")
        ).digest()
        dsa_pub = ml_dsa_keygen(dsa_alg, seed=dsa_seed)["public_key"]

    current_device.pqc_kem_alg = kem_alg
    current_device.pqc_kem_public_key = kem_pub
    current_device.pqc_dsa_alg = dsa_alg
    current_device.pqc_dsa_public_key = dsa_pub
    await db.commit()
    await db.refresh(current_device)

    return {
        "success": True,
        "data": {
            "device_id": str(current_device.device_id),
            "pqc_kem_alg": current_device.pqc_kem_alg,
            "pqc_kem_public_key": current_device.pqc_kem_public_key,
            "pqc_dsa_alg": current_device.pqc_dsa_alg,
            "pqc_dsa_public_key": current_device.pqc_dsa_public_key,
        },
        "error": None,
    }


@router.post("/{device_id}/prekeys")
async def upload_device_prekeys(
    device_id: uuid.UUID,
    payload: PrekeyBatchUpload,
    current_device: Device = Depends(get_current_device),
    db: AsyncSession = Depends(get_db)
):
    """Upload signed prekey and one-time prekeys for asynchronous E2EE session initiation."""
    if current_device.device_id != device_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "FORBIDDEN",
                "message": "Cannot upload prekeys for another device"
            }
        )

    count = 0
    for item in payload.prekeys:
        prekey = DevicePrekey(
            device_id=device_id,
            prekey_type=item.prekey_type,
            key_identifier=item.key_identifier,
            public_key=item.public_key,
            signature=item.signature
        )
        db.add(prekey)
        count += 1

    await db.commit()
    return {
        "success": True,
        "data": {
            "device_id": str(device_id),
            "uploaded_count": count
        },
        "error": None
    }


@router.get("/{device_id}/prekeys/bundle")
async def get_prekey_bundle(
    device_id: uuid.UUID,
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db)
):
    """Retrieve public prekey bundle required by another party to initiate an E2EE session."""
    device_stmt = select(Device).where(Device.device_id == device_id)
    device_res = await db.execute(device_stmt)
    device = device_res.scalar_one_or_none()

    if not device or device.status != "active":
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "DEVICE_NOT_FOUND",
                "message": "Active device not found"
            }
        )

    identity = (
        await db.execute(
            select(Identity).where(Identity.identity_id == device.identity_id)
        )
    ).scalar_one_or_none()
    if (
        identity is None
        or (
            principal.organization_id is not None
            and identity.organization_id != principal.organization_id
        )
    ):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "ORGANIZATION_ISOLATION",
                "message": "This device belongs to another organization"
            }
        )

    # 1. Fetch latest signed prekey
    spk_stmt = (
        select(DevicePrekey)
        .where(
            DevicePrekey.device_id == device_id,
            DevicePrekey.prekey_type == "signed_prekey"
        )
        .order_by(DevicePrekey.created_at.desc())
        .limit(1)
    )
    spk_res = await db.execute(spk_stmt)
    signed_prekey = spk_res.scalar_one_or_none()

    # 2. Fetch and consume one available one-time prekey
    otk_stmt = (
        select(DevicePrekey)
        .where(
            and_(
                DevicePrekey.device_id == device_id,
                DevicePrekey.prekey_type == "one_time_prekey",
                DevicePrekey.consumed_at.is_(None)
            )
        )
        .limit(1)
        .with_for_update()
    )
    otk_res = await db.execute(otk_stmt)
    one_time_prekey = otk_res.scalar_one_or_none()

    if one_time_prekey:
        one_time_prekey.consumed_at = datetime.now(timezone.utc)
        await db.commit()

    return {
        "success": True,
        "data": {
            "device_id": str(device.device_id),
            "identity_id": str(device.identity_id),
            "public_device_key": device.public_device_key,
            "signed_prekey": {
                "key_identifier": signed_prekey.key_identifier,
                "public_key": signed_prekey.public_key,
                "signature": signed_prekey.signature
            } if signed_prekey else None,
            "one_time_prekey": {
                "key_identifier": one_time_prekey.key_identifier,
                "public_key": one_time_prekey.public_key
            } if one_time_prekey else None
        },
        "error": None
    }
