import uuid
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.exc import IntegrityError

from app.core.database import get_db
from app.core.dependencies import get_current_device
from app.models.device import Device
from app.models.identity import Identity
from app.models.contact import Contact
from app.schemas.contact import ContactCreate


async def _current_identity(db: AsyncSession, current_device: Device) -> Identity:
    identity = (
        await db.execute(
            select(Identity).where(Identity.identity_id == current_device.identity_id)
        )
    ).scalar_one_or_none()
    if not identity:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "IDENTITY_NOT_FOUND",
                "message": "Identity associated with this device was not found",
            },
        )
    return identity

router = APIRouter(
    prefix="/api/v1/contacts",
    tags=["Contacts"]
)


@router.post("")
@router.post("/")
async def add_contact(
    payload: ContactCreate,
    current_device: Device = Depends(get_current_device),
    db: AsyncSession = Depends(get_db)
):
    """Add a contact for the current authenticated identity."""
    if payload.contact_identity_id == current_device.identity_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "INVALID_REQUEST",
                "message": "Cannot add oneself as a contact"
            }
        )

    # Check if target identity exists in the same organization.
    current_identity = await _current_identity(db, current_device)
    target_stmt = select(Identity).where(Identity.identity_id == payload.contact_identity_id)
    target_res = await db.execute(target_stmt)
    target_identity = target_res.scalar_one_or_none()

    if not target_identity:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "IDENTITY_NOT_FOUND",
                "message": "Target contact identity not found"
            }
        )

    if target_identity.organization_id != current_identity.organization_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "ORGANIZATION_ISOLATION",
                "message": "Contacts must belong to the same organization"
            }
        )

    if target_identity.status != "active":
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "code": "USER_NOT_ACTIVE",
                "message": f"User is {target_identity.status} and cannot be added"
            }
        )

    contact = Contact(
        owner_identity_id=current_device.identity_id,
        contact_identity_id=payload.contact_identity_id,
        verification_status=payload.verification_status
    )

    try:
        db.add(contact)
        await db.commit()
        await db.refresh(contact)
        return {
            "success": True,
            "data": {
                "contact_id": str(contact.contact_id),
                "owner_identity_id": str(contact.owner_identity_id),
                "contact_identity_id": str(contact.contact_identity_id),
                "verification_status": contact.verification_status,
                "added_at": contact.added_at.isoformat()
            },
            "error": None
        }
    except IntegrityError:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "code": "CONTACT_ALREADY_EXISTS",
                "message": "Contact has already been added"
            }
        )


@router.get("")
@router.get("/")
async def list_contacts(
    current_device: Device = Depends(get_current_device),
    db: AsyncSession = Depends(get_db)
):
    """List all contacts for the current authenticated identity."""
    current_identity = await _current_identity(db, current_device)
    stmt = (
        select(Contact, Identity)
        .join(Identity, Contact.contact_identity_id == Identity.identity_id)
        .where(
            Contact.owner_identity_id == current_device.identity_id,
            Identity.organization_id == current_identity.organization_id,
            Identity.status == "active",
        )
    )
    result = await db.execute(stmt)
    rows = result.all()

    contacts_data = []
    for contact, contact_identity in rows:
        contacts_data.append({
            "contact_id": str(contact.contact_id),
            "contact_identity_id": str(contact.contact_identity_id),
            "public_identity": contact_identity.public_identity,
            "identity_fingerprint": contact_identity.identity_fingerprint,
            "verification_status": contact.verification_status,
            "added_at": contact.added_at.isoformat()
        })

    return {
        "success": True,
        "data": contacts_data,
        "error": None
    }


@router.get("/{contact_id}")
async def get_contact_detail(
    contact_id: uuid.UUID,
    current_device: Device = Depends(get_current_device),
    db: AsyncSession = Depends(get_db)
):
    """Get detail of a specific contact."""
    current_identity = await _current_identity(db, current_device)
    stmt = (
        select(Contact, Identity)
        .join(Identity, Contact.contact_identity_id == Identity.identity_id)
        .where(
            Contact.contact_id == contact_id,
            Contact.owner_identity_id == current_device.identity_id,
            Identity.organization_id == current_identity.organization_id,
        )
    )
    result = await db.execute(stmt)
    row = result.first()

    if not row:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "CONTACT_NOT_FOUND",
                "message": "Contact not found"
            }
        )

    contact, contact_identity = row
    return {
        "success": True,
        "data": {
            "contact_id": str(contact.contact_id),
            "contact_identity_id": str(contact.contact_identity_id),
            "public_identity": contact_identity.public_identity,
            "identity_fingerprint": contact_identity.identity_fingerprint,
            "verification_status": contact.verification_status,
            "added_at": contact.added_at.isoformat()
        },
        "error": None
    }


@router.delete("/{contact_id}")
async def remove_contact(
    contact_id: uuid.UUID,
    current_device: Device = Depends(get_current_device),
    db: AsyncSession = Depends(get_db)
):
    """Delete a contact from the user's contact list."""
    stmt = select(Contact).where(
        Contact.contact_id == contact_id,
        Contact.owner_identity_id == current_device.identity_id
    )
    result = await db.execute(stmt)
    contact = result.scalar_one_or_none()

    if not contact:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "CONTACT_NOT_FOUND",
                "message": "Contact not found"
            }
        )

    await db.delete(contact)
    await db.commit()

    return {
        "success": True,
        "data": {"contact_id": str(contact_id), "status": "deleted"},
        "error": None
    }
