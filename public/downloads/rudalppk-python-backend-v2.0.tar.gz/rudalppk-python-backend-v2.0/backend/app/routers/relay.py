import json
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Query, status
from sqlalchemy import select

from app.core.database import AsyncSessionLocal
from app.core.security import decode_device_access_token
from app.models.device import Device
from app.models.identity import Identity
from app.models.organization import Organization
from app.models.message import DeliveryReceipt
from app.services.relay_manager import relay_manager

router = APIRouter(
    tags=["WebSocket Relay"],
)


@router.websocket("/ws/v1/relay")
async def websocket_relay(
    websocket: WebSocket,
    token: str = Query(...),
):
    """
    WebSocket endpoint for real-time ciphertext notification & delivery acknowledgment.
    Requires device JWT token as query parameter: /ws/v1/relay?token=<jwt>
    """
    try:
        payload = decode_device_access_token(token)
        device_id = uuid.UUID(payload["sub"])
        identity_id = uuid.UUID(payload["identity_id"])
    except Exception:
        await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
        return

    # Verify device, identity and organization are still active.
    async with AsyncSessionLocal() as db:
        device = (
            await db.execute(
                select(Device).where(Device.device_id == device_id)
            )
        ).scalar_one_or_none()
        if not device or device.status != "active":
            await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
            return

        identity = (
            await db.execute(
                select(Identity).where(Identity.identity_id == identity_id)
            )
        ).scalar_one_or_none()
        if (
            not identity
            or identity.identity_id != device.identity_id
            or identity.status != "active"
        ):
            await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
            return

        if identity.organization_id is not None:
            organization = (
                await db.execute(
                    select(Organization).where(
                        Organization.organization_id == identity.organization_id
                    )
                )
            ).scalar_one_or_none()
            if not organization or organization.status != "active":
                await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
                return

    await relay_manager.connect(device_id, identity_id, websocket)

    try:
        while True:
            raw_text = await websocket.receive_text()
            try:
                msg_data = json.loads(raw_text)
                event = msg_data.get("event")
                data = msg_data.get("data", {})

                if event == "message_acknowledged":
                    target_msg_id = uuid.UUID(data.get("message_id"))
                    ack_status = data.get("delivery_status")
                    if ack_status not in {"delivered", "read"}:
                        ack_status = "delivered"

                    async with AsyncSessionLocal() as db:
                        receipt_stmt = select(DeliveryReceipt).where(
                            DeliveryReceipt.message_id == target_msg_id,
                            DeliveryReceipt.recipient_device_id == device_id,
                        )
                        receipt = (
                            await db.execute(receipt_stmt)
                        ).scalar_one_or_none()
                        if receipt:
                            receipt.delivery_status = ack_status
                            now = datetime.now(timezone.utc)
                            if not receipt.delivered_at:
                                receipt.delivered_at = now
                            if ack_status == "read":
                                receipt.read_at = now
                            await db.commit()

            except Exception:
                continue

    except WebSocketDisconnect:
        relay_manager.disconnect(device_id, identity_id, websocket)
