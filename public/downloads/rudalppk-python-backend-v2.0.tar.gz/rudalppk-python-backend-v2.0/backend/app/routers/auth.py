import secrets
import uuid
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import get_db
from app.core.pqc_backend import ml_dsa_verify, normalize_dsa_alg, normalize_kem_alg
from app.core.security import (
    create_device_access_token,
    verify_ed25519_signature,
)
from app.models.device import Device
from app.models.identity import Identity
from app.models.organization import Organization
from app.models.challenge import AuthChallenge
from app.schemas.auth import ChallengeRequest, VerifyRequest

router = APIRouter(
    prefix="/api/v1/auth",
    tags=["Authentication"],
)


def _status_error(identity_status: str) -> HTTPException:
    mapping = {
        "pending": (
            "ACCOUNT_PENDING",
            "Account is pending activation. Use the organization activation credential",
        ),
        "suspended": (
            "ACCOUNT_SUSPENDED",
            "Account is suspended and cannot authenticate",
        ),
        "revoked": (
            "ACCOUNT_REVOKED",
            "Account has been revoked and cannot authenticate",
        ),
    }
    code, message = mapping.get(
        identity_status,
        ("ACCOUNT_INACTIVE", f"Account is {identity_status}"),
    )
    return HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail={"code": code, "message": message},
    )


async def _device_with_context(
    db: AsyncSession,
    device: Device,
) -> tuple[Identity, Organization | None]:
    if device.status != "active":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "DEVICE_REVOKED",
                "message": "Device is no longer active",
            },
        )

    identity = (
        await db.execute(
            select(Identity).where(Identity.identity_id == device.identity_id)
        )
    ).scalar_one_or_none()

    if not identity:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "IDENTITY_NOT_FOUND",
                "message": "Identity associated with this device was not found",
            },
        )

    if identity.status != "active":
        raise _status_error(identity.status)

    organization = (
        await db.execute(
            select(Organization).where(
                Organization.organization_id == identity.organization_id
            )
        )
    ).scalar_one_or_none()

    if organization and organization.status != "active":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "ORGANIZATION_INACTIVE",
                "message": "The organization is not active",
            },
        )

    return identity, organization


def _response_data(
    device: Device,
    identity: Identity,
    organization: Organization | None,
) -> dict:
    return {
        "device_id": str(device.device_id),
        "identity_id": str(identity.identity_id),
        "public_identity": identity.public_identity,
        "display_name": identity.display_name,
        "account_status": identity.status,
        "organization_id": str(identity.organization_id)
        if identity.organization_id
        else None,
        "organization_name": organization.organization_name if organization else None,
        "pqc_kem_alg": device.pqc_kem_alg or (organization.pqc_kem_alg if organization else "ML-KEM-768"),
        "pqc_kem_public_key": device.pqc_kem_public_key,
        "pqc_dsa_alg": device.pqc_dsa_alg or (organization.pqc_dsa_alg if organization else "ML-DSA-65"),
        "pqc_dsa_public_key": device.pqc_dsa_public_key,
    }


async def _resolve_device(
    db: AsyncSession,
    payload: ChallengeRequest,
) -> Device:
    if payload.device_id is not None:
        device = (
            await db.execute(
                select(Device).where(Device.device_id == payload.device_id)
            )
        ).scalar_one_or_none()

        if not device:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={
                    "code": "DEVICE_NOT_FOUND",
                    "message": "Device not registered",
                },
            )
        return device

    device = (
        await db.execute(
            select(Device).where(
                Device.auth_public_key == payload.auth_public_key,
                Device.status == "active",
            )
        )
    ).scalars().first()

    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "DEVICE_NOT_FOUND",
                "message": "No active device matches the authentication public key",
            },
        )
    return device


@router.post("/challenge")
@router.post("/challenge/")
async def create_challenge(
    payload: ChallengeRequest,
    db: AsyncSession = Depends(get_db),
):
    device = await _resolve_device(db, payload)
    identity, organization = await _device_with_context(db, device)

    nonce = secrets.token_urlsafe(32)
    expires_at = datetime.now(timezone.utc) + timedelta(
        minutes=settings.challenge_expiration_minutes
    )

    challenge = AuthChallenge(
        device_id=device.device_id,
        nonce=nonce,
        expires_at=expires_at,
        is_used=False,
    )
    db.add(challenge)
    await db.commit()
    await db.refresh(challenge)

    return {
        "success": True,
        "data": {
            "challenge_id": str(challenge.challenge_id),
            "nonce": challenge.nonce,
            "expires_at": challenge.expires_at.isoformat(),
            **_response_data(device, identity, organization),
        },
        "error": None,
    }


@router.post("/verify")
@router.post("/verify/")
async def verify_challenge(
    payload: VerifyRequest,
    db: AsyncSession = Depends(get_db),
):
    now = datetime.now(timezone.utc)

    challenge = (
        await db.execute(
            select(AuthChallenge).where(
                AuthChallenge.challenge_id == payload.challenge_id,
                AuthChallenge.device_id == payload.device_id,
            )
        )
    ).scalar_one_or_none()

    if not challenge:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "CHALLENGE_NOT_FOUND",
                "message": "Authentication challenge not found for this device",
            },
        )

    if challenge.is_used:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "CHALLENGE_ALREADY_USED",
                "message": "Challenge has already been used and cannot be reused",
            },
        )

    if challenge.expires_at < now:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "CHALLENGE_EXPIRED",
                "message": "Challenge has expired",
            },
        )

    device = (
        await db.execute(
            select(Device).where(Device.device_id == payload.device_id)
        )
    ).scalar_one_or_none()

    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "DEVICE_NOT_FOUND",
                "message": "Device not registered",
            },
        )

    identity, organization = await _device_with_context(db, device)

    message_bytes = challenge.nonce.encode("utf-8")
    is_valid = verify_ed25519_signature(
        public_key_str=device.auth_public_key,
        message=message_bytes,
        signature_str=payload.signature,
    )

    if not is_valid:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={
                "code": "INVALID_SIGNATURE",
                "message": "Ed25519 signature verification failed",
            },
        )

    # Optionally update PQC keys and verify ML-DSA challenge signature (Hybrid Auth)
    if payload.pqc_kem_public_key:
        try:
            device.pqc_kem_alg = normalize_kem_alg(
                payload.pqc_kem_alg or device.pqc_kem_alg
            )
            device.pqc_kem_public_key = payload.pqc_kem_public_key
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={"code": "INVALID_PQC_KEY", "message": str(exc)},
            )

    if payload.pqc_dsa_public_key:
        try:
            device.pqc_dsa_alg = normalize_dsa_alg(
                payload.pqc_dsa_alg or device.pqc_dsa_alg
            )
            device.pqc_dsa_public_key = payload.pqc_dsa_public_key
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={"code": "INVALID_PQC_KEY", "message": str(exc)},
            )

    if payload.pqc_signature:
        dsa_pk = payload.pqc_dsa_public_key or device.pqc_dsa_public_key
        dsa_alg = payload.pqc_dsa_alg or device.pqc_dsa_alg or "ML-DSA-65"
        if not dsa_pk or not ml_dsa_verify(message_bytes, payload.pqc_signature, dsa_pk, dsa_alg):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "code": "INVALID_PQC_SIGNATURE",
                    "message": f"{dsa_alg} post-quantum signature verification failed",
                },
            )

    challenge.is_used = True
    challenge.used_at = now
    await db.commit()

    access_token, expires_in = create_device_access_token(
        device_id=str(device.device_id),
        identity_id=str(device.identity_id),
        organization_id=str(identity.organization_id)
        if identity.organization_id
        else None,
    )

    return {
        "success": True,
        "data": {
            "access_token": access_token,
            "token_type": "bearer",
            "expires_in": expires_in,
            **_response_data(device, identity, organization),
        },
        "error": None,
    }
