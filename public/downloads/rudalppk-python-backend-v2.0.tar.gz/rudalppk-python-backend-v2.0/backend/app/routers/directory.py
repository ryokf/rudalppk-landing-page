import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select, or_
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.dependencies import Principal, get_principal
from app.models.device import Device
from app.models.identity import Identity

router = APIRouter(
    prefix="/api/v1/directory",
    tags=["Organization Directory"],
)


def _member_data(identity: Identity, devices: list[Device]) -> dict:
    active_devices = [device for device in devices if device.status == "active"]
    return {
        "identity_id": str(identity.identity_id),
        "display_name": identity.display_name,
        "public_identity": identity.public_identity,
        "identity_fingerprint": identity.identity_fingerprint,
        "status": identity.status,
        "organization_id": str(identity.organization_id) if identity.organization_id else None,
        "device_count": len(devices),
        "active_device_count": len(active_devices),
        "devices": [
            {
                "device_id": str(device.device_id),
                "device_name": device.device_name,
                "public_device_key": device.public_device_key,
                "pqc_kem_alg": device.pqc_kem_alg,
                "pqc_kem_public_key": device.pqc_kem_public_key,
                "pqc_dsa_alg": device.pqc_dsa_alg,
                "pqc_dsa_public_key": device.pqc_dsa_public_key,
                "status": device.status,
            }
            for device in active_devices
        ],
    }


@router.get("/members")
async def list_directory_members(
    search: str | None = None,
    include_self: bool = False,
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    """List active members of the caller's organization for contacts and pickers."""
    if principal.organization_id is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "ORGANIZATION_REQUIRED",
                "message": "Directory access requires an organization account",
            },
        )

    stmt = select(Identity).where(
        Identity.organization_id == principal.organization_id,
        Identity.status == "active",
    )
    if not include_self and principal.identity_id is not None:
        stmt = stmt.where(Identity.identity_id != principal.identity_id)
    if search and search.strip():
        pattern = f"%{search.strip()}%"
        stmt = stmt.where(
            or_(
                Identity.display_name.ilike(pattern),
                Identity.public_identity.ilike(pattern),
                Identity.identity_fingerprint.ilike(pattern),
            )
        )
    stmt = stmt.order_by(Identity.display_name.asc().nulls_last(), Identity.created_at.asc())

    identities = (await db.execute(stmt)).scalars().all()
    identity_ids = [identity.identity_id for identity in identities]

    devices_by_identity: dict[uuid.UUID, list[Device]] = {}
    if identity_ids:
        devices = (
            await db.execute(
                select(Device).where(Device.identity_id.in_(identity_ids))
            )
        ).scalars().all()
        for device in devices:
            devices_by_identity.setdefault(device.identity_id, []).append(device)

    return {
        "success": True,
        "data": [
            _member_data(identity, devices_by_identity.get(identity.identity_id, []))
            for identity in identities
        ],
        "error": None,
    }


@router.get("/members/{identity_id}")
async def get_directory_member(
    identity_id: uuid.UUID,
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    if principal.organization_id is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "ORGANIZATION_REQUIRED",
                "message": "Directory access requires an organization account",
            },
        )

    identity = (
        await db.execute(
            select(Identity).where(
                Identity.identity_id == identity_id,
                Identity.organization_id == principal.organization_id,
            )
        )
    ).scalar_one_or_none()

    if not identity:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "USER_NOT_FOUND",
                "message": "User not found in this organization",
            },
        )

    devices = (
        await db.execute(
            select(Device).where(Device.identity_id == identity.identity_id)
        )
    ).scalars().all()

    return {
        "success": True,
        "data": _member_data(identity, devices),
        "error": None,
    }
