import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.dependencies import Principal, get_principal
from app.models.device import Device
from app.models.identity import Identity
from app.models.organization import Organization
from app.schemas.identity import IdentityCreate  # noqa: F401 - kept for compatibility

router = APIRouter(
    prefix="/api/v1",
    tags=["Identity"],
)


def _not_found(code: str, message: str) -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail={"code": code, "message": message},
    )


async def _organization_data(
    db: AsyncSession,
    organization_id: uuid.UUID | None,
) -> Organization | None:
    if organization_id is None:
        return None
    return (
        await db.execute(
            select(Organization).where(
                Organization.organization_id == organization_id
            )
        )
    ).scalar_one_or_none()


def _identity_data(identity: Identity, devices: list[Device]) -> dict:
    return {
        "identity_id": str(identity.identity_id),
        "organization_id": str(identity.organization_id)
        if identity.organization_id
        else None,
        "display_name": identity.display_name,
        "public_identity": identity.public_identity,
        "identity_fingerprint": identity.identity_fingerprint,
        "status": identity.status,
        "activated_at": identity.activated_at.isoformat()
        if identity.activated_at
        else None,
        "created_at": identity.created_at.isoformat(),
        "devices": [
            {
                "device_id": str(device.device_id),
                "device_name": device.device_name,
                "public_device_key": device.public_device_key,
                "auth_public_key": device.auth_public_key,
                "pqc_kem_alg": device.pqc_kem_alg,
                "pqc_kem_public_key": device.pqc_kem_public_key,
                "pqc_dsa_alg": device.pqc_dsa_alg,
                "pqc_dsa_public_key": device.pqc_dsa_public_key,
                "status": device.status,
                "registered_at": device.registered_at.isoformat(),
            }
            for device in devices
        ],
    }


async def _load_identity_for_principal(
    db: AsyncSession,
    principal: Principal,
    identity_id: uuid.UUID,
) -> Identity:
    identity = (
        await db.execute(
            select(Identity).where(Identity.identity_id == identity_id)
        )
    ).scalar_one_or_none()

    if not identity:
        raise _not_found("IDENTITY_NOT_FOUND", "Identity not found")

    if (
        principal.organization_id is not None
        and identity.organization_id != principal.organization_id
    ):
        raise _not_found("IDENTITY_NOT_FOUND", "Identity not found")

    return identity


@router.post("/identity")
@router.post("/identity/")
async def register_identity():
    """Self-registration is disabled in SAD v2.0.

    Accounts are provisioned by an organization administrator through
    /api/v1/organizations/users and activated through /api/v1/activation.
    """
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail={
            "code": "SELF_REGISTRATION_DISABLED",
            "message": (
                "Self-registration is disabled. Use an organization-issued "
                "activation credential"
            ),
        },
    )


@router.get("/me")
async def get_current_identity(
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    """Return the authenticated caller's identity (device) or admin profile."""
    organization = await _organization_data(db, principal.organization_id)

    if principal.is_device:
        if principal.identity is None or principal.device is None:
            raise _not_found("IDENTITY_NOT_FOUND", "Identity not found")

        devices = (
            await db.execute(
                select(Device).where(
                    Device.identity_id == principal.identity.identity_id
                )
            )
        ).scalars().all()

        return {
            "success": True,
            "data": {
                "kind": "field_agent",
                "identity": _identity_data(principal.identity, devices),
                "organization": {
                    "organization_id": str(organization.organization_id)
                    if organization
                    else None,
                    "organization_name": organization.organization_name
                    if organization
                    else None,
                    "status": organization.status if organization else None,
                    "pqc_kem_alg": organization.pqc_kem_alg
                    if organization
                    else "ML-KEM-768",
                    "pqc_dsa_alg": organization.pqc_dsa_alg
                    if organization
                    else "ML-DSA-65",
                },
            },
            "error": None,
        }

    if principal.is_admin and principal.admin is not None:
        return {
            "success": True,
            "data": {
                "kind": "organization_admin",
                "admin": {
                    "admin_id": str(principal.admin.admin_id),
                    "email": principal.admin.email,
                    "display_name": principal.admin.display_name,
                    "role": principal.admin.role,
                    "status": principal.admin.status,
                },
                "organization": {
                    "organization_id": str(organization.organization_id)
                    if organization
                    else None,
                    "organization_name": organization.organization_name
                    if organization
                    else None,
                    "status": organization.status if organization else None,
                    "pqc_kem_alg": organization.pqc_kem_alg
                    if organization
                    else "ML-KEM-768",
                    "pqc_dsa_alg": organization.pqc_dsa_alg
                    if organization
                    else "ML-DSA-65",
                },
            },
            "error": None,
        }

    raise _not_found("IDENTITY_NOT_FOUND", "Identity not found")


@router.get("/identity/{identity_id}")
async def get_identity(
    identity_id: uuid.UUID,
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    identity = await _load_identity_for_principal(db, principal, identity_id)

    devices = (
        await db.execute(
            select(Device).where(Device.identity_id == identity.identity_id)
        )
    ).scalars().all()

    return {
        "success": True,
        "data": _identity_data(identity, devices),
        "error": None,
    }


@router.get("/identity/fingerprint/{fingerprint}")
async def get_identity_by_fingerprint(
    fingerprint: str,
    principal: Principal = Depends(get_principal),
    db: AsyncSession = Depends(get_db),
):
    identity = (
        await db.execute(
            select(Identity).where(
                Identity.identity_fingerprint == fingerprint.strip().lower()
            )
        )
    ).scalar_one_or_none()

    if not identity:
        raise _not_found(
            "IDENTITY_NOT_FOUND", "Identity with fingerprint not found"
        )

    if (
        principal.organization_id is not None
        and identity.organization_id != principal.organization_id
    ):
        raise _not_found(
            "IDENTITY_NOT_FOUND", "Identity with fingerprint not found"
        )

    return {
        "success": True,
        "data": _identity_data(identity, []),
        "error": None,
    }
