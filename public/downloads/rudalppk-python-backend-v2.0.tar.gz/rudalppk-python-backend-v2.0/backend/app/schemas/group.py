import uuid

from pydantic import BaseModel, Field


class GroupCreate(BaseModel):
    title: str = Field(min_length=1, max_length=150)
    members: list[uuid.UUID] = Field(default_factory=list)
    group_admin_identity_id: uuid.UUID | None = None


class GroupUpdate(BaseModel):
    title: str | None = Field(default=None, min_length=1, max_length=150)


class GroupMemberAdd(BaseModel):
    identity_id: uuid.UUID
    member_role: str = Field(default="member", pattern="^(member|admin)$")
