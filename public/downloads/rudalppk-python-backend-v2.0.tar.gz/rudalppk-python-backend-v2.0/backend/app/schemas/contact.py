import uuid
from datetime import datetime
from pydantic import BaseModel, Field


class ContactCreate(BaseModel):
    contact_identity_id: uuid.UUID
    verification_status: str = Field(default="unverified")


class ContactResponse(BaseModel):
    contact_id: uuid.UUID
    owner_identity_id: uuid.UUID
    contact_identity_id: uuid.UUID
    verification_status: str
    added_at: datetime
