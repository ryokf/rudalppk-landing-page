import uuid
from datetime import datetime
from pydantic import BaseModel, Field


class DirectConversationCreate(BaseModel):
    peer_identity_id: uuid.UUID


class ConversationCreate(BaseModel):
    conversation_type: str = Field(default="direct", pattern="^(direct|group)$")
    title: str | None = Field(default=None, max_length=150)
    members: list[uuid.UUID] = Field(min_length=1)


class ConversationMemberAdd(BaseModel):
    identity_id: uuid.UUID
    member_role: str = Field(default="member", pattern="^(member|admin)$")


class ConversationResponse(BaseModel):
    conversation_id: uuid.UUID
    conversation_type: str
    title: str | None = None
    key_epoch: int = 1
    created_at: datetime
    members: list[uuid.UUID] = []
