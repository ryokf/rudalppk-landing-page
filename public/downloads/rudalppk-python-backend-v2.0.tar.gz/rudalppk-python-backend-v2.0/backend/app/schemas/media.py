import uuid
from pydantic import BaseModel, Field


class MediaUploadRequest(BaseModel):
    content_type: str = Field(default="audio/ogg; codecs=opus")
    file_size: int = Field(gt=0)


class MediaCompleteRequest(BaseModel):
    media_id: uuid.UUID
    message_id: uuid.UUID | None = None
