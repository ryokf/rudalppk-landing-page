from pydantic import BaseModel, Field


class DeviceCreate(BaseModel):
    device_name: str = Field(min_length=1, max_length=100)
    public_device_key: str = Field(min_length=1)
    auth_public_key: str = Field(min_length=1)


class IdentityCreate(BaseModel):
    public_identity: str = Field(min_length=1)
    identity_fingerprint: str = Field(min_length=16, max_length=128)
    device: DeviceCreate