import uuid
from pydantic import BaseModel, Field, model_validator


class ChallengeRequest(BaseModel):
    device_id: uuid.UUID | None = None
    auth_public_key: str | None = None

    @model_validator(mode="after")
    def require_lookup(self):
        if self.device_id is None and not self.auth_public_key:
            raise ValueError("Provide device_id or auth_public_key")
        return self


class ChallengeResponseData(BaseModel):
    challenge_id: uuid.UUID
    nonce: str
    expires_at: str
    device_id: uuid.UUID
    identity_id: uuid.UUID
    public_identity: str
    display_name: str | None = None
    account_status: str
    organization_id: uuid.UUID | None = None
    organization_name: str | None = None


class VerifyRequest(BaseModel):
    challenge_id: uuid.UUID
    device_id: uuid.UUID
    signature: str = Field(min_length=1)
    pqc_signature: str | None = Field(default=None)
    pqc_dsa_alg: str | None = Field(default=None)
    pqc_dsa_public_key: str | None = Field(default=None)
    pqc_kem_alg: str | None = Field(default=None)
    pqc_kem_public_key: str | None = Field(default=None)


class TokenResponseData(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int
    device_id: uuid.UUID
    identity_id: uuid.UUID
    organization_id: uuid.UUID | None = None
    organization_name: str | None = None
    public_identity: str
    display_name: str | None = None
