import uuid
from datetime import datetime
from pydantic import BaseModel, Field


class MessageCreate(BaseModel):
    conversation_id: uuid.UUID
    client_message_id: uuid.UUID
    protocol_version: str = Field(default="2")
    key_epoch: int = Field(default=1, ge=1)
    message_type: str = Field(default="text")
    ciphertext: str = Field(min_length=1, description="Base64 encoded ciphertext")


class MessageResponse(BaseModel):
    message_id: uuid.UUID
    conversation_id: uuid.UUID
    sender_device_id: uuid.UUID
    client_message_id: uuid.UUID
    protocol_version: str
    key_epoch: int
    message_type: str
    ciphertext: str
    created_at: datetime


class ReceiptUpdate(BaseModel):
    delivery_status: str = Field(pattern="^(delivered|read)$")
