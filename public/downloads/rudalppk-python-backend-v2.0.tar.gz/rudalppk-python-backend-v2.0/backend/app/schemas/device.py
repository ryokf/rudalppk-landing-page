import uuid
from datetime import datetime
from pydantic import BaseModel


class DeviceResponse(BaseModel):
    device_id: uuid.UUID
    identity_id: uuid.UUID
    device_name: str | None = None
    public_device_key: str
    auth_public_key: str
    pqc_kem_alg: str | None = None
    pqc_kem_public_key: str | None = None
    pqc_dsa_alg: str | None = None
    pqc_dsa_public_key: str | None = None
    status: str
    registered_at: datetime


class DevicePqcKeyUpdate(BaseModel):
    pqc_kem_alg: str = "ML-KEM-768"
    pqc_kem_public_key: str | None = None
    pqc_dsa_alg: str = "ML-DSA-65"
    pqc_dsa_public_key: str | None = None
