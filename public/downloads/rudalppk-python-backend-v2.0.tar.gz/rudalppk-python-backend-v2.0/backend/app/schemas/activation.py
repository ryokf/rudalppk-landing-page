from pydantic import BaseModel, Field


class ActivationVerifyRequest(BaseModel):
    code: str = Field(min_length=8, max_length=128)


class ActivationCompleteRequest(BaseModel):
    code: str = Field(min_length=8, max_length=128)
    identity_fingerprint: str = Field(min_length=16, max_length=128)
    device_name: str = Field(min_length=1, max_length=100)
    public_device_key: str = Field(min_length=1)
    auth_public_key: str = Field(min_length=1)
    pqc_kem_alg: str | None = Field(default="ML-KEM-768")
    pqc_kem_public_key: str | None = Field(default=None)
    pqc_dsa_alg: str | None = Field(default="ML-DSA-65")
    pqc_dsa_public_key: str | None = Field(default=None)
