import uuid
from pydantic import BaseModel, Field


class PrekeyItem(BaseModel):
    prekey_type: str = Field(pattern="^(signed_prekey|one_time_prekey)$")
    key_identifier: str = Field(min_length=1, max_length=100)
    public_key: str = Field(min_length=1)
    signature: str | None = None


class PrekeyBatchUpload(BaseModel):
    prekeys: list[PrekeyItem] = Field(min_length=1)


class PrekeyBundleResponse(BaseModel):
    device_id: uuid.UUID
    identity_id: uuid.UUID
    public_device_key: str
    signed_prekey: dict | None = None
    one_time_prekey: dict | None = None
