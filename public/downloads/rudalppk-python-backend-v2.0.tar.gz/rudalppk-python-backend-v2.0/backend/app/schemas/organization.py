import uuid
from datetime import datetime

from pydantic import BaseModel, Field, field_validator


class OrganizationCreate(BaseModel):
    organization_name: str = Field(min_length=2, max_length=150)
    admin_email: str = Field(min_length=5, max_length=255)
    admin_password: str = Field(min_length=10, max_length=128)
    admin_display_name: str = Field(default="Organization Owner", min_length=1, max_length=150)

    @field_validator("admin_email")
    @classmethod
    def validate_email(cls, value: str) -> str:
        value = value.strip().lower()
        if "@" not in value or value.startswith("@") or value.endswith("@"):
            raise ValueError("A valid administrator email is required")
        return value


class OrganizationUpdate(BaseModel):
    organization_name: str | None = Field(default=None, min_length=2, max_length=150)
    pqc_kem_alg: str | None = Field(default=None)
    pqc_dsa_alg: str | None = Field(default=None)


class AdminLoginRequest(BaseModel):
    email: str = Field(min_length=5, max_length=255)
    password: str = Field(min_length=1, max_length=128)

    @field_validator("email")
    @classmethod
    def normalize_email(cls, value: str) -> str:
        return value.strip().lower()


class AdminCreate(BaseModel):
    email: str = Field(min_length=5, max_length=255)
    display_name: str = Field(min_length=1, max_length=150)
    password: str = Field(min_length=10, max_length=128)
    role: str = Field(default="admin", pattern="^(owner|admin)$")

    @field_validator("email")
    @classmethod
    def normalize_email(cls, value: str) -> str:
        value = value.strip().lower()
        if "@" not in value:
            raise ValueError("A valid administrator email is required")
        return value


class AdminUpdate(BaseModel):
    display_name: str | None = Field(default=None, min_length=1, max_length=150)
    status: str | None = Field(default=None, pattern="^(active|suspended)$")
    password: str | None = Field(default=None, min_length=10, max_length=128)


class FieldAgentCreate(BaseModel):
    display_name: str = Field(min_length=1, max_length=150)


class FieldAgentUpdate(BaseModel):
    display_name: str | None = Field(default=None, min_length=1, max_length=150)
    status: str | None = Field(
        default=None,
        pattern="^(active|suspended|revoked)$",
        description="Use activation to move a pending account to active.",
    )


class CredentialIssueResponse(BaseModel):
    credential_id: uuid.UUID
    activation_code: str
    expires_at: datetime
    identity_id: uuid.UUID
