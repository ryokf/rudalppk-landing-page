import base64
import binascii
import hashlib
import hmac
import secrets
from datetime import datetime, timedelta, timezone

import jwt
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.exceptions import InvalidSignature

from app.core.config import settings

_PASSWORD_ITERATIONS = 260_000


def decode_bytes(data: str) -> bytes:
    """Decode string from Base64 (standard or urlsafe) or Hex to raw bytes."""
    clean_data = data.strip()

    # Try standard / urlsafe Base64
    for decoder in (base64.b64decode, base64.urlsafe_b64decode):
        try:
            padded = clean_data + "=" * (-len(clean_data) % 4)
            decoded = decoder(padded)
            if len(decoded) in (32, 64):  # Common key/signature lengths
                return decoded
        except Exception:
            continue

    # Try Hex
    try:
        decoded = bytes.fromhex(clean_data)
        if len(decoded) in (32, 64):
            return decoded
    except Exception:
        pass

    # Fallback to any base64
    try:
        padded = clean_data + "=" * (-len(clean_data) % 4)
        return base64.b64decode(padded)
    except Exception:
        pass

    raise ValueError("Failed to decode data from base64 or hex format")


def verify_ed25519_signature(public_key_str: str, message: bytes, signature_str: str) -> bool:
    """Verify Ed25519 signature over message bytes using public key string."""
    try:
        pub_bytes = decode_bytes(public_key_str)
        if len(pub_bytes) != 32:
            return False

        sig_bytes = decode_bytes(signature_str)
        if len(sig_bytes) != 64:
            return False

        public_key = Ed25519PublicKey.from_public_bytes(pub_bytes)
        public_key.verify(sig_bytes, message)
        return True
    except (InvalidSignature, ValueError, Exception):
        return False


def derive_identity_fingerprint(auth_public_key: str) -> str:
    """SHA-256 of the Ed25519 public key bytes, first 32 hex characters."""
    try:
        key_bytes = decode_bytes(auth_public_key)
    except ValueError as exc:
        raise ValueError("Authentication public key is not valid Base64 or Hex") from exc

    if len(key_bytes) != 32:
        raise ValueError("Authentication public key must be 32 bytes")

    return hashlib.sha256(key_bytes).hexdigest()[:32]


def derive_public_identity(fingerprint: str) -> str:
    return f"AGENT_{fingerprint[:10].upper()}"


def validate_identity_proof(identity_fingerprint: str, auth_public_key: str) -> str:
    """Validate that the fingerprint belongs to the supplied Ed25519 key.

    Returns the canonical public identity label. The client cannot choose an
    arbitrary fingerprint or public identity during activation.
    """
    normalized = identity_fingerprint.strip().lower()
    expected = derive_identity_fingerprint(auth_public_key)
    if not hmac.compare_digest(normalized, expected):
        raise ValueError("Identity fingerprint does not match the authentication public key")
    return derive_public_identity(expected)


# ---------------------------------------------------------------------------
# Password hashing for organization administrator accounts
# ---------------------------------------------------------------------------

def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt,
        _PASSWORD_ITERATIONS,
    )
    return "pbkdf2_sha256${}${}${}".format(
        _PASSWORD_ITERATIONS,
        base64.b64encode(salt).decode("ascii"),
        base64.b64encode(digest).decode("ascii"),
    )


def verify_password(password: str, encoded: str) -> bool:
    try:
        algorithm, iterations, salt_b64, digest_b64 = encoded.split("$", 3)
        if algorithm != "pbkdf2_sha256":
            return False
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(digest_b64)
        actual = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            salt,
            int(iterations),
        )
        return hmac.compare_digest(actual, expected)
    except (ValueError, binascii.Error):
        return False


# ---------------------------------------------------------------------------
# JWT access tokens
# ---------------------------------------------------------------------------

def create_device_access_token(
    device_id: str,
    identity_id: str,
    organization_id: str | None = None,
) -> tuple[str, int]:
    """Generate JWT session token for an authenticated device."""
    expires_delta = timedelta(hours=settings.jwt_expiration_hours)
    now = datetime.now(timezone.utc)
    expires_at = now + expires_delta

    payload = {
        "sub": device_id,
        "identity_id": identity_id,
        "organization_id": organization_id,
        "type": "device_session",
        "iat": now,
        "exp": expires_at,
    }

    token = jwt.encode(
        payload,
        settings.jwt_secret_key,
        algorithm=settings.jwt_algorithm,
    )
    return token, int(expires_delta.total_seconds())


def create_admin_access_token(
    admin_id: str,
    organization_id: str,
    role: str,
) -> tuple[str, int]:
    """Generate JWT session token for an organization administrator."""
    expires_delta = timedelta(hours=settings.admin_jwt_expiration_hours)
    now = datetime.now(timezone.utc)
    expires_at = now + expires_delta

    payload = {
        "sub": admin_id,
        "organization_id": organization_id,
        "role": role,
        "type": "admin_session",
        "iat": now,
        "exp": expires_at,
    }

    token = jwt.encode(
        payload,
        settings.jwt_secret_key,
        algorithm=settings.jwt_algorithm,
    )
    return token, int(expires_delta.total_seconds())


def decode_token(token: str) -> dict:
    """Decode any platform JWT access token and validate its signature/expiry."""
    try:
        return jwt.decode(
            token,
            settings.jwt_secret_key,
            algorithms=[settings.jwt_algorithm],
        )
    except jwt.PyJWTError as exc:
        raise ValueError(f"Token invalid or expired: {exc}") from exc


def decode_device_access_token(token: str) -> dict:
    """Decode and validate a device JWT access token."""
    payload = decode_token(token)
    if payload.get("type") != "device_session":
        raise ValueError("Invalid token type")
    return payload


def decode_admin_access_token(token: str) -> dict:
    """Decode and validate an administrator JWT access token."""
    payload = decode_token(token)
    if payload.get("type") != "admin_session":
        raise ValueError("Invalid token type")
    return payload
