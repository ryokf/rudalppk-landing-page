import hmac
import uuid
from dataclasses import dataclass
from typing import Literal

from fastapi import Depends, Header, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import get_db
from app.core.security import decode_token
from app.models.device import Device
from app.models.identity import Identity
from app.models.organization import Organization, OrganizationAdmin


bearer_scheme = HTTPBearer(auto_error=False)


@dataclass
class Principal:
    """Authenticated caller derived from the JWT and verified against the DB."""

    kind: Literal["device", "admin"]
    organization_id: uuid.UUID | None
    organization: Organization | None
    identity_id: uuid.UUID | None = None
    device: Device | None = None
    identity: Identity | None = None
    admin: OrganizationAdmin | None = None

    @property
    def is_admin(self) -> bool:
        return self.kind == "admin"

    @property
    def is_device(self) -> bool:
        return self.kind == "device"


async def _load_active_organization(
    organization_id: uuid.UUID | None,
    db: AsyncSession,
) -> Organization | None:
    if organization_id is None:
        return None

    result = await db.execute(
        select(Organization).where(Organization.organization_id == organization_id)
    )
    organization = result.scalar_one_or_none()
    if not organization:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "ORGANIZATION_NOT_FOUND",
                "message": "The organization for this account no longer exists",
            },
        )
    if organization.status != "active":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "ORGANIZATION_INACTIVE",
                "message": "The organization is not active",
            },
        )
    return organization


async def get_principal(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
    db: AsyncSession = Depends(get_db),
) -> Principal:
    """Authenticate either a field-agent device or an organization administrator."""
    if not credentials or not credentials.credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={
                "code": "UNAUTHORIZED",
                "message": "Authorization header with Bearer token is required",
            },
        )

    try:
        payload = decode_token(credentials.credentials)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"code": "UNAUTHORIZED", "message": str(exc)},
        )

    token_type = payload.get("type")
    subject = payload.get("sub")

    if token_type == "device_session":
        try:
            device_uuid = uuid.UUID(str(subject))
        except (TypeError, ValueError):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "code": "UNAUTHORIZED",
                    "message": "Malformed device identifier in token",
                },
            )

        result = await db.execute(
            select(Device).where(Device.device_id == device_uuid)
        )
        device = result.scalar_one_or_none()

        if not device:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "code": "DEVICE_NOT_FOUND",
                    "message": "Device associated with token was not found",
                },
            )

        if device.status != "active":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "code": "DEVICE_REVOKED",
                    "message": "Device has been revoked and cannot perform actions",
                },
            )

        identity_result = await db.execute(
            select(Identity).where(Identity.identity_id == device.identity_id)
        )
        identity = identity_result.scalar_one_or_none()

        if not identity:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "code": "IDENTITY_NOT_FOUND",
                    "message": "Identity associated with this device was not found",
                },
            )

        if identity.status != "active":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "code": f"ACCOUNT_{identity.status.upper()}",
                    "message": f"Account is {identity.status} and cannot perform actions",
                },
            )

        organization = await _load_active_organization(identity.organization_id, db)

        return Principal(
            kind="device",
            organization_id=identity.organization_id,
            organization=organization,
            identity_id=identity.identity_id,
            device=device,
            identity=identity,
        )

    if token_type == "admin_session":
        try:
            admin_uuid = uuid.UUID(str(subject))
        except (TypeError, ValueError):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "code": "UNAUTHORIZED",
                    "message": "Malformed administrator identifier in token",
                },
            )

        result = await db.execute(
            select(OrganizationAdmin).where(
                OrganizationAdmin.admin_id == admin_uuid
            )
        )
        admin = result.scalar_one_or_none()

        if not admin:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "code": "ADMIN_NOT_FOUND",
                    "message": "Administrator associated with token was not found",
                },
            )

        if admin.status != "active":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "code": "ADMIN_INACTIVE",
                    "message": "Administrator account is not active",
                },
            )

        organization = await _load_active_organization(admin.organization_id, db)

        return Principal(
            kind="admin",
            organization_id=admin.organization_id,
            organization=organization,
            admin=admin,
        )

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail={
            "code": "UNAUTHORIZED",
            "message": "Token type is not supported",
        },
    )


async def get_current_device(
    principal: Principal = Depends(get_principal),
) -> Device:
    """Dependency for endpoints that require an authenticated field-agent device."""
    if not principal.is_device or principal.device is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "DEVICE_REQUIRED",
                "message": "This endpoint requires a field-agent device session",
            },
        )
    return principal.device


async def get_current_admin(
    principal: Principal = Depends(get_principal),
) -> OrganizationAdmin:
    """Dependency for endpoints that require an organization administrator."""
    if not principal.is_admin or principal.admin is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "ADMIN_REQUIRED",
                "message": "This endpoint requires an organization administrator session",
            },
        )
    return principal.admin


async def require_organization_owner(
    principal: Principal = Depends(get_principal),
) -> Principal:
    if not principal.is_admin or principal.admin is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "ADMIN_REQUIRED",
                "message": "This endpoint requires an organization administrator session",
            },
        )
    if principal.admin.role != "owner":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "OWNER_REQUIRED",
                "message": "Only the organization owner can perform this action",
            },
        )
    return principal


async def require_system_admin(
    x_system_admin_key: str | None = Header(
        default=None,
        alias="X-System-Admin-Key",
    ),
) -> None:
    """Protect system-level operations such as creating a new organization."""
    expected = settings.system_admin_api_key
    if not expected:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "code": "SYSTEM_ADMIN_NOT_CONFIGURED",
                "message": "System administrator provisioning is not configured",
            },
        )
    if not x_system_admin_key or not hmac.compare_digest(
        x_system_admin_key, expected
    ):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "SYSTEM_ADMIN_REQUIRED",
                "message": "A valid X-System-Admin-Key header is required",
            },
        )


def same_organization(
    left: uuid.UUID | None,
    right: uuid.UUID | None,
) -> bool:
    """Organization isolation check; legacy unassigned identities share a scope."""
    return left == right
