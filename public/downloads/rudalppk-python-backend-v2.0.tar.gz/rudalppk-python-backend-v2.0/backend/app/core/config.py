from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    database_url: str
    jwt_secret_key: str = "field-sec-comm-secret-key-change-in-prod"
    jwt_algorithm: str = "HS256"
    jwt_expiration_hours: int = 24
    admin_jwt_expiration_hours: int = 12
    challenge_expiration_minutes: int = 5

    # Post-quantum cryptography backend. "custom" keeps the prototype engine
    # that the current Flutter client interoperates with. "pqcrypto" uses
    # PQClean's FIPS 203 (ML-KEM) / FIPS 204 (ML-DSA) implementations.
    pqc_backend: str = "custom"

    # Organization provisioning
    activation_credential_expiry_hours: int = 72
    allow_agent_group_creation: bool = True
    allow_cross_organization_groups: bool = False

    # Optional system-level bootstrap. When configured, the first startup creates
    # an organization and its owner account. Never enable default credentials in
    # production.
    system_admin_api_key: str | None = None
    bootstrap_organization_name: str | None = None
    bootstrap_admin_email: str | None = None
    bootstrap_admin_password: str | None = None
    bootstrap_admin_display_name: str = "Organization Owner"
    bootstrap_backfill_legacy_identities: bool = False

    # Object Storage (SeaweedFS S3)
    s3_endpoint_url: str = "http://storage:8333"
    s3_public_url: str = "http://localhost:8333"
    s3_bucket_name: str = "securechat-media"

    model_config = SettingsConfigDict(
        env_file=".env",
        extra="ignore"
    )


settings = Settings()
