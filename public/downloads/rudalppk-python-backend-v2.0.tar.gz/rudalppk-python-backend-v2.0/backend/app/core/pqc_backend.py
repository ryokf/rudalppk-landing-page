"""Pluggable Post-Quantum Cryptography (PQC) backend façade.

The prototype historically used ``app.core.pqc`` for every KEM/DSA operation.
That module is **not** FIPS 203/204 compliant, so this façade adds a selectable
backend without removing the original implementation:

* ``custom``  – the existing prototype engine. It is the default because the
  current Flutter client speaks its custom wire format.
* ``pqcrypto`` – PQClean bindings for real FIPS 203 (ML-KEM) and FIPS 204
  (ML-DSA) implementations. Keys and signatures from this backend are *not*
  interchangeable with the custom prototype.

Select the backend with the ``PQC_BACKEND`` environment variable. The default
remains ``custom`` until the Flutter client is migrated.

Security note: ``pqcrypto`` provides standards-conformant reference
implementations, but this project has not validated them against NIST ACVP
vectors or obtained a CMVP certificate. Do not describe the deployment as
"FIPS certified" solely because this backend is selected.
"""

from __future__ import annotations

import base64
import importlib
from functools import lru_cache
from typing import Any, Protocol, runtime_checkable

from app.core.pqc import (
    DEFAULT_DSA_ALG,
    DEFAULT_KEM_ALG,
    ML_DSA_SPECS,
    ML_KEM_SPECS,
    ml_dsa_keygen as _custom_dsa_keygen,
    ml_dsa_sign as _custom_dsa_sign,
    ml_dsa_verify as _custom_dsa_verify,
    ml_kem_decapsulate as _custom_kem_decapsulate,
    ml_kem_encapsulate as _custom_kem_encapsulate,
    ml_kem_keygen as _custom_kem_keygen,
    normalize_dsa_alg,
    normalize_kem_alg,
    run_pqc_benchmark as _custom_run_pqc_benchmark,
    simulate_quantum_rsa_attack as _custom_simulate_quantum_rsa_attack,
)


class PqcBackendError(RuntimeError):
    """Base class for PQC backend selection and availability failures."""


class PqcBackendUnavailable(PqcBackendError):
    """Raised when the selected backend's dependency is not installed."""


class PqcOperationUnsupported(PqcBackendError):
    """Raised when a backend cannot safely perform a requested operation."""


@runtime_checkable
class PqcBackend(Protocol):
    """Common interface implemented by every PQC backend."""

    name: str
    description: str
    is_fips_203_204: bool
    fips_validated: bool
    supports_seeded_keygen: bool
    interoperable_with_flutter_client: bool

    def kem_keygen(
        self, alg: str = DEFAULT_KEM_ALG, seed: bytes | None = None
    ) -> dict[str, str]: ...

    def kem_encapsulate(
        self,
        public_key_b64: str,
        alg: str | None = None,
        coin: bytes | None = None,
    ) -> dict[str, str]: ...

    def kem_decapsulate(
        self,
        ciphertext_b64: str,
        secret_key_b64: str,
        alg: str | None = None,
    ) -> bytes: ...

    def dsa_keygen(
        self, alg: str = DEFAULT_DSA_ALG, seed: bytes | None = None
    ) -> dict[str, str]: ...

    def dsa_sign(
        self, message: bytes, secret_key_b64: str, alg: str | None = None
    ) -> str: ...

    def dsa_verify(
        self,
        message: bytes,
        signature_b64: str,
        public_key_b64: str,
        alg: str | None = None,
    ) -> bool: ...


# ---------------------------------------------------------------------------
# Custom prototype backend (Flutter-compatible)
# ---------------------------------------------------------------------------


class CustomPqcBackend:
    """Adapter around the original, Flutter-compatible prototype primitives."""

    name = "custom"
    description = (
        "Prototype ring-LWE/Ed25519 construction used by the current Flutter "
        "client. NOT FIPS 203/204 compliant."
    )
    is_fips_203_204 = False
    fips_validated = False
    supports_seeded_keygen = True
    interoperable_with_flutter_client = True

    def kem_keygen(
        self, alg: str = DEFAULT_KEM_ALG, seed: bytes | None = None
    ) -> dict[str, str]:
        return _custom_kem_keygen(alg, seed=seed)

    def kem_encapsulate(
        self,
        public_key_b64: str,
        alg: str | None = None,
        coin: bytes | None = None,
    ) -> dict[str, str]:
        return _custom_kem_encapsulate(public_key_b64, alg=alg, coin=coin)

    def kem_decapsulate(
        self,
        ciphertext_b64: str,
        secret_key_b64: str,
        alg: str | None = None,
    ) -> bytes:
        return _custom_kem_decapsulate(ciphertext_b64, secret_key_b64, alg)

    def dsa_keygen(
        self, alg: str = DEFAULT_DSA_ALG, seed: bytes | None = None
    ) -> dict[str, str]:
        return _custom_dsa_keygen(alg, seed=seed)

    def dsa_sign(
        self, message: bytes, secret_key_b64: str, alg: str | None = None
    ) -> str:
        return _custom_dsa_sign(message, secret_key_b64, alg)

    def dsa_verify(
        self,
        message: bytes,
        signature_b64: str,
        public_key_b64: str,
        alg: str | None = None,
    ) -> bool:
        return _custom_dsa_verify(message, signature_b64, public_key_b64, alg)


# ---------------------------------------------------------------------------
# Real FIPS 203/204 backend (PQClean via pqcrypto)
# ---------------------------------------------------------------------------

_KEM_MODULES = {
    "ML-KEM-512": "pqcrypto.kem.ml_kem_512",
    "ML-KEM-768": "pqcrypto.kem.ml_kem_768",
    "ML-KEM-1024": "pqcrypto.kem.ml_kem_1024",
}
_DSA_MODULES = {
    "ML-DSA-44": "pqcrypto.sign.ml_dsa_44",
    "ML-DSA-65": "pqcrypto.sign.ml_dsa_65",
    "ML-DSA-87": "pqcrypto.sign.ml_dsa_87",
}


def _b64encode(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def _b64decode(value: str, label: str) -> bytes:
    try:
        return base64.b64decode(value, validate=True)
    except Exception as exc:
        raise ValueError(f"Invalid Base64 {label}") from exc


def _check_length(value: bytes, expected: int, label: str) -> None:
    if len(value) != expected:
        raise ValueError(
            f"Invalid {label} length: expected {expected} bytes, got {len(value)}"
        )


@lru_cache(maxsize=None)
def _load_module(path: str):
    return importlib.import_module(path)


class PqcryptoBackend:
    """FIPS 203/204 backend backed by PQClean's ``pqcrypto`` bindings."""

    name = "pqcrypto"
    description = (
        "PQClean reference implementations of FIPS 203 ML-KEM and FIPS 204 "
        "ML-DSA (not CMVP-validated)."
    )
    is_fips_203_204 = True
    fips_validated = False
    supports_seeded_keygen = False
    interoperable_with_flutter_client = False

    def _kem_module(self, alg: str | None) -> tuple[str, Any]:
        alg_name = normalize_kem_alg(alg)
        try:
            return alg_name, _load_module(_KEM_MODULES[alg_name])
        except ImportError as exc:
            raise PqcBackendUnavailable(
                "pqcrypto is selected via PQC_BACKEND but is not installed. "
                "Install it with: pip install pqcrypto"
            ) from exc

    def _dsa_module(self, alg: str | None) -> tuple[str, Any]:
        alg_name = normalize_dsa_alg(alg)
        try:
            return alg_name, _load_module(_DSA_MODULES[alg_name])
        except ImportError as exc:
            raise PqcBackendUnavailable(
                "pqcrypto is selected via PQC_BACKEND but is not installed. "
                "Install it with: pip install pqcrypto"
            ) from exc

    @staticmethod
    def _reject_seed(operation: str, seed: bytes | None) -> None:
        if seed is not None:
            raise PqcOperationUnsupported(
                f"The pqcrypto backend cannot perform deterministic seeded "
                f"{operation}. FIPS 203/204 key generation is randomized; "
                "derive-on-demand keys would not be recoverable and would "
                "silently break decryption. Supply client-generated public "
                "keys (keeping private keys on the device) or use "
                "PQC_BACKEND=custom for prototype interoperability."
            )

    def kem_keygen(
        self, alg: str = DEFAULT_KEM_ALG, seed: bytes | None = None
    ) -> dict[str, str]:
        self._reject_seed("ML-KEM key generation", seed)
        alg_name, module = self._kem_module(alg)
        public_key, secret_key = module.keygen()
        return {
            "alg": alg_name,
            "public_key": _b64encode(public_key),
            "secret_key": _b64encode(secret_key),
            # Randomized key generation has no reproducible seed to return.
            "seed": "",
        }

    def kem_encapsulate(
        self,
        public_key_b64: str,
        alg: str | None = None,
        coin: bytes | None = None,
    ) -> dict[str, str]:
        if coin is not None:
            raise PqcOperationUnsupported(
                "The pqcrypto backend uses FIPS 203 randomized encapsulation; "
                "a caller-supplied coin is not supported."
            )
        alg_name, module = self._kem_module(alg)
        public_key = _b64decode(public_key_b64, f"{alg_name} public key")
        _check_length(
            public_key, ML_KEM_SPECS[alg_name]["pk_bytes"], f"{alg_name} public key"
        )
        ciphertext, shared_secret = module.encaps(public_key)
        return {
            "alg": alg_name,
            "ciphertext": _b64encode(ciphertext),
            "shared_secret": _b64encode(shared_secret),
        }

    def kem_decapsulate(
        self,
        ciphertext_b64: str,
        secret_key_b64: str,
        alg: str | None = None,
    ) -> bytes:
        alg_name, module = self._kem_module(alg)
        ciphertext = _b64decode(ciphertext_b64, f"{alg_name} ciphertext")
        secret_key = _b64decode(secret_key_b64, f"{alg_name} secret key")
        _check_length(
            ciphertext, ML_KEM_SPECS[alg_name]["ct_bytes"], f"{alg_name} ciphertext"
        )
        _check_length(
            secret_key, ML_KEM_SPECS[alg_name]["sk_bytes"], f"{alg_name} secret key"
        )
        try:
            return module.decaps(secret_key, ciphertext)
        except Exception as exc:
            raise ValueError(f"{alg_name} decapsulation failed") from exc

    def dsa_keygen(
        self, alg: str = DEFAULT_DSA_ALG, seed: bytes | None = None
    ) -> dict[str, str]:
        self._reject_seed("ML-DSA key generation", seed)
        alg_name, module = self._dsa_module(alg)
        public_key, secret_key = module.keygen()
        return {
            "alg": alg_name,
            "public_key": _b64encode(public_key),
            "secret_key": _b64encode(secret_key),
            # Randomized key generation has no reproducible seed to return.
            "seed": "",
        }

    def dsa_sign(
        self, message: bytes, secret_key_b64: str, alg: str | None = None
    ) -> str:
        alg_name, module = self._dsa_module(alg)
        secret_key = _b64decode(secret_key_b64, f"{alg_name} secret key")
        _check_length(
            secret_key, ML_DSA_SPECS[alg_name]["sk_bytes"], f"{alg_name} secret key"
        )
        signature = module.sign(secret_key, message)
        return _b64encode(signature)

    def dsa_verify(
        self,
        message: bytes,
        signature_b64: str,
        public_key_b64: str,
        alg: str | None = None,
    ) -> bool:
        try:
            alg_name, module = self._dsa_module(alg)
            signature = _b64decode(signature_b64, f"{alg_name} signature")
            public_key = _b64decode(public_key_b64, f"{alg_name} public key")
            _check_length(
                signature, ML_DSA_SPECS[alg_name]["sig_bytes"], f"{alg_name} signature"
            )
            _check_length(
                public_key, ML_DSA_SPECS[alg_name]["pk_bytes"], f"{alg_name} public key"
            )
            # pqcrypto returns None on success and raises on failure.
            module.verify(public_key, message, signature)
            return True
        except PqcBackendError:
            # Missing dependency / bad backend configuration must not be
            # silently reported as an invalid signature.
            raise
        except Exception:
            return False


# ---------------------------------------------------------------------------
# Backend registry and façade
# ---------------------------------------------------------------------------

_BACKEND_CLASSES = {
    "custom": CustomPqcBackend,
    "pqcrypto": PqcryptoBackend,
}
_BACKEND_ALIASES = {
    "prototype": "custom",
    "legacy": "custom",
    "real": "pqcrypto",
    "fips": "pqcrypto",
    "pqclean": "pqcrypto",
}


def _configured_backend_name() -> str:
    """Return the selected backend, preferring application settings.

    Falls back to the ``PQC_BACKEND`` environment variable so this module stays
    importable in standalone backend-conformance tests that run without the
    full application dependency set installed.
    """
    try:
        from app.core.config import settings
    except ModuleNotFoundError:
        import os

        return (os.getenv("PQC_BACKEND") or "custom").strip().lower()
    return (settings.pqc_backend or "custom").strip().lower()


def _resolve_backend_name(name: str | None) -> str:
    raw = name if name is not None else _configured_backend_name()
    key = (raw or "custom").strip().lower()
    return _BACKEND_ALIASES.get(key, key)


@lru_cache(maxsize=None)
def _backend_for_key(key: str) -> PqcBackend:
    backend_class = _BACKEND_CLASSES.get(key)
    if backend_class is None:
        supported = ", ".join(sorted(_BACKEND_CLASSES))
        raise PqcBackendError(
            f"Unknown PQC backend '{key}'. Supported backends: {supported}"
        )
    return backend_class()


def get_pqc_backend(name: str | None = None) -> PqcBackend:
    """Return the selected backend.

    ``name`` overrides ``settings.pqc_backend`` (useful for tests and
    diagnostics). The selected backend is not imported until a method is called,
    so the default ``custom`` backend works without ``pqcrypto`` installed.
    """
    return _backend_for_key(_resolve_backend_name(name))


@lru_cache(maxsize=1)
def pqcrypto_available() -> bool:
    """Return whether the optional real PQC dependency can be imported."""
    try:
        _load_module(_KEM_MODULES["ML-KEM-768"])
        _load_module(_DSA_MODULES["ML-DSA-65"])
        return True
    except Exception:
        return False


def _backend_metadata(name: str) -> dict[str, Any]:
    backend = _BACKEND_CLASSES[name]()
    return {
        "name": backend.name,
        "description": backend.description,
        "is_fips_203_204": backend.is_fips_203_204,
        "fips_validated": backend.fips_validated,
        "supports_seeded_keygen": backend.supports_seeded_keygen,
        "interoperable_with_flutter_client": (
            backend.interoperable_with_flutter_client
        ),
        "available": True if name == "custom" else pqcrypto_available(),
    }


def get_pqc_backend_info(name: str | None = None) -> dict[str, Any]:
    """Return metadata for the active backend (without exposing key material)."""
    backend = get_pqc_backend(name)
    info = _backend_metadata(backend.name)
    info["active"] = True
    return info


def get_pqc_backend_catalog() -> dict[str, Any]:
    """Return configuration and availability for every known backend."""
    configured = _configured_backend_name()
    active: str | None = None
    configuration_error: str | None = None
    try:
        active = get_pqc_backend().name
    except PqcBackendError as exc:
        configuration_error = str(exc)

    return {
        "configured": configured,
        "active": active,
        "configuration_error": configuration_error,
        "backends": [_backend_metadata(name) for name in _BACKEND_CLASSES],
        "note": (
            "The custom backend is a prototype and is NOT FIPS 203/204 "
            "compliant. The pqcrypto backend implements the standards but "
            "uses randomized key generation, so legacy seed-derived key flows "
            "must migrate to client-generated keys before it can be enabled."
        ),
    }


# ---------------------------------------------------------------------------
# Façade functions matching the historical app.core.pqc signatures
# ---------------------------------------------------------------------------


def ml_kem_keygen(
    alg: str = DEFAULT_KEM_ALG, seed: bytes | None = None
) -> dict[str, str]:
    return get_pqc_backend().kem_keygen(alg, seed)


def ml_kem_encapsulate(
    public_key_b64: str,
    alg: str | None = None,
    coin: bytes | None = None,
) -> dict[str, str]:
    return get_pqc_backend().kem_encapsulate(public_key_b64, alg, coin)


def ml_kem_decapsulate(
    ciphertext_b64: str,
    secret_key_b64: str,
    alg: str | None = None,
) -> bytes:
    return get_pqc_backend().kem_decapsulate(ciphertext_b64, secret_key_b64, alg)


def ml_dsa_keygen(
    alg: str = DEFAULT_DSA_ALG, seed: bytes | None = None
) -> dict[str, str]:
    return get_pqc_backend().dsa_keygen(alg, seed)


def ml_dsa_sign(
    message: bytes, secret_key_b64: str, alg: str | None = None
) -> str:
    return get_pqc_backend().dsa_sign(message, secret_key_b64, alg)


def ml_dsa_verify(
    message: bytes,
    signature_b64: str,
    public_key_b64: str,
    alg: str | None = None,
) -> bool:
    return get_pqc_backend().dsa_verify(
        message, signature_b64, public_key_b64, alg
    )


def run_pqc_benchmark() -> dict[str, Any]:
    """Benchmark the active backend, not just the custom prototype engine."""
    return _custom_run_pqc_benchmark(get_pqc_backend())


def simulate_quantum_rsa_attack(**kwargs: Any) -> dict[str, Any]:
    """Run the lab simulation, using the active backend for its PQC comparison."""
    return _custom_simulate_quantum_rsa_attack(
        backend=get_pqc_backend(), **kwargs
    )


__all__ = [
    "DEFAULT_DSA_ALG",
    "DEFAULT_KEM_ALG",
    "ML_DSA_SPECS",
    "ML_KEM_SPECS",
    "CustomPqcBackend",
    "PqcBackend",
    "PqcBackendError",
    "PqcBackendUnavailable",
    "PqcOperationUnsupported",
    "PqcryptoBackend",
    "get_pqc_backend",
    "get_pqc_backend_catalog",
    "get_pqc_backend_info",
    "ml_dsa_keygen",
    "ml_dsa_sign",
    "ml_dsa_verify",
    "ml_kem_decapsulate",
    "ml_kem_encapsulate",
    "ml_kem_keygen",
    "normalize_dsa_alg",
    "normalize_kem_alg",
    "pqcrypto_available",
    "run_pqc_benchmark",
    "simulate_quantum_rsa_attack",
]
