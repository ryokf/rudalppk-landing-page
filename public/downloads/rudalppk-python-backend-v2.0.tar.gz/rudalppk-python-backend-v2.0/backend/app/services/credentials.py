import hashlib
import secrets
import string

# Ambiguous characters (0/O, 1/I/L) are intentionally excluded so activation
# codes can be read aloud or copied by hand.
_CODE_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"


def generate_activation_code() -> str:
    groups = [
        "".join(secrets.choice(_CODE_ALPHABET) for _ in range(4))
        for _ in range(4)
    ]
    return "SFC-" + "-".join(groups)


def normalize_activation_code(code: str) -> str:
    allowed = set(_CODE_ALPHABET)
    return "".join(
        character
        for character in code.strip().upper()
        if character in allowed
    )


def hash_activation_code(code: str) -> str:
    return hashlib.sha256(normalize_activation_code(code).encode("utf-8")).hexdigest()
