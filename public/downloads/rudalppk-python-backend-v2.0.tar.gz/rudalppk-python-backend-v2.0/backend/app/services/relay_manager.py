import json
import logging
import uuid
from typing import Dict, Set
from fastapi import WebSocket

logger = logging.getLogger(__name__)


class WebSocketRelayManager:
    """Manages active WebSocket connections for realtime ciphertext relay notification."""

    def __init__(self):
        # Maps device_id -> set of active WebSockets
        self._device_connections: Dict[uuid.UUID, Set[WebSocket]] = {}
        # Maps identity_id -> set of active WebSockets
        self._identity_connections: Dict[uuid.UUID, Set[WebSocket]] = {}

    async def connect(self, device_id: uuid.UUID, identity_id: uuid.UUID, websocket: WebSocket):
        await websocket.accept()
        if device_id not in self._device_connections:
            self._device_connections[device_id] = set()
        self._device_connections[device_id].add(websocket)

        if identity_id not in self._identity_connections:
            self._identity_connections[identity_id] = set()
        self._identity_connections[identity_id].add(websocket)
        logger.info(f"WebSocket connected: device={device_id}, identity={identity_id}")

    def disconnect(self, device_id: uuid.UUID, identity_id: uuid.UUID, websocket: WebSocket):
        if device_id in self._device_connections:
            self._device_connections[device_id].discard(websocket)
            if not self._device_connections[device_id]:
                del self._device_connections[device_id]

        if identity_id in self._identity_connections:
            self._identity_connections[identity_id].discard(websocket)
            if not self._identity_connections[identity_id]:
                del self._identity_connections[identity_id]
        logger.info(f"WebSocket disconnected: device={device_id}")

    async def notify_devices(self, device_ids: list[uuid.UUID], event: str, data: dict):
        """Send notification event to specified devices if they are currently online."""
        payload = json.dumps({
            "event": event,
            "data": data
        })

        for device_id in device_ids:
            connections = self._device_connections.get(device_id, set())
            for ws in list(connections):
                try:
                    await ws.send_text(payload)
                except Exception as exc:
                    logger.warning(f"Failed to send to device {device_id}: {exc}")
                    connections.discard(ws)


# Global singleton instance
relay_manager = WebSocketRelayManager()
