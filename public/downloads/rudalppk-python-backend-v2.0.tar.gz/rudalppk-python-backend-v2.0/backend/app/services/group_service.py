import uuid
from datetime import datetime, timezone

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.dependencies import Principal
from app.models.conversation import Conversation, ConversationMember
from app.models.device import Device
from app.models.group_event import GroupMembershipEvent
from app.services.relay_manager import relay_manager


async def load_conversation(
    db: AsyncSession,
    conversation_id: uuid.UUID,
) -> Conversation | None:
    stmt = (
        select(Conversation)
        .where(Conversation.conversation_id == conversation_id)
        .options(selectinload(Conversation.members))
    )
    return (await db.execute(stmt)).scalar_one_or_none()


def active_members(conversation: Conversation) -> list[ConversationMember]:
    return [member for member in conversation.members if member.left_at is None]


def find_membership(
    conversation: Conversation,
    identity_id: uuid.UUID | None,
) -> ConversationMember | None:
    if identity_id is None:
        return None
    for member in conversation.members:
        if member.identity_id == identity_id and member.left_at is None:
            return member
    return None


def is_organization_admin_for(
    principal: Principal,
    conversation: Conversation,
) -> bool:
    return (
        principal.is_admin
        and conversation.conversation_type == "group"
        and principal.organization_id is not None
        and conversation.organization_id == principal.organization_id
    )


def is_group_admin_for(
    principal: Principal,
    conversation: Conversation,
) -> bool:
    if not principal.is_device:
        return False
    membership = find_membership(conversation, principal.identity_id)
    return membership is not None and membership.member_role == "admin"


async def require_group_access(
    db: AsyncSession,
    conversation_id: uuid.UUID,
    principal: Principal,
    *,
    require_manage: bool = False,
) -> tuple[Conversation, ConversationMember | None]:
    """Load a group and enforce organization/membership authorization."""
    conversation = await load_conversation(db, conversation_id)

    if not conversation or conversation.conversation_type != "group":
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "GROUP_NOT_FOUND",
                "message": "Group not found",
            },
        )

    if principal.organization_id != conversation.organization_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "ORGANIZATION_ISOLATION",
                "message": "This group belongs to another organization",
            },
        )

    membership = find_membership(conversation, principal.identity_id)
    can_manage = is_organization_admin_for(principal, conversation) or (
        membership is not None and membership.member_role == "admin"
    )

    if principal.is_admin:
        # Organization admins can see and manage groups, but they are not
        # conversation members and cannot read or send messages.
        return conversation, membership

    if membership is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "NOT_A_MEMBER",
                "message": "You are not an active member of this group",
            },
        )

    if require_manage and not can_manage:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "GROUP_ADMIN_REQUIRED",
                "message": "Only a group administrator can perform this action",
            },
        )

    return conversation, membership


def record_event(
    db: AsyncSession,
    conversation: Conversation,
    action: str,
    *,
    identity_id: uuid.UUID | None,
    actor_type: str,
    actor_id: uuid.UUID | None,
) -> None:
    db.add(
        GroupMembershipEvent(
            conversation_id=conversation.conversation_id,
            identity_id=identity_id,
            action=action,
            actor_type=actor_type,
            actor_id=actor_id,
            key_epoch=conversation.key_epoch,
        )
    )


def bump_key_epoch(conversation: Conversation) -> None:
    conversation.key_epoch = int(conversation.key_epoch or 1) + 1


async def ensure_group_admin(
    db: AsyncSession,
    conversation: Conversation,
    *,
    excluding_identity_id: uuid.UUID | None = None,
) -> None:
    """Promote the earliest-joined remaining member if no group admin is left."""
    remaining = [
        member
        for member in active_members(conversation)
        if member.identity_id != excluding_identity_id
    ]
    if not remaining:
        return

    if any(member.member_role == "admin" for member in remaining):
        return

    remaining.sort(key=lambda member: member.joined_at)
    remaining[0].member_role = "admin"
    record_event(
        db,
        conversation,
        "role_promoted",
        identity_id=remaining[0].identity_id,
        actor_type="system",
        actor_id=None,
    )


async def notify_membership_changed(
    db: AsyncSession,
    conversation: Conversation,
) -> None:
    """Tell all active member devices to refresh their member/key-epoch state."""
    member_ids = [member.identity_id for member in active_members(conversation)]
    if not member_ids:
        return

    device_stmt = select(Device.device_id).where(
        Device.identity_id.in_(member_ids),
        Device.status == "active",
    )
    device_ids = list((await db.execute(device_stmt)).scalars().all())
    if not device_ids:
        return

    await relay_manager.notify_devices(
        device_ids=device_ids,
        event="group_membership_changed",
        data={
            "group_id": str(conversation.conversation_id),
            "key_epoch": conversation.key_epoch,
        },
    )


def actor_fields(principal: Principal) -> tuple[str, uuid.UUID | None]:
    if principal.is_admin:
        return "admin", principal.admin.admin_id if principal.admin else None
    return "identity", principal.identity_id


def utcnow() -> datetime:
    return datetime.now(timezone.utc)
