import uuid
from datetime import datetime, timezone

from sqlalchemy import DateTime, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class SignedArtifact(Base):
    """PERISAI-Sign: ML-DSA signed command instructions, OT/IoT firmware packages, and field reports."""

    __tablename__ = "signed_artifacts"

    artifact_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
    )

    organization_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organizations.organization_id", ondelete="CASCADE"),
        nullable=True,
        index=True,
    )

    artifact_type: Mapped[str] = mapped_column(
        String(40),
        nullable=False,
        default="command_instruction",
    )

    title: Mapped[str] = mapped_column(
        String(200),
        nullable=False,
    )

    content_text: Mapped[str] = mapped_column(
        Text,
        nullable=False,
    )

    content_hash_sha256: Mapped[str] = mapped_column(
        String(128),
        nullable=False,
    )

    algorithm: Mapped[str] = mapped_column(
        String(30),
        nullable=False,
        default="ML-DSA-65",
    )

    signature_b64: Mapped[str] = mapped_column(
        Text,
        nullable=False,
    )

    signer_type: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
        default="admin",
    )

    signer_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False,
    )

    signer_display_name: Mapped[str] = mapped_column(
        String(150),
        nullable=False,
        default="Authorized Commander",
    )

    signer_public_key_b64: Mapped[str] = mapped_column(
        Text,
        nullable=False,
    )

    metadata_json: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
        default=None,
    )

    status: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
        default="active",
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False,
        index=True,
    )

    revoked_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        default=None,
    )


class PqcAuditLog(Base):
    """PERISAI-Sign & PERISAI-Lab audit trail for verification outcomes and quantum simulations."""

    __tablename__ = "pqc_audit_logs"

    log_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
    )

    organization_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organizations.organization_id", ondelete="CASCADE"),
        nullable=True,
        index=True,
    )

    event_type: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        index=True,
    )

    algorithm: Mapped[str] = mapped_column(
        String(80),
        nullable=False,
        default="ML-DSA-65",
    )

    status: Mapped[str] = mapped_column(
        String(40),
        nullable=False,
        default="VALID",
    )

    actor_name: Mapped[str] = mapped_column(
        String(150),
        nullable=False,
        default="System",
    )

    target_id: Mapped[str | None] = mapped_column(
        String(200),
        nullable=True,
        default=None,
    )

    details_json: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
        default=None,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False,
        index=True,
    )

