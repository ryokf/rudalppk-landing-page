import uuid
from datetime import datetime, timezone

from sqlalchemy import String, DateTime, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class Identity(Base):
    __tablename__ = "identities"

    identity_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4
    )

    organization_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organizations.organization_id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )

    public_identity: Mapped[str] = mapped_column(
        String,
        unique=True,
        nullable=False
    )

    identity_fingerprint: Mapped[str] = mapped_column(
        String(128),
        unique=True,
        nullable=False
    )

    display_name: Mapped[str | None] = mapped_column(
        String(150),
        nullable=True,
        default=None,
    )

    status: Mapped[str] = mapped_column(
        String(20),
        default="active"
    )

    provisioned_by_admin_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("organization_admins.admin_id", ondelete="SET NULL"),
        nullable=True,
        default=None,
    )

    activated_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        default=None,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc)
    )
