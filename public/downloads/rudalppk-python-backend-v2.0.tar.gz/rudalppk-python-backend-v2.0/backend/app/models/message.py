import uuid
from datetime import datetime, timezone

from sqlalchemy import String, DateTime, ForeignKey, UniqueConstraint, LargeBinary, Integer
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base


class Message(Base):
    __tablename__ = "messages"
    __table_args__ = (
        UniqueConstraint("sender_device_id", "client_message_id", name="uq_sender_device_client_message"),
    )

    message_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4
    )

    conversation_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("conversations.conversation_id", ondelete="CASCADE"),
        nullable=False,
        index=True
    )

    sender_device_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("devices.device_id", ondelete="CASCADE"),
        nullable=False,
        index=True
    )

    client_message_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        nullable=False
    )

    protocol_version: Mapped[str] = mapped_column(
        String(30),
        nullable=False
    )

    key_epoch: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=1,
    )

    message_type: Mapped[str] = mapped_column(
        String(20),
        default="text",
        nullable=False
    )

    # Stored strictly as raw ciphertext binary (Zero-Knowledge)
    ciphertext: Mapped[bytes] = mapped_column(
        LargeBinary,
        nullable=False
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False,
        index=True
    )

    expires_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        default=None,
        index=True
    )

    receipts = relationship("DeliveryReceipt", back_populates="message", cascade="all, delete-orphan")


class DeliveryReceipt(Base):
    __tablename__ = "delivery_receipts"
    __table_args__ = (
        UniqueConstraint("message_id", "recipient_device_id", name="uq_message_recipient_device"),
    )

    receipt_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4
    )

    message_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("messages.message_id", ondelete="CASCADE"),
        nullable=False,
        index=True
    )

    recipient_device_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("devices.device_id", ondelete="CASCADE"),
        nullable=False,
        index=True
    )

    delivery_status: Mapped[str] = mapped_column(
        String(20),
        default="pending",
        nullable=False
    )

    delivered_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        default=None
    )

    read_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        default=None
    )

    message = relationship("Message", back_populates="receipts")
