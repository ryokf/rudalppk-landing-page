import uuid
from datetime import datetime, timezone

from sqlalchemy import String, DateTime, ForeignKey, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class DevicePrekey(Base):
    __tablename__ = "device_prekeys"
    __table_args__ = (
        UniqueConstraint("device_id", "key_identifier", name="uq_device_prekey_identifier"),
    )

    prekey_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4
    )

    device_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("devices.device_id", ondelete="CASCADE"),
        nullable=False,
        index=True
    )

    prekey_type: Mapped[str] = mapped_column(
        String(30),
        nullable=False
    )

    key_identifier: Mapped[str] = mapped_column(
        String(100),
        nullable=False
    )

    public_key: Mapped[str] = mapped_column(
        String,
        nullable=False
    )

    signature: Mapped[str | None] = mapped_column(
        String,
        nullable=True,
        default=None
    )

    consumed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        default=None
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        nullable=False
    )
