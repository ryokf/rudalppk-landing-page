import uuid
from datetime import datetime, timezone

from sqlalchemy import String, DateTime, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class Device(Base):
    __tablename__ = "devices"

    device_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4
    )

    identity_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("identities.identity_id"),
        nullable=False
    )

    device_name: Mapped[str] = mapped_column(
        String(100)
    )

    public_device_key: Mapped[str] = mapped_column(
        String,
        nullable=False
    )

    auth_public_key: Mapped[str] = mapped_column(
        String,
        nullable=False
    )

    pqc_kem_alg: Mapped[str | None] = mapped_column(
        String(30),
        nullable=True,
        default="ML-KEM-768",
    )

    pqc_kem_public_key: Mapped[str | None] = mapped_column(
        String,
        nullable=True,
        default=None,
    )

    pqc_dsa_alg: Mapped[str | None] = mapped_column(
        String(30),
        nullable=True,
        default="ML-DSA-65",
    )

    pqc_dsa_public_key: Mapped[str | None] = mapped_column(
        String,
        nullable=True,
        default=None,
    )

    status: Mapped[str] = mapped_column(
        String(20),
        default="active"
    )

    registered_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc)
    )

    revoked_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        default=None
    )