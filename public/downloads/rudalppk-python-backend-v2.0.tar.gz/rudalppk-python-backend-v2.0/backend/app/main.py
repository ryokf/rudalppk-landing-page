from contextlib import asynccontextmanager
from datetime import datetime, timezone

from fastapi import FastAPI, Request, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from sqlalchemy import text, select

from app.core.config import settings
from app.core.database import engine, Base, AsyncSessionLocal
from app.core.pqc_backend import (
    PqcBackendError,
    PqcBackendUnavailable,
    PqcOperationUnsupported,
)
from app.core.security import hash_password
import app.models  # noqa: F401 - ensure all models are registered with Base.metadata
from app.models.identity import Identity
from app.models.organization import Organization, OrganizationAdmin
from app.routers import (
    identity,
    auth,
    devices,
    contacts,
    conversations,
    messages,
    media,
    relay,
    activation,
    organization,
    directory,
    groups,
    perisai_sign,
    perisai_lab,
)


async def _run_idempotent_migrations(conn) -> None:
    """Add columns introduced in SAD v2.0 & PERISAI-Q to an existing database."""
    await conn.execute(text("CREATE EXTENSION IF NOT EXISTS pgcrypto;"))

    # Ensure signed_artifacts and pqc_audit_logs match the latest PERISAI-Q schema
    for tbl, required_col in [
        ("signed_artifacts", "content_text"),
        ("pqc_audit_logs", "actor_name"),
    ]:
        tbl_exists = (
            await conn.execute(
                text(
                    """
                    SELECT 1 FROM information_schema.tables
                    WHERE table_name = :table_name
                    """
                ),
                {"table_name": tbl},
            )
        ).first()
        if tbl_exists:
            col_exists = (
                await conn.execute(
                    text(
                        """
                        SELECT 1 FROM information_schema.columns
                        WHERE table_name = :table_name
                          AND column_name = :column_name
                        """
                    ),
                    {"table_name": tbl, "column_name": required_col},
                )
            ).first()
            if not col_exists:
                await conn.execute(text(f"DROP TABLE IF EXISTS {tbl} CASCADE;"))

    await conn.run_sync(Base.metadata.create_all)

    column_migrations = [
        (
            "identities",
            "organization_id",
            "ADD COLUMN IF NOT EXISTS organization_id UUID",
        ),
        (
            "identities",
            "display_name",
            "ADD COLUMN IF NOT EXISTS display_name VARCHAR(150)",
        ),
        (
            "identities",
            "provisioned_by_admin_id",
            "ADD COLUMN IF NOT EXISTS provisioned_by_admin_id UUID",
        ),
        (
            "identities",
            "activated_at",
            "ADD COLUMN IF NOT EXISTS activated_at TIMESTAMPTZ",
        ),
        (
            "conversations",
            "organization_id",
            "ADD COLUMN IF NOT EXISTS organization_id UUID",
        ),
        (
            "conversations",
            "key_epoch",
            "ADD COLUMN IF NOT EXISTS key_epoch INTEGER NOT NULL DEFAULT 1",
        ),
        (
            "messages",
            "key_epoch",
            "ADD COLUMN IF NOT EXISTS key_epoch INTEGER NOT NULL DEFAULT 1",
        ),
        (
            "devices",
            "auth_public_key",
            "ADD COLUMN IF NOT EXISTS auth_public_key TEXT NOT NULL DEFAULT ''",
        ),
        (
            "devices",
            "pqc_kem_alg",
            "ADD COLUMN IF NOT EXISTS pqc_kem_alg VARCHAR(30) NOT NULL DEFAULT 'ML-KEM-768'",
        ),
        (
            "devices",
            "pqc_kem_public_key",
            "ADD COLUMN IF NOT EXISTS pqc_kem_public_key TEXT",
        ),
        (
            "devices",
            "pqc_dsa_alg",
            "ADD COLUMN IF NOT EXISTS pqc_dsa_alg VARCHAR(30) NOT NULL DEFAULT 'ML-DSA-65'",
        ),
        (
            "devices",
            "pqc_dsa_public_key",
            "ADD COLUMN IF NOT EXISTS pqc_dsa_public_key TEXT",
        ),
        (
            "organizations",
            "pqc_kem_alg",
            "ADD COLUMN IF NOT EXISTS pqc_kem_alg VARCHAR(30) NOT NULL DEFAULT 'ML-KEM-768'",
        ),
        (
            "organizations",
            "pqc_dsa_alg",
            "ADD COLUMN IF NOT EXISTS pqc_dsa_alg VARCHAR(30) NOT NULL DEFAULT 'ML-DSA-65'",
        ),
        (
            "organization_admins",
            "pqc_kem_alg",
            "ADD COLUMN IF NOT EXISTS pqc_kem_alg VARCHAR(30) NOT NULL DEFAULT 'ML-KEM-768'",
        ),
        (
            "organization_admins",
            "pqc_dsa_alg",
            "ADD COLUMN IF NOT EXISTS pqc_dsa_alg VARCHAR(30) NOT NULL DEFAULT 'ML-DSA-65'",
        ),
    ]

    for table, column, statement in column_migrations:
        exists = (
            await conn.execute(
                text(
                    """
                    SELECT 1
                    FROM information_schema.columns
                    WHERE table_name = :table_name
                      AND column_name = :column_name
                    """
                ),
                {"table_name": table, "column_name": column},
            )
        ).first()
        if not exists:
            await conn.execute(text(f"ALTER TABLE {table} {statement};"))


async def _bootstrap_organization() -> None:
    """Optionally seed the first organization and owner administrator."""
    if not (
        settings.bootstrap_organization_name
        and settings.bootstrap_admin_email
        and settings.bootstrap_admin_password
    ):
        return

    async with AsyncSessionLocal() as db:
        organization = (
            await db.execute(
                select(Organization).where(
                    Organization.organization_name
                    == settings.bootstrap_organization_name
                )
            )
        ).scalar_one_or_none()

        if not organization:
            organization = Organization(
                organization_name=settings.bootstrap_organization_name,
                status="active",
            )
            db.add(organization)
            await db.flush()

        admin = (
            await db.execute(
                select(OrganizationAdmin).where(
                    OrganizationAdmin.email == settings.bootstrap_admin_email.lower()
                )
            )
        ).scalar_one_or_none()

        if not admin:
            admin = OrganizationAdmin(
                organization_id=organization.organization_id,
                email=settings.bootstrap_admin_email.lower(),
                display_name=settings.bootstrap_admin_display_name,
                password_hash=hash_password(settings.bootstrap_admin_password),
                role="owner",
                status="active",
                created_at=datetime.now(timezone.utc),
            )
            db.add(admin)

        if settings.bootstrap_backfill_legacy_identities:
            await db.execute(
                text(
                    """
                    UPDATE identities
                    SET organization_id = :organization_id
                    WHERE organization_id IS NULL
                    """
                ),
                {"organization_id": str(organization.organization_id)},
            )

        await db.commit()


@asynccontextmanager
async def lifespan(app: FastAPI):
    async with engine.begin() as conn:
        await _run_idempotent_migrations(conn)
    await _bootstrap_organization()
    yield


app = FastAPI(
    title="Secure Field Communication API",
    version="2.0.0",
    lifespan=lifespan,
)

# Enable CORS for Flutter Web and Mobile clients
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Standard envelope error handling
@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    if isinstance(exc.detail, dict):
        code = exc.detail.get("code", "ERROR")
        message = exc.detail.get("message", "An error occurred")
        details = exc.detail.get("details")
    else:
        code = "HTTP_ERROR"
        message = str(exc.detail)
        details = None

    error: dict = {"code": code, "message": message}
    if details is not None:
        error["details"] = details

    return JSONResponse(
        status_code=exc.status_code,
        content={
            "success": False,
            "data": None,
            "error": error,
        },
    )


@app.exception_handler(PqcBackendError)
async def pqc_backend_exception_handler(request: Request, exc: PqcBackendError):
    """Return a clear API error instead of a generic 500 for backend issues."""
    if isinstance(exc, PqcOperationUnsupported):
        status_code = status.HTTP_501_NOT_IMPLEMENTED
        code = "PQC_OPERATION_UNSUPPORTED"
    elif isinstance(exc, PqcBackendUnavailable):
        status_code = status.HTTP_503_SERVICE_UNAVAILABLE
        code = "PQC_BACKEND_UNAVAILABLE"
    else:
        status_code = status.HTTP_503_SERVICE_UNAVAILABLE
        code = "PQC_BACKEND_ERROR"

    return JSONResponse(
        status_code=status_code,
        content={
            "success": False,
            "data": None,
            "error": {
                "code": code,
                "message": str(exc),
            },
        },
    )


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={
            "success": False,
            "data": None,
            "error": {
                "code": "INVALID_REQUEST",
                "message": "Request validation failed",
                "details": exc.errors(),
            },
        },
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "success": False,
            "data": None,
            "error": {
                "code": "INTERNAL_SERVER_ERROR",
                "message": str(exc),
            },
        },
    )


# Register all routers
app.include_router(identity.router)
app.include_router(auth.router)
app.include_router(activation.router)
app.include_router(organization.router)
app.include_router(directory.router)
app.include_router(groups.router)
app.include_router(devices.router)
app.include_router(contacts.router)
app.include_router(conversations.router)
app.include_router(messages.router)
app.include_router(media.router)
app.include_router(relay.router)
app.include_router(perisai_sign.router)
app.include_router(perisai_lab.router)


@app.get("/")
async def root():
    return {
        "application": "Secure Field Communication",
        "version": "2.0.0",
        "status": "running",
    }


@app.get("/health")
async def health():
    return {
        "status": "healthy",
        "version": "2.0.0",
    }
