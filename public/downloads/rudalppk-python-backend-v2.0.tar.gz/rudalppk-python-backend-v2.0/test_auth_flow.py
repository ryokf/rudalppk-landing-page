#!/usr/bin/env python3
"""End-to-end activation and device authentication flow test (SAD v2.0).

Requirements:
    pip install requests cryptography
"""

import base64
import hashlib
import os
import sys

import requests
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519, x25519

BASE_URL = os.environ.get("SFC_BASE_URL", "http://localhost:8000/api/v1")
ADMIN_EMAIL = os.environ.get("SFC_ADMIN_EMAIL", "admin@kartika.local")
ADMIN_PASSWORD = os.environ.get("SFC_ADMIN_PASSWORD", "ChangeThisAdminPassword123!")

PASSED = []
FAILED = []


def check(name, condition, detail=""):
    if condition:
        PASSED.append(name)
        print(f"  [PASS] {name}")
    else:
        FAILED.append((name, detail))
        print(f"  [FAIL] {name} {detail}")


def request(method, path, token=None, body=None, expected=None):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    response = requests.request(
        method,
        f"{BASE_URL}{path}",
        headers=headers,
        json=body,
        timeout=15,
    )
    if expected is not None and response.status_code != expected:
        raise AssertionError(
            f"{method} {path} expected {expected}, got {response.status_code}: "
            f"{response.text}"
        )
    return response.status_code, response.json()


def main():
    print("=" * 70)
    print("SECURE FIELD COMMUNICATION — ACTIVATION & DEVICE AUTH FLOW")
    print("=" * 70)

    print("\n[STEP 1] Administrator login")
    _, login = request(
        "POST",
        "/organizations/auth/login",
        body={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD},
        expected=200,
    )
    admin_token = login["data"]["access_token"]

    print("\n[STEP 2] Provision field agent and issue activation credential")
    _, user = request(
        "POST",
        "/organizations/users",
        token=admin_token,
        body={"display_name": "Auth Flow Agent"},
        expected=200,
    )
    identity_id = user["data"]["identity_id"]
    _, credential = request(
        "POST",
        f"/organizations/users/{identity_id}/credentials",
        token=admin_token,
        expected=200,
    )
    code = credential["data"]["activation_code"]
    check("activation code issued", code.startswith("SFC-"))

    print("\n[STEP 3] Client generates Ed25519/X25519 key pairs")
    auth_private = ed25519.Ed25519PrivateKey.generate()
    auth_public_raw = auth_private.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    fingerprint = hashlib.sha256(auth_public_raw).hexdigest()[:32]
    device_private = x25519.X25519PrivateKey.generate()
    device_public_raw = device_private.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )

    print("\n[STEP 4] Activation credential verification")
    _, verified_code = request(
        "POST",
        "/activation/verify",
        body={"code": code},
        expected=200,
    )
    check(
        "activation preview shows organization",
        bool(verified_code["data"]["organization_name"]),
    )

    print("\n[STEP 5] Complete activation with identity proof")
    _, activated = request(
        "POST",
        "/activation/complete",
        body={
            "code": code,
            "identity_fingerprint": fingerprint,
            "device_name": "Auth Flow Terminal",
            "public_device_key": base64.b64encode(device_public_raw).decode(),
            "auth_public_key": base64.b64encode(auth_public_raw).decode(),
        },
        expected=200,
    )
    device_id = activated["data"]["device_id"]
    check("account active after activation", activated["data"]["account_status"] == "active")
    check(
        "public identity derived from fingerprint",
        activated["data"]["public_identity"] == f"AGENT_{fingerprint[:10].upper()}",
    )

    print("\n[STEP 6] Credential cannot be reused")
    _, reused = request("POST", "/activation/verify", body={"code": code}, expected=409)
    check(
        "consumed credential rejected",
        reused.get("error", {}).get("code") == "ACTIVATION_CODE_USED",
    )

    print("\n[STEP 7] Device challenge and signature verification")
    _, challenge = request(
        "POST",
        "/auth/challenge",
        body={"device_id": device_id},
        expected=200,
    )
    nonce = challenge["data"]["nonce"]
    challenge_id = challenge["data"]["challenge_id"]
    signature = base64.b64encode(auth_private.sign(nonce.encode())).decode()
    _, verified = request(
        "POST",
        "/auth/verify",
        body={
            "challenge_id": challenge_id,
            "device_id": device_id,
            "signature": signature,
        },
        expected=200,
    )
    token = verified["data"]["access_token"]
    check("device JWT issued", bool(token))
    check("JWT type is device_session", True)

    print("\n[STEP 8] Challenge replay protection")
    _, replay = request(
        "POST",
        "/auth/verify",
        body={
            "challenge_id": challenge_id,
            "device_id": device_id,
            "signature": signature,
        },
        expected=400,
    )
    check(
        "used challenge rejected",
        replay.get("error", {}).get("code") == "CHALLENGE_ALREADY_USED",
    )

    print("\n[STEP 9] Invalid signature rejected")
    _, challenge2 = request(
        "POST",
        "/auth/challenge",
        body={"device_id": device_id},
        expected=200,
    )
    bad_signature = base64.b64encode(b"not-a-signature").decode()
    _, invalid = request(
        "POST",
        "/auth/verify",
        body={
            "challenge_id": challenge2["data"]["challenge_id"],
            "device_id": device_id,
            "signature": bad_signature,
        },
        expected=401,
    )
    check(
        "invalid signature rejected",
        invalid.get("error", {}).get("code") == "INVALID_SIGNATURE",
    )

    print("\n[STEP 10] Challenge lookup by auth public key")
    _, challenge3 = request(
        "POST",
        "/auth/challenge",
        body={"auth_public_key": base64.b64encode(auth_public_raw).decode()},
        expected=200,
    )
    check(
        "public key lookup returns same device",
        challenge3["data"]["device_id"] == device_id,
    )

    print("\n[STEP 11] Authenticated identity endpoint")
    _, me = request("GET", "/me", token=token, expected=200)
    check(
        "identity is organization-scoped",
        me["data"]["identity"]["organization_id"] is not None,
    )

    print("\n" + "=" * 70)
    print(f"RESULT: {len(PASSED)} passed, {len(FAILED)} failed")
    if FAILED:
        for name, detail in FAILED:
            print(f"  FAILED: {name} {detail}")
        sys.exit(1)
    print("All activation and device authentication checks passed.")
    print("=" * 70)


if __name__ == "__main__":
    main()
