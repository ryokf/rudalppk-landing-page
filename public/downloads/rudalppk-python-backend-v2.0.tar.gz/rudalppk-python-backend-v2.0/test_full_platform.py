#!/usr/bin/env python3
"""SAD v2.0 integration test suite.

Covers organization provisioning, activation credentials, device
authentication, personal/group conversation separation, organization
isolation, group key epochs, authorization, and revocation.

Run against a live backend:
    pip install requests cryptography
    python3 test_full_platform.py
"""

import base64
import hashlib
import os
import sys
import uuid
from datetime import datetime

import requests
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519, x25519

BASE_URL = os.environ.get("SFC_BASE_URL", "http://localhost:8000/api/v1")
ADMIN_EMAIL = os.environ.get("SFC_ADMIN_EMAIL", "admin@kartika.local")
ADMIN_PASSWORD = os.environ.get("SFC_ADMIN_PASSWORD", "ChangeThisAdminPassword123!")

PASSED = []
FAILED = []


def check(name, condition, detail=""):
    if condition:
        PASSED.append(name)
        print(f"  [PASS] {name}")
    else:
        FAILED.append((name, detail))
        print(f"  [FAIL] {name} {detail}")


def request(method, path, token=None, body=None, expected=None):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    response = requests.request(
        method,
        f"{BASE_URL}{path}",
        headers=headers,
        json=body,
        timeout=15,
    )
    if expected is not None and response.status_code != expected:
        raise AssertionError(
            f"{method} {path} expected {expected}, got {response.status_code}: "
            f"{response.text}"
        )
    try:
        return response.status_code, response.json()
    except ValueError:
        return response.status_code, {}


def make_agent(admin_token, display_name):
    """Provision, activate and authenticate a field agent."""
    _, created = request(
        "POST",
        "/organizations/users",
        token=admin_token,
        body={"display_name": display_name},
        expected=200,
    )
    identity_id = created["data"]["identity_id"]

    _, credential = request(
        "POST",
        f"/organizations/users/{identity_id}/credentials",
        token=admin_token,
        expected=200,
    )
    code = credential["data"]["activation_code"]

    auth_private = ed25519.Ed25519PrivateKey.generate()
    auth_public_raw = auth_private.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    fingerprint = hashlib.sha256(auth_public_raw).hexdigest()[:32]

    device_private = x25519.X25519PrivateKey.generate()
    device_public_raw = device_private.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )

    _, activated = request(
        "POST",
        "/activation/complete",
        body={
            "code": code,
            "identity_fingerprint": fingerprint,
            "device_name": f"{display_name} Terminal",
            "public_device_key": base64.b64encode(device_public_raw).decode(),
            "auth_public_key": base64.b64encode(auth_public_raw).decode(),
        },
        expected=200,
    )
    device_id = activated["data"]["device_id"]

    _, challenge = request(
        "POST",
        "/auth/challenge",
        body={"device_id": device_id},
        expected=200,
    )
    signature = auth_private.sign(challenge["data"]["nonce"].encode())
    _, verified = request(
        "POST",
        "/auth/verify",
        body={
            "challenge_id": challenge["data"]["challenge_id"],
            "device_id": device_id,
            "signature": base64.b64encode(signature).decode(),
        },
        expected=200,
    )

    return {
        "identity_id": identity_id,
        "device_id": device_id,
        "token": verified["data"]["access_token"],
        "auth_private": auth_private,
        "fingerprint": fingerprint,
        "public_identity": verified["data"]["public_identity"],
        "organization_id": verified["data"]["organization_id"],
    }


def main():
    print("=" * 78)
    print("SECURE FIELD COMMUNICATION — SAD v2.0 INTEGRATION TESTS")
    print("=" * 78)

    # 1. Administrator login -------------------------------------------------
    print("\n[1] Organization administrator login")
    status, login = request(
        "POST",
        "/organizations/auth/login",
        body={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD},
        expected=200,
    )
    admin_token = login["data"]["access_token"]
    organization_id = login["data"]["organization"]["organization_id"]
    check("admin login returns organization and session", bool(organization_id))

    # 2. Self-registration is disabled --------------------------------------
    print("\n[2] End-user self-registration is disabled")
    _, self_reg = request(
        "POST",
        "/identity",
        body={
            "public_identity": "AGENT_SELF",
            "identity_fingerprint": "a" * 32,
            "device": {
                "device_name": "self",
                "public_device_key": "x",
                "auth_public_key": "y",
            },
        },
        expected=403,
    )
    check(
        "POST /identity rejected",
        self_reg.get("error", {}).get("code") == "SELF_REGISTRATION_DISABLED",
        str(self_reg),
    )

    # 3. Provision and activate two agents ----------------------------------
    print("\n[3] Provisioning and one-time activation")
    agent_a = make_agent(admin_token, "Alpha")
    agent_b = make_agent(admin_token, "Bravo")
    check("agent A activated and authenticated", bool(agent_a["token"]))
    check("agent B activated and authenticated", bool(agent_b["token"]))

    _, reused = request(
        "POST",
        "/activation/verify",
        body={"code": "SFC-AAAA-AAAA-AAAA-AAAA"},
        expected=404,
    )
    check("unknown activation code rejected", reused.get("error", {}).get("code") == "INVALID_ACTIVATION_CODE")

    # 4. Organization isolation ---------------------------------------------
    print("\n[4] Organization isolation")
    _, dir_a = request("GET", "/directory/members", token=agent_a["token"], expected=200)
    member_ids = [member["identity_id"] for member in dir_a["data"]]
    check(
        "directory only contains same-organization members",
        agent_b["identity_id"] in member_ids
        and all(member["organization_id"] == organization_id for member in dir_a["data"]),
    )

    # 5. Personal conversation ----------------------------------------------
    print("\n[5] Personal conversation separation")
    _, direct = request(
        "POST",
        "/conversations/direct",
        token=agent_a["token"],
        body={"peer_identity_id": agent_b["identity_id"]},
        expected=200,
    )
    direct_id = direct["data"]["conversation_id"]
    check("direct conversation created", bool(direct_id))

    _, direct_again = request(
        "POST",
        "/conversations/direct",
        token=agent_a["token"],
        body={"peer_identity_id": agent_b["identity_id"]},
        expected=200,
    )
    check(
        "direct conversation is idempotent",
        direct_again["data"]["conversation_id"] == direct_id,
    )

    _, direct_list = request(
        "GET",
        "/conversations/direct",
        token=agent_a["token"],
        expected=200,
    )
    check("personal conversation listed", len(direct_list["data"]) == 1)

    # 6. Group creation, membership and key epochs -------------------------
    print("\n[6] Group management and key epochs")
    _, group = request(
        "POST",
        "/groups",
        token=agent_a["token"],
        body={"title": "Tim Lapangan", "members": [agent_b["identity_id"]]},
        expected=200,
    )
    group_id = group["data"]["conversation_id"]
    epoch_1 = group["data"]["key_epoch"]
    check("group created with epoch 1", epoch_1 == 1)

    _, group_detail = request("GET", f"/groups/{group_id}", token=agent_b["token"], expected=200)
    check("group member can read group detail", group_detail["data"]["conversation_id"] == group_id)

    _, added = request(
        "POST",
        f"/groups/{group_id}/members",
        token=agent_a["token"],
        body={"identity_id": agent_b["identity_id"]},
        expected=409,
    )
    check("duplicate membership rejected", added.get("error", {}).get("code") == "ALREADY_MEMBER")

    _, group_list_b = request("GET", "/groups", token=agent_b["token"], expected=200)
    check("group listed for member", any(g["conversation_id"] == group_id for g in group_list_b["data"]))

    # 7. Group message epoch enforcement ------------------------------------
    print("\n[7] Group key epoch enforcement")
    _, msg_ok = request(
        "POST",
        "/messages",
        token=agent_a["token"],
        body={
            "conversation_id": group_id,
            "client_message_id": str(uuid.uuid4()),
            "protocol_version": "2",
            "key_epoch": epoch_1,
            "message_type": "text",
            "ciphertext": base64.b64encode(b"opaque-ciphertext").decode(),
        },
        expected=200,
    )
    check("message with current epoch accepted", msg_ok["data"]["key_epoch"] == epoch_1)

    _, msg_stale = request(
        "POST",
        "/messages",
        token=agent_a["token"],
        body={
            "conversation_id": group_id,
            "client_message_id": str(uuid.uuid4()),
            "protocol_version": "2",
            "key_epoch": 999,
            "message_type": "text",
            "ciphertext": base64.b64encode(b"opaque-ciphertext").decode(),
        },
        expected=409,
    )
    check(
        "stale epoch rejected",
        msg_stale.get("error", {}).get("code") == "KEY_EPOCH_STALE",
    )

    # 8. Remove member bumps epoch ------------------------------------------
    print("\n[8] Membership removal rotates group key")
    _, removed = request(
        "DELETE",
        f"/groups/{group_id}/members/{agent_b['identity_id']}",
        token=agent_a["token"],
        expected=200,
    )
    check("member removed", removed["data"]["status"] == "member_removed")
    check("epoch incremented after removal", removed["data"]["key_epoch"] == epoch_1 + 1)

    _, forbidden = request(
        "GET",
        f"/groups/{group_id}",
        token=agent_b["token"],
        expected=403,
    )
    check("removed member cannot read group", forbidden.get("error", {}).get("code") == "NOT_A_MEMBER")

    # 9. Admin authorization boundaries -------------------------------------
    print("\n[9] Administrator authorization boundaries")
    _, admin_messages = request(
        "GET",
        f"/messages/conversation/{direct_id}",
        token=admin_token,
        expected=403,
    )
    check("admin cannot read messages", admin_messages.get("error", {}).get("code") == "DEVICE_REQUIRED")

    _, admin_groups = request("GET", "/groups", token=admin_token, expected=200)
    check("admin can list organization groups", isinstance(admin_groups["data"], list))

    # 10. Suspension and revocation -----------------------------------------
    print("\n[10] Suspension and revocation")
    _, suspended = request(
        "PATCH",
        f"/organizations/users/{agent_b['identity_id']}",
        token=admin_token,
        body={"status": "suspended"},
        expected=200,
    )
    check("user suspended", suspended["data"]["status"] == "suspended")

    _, challenge_suspended = request(
        "POST",
        "/auth/challenge",
        body={"device_id": agent_b["device_id"]},
        expected=403,
    )
    check(
        "suspended user cannot authenticate",
        challenge_suspended.get("error", {}).get("code") == "ACCOUNT_SUSPENDED",
    )

    _, reactivated = request(
        "PATCH",
        f"/organizations/users/{agent_b['identity_id']}",
        token=admin_token,
        body={"status": "active"},
        expected=200,
    )
    check("suspended user reactivated", reactivated["data"]["status"] == "active")

    _, revoked = request(
        "POST",
        f"/organizations/users/{agent_b['identity_id']}/revoke",
        token=admin_token,
        expected=200,
    )
    check("user revoked", revoked["data"]["status"] == "revoked")

    _, challenge_revoked = request(
        "POST",
        "/auth/challenge",
        body={"device_id": agent_b["device_id"]},
        expected=403,
    )
    check(
        "revoked user cannot authenticate",
        challenge_revoked.get("error", {}).get("code")
        in {"ACCOUNT_REVOKED", "DEVICE_REVOKED"},
    )

    # 11. Admin management (owner) ------------------------------------------
    print("\n[11] Administrator management")
    email = f"ops-{uuid.uuid4().hex[:8]}@example.test"
    password = "AnotherAdminPass123!"
    _, new_admin = request(
        "POST",
        "/organizations/admins",
        token=admin_token,
        body={
            "email": email,
            "display_name": "Operations Admin",
            "password": password,
            "role": "admin",
        },
        expected=200,
    )
    check("owner creates additional admin", bool(new_admin["data"]["admin_id"]))

    _, new_admin_login = request(
        "POST",
        "/organizations/auth/login",
        body={"email": email, "password": password},
        expected=200,
    )
    check("new admin can log in", bool(new_admin_login["data"]["access_token"]))

    # Summary ----------------------------------------------------------------
    print("\n" + "=" * 78)
    print(f"RESULT: {len(PASSED)} passed, {len(FAILED)} failed")
    if FAILED:
        for name, detail in FAILED:
            print(f"  FAILED: {name} {detail}")
        sys.exit(1)
    print("All SAD v2.0 integration checks passed.")
    print("=" * 78)


if __name__ == "__main__":
    main()
