#!/usr/bin/env python3
"""Developer helper: provision demo agents and print Flutter localStorage payload.

Creates two organization agents, activates them with keys derived exactly like
the Flutter client, authenticates them, opens a personal conversation and a
group, and prints JSON that can be seeded into a Flutter web session.

Usage:
    python3 tools/seed_demo.py
"""

import base64
import hashlib
import json
import os
import sys

import requests
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519, x25519

BASE_URL = os.environ.get("SFC_BASE_URL", "http://localhost:8000/api/v1")
ADMIN_EMAIL = os.environ.get("SFC_ADMIN_EMAIL", "admin@kartika.local")
ADMIN_PASSWORD = os.environ.get("SFC_ADMIN_PASSWORD", "ChangeThisAdminPassword123!")

KDF_SALT = "secure-field-communication/v1"


def derive_seed(phrase: str, purpose: str) -> bytes:
    salt = f"{KDF_SALT}:{purpose}".encode()
    return hashlib.pbkdf2_hmac("sha256", phrase.encode(), salt, 100_000, 32)


def request(method, path, token=None, body=None, expected=200):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    response = requests.request(
        method, f"{BASE_URL}{path}", headers=headers, json=body, timeout=20
    )
    if response.status_code != expected:
        raise SystemExit(
            f"{method} {path} -> {response.status_code}: {response.text}"
        )
    return response.json()["data"]


def make_agent(admin_token, display_name, phrase):
    user = request(
        "POST",
        "/organizations/users",
        token=admin_token,
        body={"display_name": display_name},
    )
    credential = request(
        "POST",
        f"/organizations/users/{user['identity_id']}/credentials",
        token=admin_token,
    )

    auth_seed = derive_seed(phrase, "auth")
    device_seed = derive_seed(phrase, "device")

    auth_private = ed25519.Ed25519PrivateKey.from_private_bytes(auth_seed)
    auth_public = auth_private.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    device_private = x25519.X25519PrivateKey.from_private_bytes(device_seed)
    device_public = device_private.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    fingerprint = hashlib.sha256(auth_public).hexdigest()[:32]

    activated = request(
        "POST",
        "/activation/complete",
        body={
            "code": credential["activation_code"],
            "identity_fingerprint": fingerprint,
            "device_name": f"{display_name} Browser",
            "public_device_key": base64.b64encode(device_public).decode(),
            "auth_public_key": base64.b64encode(auth_public).decode(),
        },
    )

    challenge = request(
        "POST", "/auth/challenge", body={"device_id": activated["device_id"]}
    )
    signature = auth_private.sign(challenge["nonce"].encode())
    verified = request(
        "POST",
        "/auth/verify",
        body={
            "challenge_id": challenge["challenge_id"],
            "device_id": activated["device_id"],
            "signature": base64.b64encode(signature).decode(),
        },
    )

    identity = {
        "identityId": activated["identity_id"],
        "deviceId": activated["device_id"],
        "publicIdentity": activated["public_identity"],
        "identityFingerprint": fingerprint,
        "publicDeviceKey": base64.b64encode(device_public).decode(),
        "authPublicKey": base64.b64encode(auth_public).decode(),
        "devicePrivateKey": base64.b64encode(device_seed).decode(),
        "authPrivateKey": base64.b64encode(auth_seed).decode(),
        "recoveryPhrase": phrase,
        "displayName": display_name,
        "recoveryConfirmed": True,
        "organizationId": activated["organization_id"],
        "organizationName": activated["organization_name"],
        "accountStatus": activated["account_status"],
    }
    return {"identity": identity, "token": verified["access_token"]}


def main():
    admin_token = request(
        "POST",
        "/organizations/auth/login",
        body={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD},
    )["access_token"]

    phrase_a = "alpha bravo charlie delta echo foxtrot golf hotel india juliet kilo lima"
    phrase_b = "mike november oscar papa quebec romeo sierra tango uniform victor whiskey xray"

    agent_a = make_agent(admin_token, "Seed Alpha", phrase_a)
    agent_b = make_agent(admin_token, "Seed Bravo", phrase_b)

    direct = request(
        "POST",
        "/conversations/direct",
        token=agent_a["token"],
        body={"peer_identity_id": agent_b["identity"]["identityId"]},
    )
    group = request(
        "POST",
        "/groups",
        token=agent_a["token"],
        body={
            "title": "Seed Operations",
            "members": [agent_b["identity"]["identityId"]],
        },
    )

    print(
        json.dumps(
            {
                "agent": agent_a,
                "peer": agent_b,
                "direct_conversation_id": direct["conversation_id"],
                "group_conversation_id": group["conversation_id"],
            },
            indent=2,
        )
    )
    print(
        f"\nSeeded direct={direct['conversation_id']} group={group['conversation_id']}",
        file=sys.stderr,
    )


if __name__ == "__main__":
    main()
