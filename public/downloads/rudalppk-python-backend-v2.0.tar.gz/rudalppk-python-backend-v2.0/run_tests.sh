#!/usr/bin/env bash
set -e

echo "=== SECURE FIELD COMMUNICATION PLATFORM — TEST RUNNER ==="

# Check python dependencies
python3 -c "import requests, cryptography" 2>/dev/null || {
    echo "Installing test dependencies: requests cryptography..."
    pip install requests cryptography
}

echo "Running PQC backend conformance tests (real backend skipped if pqcrypto is absent)..."
python3 test_pqc_backend.py

echo "Running activation & device authentication tests..."
python3 test_auth_flow.py

echo "Running full SAD v2.0 platform integration tests..."
python3 test_full_platform.py
