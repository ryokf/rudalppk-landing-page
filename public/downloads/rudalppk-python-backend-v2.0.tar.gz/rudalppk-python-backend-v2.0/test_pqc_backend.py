#!/usr/bin/env python3
"""Unit tests for the pluggable PQC backend.

Run from the Backend directory with the backend dependencies installed:

    python3 test_pqc_backend.py

These tests exercise the backend façade directly (no live API required). They
verify that the custom prototype backend and the real FIPS 203/204 backend
round-trip correctly and that their keys/signatures do not cross-verify.
"""

import base64
import os
import sys

# app.core.config requires DATABASE_URL even though these tests never touch a DB.
os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///:memory:")
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "backend"))

from app.core.pqc_backend import (  # noqa: E402
    ML_DSA_SPECS,
    ML_KEM_SPECS,
    PqcOperationUnsupported,
    get_pqc_backend,
    get_pqc_backend_catalog,
    pqcrypto_available,
)

PASSED = []
FAILED = []


def check(name, condition, detail=""):
    if condition:
        PASSED.append(name)
        print(f"  [PASS] {name}")
    else:
        FAILED.append((name, detail))
        print(f"  [FAIL] {name} {detail}")


def exercise_backend(backend_name):
    backend = get_pqc_backend(backend_name)
    check(f"{backend_name}: backend name", backend.name == backend_name)

    for alg, spec in ML_KEM_SPECS.items():
        keypair = backend.kem_keygen(alg)
        public_key = base64.b64decode(keypair["public_key"])
        secret_key = base64.b64decode(keypair["secret_key"])
        check(
            f"{backend_name}: {alg} key sizes",
            len(public_key) == spec["pk_bytes"] and len(secret_key) == spec["sk_bytes"],
            f"pk={len(public_key)} sk={len(secret_key)}",
        )
        encapsulated = backend.kem_encapsulate(keypair["public_key"], alg)
        ciphertext = base64.b64decode(encapsulated["ciphertext"])
        shared_secret = base64.b64decode(encapsulated["shared_secret"])
        decapsulated = backend.kem_decapsulate(
            encapsulated["ciphertext"], keypair["secret_key"], alg
        )
        check(
            f"{backend_name}: {alg} encaps/decaps",
            len(ciphertext) == spec["ct_bytes"] and shared_secret == decapsulated,
            f"ct={len(ciphertext)}",
        )

    for alg, spec in ML_DSA_SPECS.items():
        keypair = backend.dsa_keygen(alg)
        public_key = base64.b64decode(keypair["public_key"])
        secret_key = base64.b64decode(keypair["secret_key"])
        check(
            f"{backend_name}: {alg} key sizes",
            len(public_key) == spec["pk_bytes"] and len(secret_key) == spec["sk_bytes"],
            f"pk={len(public_key)} sk={len(secret_key)}",
        )
        message = f"PERISAI backend test {backend_name} {alg}".encode()
        signature = backend.dsa_sign(message, keypair["secret_key"], alg)
        check(
            f"{backend_name}: {alg} signature size",
            len(base64.b64decode(signature)) == spec["sig_bytes"],
        )
        check(
            f"{backend_name}: {alg} verify valid",
            backend.dsa_verify(message, signature, keypair["public_key"], alg) is True,
        )
        check(
            f"{backend_name}: {alg} reject tampered",
            backend.dsa_verify(
                message + b"!", signature, keypair["public_key"], alg
            )
            is False,
        )


def main():
    print("=" * 70)
    print("PQC BACKEND ABSTRACTION TESTS")
    print("=" * 70)

    catalog = get_pqc_backend_catalog()
    check("catalog lists custom backend", any(
        backend["name"] == "custom" for backend in catalog["backends"]
    ))
    check("catalog lists pqcrypto backend", any(
        backend["name"] == "pqcrypto" for backend in catalog["backends"]
    ))
    custom = get_pqc_backend("custom")
    check("custom backend is not FIPS 203/204", custom.is_fips_203_204 is False)
    check("custom backend supports seeded keygen", custom.supports_seeded_keygen is True)

    print("\n[1] Custom prototype backend")
    exercise_backend("custom")

    if not pqcrypto_available():
        print("\n[2] Real FIPS 203/204 backend: SKIPPED (pqcrypto not installed)")
    else:
        print("\n[2] Real FIPS 203/204 backend")
        real = get_pqc_backend("pqcrypto")
        check("real backend declares FIPS 203/204", real.is_fips_203_204 is True)
        check("real backend is not CMVP-validated", real.fips_validated is False)
        check("real backend does not support seeded keygen", real.supports_seeded_keygen is False)
        exercise_backend("pqcrypto")

        print("\n[3] Cross-backend isolation")
        custom_kp = custom.dsa_keygen("ML-DSA-65")
        custom_sig = custom.dsa_sign(
            b"cross-backend", custom_kp["secret_key"], "ML-DSA-65"
        )
        check(
            "real backend rejects custom signature",
            real.dsa_verify(
                b"cross-backend", custom_sig, custom_kp["public_key"], "ML-DSA-65"
            )
            is False,
        )

        real_kp = real.dsa_keygen("ML-DSA-65")
        real_sig = real.dsa_sign(b"cross-backend", real_kp["secret_key"], "ML-DSA-65")
        check(
            "custom backend rejects real signature",
            custom.dsa_verify(
                b"cross-backend", real_sig, real_kp["public_key"], "ML-DSA-65"
            )
            is False,
        )

        print("\n[4] Explicit rejection of unsafe seeded key generation")
        try:
            real.kem_keygen("ML-KEM-768", seed=b"\x01" * 32)
        except PqcOperationUnsupported as exc:
            check("real backend rejects seeded ML-KEM keygen", True, str(exc))
        else:
            check("real backend rejects seeded ML-KEM keygen", False, "no exception")

        try:
            real.dsa_keygen("ML-DSA-65", seed=b"\x02" * 32)
        except PqcOperationUnsupported as exc:
            check("real backend rejects seeded ML-DSA keygen", True, str(exc))
        else:
            check("real backend rejects seeded ML-DSA keygen", False, "no exception")

    print("\n" + "=" * 70)
    print(f"RESULT: {len(PASSED)} passed, {len(FAILED)} failed")
    if FAILED:
        for name, detail in FAILED:
            print(f"  - {name}: {detail}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
