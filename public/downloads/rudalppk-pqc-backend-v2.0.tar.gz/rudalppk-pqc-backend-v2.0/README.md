# Secure Field Communication — SAD v2.0 Implementation

This repository implements the SAD v2.0 improvement: independent organization
web and field-agent mobile frontends sharing one FastAPI backend.

## Components

| Path | Description |
|---|---|
| `Backend/` | FastAPI backend, PostgreSQL schema, WebSocket relay, activation/provisioning, RBAC. |
| `flutter_application_chat/` | Independent Flutter mobile/web client for field agents. |
| `organization_web/` | Independent static web console for organization administrators. |
| `SAD-Improvement_1.md` | Authoritative SAD v2.0 document. |

## Architecture

```text
organization_web  (static SPA)
        │ REST
        ▼
FastAPI backend ── PostgreSQL ── ciphertext messages
        ▲
        │ REST + WebSocket
flutter_application_chat (field agents)
```

- Organization administrators log in to the web console with email/password
  (PBKDF2-HMAC-SHA256) and manage users, activation credentials, and groups.
- Field agents activate organization-issued accounts with a one-time code and a
  12-word recovery phrase generated on-device.
- Device authentication remains Ed25519 challenge/response with a
  `device_session` JWT; admin sessions use `admin_session`.
- Personal and group conversations are separated. Groups enforce
  same-organization membership and a server-checked `key_epoch` that is bumped
  on every membership change.
- The backend never receives plaintext messages or private keys.

## Backend Setup

```bash
cd Backend
docker compose up --build
```

The backend runs on `http://localhost:8000`. On first startup it applies
idempotent PostgreSQL migrations and optionally bootstraps an organization and
owner administrator from environment variables.

Development defaults in `Backend/.env`:

```text
BOOTSTRAP_ORGANIZATION_NAME=Kartika Operations
BOOTSTRAP_ADMIN_EMAIL=admin@kartika.local
BOOTSTRAP_ADMIN_PASSWORD=ChangeThisAdminPassword123!
SYSTEM_ADMIN_API_KEY=dev-system-admin-key
ACTIVATION_CREDENTIAL_EXPIRY_HOURS=72
ALLOW_AGENT_GROUP_CREATION=true
ALLOW_CROSS_ORGANIZATION_GROUPS=false
```

**Change all secrets before production.**

## Web Console

Serve `organization_web/` with any static file server:

```bash
cd organization_web
python3 -m http.server 8080
```

Open `http://localhost:8080`, sign in with the bootstrap administrator, then
create field agents and activation codes.

## Mobile App

See [`flutter_application_chat/README.md`](flutter_application_chat/README.md).

```bash
cd flutter_application_chat
flutter pub get
flutter run -d chrome
```

## Tests

Backend integration tests require the Docker stack to be running:

```bash
cd Backend
python3 test_auth_flow.py
python3 test_full_platform.py
# or
./run_tests.sh
```

Flutter tests:

```bash
cd flutter_application_chat
flutter analyze
flutter test
flutter build web --release
```

## Key API Groups

| Area | Endpoints |
|---|---|
| Activation | `POST /api/v1/activation/verify`, `POST /api/v1/activation/complete` |
| Device auth | `POST /api/v1/auth/challenge`, `POST /api/v1/auth/verify` |
| Identity | `GET /api/v1/me`, `GET /api/v1/identity/{id}` |
| Organization | `POST /api/v1/organizations/auth/login`, `GET/PATCH /api/v1/organizations/me` |
| Users | `GET/POST /api/v1/organizations/users`, `PATCH/POST .../{id}/credentials`, `.../{id}/revoke` |
| Directory | `GET /api/v1/directory/members` |
| Personal chat | `POST/GET /api/v1/conversations/direct` |
| Groups | `POST/GET /api/v1/groups`, `PATCH /api/v1/groups/{id}`, member endpoints, `/leave` |
| Messages | `POST /api/v1/messages`, `GET /api/v1/messages/pending`, `GET /api/v1/messages/conversation/{id}`, `POST /api/v1/messages/{id}/ack` |

## Security Decisions

- Self-registration (`POST /api/v1/identity`) is disabled.
- Activation codes are stored only as SHA-256 hashes, expire after 72 hours,
  and are single-use.
- Identity fingerprints are validated server-side against the Ed25519 public
  key; clients cannot choose arbitrary public identities.
- Revoking a user revokes devices, unconsumed credentials, and active
  conversation memberships, bumps group epochs, and notifies member devices.
- Group E2EE uses per-message AES keys wrapped for each active device with
  pairwise X25519 + HKDF-SHA256 keys. `key_epoch` is included in the envelope
  and binds wrapping to the current membership epoch.
