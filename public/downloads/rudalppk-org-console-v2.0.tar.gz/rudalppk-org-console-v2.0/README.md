# Secure Field Communication — Organization Web Console

Independent static web application for organization administrators (SAD v2.0).
It is intentionally separate from the Flutter field-agent mobile app and talks
to the same FastAPI backend.

## Features

- Administrator login with email + password (PBKDF2-HMAC-SHA256).
- Organization profile and rename (owner only).
- Field-agent user provisioning (no end-user self-registration).
- One-time activation credential issuance with expiry display.
- User detail: devices and credential state.
- Suspend, reactivate, and revoke users (revocation also revokes devices,
  unconsumed credentials, and group memberships).
- Group management: create, rename, add/remove members; membership changes
  bump the group `key_epoch`.
- Administrator management (owner only): create, suspend, reset password.
- Configurable backend base URL, persisted in `localStorage`.

## Run

No build step is required. Serve the folder with any static file server:

```bash
cd organization_web
python3 -m http.server 8080
```

Then open <http://localhost:8080>.

For Docker/nginx, copy the folder into any static web root and point the
browser at the backend URL (`http://localhost:8000/api/v1` by default).

## Security Notes

- The admin JWT is stored only in the browser's `localStorage`.
- The web console never has access to message plaintext or private keys.
- Administrators manage accounts and groups; they cannot read personal or
  group messages.
- Set `SYSTEM_ADMIN_API_KEY`, `JWT_SECRET_KEY`, and strong bootstrap
  credentials in the backend environment before production use.
