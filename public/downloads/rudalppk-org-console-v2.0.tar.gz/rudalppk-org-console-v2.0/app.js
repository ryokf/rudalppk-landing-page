/* Secure Field Communication — Organization Console (SAD v2.0)
 * Independent static web frontend for organization administrators.
 */
(function () {
  'use strict';

  const STORAGE_KEYS = {
    token: 'sfc_admin_token',
    baseUrl: 'sfc_admin_base_url',
  };

  const state = {
    baseUrl:
      localStorage.getItem(STORAGE_KEYS.baseUrl) ||
      'http://localhost:8000/api/v1',
    token: localStorage.getItem(STORAGE_KEYS.token) || null,
    org: null,
    admin: null,
    users: [],
    groups: [],
    admins: [],
    directory: [],
    signedArtifacts: [],
    auditLogs: [],
    quantumSim: null,
    fleetAudit: null,
    benchmark: null,
    verifyResult: null,
    signMode: 'command_instruction',
    selectedUploadFile: null,
    lastGeneratedKeyBundle: null,
    view: 'users',
    error: '',
    success: '',
    modal: null,
    groupDetail: null,
    loading: false,
  };

  // ---------------------------------------------------------------------------
  // API helpers
  // ---------------------------------------------------------------------------

  async function api(path, options = {}) {
    const headers = { Accept: 'application/json' };
    if (options.body !== undefined) headers['Content-Type'] = 'application/json';
    if (state.token) headers['Authorization'] = `Bearer ${state.token}`;

    let response;
    try {
      response = await fetch(state.baseUrl + path, {
        method: options.method || 'GET',
        headers,
        body: options.body !== undefined ? JSON.stringify(options.body) : undefined,
      });
    } catch (err) {
      throw new Error('Tidak dapat terhubung ke backend. Periksa URL dan jaringan.');
    }

    let json = null;
    try {
      json = await response.json();
    } catch (_) {
      json = null;
    }

    if (!response.ok) {
      const error = new Error(
        (json && json.error && json.error.message) || `HTTP ${response.status}`,
      );
      error.code = json && json.error ? json.error.code : null;
      error.details = json && json.error ? json.error.details : null;
      throw error;
    }

    return json ? json.data : null;
  }

  function setToken(token) {
    state.token = token;
    if (token) localStorage.setItem(STORAGE_KEYS.token, token);
    else localStorage.removeItem(STORAGE_KEYS.token);
  }

  function setBaseUrl(url) {
    state.baseUrl = url.replace(/\/+$/, '');
    localStorage.setItem(STORAGE_KEYS.baseUrl, state.baseUrl);
  }

  // ---------------------------------------------------------------------------
  // Shell
  // ---------------------------------------------------------------------------

  function shellHtml() {
    const org = state.org || {};
    const admin = state.admin || {};
    return `
      <div class="app-shell">
        <aside class="sidebar">
          <div class="brand">
            <div class="brand-badge">SFC</div>
            <div>
              <strong>Secure Field Comms</strong>
              <span>Organization Console</span>
            </div>
          </div>
          <button class="nav-item ${state.view === 'users' ? 'active' : ''}" onclick="Actions.setView('users')">
            👤 Pengguna
          </button>
          <button class="nav-item ${state.view === 'groups' ? 'active' : ''}" onclick="Actions.setView('groups')">
            👥 Grup
          </button>
          <button class="nav-item ${state.view === 'admins' ? 'active' : ''}" onclick="Actions.setView('admins')">
            🛡️ Administrator
          </button>
          <button class="nav-item ${state.view === 'perisai_sign' ? 'active' : ''}" onclick="Actions.setView('perisai_sign')">
            📜 PERISAI-Sign (ML-DSA)
          </button>
          <button class="nav-item ${state.view === 'perisai_lab' ? 'active' : ''}" onclick="Actions.setView('perisai_lab')">
            🧪 PERISAI-Lab (PQC)
          </button>
          <button class="nav-item ${state.view === 'settings' ? 'active' : ''}" onclick="Actions.setView('settings')">
            ⚙️ Pengaturan
          </button>
          <div class="sidebar-footer">
            <div class="muted" style="font-size:11px;padding:0 6px">
              ${escapeHtml(org.organization_name || '-')}<br/>
              ${escapeHtml(admin.email || '')} • ${escapeHtml(admin.role || '')}
            </div>
            <button class="ghost" onclick="Actions.logout()">Keluar</button>
          </div>
        </aside>
        <main class="main">
          <div class="topbar">
            <div>
              <h1>${viewTitle()}</h1>
              <p>${viewSubtitle()}</p>
            </div>
            <div class="flex">
              ${state.error ? `<div class="error-box" style="margin:0">${escapeHtml(state.error)}</div>` : ''}
              ${state.success ? `<div class="success-box" style="margin:0">${escapeHtml(state.success)}</div>` : ''}
            </div>
          </div>
          <div id="view">${viewHtml()}</div>
        </main>
      </div>
      ${modalHtml()}
    `;
  }

  function viewTitle() {
    switch (state.view) {
      case 'users':
        return 'Manajemen Pengguna';
      case 'groups':
        return 'Manajemen Grup';
      case 'admins':
        return 'Administrator Organisasi';
      case 'perisai_sign':
        return 'PERISAI-Sign — Otentikasi Pasca-Kuantum (NIST FIPS 204)';
      case 'perisai_lab':
        return 'PERISAI-Lab — Simulator Serangan Kuantum & Audit Armada PQC';
      case 'settings':
        return 'Pengaturan Organisasi';
      default:
        return 'Konsol';
    }
  }

  function viewSubtitle() {
    switch (state.view) {
      case 'users':
        return 'Provisioning akun, kredensial aktivasi, dan pencabutan akses.';
      case 'groups':
        return 'Grup hanya dapat berisi anggota organisasi yang sama.';
      case 'admins':
        return 'Kelola administrator yang dapat mengelola organisasi ini.';
      case 'perisai_sign':
        return 'Tanda tangani instruksi komando & paket firmware OT/IoT dengan ML-DSA-44, ML-DSA-65, atau ML-DSA-87.';
      case 'perisai_lab':
        return 'Simulasi algoritma Shor & QUBO terhadap RSA vs ketahanan ML-KEM (512/768/1024) & ML-DSA (44/65/87).';
      case 'settings':
        return 'Informasi organisasi, kebijakan standar NIST PQC, dan koneksi backend.';
      default:
        return '';
    }
  }

  function viewHtml() {
    switch (state.view) {
      case 'users':
        return usersHtml();
      case 'groups':
        return groupsHtml();
      case 'admins':
        return adminsHtml();
      case 'perisai_sign':
        return perisaiSignHtml();
      case 'perisai_lab':
        return perisaiLabHtml();
      case 'settings':
        return settingsHtml();
      default:
        return '';
    }
  }

  function modalHtml() {
    if (!state.modal) return '';
    const modal = state.modal;

    if (modal.type === 'credential') {
      return `
        <div class="modal-backdrop" onclick="Actions.closeModal()">
          <div class="modal" onclick="event.stopPropagation()">
            <h3>Kredensial Aktivasi</h3>
            <p class="muted">
              Salin kode ini dan sampaikan kepada petugas lapangan melalui saluran
              aman. Kode hanya dapat digunakan sekali dan kedaluwarsa
              ${escapeHtml(modal.expiresAt || '-')}.
            </p>
            <div class="code-box">
              <span class="code">${escapeHtml(modal.code || '-')}</span>
              <button class="primary" onclick="Actions.copy('${escapeHtml(modal.code || '')}')">Salin</button>
            </div>
            <div class="modal-actions">
              <button class="ghost" onclick="Actions.closeModal()">Tutup</button>
            </div>
          </div>
        </div>
      `;
    }

    if (modal.type === 'createUser') {
      return `
        <div class="modal-backdrop" onclick="Actions.closeModal()">
          <div class="modal" onclick="event.stopPropagation()">
            <h3>Buat Akun Petugas</h3>
            <form onsubmit="Actions.submitCreateUser(event)">
              <div>
                <label>Nama / Call-sign</label>
                <input name="displayName" required maxlength="150" placeholder="Contoh: Alpha, Bravo" />
              </div>
              <div class="modal-actions">
                <button type="button" class="ghost" onclick="Actions.closeModal()">Batal</button>
                <button type="submit" class="primary">Buat Akun</button>
              </div>
            </form>
          </div>
        </div>
      `;
    }

    if (modal.type === 'userDetail') {
      const user = modal.user || {};
      const devices = user.devices || [];
      const credentials = user.credentials || [];
      return `
        <div class="modal-backdrop" onclick="Actions.closeModal()">
          <div class="modal" onclick="event.stopPropagation()">
            <h3>Detail Pengguna</h3>
            <p class="muted">${escapeHtml(user.public_identity || '-')} •
              <span class="badge ${escapeHtml(user.status || '')}">${escapeHtml(user.status || '')}</span>
            </p>
            <div class="row" style="margin-bottom:12px">
              <div class="grow"><label>Identity ID</label><div class="mono">${escapeHtml(user.identity_id || '-')}</div></div>
              <div class="grow"><label>Fingerprint</label><div class="mono">${escapeHtml(user.identity_fingerprint || '-')}</div></div>
            </div>
            <label>Perangkat (${devices.length})</label>
            ${devices.length ? devices.map((d) => `
              <div class="row between" style="padding:6px 0;border-bottom:1px solid var(--border)">
                <div>
                  <div>${escapeHtml(d.device_name || 'Perangkat')}</div>
                  <div class="mono muted">${escapeHtml(d.device_id)}</div>
                  <div class="muted" style="font-size:10.5px;margin-top:2px">
                    PQC: <span class="mono">${escapeHtml(d.pqc_kem_alg || 'ML-KEM-768')}</span> +
                    <span class="mono">${escapeHtml(d.pqc_dsa_alg || 'ML-DSA-65')}</span>
                    ${d.pqc_kem_public_key ? '• <span style="color:#2dd4bf">Kunci PQC Terdaftar ✓</span>' : '• <span style="color:#fbbf24">Legacy Only</span>'}
                  </div>
                </div>
                <span class="badge ${escapeHtml(d.status || '')}">${escapeHtml(d.status || '')}</span>
              </div>
            `).join('') : '<div class="empty">Belum ada perangkat aktif.</div>'}
            <label style="margin-top:14px">Kredensial (${credentials.length})</label>
            ${credentials.length ? credentials.map((c) => `
              <div class="row between" style="padding:6px 0;border-bottom:1px solid var(--border)">
                <div class="mono">${escapeHtml(c.credential_id)}</div>
                <div class="muted">${escapeHtml(c.consumed_at ? 'Terpakai' : (c.revoked_at ? 'Dicabut' : 'Aktif'))}</div>
              </div>
            `).join('') : '<div class="empty">Belum ada kredensial.</div>'}
            <div class="modal-actions">
              <button class="ghost" onclick="Actions.closeModal()">Tutup</button>
            </div>
          </div>
        </div>
      `;
    }

    if (modal.type === 'createGroup') {
      const activeUsers = state.users.filter((u) => u.status === 'active');
      return `
        <div class="modal-backdrop" onclick="Actions.closeModal()">
          <div class="modal" onclick="event.stopPropagation()">
            <h3>Buat Grup</h3>
            <form onsubmit="Actions.submitCreateGroup(event)">
              <div>
                <label>Nama grup</label>
                <input name="title" required maxlength="150" placeholder="Contoh: Tim Operasi Lapangan" />
              </div>
              <div>
                <label>Group admin</label>
                <select name="groupAdminId" required>
                  ${activeUsers.map((u) => `<option value="${escapeHtml(u.identity_id)}">${escapeHtml(u.display_name || u.public_identity)}</option>`).join('')}
                </select>
              </div>
              <div>
                <label>Anggota awal (opsional)</label>
                <div class="checkbox-list">
                  ${activeUsers.map((u) => `
                    <label class="checkbox-row">
                      <input type="checkbox" name="members" value="${escapeHtml(u.identity_id)}" />
                      <div>${escapeHtml(u.display_name || u.public_identity)}
                        <small>${escapeHtml(u.public_identity)}</small>
                      </div>
                    </label>
                  `).join('')}
                </div>
              </div>
              <div class="modal-actions">
                <button type="button" class="ghost" onclick="Actions.closeModal()">Batal</button>
                <button type="submit" class="primary">Buat Grup</button>
              </div>
            </form>
          </div>
        </div>
      `;
    }

    if (modal.type === 'createAdmin') {
      return `
        <div class="modal-backdrop" onclick="Actions.closeModal()">
          <div class="modal" onclick="event.stopPropagation()">
            <h3>Tambah Administrator</h3>
            <form onsubmit="Actions.submitCreateAdmin(event)">
              <div>
                <label>Email</label>
                <input name="email" type="email" required maxlength="255" />
              </div>
              <div>
                <label>Nama tampilan</label>
                <input name="displayName" required maxlength="150" />
              </div>
              <div>
                <label>Kata sandi (min. 10 karakter)</label>
                <input name="password" type="password" required minlength="10" />
              </div>
              <div>
                <label>Peran</label>
                <select name="role">
                  <option value="admin">Admin</option>
                  <option value="owner">Owner</option>
                </select>
              </div>
              <div class="modal-actions">
                <button type="button" class="ghost" onclick="Actions.closeModal()">Batal</button>
                <button type="submit" class="primary">Tambah</button>
              </div>
            </form>
          </div>
        </div>
      `;
    }

    if (modal.type === 'decryptArtifact') {
      const a = modal.artifact || {};
      const meta = a.meta || {};
      const kemAlg = meta.kem_algorithm || 'ML-KEM-768';
      return `
        <div class="modal-backdrop" onclick="Actions.closeModal()">
          <div class="modal" style="max-width:560px" onclick="event.stopPropagation()">
            <h3>🔓 Dekripsi & Buka File PQC (${escapeHtml(kemAlg)} + ${escapeHtml(a.algorithm || 'ML-DSA-65')})</h3>
            <p class="muted" style="margin-top:-6px">
              File <strong>${escapeHtml(meta.file_name || a.title)}</strong> terkunci dengan enkripsi pasca-kuantum
              <strong>${escapeHtml(kemAlg)}</strong> + <strong>AES-256-GCM</strong>. Hanya pemegang Kunci Privat
              <code>${escapeHtml(kemAlg)}</code> yang dapat membuka dan mengunduh file aslinya.
            </p>
            ${modal.decryptError ? `<div class="error-box">${escapeHtml(modal.decryptError)}</div>` : ''}
            <form onsubmit="Actions.submitDecryptArtifact(event, '${escapeHtml(a.artifact_id)}')">
              <div>
                <label>Opsi 1: Upload File Kunci (<code>.pqc-key.json</code>)</label>
                <input type="file" accept=".json,application/json" onchange="Actions.handleKeyFileImport(event)" />
              </div>
              <div>
                <label>Opsi 2: Tempel Kunci Privat Dekripsi (${escapeHtml(kemAlg)} Secret Key Base64)</label>
                <textarea id="decrypt-kem-key-input" name="kemSecretKey" rows="4" class="mono" required placeholder="Tempel kunci privat ${escapeHtml(kemAlg)} di sini atau klik Upload File Kunci di atas...">${escapeHtml(modal.prefillKey || '')}</textarea>
              </div>
              <div class="modal-actions" style="justify-content:space-between;flex-wrap:wrap">
                <button type="button" class="danger" onclick="Actions.fillFakeKemKey()">🧪 Simulasi Kunci Palsu (Tanpa Hak Akses)</button>
                <div class="actions">
                  <button type="button" class="ghost" onclick="Actions.closeModal()">Batal</button>
                  <button type="submit" class="primary">🔓 Dekripsi & Unduh File Asli</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      `;
    }

    if (modal.type === 'verifyFileArtifact') {
      const a = modal.artifact || {};
      const meta = a.meta || {};
      return `
        <div class="modal-backdrop" onclick="Actions.closeModal()">
          <div class="modal" style="max-width:540px" onclick="event.stopPropagation()">
            <h3>🔍 Cek Keaslian File terhadap Segel ${escapeHtml(a.algorithm || 'ML-DSA-65')}</h3>
            <p class="muted" style="margin-top:-6px">
              Pilih file dari komputer Anda untuk memverifikasi apakah file tersebut masih murni sesuai segel
              tanda tangan <strong>${escapeHtml(a.algorithm)}</strong> pada artefak <strong>${escapeHtml(a.title)}</strong>
              (File asli: <code>${escapeHtml(meta.file_name || '-')}</code>). Jika berubah 1 byte saja, verifikasi akan ditolak!
            </p>
            <form onsubmit="Actions.submitVerifyUploadedFile(event, '${escapeHtml(a.artifact_id)}')">
              <div>
                <label>Pilih File dari Komputer untuk Dicek</label>
                <input type="file" required onchange="Actions.handleVerifyFileSelect(event)" />
              </div>
              <div class="modal-actions">
                <button type="button" class="ghost" onclick="Actions.closeModal()">Batal</button>
                <button type="submit" class="primary">🔍 Verifikasi Keaslian File</button>
              </div>
            </form>
          </div>
        </div>
      `;
    }

    return '';
  }

  function usersHtml() {
    return `
      <div class="panel">
        <div class="flex between wrap" style="margin-bottom:14px">
          <div>
            <h2 style="margin:0">Daftar Petugas Lapangan (${state.users.length})</h2>
            <div class="muted" style="font-size:11.5px;margin-top:2px">
              Buat akun petugas lapangan dan terbitkan <strong>Kode Aktivasi</strong> untuk login di aplikasi Mobile/Flutter.
            </div>
          </div>
          <div class="actions">
            <button class="ghost" onclick="Actions.loadUsers()">Muat Ulang</button>
            <button class="primary" onclick="Actions.openCreateUser()">+ Buat Akun Petugas & Kode Aktivasi</button>
          </div>
        </div>
        ${state.users.length ? `
          <div style="overflow:auto">
          <table class="table">
            <thead>
              <tr>
                <th>Nama Petugas</th>
                <th>Identitas</th>
                <th>Status</th>
                <th>Perangkat</th>
                <th>Status Kode Aktivasi</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              ${state.users.map((u) => userRowHtml(u)).join('')}
            </tbody>
          </table>
          </div>
        ` : `
          <div class="empty">
            Belum ada petugas lapangan.<br/><br/>
            <button class="primary" onclick="Actions.openCreateUser()">+ Buat Akun Petugas Pertama & Dapatkan Kode Aktivasi</button>
          </div>
        `}
      </div>
    `;
  }

  function userRowHtml(u) {
    const credential = u.credential;
    const credentialLabel = credential
      ? (credential.consumed_at
          ? 'Terpakai'
          : (credential.revoked_at ? 'Dicabut' : 'Aktif'))
      : '-';
    return `
      <tr>
        <td>
          <div>${escapeHtml(u.display_name || '-')}</div>
          <div class="muted" style="font-size:10.5px">ID ${escapeHtml(u.identity_id)}</div>
        </td>
        <td>
          <div class="mono">${escapeHtml(u.public_identity || '-')}</div>
          <div class="muted mono" style="font-size:10px">${escapeHtml(u.identity_fingerprint || '')}</div>
        </td>
        <td><span class="badge ${escapeHtml(u.status)}">${escapeHtml(u.status)}</span></td>
        <td>${u.active_device_count || 0} / ${u.device_count || 0}</td>
        <td>${escapeHtml(credentialLabel)}</td>
        <td>
          <div class="actions">
            <button class="ghost" onclick="Actions.openUserDetail('${escapeHtml(u.identity_id)}')">Detail</button>
            ${u.status === 'pending' ? `<button class="primary" onclick="Actions.issueCredential('${escapeHtml(u.identity_id)}')">Buat Kode</button>` : ''}
            ${u.status === 'active' ? `<button class="ghost" onclick="Actions.suspendUser('${escapeHtml(u.identity_id)}')">Suspend</button>` : ''}
            ${u.status === 'suspended' ? `<button class="ghost" onclick="Actions.activateUser('${escapeHtml(u.identity_id)}')">Aktifkan</button>` : ''}
            ${u.status !== 'revoked' ? `<button class="danger" onclick="Actions.revokeUser('${escapeHtml(u.identity_id)}')">Cabut</button>` : ''}
          </div>
        </td>
      </tr>
    `;
  }

  function groupsHtml() {
    return `
      <div class="panel">
        <div class="flex between wrap" style="margin-bottom:14px">
          <h2 style="margin:0">Grup Organisasi (${state.groups.length})</h2>
          <div class="actions">
            <button class="ghost" onclick="Actions.loadGroups()">Muat Ulang</button>
            <button class="primary" onclick="Actions.openCreateGroup()">+ Buat Grup</button>
          </div>
        </div>
        ${state.groups.length ? `
          <table class="table">
            <thead>
              <tr><th>Nama</th><th>Anggota</th><th>Epoch</th><th>Dibuat</th><th>Aksi</th></tr>
            </thead>
            <tbody>
              ${state.groups.map((g) => `
                <tr>
                  <td>${escapeHtml(g.title || 'Grup')}</td>
                  <td>${g.member_count || 0}</td>
                  <td class="mono">${g.key_epoch || 1}</td>
                  <td class="muted">${escapeHtml(formatDate(g.created_at))}</td>
                  <td>
                    <div class="actions">
                      <button class="ghost" onclick="Actions.openGroup('${escapeHtml(g.conversation_id)}')">Kelola</button>
                    </div>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        ` : '<div class="empty">Belum ada grup. Buat grup untuk koordinasi tim lapangan.</div>'}
      </div>
      ${state.groupDetail ? groupDetailHtml(state.groupDetail) : ''}
    `;
  }

  function groupDetailHtml(group) {
    const members = group.members || [];
    const memberIds = new Set(members.map((m) => m.identity_id));
    const candidates = state.directory.filter(
      (d) => d.status === 'active' && !memberIds.has(d.identity_id),
    );
    return `
      <div class="panel">
        <div class="flex between wrap" style="margin-bottom:12px">
          <div>
            <h2 style="margin:0">${escapeHtml(group.title || 'Grup')}</h2>
            <div class="muted">Epoch kunci: ${group.key_epoch || 1} • ${members.length} anggota</div>
          </div>
          <div class="actions">
            <button class="ghost" onclick="Actions.renameGroup('${escapeHtml(group.conversation_id)}')">Ubah Nama</button>
            <button class="ghost" onclick="Actions.closeGroupDetail()">Tutup</button>
          </div>
        </div>
        <div class="panel" style="background:var(--surface-2);margin-bottom:12px">
          <label>Tambah anggota</label>
          <div class="row">
            <div class="grow">
              <select id="add-member-select">
                ${candidates.length ? candidates.map((c) => `
                  <option value="${escapeHtml(c.identity_id)}">${escapeHtml(c.display_name || c.public_identity)} (${escapeHtml(c.public_identity)})</option>
                `).join('') : '<option value="">Tidak ada kandidat</option>'}
              </select>
            </div>
            <button class="primary" ${candidates.length ? '' : 'disabled'} onclick="Actions.addGroupMember('${escapeHtml(group.conversation_id)}')">Tambah</button>
          </div>
        </div>
        <table class="table">
          <thead><tr><th>Anggota</th><th>Peran</th><th>Perangkat</th><th>Aksi</th></tr></thead>
          <tbody>
            ${members.map((m) => `
              <tr>
                <td>
                  <div>${escapeHtml(m.display_name || m.public_identity)}</div>
                  <div class="muted mono" style="font-size:10px">${escapeHtml(m.identity_id)}</div>
                </td>
                <td><span class="badge ${m.member_role === 'admin' ? 'admin' : 'active'}">${escapeHtml(m.member_role)}</span></td>
                <td>${(m.devices || []).length}</td>
                <td>
                  <button class="danger" onclick="Actions.removeGroupMember('${escapeHtml(group.conversation_id)}','${escapeHtml(m.identity_id)}')">Keluarkan</button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  }

  function adminsHtml() {
    const isOwner = state.admin && state.admin.role === 'owner';
    return `
      <div class="panel">
        <div class="flex between wrap" style="margin-bottom:14px">
          <h2 style="margin:0">Administrator (${state.admins.length})</h2>
          <div class="actions">
            <button class="ghost" onclick="Actions.loadAdmins()">Muat Ulang</button>
            ${isOwner ? `<button class="primary" onclick="Actions.openCreateAdmin()">+ Tambah Admin</button>` : ''}
          </div>
        </div>
        <table class="table">
          <thead><tr><th>Nama</th><th>Email</th><th>Peran</th><th>Status</th><th>Login Terakhir</th><th>Aksi</th></tr></thead>
          <tbody>
            ${state.admins.map((a) => `
              <tr>
                <td>${escapeHtml(a.display_name || '-')}</td>
                <td class="mono">${escapeHtml(a.email || '-')}</td>
                <td><span class="badge ${a.role === 'owner' ? 'owner' : 'admin'}">${escapeHtml(a.role)}</span></td>
                <td><span class="badge ${escapeHtml(a.status)}">${escapeHtml(a.status)}</span></td>
                <td class="muted">${escapeHtml(formatDate(a.last_login_at))}</td>
                <td>
                  ${isOwner && a.admin_id !== state.admin.admin_id ? `
                    <div class="actions">
                      ${a.status === 'active' ? `<button class="ghost" onclick="Actions.setAdminStatus('${escapeHtml(a.admin_id)}','suspended')">Suspend</button>` : `<button class="ghost" onclick="Actions.setAdminStatus('${escapeHtml(a.admin_id)}','active')">Aktifkan</button>`}
                      <button class="ghost" onclick="Actions.resetAdminPassword('${escapeHtml(a.admin_id)}')">Reset Sandi</button>
                    </div>
                  ` : ''}
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  }

  function perisaiSignHtml() {
    const org = state.org || {};
    const defaultDsa = org.pqc_dsa_alg || 'ML-DSA-65';
    const defaultKem = org.pqc_kem_alg || 'ML-KEM-768';
    const artifacts = state.signedArtifacts || [];
    const logs = state.auditLogs || [];
    const vRes = state.verifyResult;
    const mode = state.signMode || 'command_instruction';
    const selFile = state.selectedUploadFile;
    const keyBundle = state.lastGeneratedKeyBundle;
    const users = state.users || [];
    const groups = state.groups || [];

    const recipientSelectHtml = `
      <select name="recipientTarget">
        <option value="all">🌐 Semua Agen Organisasi (Broadcast Terbuka + Segel ML-DSA)</option>
        ${users.length ? `
          <optgroup label="🎯 Spesifik Agen Lapangan (Enkripsi Kunci Publik ML-KEM Agen + AES-256-GCM)">
            ${users.map((u) => `
              <option value="agent|${escapeHtml(u.identity_id)}|${escapeHtml(u.display_name || 'Agen')}">
                🎯 Khusus Agen: ${escapeHtml(u.display_name || 'Agen')} (${u.status === 'active' ? 'Perangkat Aktif • Kunci ML-KEM Terikat' : 'Pending • Kunci ML-KEM Identitas'})
              </option>
            `).join('')}
          </optgroup>
        ` : ''}
        ${groups.length ? `
          <optgroup label="👥 Spesifik Grup Operasi">
            ${groups.map((g) => `
              <option value="group|${escapeHtml(g.conversation_id)}|${escapeHtml(g.title || 'Grup')}">
                👥 Khusus Grup: ${escapeHtml(g.title || 'Grup')}
              </option>
            `).join('')}
          </optgroup>
        ` : ''}
      </select>
    `;

    let modeDescription = '';
    let dynamicFormFields = '';
    let submitButtonLabel = '';

    if (mode === 'command_instruction') {
      modeDescription = `
        <strong>Mode 1 — Instruksi Komando Operasi (Broadcast atau Terenkripsi Spesifik Agen):</strong>
        Menandatangani surat perintah teks resmi menggunakan <strong>ML-DSA (44/65/87)</strong>.
        Jika Anda memilih <strong>🎯 Spesifik Agen Tertentu</strong> (misal <code>agent-sigung01</code>), isi perintah juga akan
        <strong>DIENKRIPSI menggunakan Public Key NIST FIPS 203 ML-KEM milik agen tersebut + AES-256-GCM</strong> sehingga hanya perangkat agen itu yang dapat membuka perintahnya!
      `;
      submitButtonLabel = '🔏 Tanda Tangani & Terbitkan Instruksi Komando (ML-DSA / ML-KEM)';
      dynamicFormFields = `
        <div class="row wrap" style="margin-top:10px">
          <div class="grow" style="flex:2">
            <label>🎯 Penerima Tujuan & Ikatan Kunci ML-KEM (Broadcast vs Spesifik Agen)</label>
            ${recipientSelectHtml}
          </div>
          <div class="grow">
            <label>Tingkat Klasifikasi Komando</label>
            <select name="classification">
              <option value="RAHASIA">RAHASIA (SECRET)</option>
              <option value="SANGAT RAHASIA">SANGAT RAHASIA (TOP SECRET)</option>
              <option value="TERBATAS">TERBATAS (RESTRICTED)</option>
            </select>
          </div>
        </div>
        <div class="row wrap" style="margin-top:10px">
          <div class="grow">
            <label>Unit Operasi Tujuan</label>
            <select name="targetUnit">
              <option value="Semua Unit Lapangan">Semua Unit Lapangan</option>
              <option value="Tim Taktis Alpha">Tim Taktis Alpha</option>
              <option value="Unit Siber & Sinyal">Unit Siber & Sinyal</option>
              <option value="Pos Komando Sektor">Pos Komando Sektor</option>
            </select>
          </div>
          <div class="grow">
            <label>Enkripsi Kunci Agen (Jika Pilih Agen Spesifik — FIPS 203)</label>
            <select name="kemAlgorithm">
              <option value="ML-KEM-512" ${defaultKem === 'ML-KEM-512' ? 'selected' : ''}>ML-KEM-512 (Kategori 1 • PK 800 B)</option>
              <option value="ML-KEM-768" ${defaultKem === 'ML-KEM-768' ? 'selected' : ''}>ML-KEM-768 (Kategori 3 • Rekomendasi • PK 1.184 B)</option>
              <option value="ML-KEM-1024" ${defaultKem === 'ML-KEM-1024' ? 'selected' : ''}>ML-KEM-1024 (Kategori 5 • Maksimum • PK 1.568 B)</option>
            </select>
          </div>
          <div class="grow">
            <label>Standar Tanda Tangan NIST FIPS 204</label>
            <select name="algorithm">
              <option value="ML-DSA-44" ${defaultDsa === 'ML-DSA-44' ? 'selected' : ''}>ML-DSA-44 (Kategori 2 • Sig 2.420 B)</option>
              <option value="ML-DSA-65" ${defaultDsa === 'ML-DSA-65' ? 'selected' : ''}>ML-DSA-65 (Kategori 3 • Rekomendasi • Sig 3.309 B)</option>
              <option value="ML-DSA-87" ${defaultDsa === 'ML-DSA-87' ? 'selected' : ''}>ML-DSA-87 (Kategori 5 • Maksimum • Sig 4.627 B)</option>
            </select>
          </div>
        </div>
        <div style="margin-top:10px">
          <label>Judul Surat Perintah Operasi</label>
          <input name="title" required maxlength="200" placeholder="Contoh: PERINTAH OPERASI SEKTOR ALPHA #09" />
        </div>
        <div style="margin-top:10px">
          <label>Isi Teks Instruksi Komando</label>
          <textarea name="contentText" rows="3" required placeholder="Tulis perintah komando resmi yang wajib diverifikasi keasliannya oleh personel lapangan..."></textarea>
        </div>
      `;
    } else if (mode === 'firmware_package') {
      modeDescription = `
        <strong>Mode 2 — Paket Firmware OT / IoT (Upload File Biner + Segel ML-DSA):</strong>
        Unggah file biner/update perangkat lapangan (Radio Taktis, Drone UAV, Sensor Radar, PLC). Sistem membaca byte file,
        menghitung <strong>Hash SHA-256</strong> dari file asli, dan menyegelnya dengan <strong>ML-DSA (44/65/87)</strong>
        agar perangkat menolak update palsu atau file yang disusupi malware.
      `;
      submitButtonLabel = '📡 Segel File Firmware OT/IoT dengan ML-DSA';
      dynamicFormFields = `
        <div class="row wrap" style="margin-top:10px">
          <div class="grow">
            <label>Model Perangkat Target (OT / IoT)</label>
            <select name="deviceModel">
              <option value="RADIO-TAKTIS-X2 (VHF/UHF)">RADIO-TAKTIS-X2 (VHF/UHF)</option>
              <option value="DRONE-UAV-RECON-04">DRONE-UAV-RECON-04</option>
              <option value="RADAR-SENSOR-PERIMETER">RADAR-SENSOR-PERIMETER</option>
              <option value="PLC-GARDU-SCADA-01">PLC-GARDU-SCADA-01</option>
            </select>
          </div>
          <div class="grow">
            <label>Nomor Versi Firmware</label>
            <input name="firmwareVersion" required maxlength="50" value="v4.2.0-build88" placeholder="Contoh: v4.2.0-build88" />
          </div>
          <div class="grow">
            <label>Standar Tanda Tangan NIST FIPS 204</label>
            <select name="algorithm">
              <option value="ML-DSA-44" ${defaultDsa === 'ML-DSA-44' ? 'selected' : ''}>ML-DSA-44 (Kategori 2 • Sig 2.420 B)</option>
              <option value="ML-DSA-65" ${defaultDsa === 'ML-DSA-65' ? 'selected' : ''}>ML-DSA-65 (Kategori 3 • Rekomendasi • Sig 3.309 B)</option>
              <option value="ML-DSA-87" ${defaultDsa === 'ML-DSA-87' ? 'selected' : ''}>ML-DSA-87 (Kategori 5 • Maksimum • Sig 4.627 B)</option>
            </select>
          </div>
        </div>
        <div class="row wrap" style="margin-top:10px">
          <div class="grow">
            <label>Nama Rilis Paket Firmware</label>
            <input name="title" required maxlength="200" placeholder="Contoh: UPDATE FIRMWARE RADIO TAKTIS X2 PATCH KEAMANAN KUANTUM" />
          </div>
          <div class="grow">
            <label>Pilih File Biner / Paket Firmware dari Komputer (Wajib Upload File)</label>
            <input type="file" required onchange="Actions.handleArtifactFileSelect(event)" />
          </div>
        </div>
        ${selFile ? `
          <div style="margin-top:8px;padding:8px 12px;background:var(--surface-2);border:1px solid #14b8a6;border-radius:8px;font-size:12px">
            📦 File siap disegel: <strong>${escapeHtml(selFile.name)}</strong> (${selFile.size.toLocaleString()} bytes • ${escapeHtml(selFile.mime || 'binary')})
          </div>
        ` : ''}
        <div style="margin-top:10px">
          <label>Catatan Rilis / Changelog Teknis (Opsional)</label>
          <textarea name="contentText" rows="2" placeholder="Contoh: Patch modul frekuensi anti-jamming & pembaruan bootloader..."></textarea>
        </div>
      `;
    } else {
      modeDescription = `
        <strong>Mode 3 — Enkripsi & Segel File Rahasia (ML-KEM + ML-DSA):</strong>
        Unggah file/dokumen rahasia dari komputer Anda. File akan <strong>DIENKRIPSI menggunakan NIST FIPS 203 ML-KEM (512/768/1024) + AES-256-GCM</strong>
        sekaligus <strong>DITANDATANGANI dengan NIST FIPS 204 ML-DSA (44/65/87)</strong>. Jika Anda memilih <strong>🎯 Spesifik Agen</strong>,
        file akan dikunci langsung ke Public Key ML-KEM perangkat agen tersebut!
      `;
      submitButtonLabel = '🔒 Enkripsi File (ML-KEM) & Segel Tanda Tangan (ML-DSA)';
      dynamicFormFields = `
        <div class="row wrap" style="margin-top:10px">
          <div class="grow" style="flex:2">
            <label>🎯 Penerima Tujuan File Rahasia (Ikatan Kunci ML-KEM Agen atau Kunci Mandiri)</label>
            ${recipientSelectHtml}
          </div>
          <div class="grow">
            <label>Algoritma Enkripsi Kunci File — NIST FIPS 203 (ML-KEM)</label>
            <select name="kemAlgorithm">
              <option value="ML-KEM-512" ${defaultKem === 'ML-KEM-512' ? 'selected' : ''}>ML-KEM-512 (Kategori 1 • PK 800 B • CT 768 B)</option>
              <option value="ML-KEM-768" ${defaultKem === 'ML-KEM-768' ? 'selected' : ''}>ML-KEM-768 (Kategori 3 • Rekomendasi • PK 1.184 B)</option>
              <option value="ML-KEM-1024" ${defaultKem === 'ML-KEM-1024' ? 'selected' : ''}>ML-KEM-1024 (Kategori 5 • Maksimum • PK 1.568 B)</option>
            </select>
          </div>
          <div class="grow">
            <label>Algoritma Segel Tanda Tangan — NIST FIPS 204 (ML-DSA)</label>
            <select name="algorithm">
              <option value="ML-DSA-44" ${defaultDsa === 'ML-DSA-44' ? 'selected' : ''}>ML-DSA-44 (Kategori 2 • Sig 2.420 B)</option>
              <option value="ML-DSA-65" ${defaultDsa === 'ML-DSA-65' ? 'selected' : ''}>ML-DSA-65 (Kategori 3 • Rekomendasi • Sig 3.309 B)</option>
              <option value="ML-DSA-87" ${defaultDsa === 'ML-DSA-87' ? 'selected' : ''}>ML-DSA-87 (Kategori 5 • Maksimum • Sig 4.627 B)</option>
            </select>
          </div>
        </div>
        <div class="row wrap" style="margin-top:10px">
          <div class="grow">
            <label>Judul Dokumen / File Rahasia</label>
            <input name="title" required maxlength="200" placeholder="Contoh: DOKUMEN INTELIJEN PETA TARGET SEKTOR 7" />
          </div>
          <div class="grow">
            <label>Pilih File dari Komputer untuk Dienkripsi (PDF, Gambar, Dokumen, ZIP, dll.)</label>
            <input type="file" required onchange="Actions.handleArtifactFileSelect(event)" />
          </div>
        </div>
        ${selFile ? `
          <div style="margin-top:8px;padding:8px 12px;background:var(--surface-2);border:1px solid #2dd4bf;border-radius:8px;font-size:12px">
            🔒 File siap dienkripsi dengan ML-KEM: <strong>${escapeHtml(selFile.name)}</strong> (${selFile.size.toLocaleString()} bytes • ${escapeHtml(selFile.mime || 'application/octet-stream')})
          </div>
        ` : ''}
        <div style="margin-top:10px">
          <label>Catatan / Keterangan Pengantar (Opsional)</label>
          <textarea name="contentText" rows="2" placeholder="Catatan pengantar (file utama akan dienkripsi penuh dengan ML-KEM + AES-256-GCM)..."></textarea>
        </div>
      `;
    }

    return `
      <div class="panel">
        <div class="flex between wrap" style="margin-bottom:14px">
          <div>
            <h2 style="margin:0">PERISAI-Sign & Proteksi File Pasca-Kuantum (NIST FIPS 203 ML-KEM & FIPS 204 ML-DSA)</h2>
            <p class="muted" style="margin:4px 0 0">
              Pilih salah satu dari <strong>3 mode proteksi</strong> di bawah ini: mendukung broadcast semua personel maupun <strong>enkripsi terikat kunci publik ML-KEM spesifik agen</strong>.
            </p>
          </div>
          <button class="ghost" onclick="Actions.loadPerisaiSign()">Muat Ulang</button>
        </div>

        <div class="row wrap" style="margin-bottom:14px;gap:8px">
          <button type="button" class="${mode === 'command_instruction' ? 'primary' : 'ghost'} grow" style="text-align:left;padding:12px" onclick="Actions.setSignMode('command_instruction')">
            <div style="font-weight:700">📋 1. Instruksi Komando Operasi</div>
            <div style="font-size:11px;opacity:0.85;margin-top:2px">Broadcast atau Enkripsi Spesifik Agen (ML-KEM + ML-DSA)</div>
          </button>
          <button type="button" class="${mode === 'firmware_package' ? 'primary' : 'ghost'} grow" style="text-align:left;padding:12px" onclick="Actions.setSignMode('firmware_package')">
            <div style="font-weight:700">📡 2. Paket Firmware OT / IoT</div>
            <div style="font-size:11px;opacity:0.85;margin-top:2px">Upload File Biner Perangkat • Hash SHA-256 & Segel ML-DSA</div>
          </button>
          <button type="button" class="${mode === 'field_report' ? 'primary' : 'ghost'} grow" style="text-align:left;padding:12px" onclick="Actions.setSignMode('field_report')">
            <div style="font-weight:700">🔒 3. Enkripsi & Segel File Rahasia</div>
            <div style="font-size:11px;opacity:0.85;margin-top:2px">Upload File -> Enkripsi ML-KEM (512/768/1024) + Segel ML-DSA</div>
          </button>
        </div>

        <div style="padding:10px 14px;background:var(--surface-2);border-left:3px solid var(--primary);border-radius:8px;font-size:12.5px;margin-bottom:12px">
          ${modeDescription}
        </div>

        <form onsubmit="Actions.submitSignArtifact(event)">
          <input type="hidden" name="artifactType" value="${escapeHtml(mode)}" />
          ${dynamicFormFields}
          <div style="margin-top:14px">
            <button type="submit" class="primary">${submitButtonLabel}</button>
          </div>
        </form>
      </div>

      ${keyBundle ? `
        <div class="panel" style="border:2px solid #2dd4bf;background:rgba(15, 118, 110, 0.12)">
          <div class="flex between wrap">
            <div>
              <h2 style="margin:0;color:#2dd4bf">
                🔑 ${keyBundle.bound_to_agent_kem ? `TERIKAT KUNCI PUBLIK ${escapeHtml(keyBundle.kem_algorithm)} MILIK AGEN "${escapeHtml(keyBundle.recipient_display_name)}"` : `KUNCI DEKRIPSI FILE (${escapeHtml(keyBundle.kem_algorithm)}) BERHASIL DIGENERATE!`}
              </h2>
              <p class="muted" style="margin:4px 0 0">
                ${keyBundle.bound_to_agent_kem
                  ? `Komando/file ini telah dienkripsi menggunakan <strong>Public Key ${escapeHtml(keyBundle.kem_algorithm)}</strong> milik perangkat <strong>${escapeHtml(keyBundle.recipient_display_name)}</strong> + AES-256-GCM dan disegel <strong>${escapeHtml(keyBundle.dsa_algorithm)}</strong>. Agen <strong>${escapeHtml(keyBundle.recipient_display_name)}</strong> dapat langsung membukanya dari aplikasi lapangan mereka!`
                  : `File <strong>${escapeHtml(keyBundle.file_name)}</strong> telah dienkripsi dengan <strong>${escapeHtml(keyBundle.kem_algorithm)} + AES-256-GCM</strong> dan disegel dengan <strong>${escapeHtml(keyBundle.dsa_algorithm)}</strong>. <strong style="color:#fbbf24">Simpan kunci ini sekarang!</strong>`
                }
              </p>
            </div>
            <button class="ghost" onclick="Actions.clearKeyBundle()">Tutup</button>
          </div>
          <div class="code-box" style="margin-top:10px">
            <div class="mono" style="font-size:11px;word-break:break-all;max-height:76px;overflow:auto;flex:1">
              ${escapeHtml(keyBundle.kem_secret_key_b64)}
            </div>
            <div class="actions">
              <button class="primary" onclick="Actions.copyKemKey()">📋 Salin Kunci ML-KEM</button>
              <button class="ghost" onclick="Actions.downloadKeyFile()">💾 Unduh File Kunci (.pqc-key.json)</button>
            </div>
          </div>
        </div>
      ` : ''}

      ${vRes ? `
        <div class="panel" style="border-color:${vRes.verified ? '#14b8a6' : '#ef4444'}">
          <div class="flex between wrap">
            <h2 style="margin:0;color:${vRes.verified ? '#2dd4bf' : '#f87171'}">
              ${vRes.verified ? '✅ VERIFIKASI ML-DSA VALID & OTENTIK' : '🚨 PERINGATAN INTEGRITAS: VERIFIKASI DITOLAK!'}
            </h2>
            <button class="ghost" onclick="Actions.clearVerifyResult()">Tutup Hasil</button>
          </div>
          <p style="margin:8px 0">${escapeHtml(vRes.message)}</p>
          <div class="row wrap mono" style="font-size:11.5px">
            <div class="grow">Algoritma: <strong>${escapeHtml(vRes.algorithm)} (${escapeHtml(vRes.nist_standard)})</strong></div>
            <div class="grow">Signature Valid: <strong>${escapeHtml(String(vRes.crypto_signature_valid))}</strong></div>
            <div class="grow">Hash Cocok: <strong>${escapeHtml(String(vRes.content_hash_matches))}</strong></div>
            <div class="grow">Penanda Tangan Dicabut: <strong>${escapeHtml(String(vRes.signer_revoked))}</strong></div>
          </div>
          <div class="mono muted" style="font-size:10.5px;margin-top:6px">
            Expected SHA-256: ${escapeHtml(vRes.expected_sha256)}<br/>
            Tested SHA-256: &nbsp;&nbsp;${escapeHtml(vRes.tested_sha256)}
          </div>
        </div>
      ` : ''}

      <div class="panel">
        <h2>Daftar Artefak Tertanda Tangan & File Terenkripsi (${artifacts.length})</h2>
        ${artifacts.length ? `
          <div style="overflow:auto">
          <table class="table">
            <thead>
              <tr>
                <th>Judul, Penerima & Detail File</th>
                <th>Algoritma NIST PQC</th>
                <th>Penanda Tangan</th>
                <th>Hash SHA-256</th>
                <th>Status</th>
                <th>Aksi Dekripsi, Verifikasi & Uji Tamper</th>
              </tr>
            </thead>
            <tbody>
              ${artifacts.map((a) => {
                const meta = a.meta || {};
                const isEncrypted = Boolean(meta.encrypted_with_kem);
                const isAgentBound = Boolean(meta.bound_to_agent_kem);
                const isFirmware = a.artifact_type === 'firmware_package';
                let typeBadge = '📋 INSTRUKSI KOMANDO';
                let recipientBadge = '<span class="badge active" style="font-size:9.5px">🌐 BROADCAST SEMUA AGEN</span>';
                if (meta.recipient_scope === 'agent' && meta.recipient_display_name) {
                  recipientBadge = `<span class="badge owner" style="font-size:9.5px">🎯 KHUSUS AGEN: ${escapeHtml(meta.recipient_display_name)}</span>`;
                } else if (meta.recipient_scope === 'group' && meta.recipient_display_name) {
                  recipientBadge = `<span class="badge admin" style="font-size:9.5px">👥 KHUSUS GRUP: ${escapeHtml(meta.recipient_display_name)}</span>`;
                }
                let extraInfo = '';
                if (isAgentBound && meta.is_text_command) {
                  typeBadge = '🔒 KOMANDO TERENKRIPSI AGEN';
                  extraInfo = `Terkunci Public Key ${meta.kem_algorithm || 'ML-KEM-768'} milik ${meta.recipient_display_name || 'Agen'} • Klasifikasi: ${meta.classification || 'SANGAT RAHASIA'}`;
                } else if (isEncrypted) {
                  typeBadge = '🔒 FILE TERENKRIPSI PQC';
                  extraInfo = `File: ${meta.file_name || '-'} (${(meta.file_size || 0).toLocaleString()} B) • Hanya bisa dibuka dengan Kunci ${meta.kem_algorithm || 'ML-KEM'}`;
                } else if (isFirmware) {
                  typeBadge = '📡 FIRMWARE OT/IoT';
                  extraInfo = `Perangkat: ${meta.device_model || 'OT'} • Versi: ${meta.firmware_version || '-'} • File: ${meta.file_name || 'teks'}`;
                } else {
                  extraInfo = `Klasifikasi: ${meta.classification || 'RAHASIA'} • Unit: ${meta.target_unit || 'Semua Unit'}`;
                }

                return `
                  <tr>
                    <td>
                      <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
                        <span class="badge ${isEncrypted ? 'owner' : 'admin'}" style="font-size:9.5px">${typeBadge}</span>
                        ${recipientBadge}
                        <strong>${escapeHtml(a.title)}</strong>
                      </div>
                      <div class="muted" style="font-size:11px;margin-top:3px">${escapeHtml(extraInfo)} • ${escapeHtml(formatDate(a.created_at))}</div>
                      <div class="muted" style="font-size:11px;max-width:360px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeHtml(a.content_text)}</div>
                    </td>
                    <td>
                      ${isEncrypted ? `<div style="margin-bottom:4px"><span class="badge owner mono">🔒 ${escapeHtml(meta.kem_algorithm || 'ML-KEM-768')}</span></div>` : ''}
                      <div><span class="badge active mono">🔏 ${escapeHtml(a.algorithm)}</span></div>
                    </td>
                    <td>${escapeHtml(a.signer_display_name)}</td>
                    <td class="mono" style="font-size:10.5px">${escapeHtml((a.content_hash_sha256 || '').slice(0, 18))}…</td>
                    <td><span class="badge ${escapeHtml(a.status)}">${escapeHtml(a.status)}</span></td>
                    <td>
                      <div class="actions">
                        ${isEncrypted && meta.bound_to_group_kem
                          ? `<button class="primary" onclick="Actions.decryptGroupPreview('${escapeHtml(a.artifact_id)}')">🔓 Pratinjau Dekripsi Grup</button>`
                          : (isEncrypted ? `<button class="primary" onclick="Actions.openDecryptModal('${escapeHtml(a.artifact_id)}')">🔓 Buka / Dekripsi File</button>` : '')}
                        ${isFirmware && meta.has_binary_payload ? `
                          <button class="primary" onclick="Actions.openVerifyFileModal('${escapeHtml(a.artifact_id)}')">🔍 Cek File</button>
                          <button class="ghost" onclick="Actions.downloadFirmware('${escapeHtml(a.artifact_id)}')">⬇️ Unduh</button>
                        ` : ''}
                        <button class="${isEncrypted ? 'ghost' : 'primary'}" onclick="Actions.verifyArtifact('${escapeHtml(a.artifact_id)}', false)">Verifikasi Segel</button>
                        <button class="ghost" onclick="Actions.verifyArtifact('${escapeHtml(a.artifact_id)}', true)">Uji Tamper 1-Bit</button>
                        ${a.status === 'active' ? `<button class="danger" onclick="Actions.revokeArtifact('${escapeHtml(a.artifact_id)}')">Cabut</button>` : ''}
                      </div>
                    </td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
          </div>
        ` : '<div class="empty">Belum ada artefak yang ditandatangani.</div>'}
      </div>

      <div class="panel">
        <h2>Log Audit Kriptografi PQC (${logs.length})</h2>
        ${logs.length ? `
          <div style="overflow:auto;max-height:280px">
          <table class="table">
            <thead><tr><th>Waktu</th><th>Event</th><th>Algoritma</th><th>Status</th><th>Aktor</th><th>Target</th></tr></thead>
            <tbody>
              ${logs.map((l) => `
                <tr>
                  <td class="muted">${escapeHtml(formatDate(l.created_at))}</td>
                  <td class="mono">${escapeHtml(l.event_type)}</td>
                  <td class="mono">${escapeHtml(l.algorithm)}</td>
                  <td><span class="badge ${l.status === 'VALID' || l.status === 'RSA_BROKEN_PQC_SAFE' ? 'active' : 'revoked'}">${escapeHtml(l.status)}</span></td>
                  <td>${escapeHtml(l.actor_name)}</td>
                  <td class="mono" style="font-size:10.5px">${escapeHtml(l.target_id || '-')}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          </div>
        ` : '<div class="empty">Belum ada log audit PQC.</div>'}
      </div>
    `;
  }

  function perisaiLabHtml() {
    const sim = state.quantumSim;
    const audit = state.fleetAudit;
    const bench = state.benchmark;
    const org = state.org || {};
    const defaultKem = org.pqc_kem_alg || 'ML-KEM-768';
    const defaultDsa = org.pqc_dsa_alg || 'ML-DSA-65';

    return `
      <div class="panel">
        <div class="flex between wrap" style="margin-bottom:12px">
          <div>
            <h2 style="margin:0">1. Simulator Serangan Kuantum (Shor's Period-Finding & QUBO vs NIST PQC)</h2>
            <p class="muted" style="margin:4px 0 0">
              Uji ketahanan RSA terhadap faktorisasi kuantum (Algoritma Shor & minimisasi energi QUBO <em>H(p,q) = (N - pq)²</em>)
              dibandingkan dengan ketahanan kisi Module-LWE pada <strong>ML-KEM (512/768/1024)</strong> dan <strong>ML-DSA (44/65/87)</strong>.
            </p>
          </div>
        </div>
        <form onsubmit="Actions.submitQuantumSim(event)">
          <div class="row wrap">
            <div class="grow">
              <label>Modulus Uji RSA (N = p × q)</label>
              <select name="rsaModulusN">
                <option value="3233">RSA N = 3233 (61 × 53 • 12-bit Semiprime)</option>
                <option value="143">RSA N = 143 (11 × 13 • 8-bit Semiprime)</option>
                <option value="10403">RSA N = 10403 (101 × 103 • 14-bit Semiprime)</option>
              </select>
            </div>
            <div class="grow">
              <label>Pembanding NIST FIPS 203 (ML-KEM)</label>
              <select name="compareKemAlg">
                <option value="ML-KEM-512" ${defaultKem === 'ML-KEM-512' ? 'selected' : ''}>ML-KEM-512 (Kategori 1)</option>
                <option value="ML-KEM-768" ${defaultKem === 'ML-KEM-768' ? 'selected' : ''}>ML-KEM-768 (Kategori 3 - Rekomendasi)</option>
                <option value="ML-KEM-1024" ${defaultKem === 'ML-KEM-1024' ? 'selected' : ''}>ML-KEM-1024 (Kategori 5)</option>
              </select>
            </div>
            <div class="grow">
              <label>Pembanding NIST FIPS 204 (ML-DSA)</label>
              <select name="compareDsaAlg">
                <option value="ML-DSA-44" ${defaultDsa === 'ML-DSA-44' ? 'selected' : ''}>ML-DSA-44 (Kategori 2)</option>
                <option value="ML-DSA-65" ${defaultDsa === 'ML-DSA-65' ? 'selected' : ''}>ML-DSA-65 (Kategori 3 - Rekomendasi)</option>
                <option value="ML-DSA-87" ${defaultDsa === 'ML-DSA-87' ? 'selected' : ''}>ML-DSA-87 (Kategori 5)</option>
              </select>
            </div>
          </div>
          <div style="margin-top:12px" class="actions">
            <button type="submit" class="primary">⚡ Jalankan Simulasi Serangan Kuantum</button>
            <button type="button" class="ghost" onclick="Actions.runFleetAudit()">🔍 Audit Kesiapan Armada</button>
            <button type="button" class="ghost" onclick="Actions.runBenchmark()">⏱️ Benchmark NIST 512/768/1024 & 44/65/87</button>
          </div>
        </form>

        ${sim ? `
          <div class="cards" style="margin-top:16px">
            <div class="card" style="border-color:#ef4444">
              <div class="label">Status RSA (N = ${sim.shor_simulation.modulus_n})</div>
              <div class="value" style="color:#f87171;font-size:18px">DITEMBUS (p=${sim.shor_simulation.recovered_factors[0]}, q=${sim.shor_simulation.recovered_factors[1]})</div>
              <div class="muted" style="font-size:11px;margin-top:4px">
                Periode r = ${sim.shor_simulation.period_r} • ${sim.shor_simulation.quantum_circuit_qubits} Qubits • Kunci Privat d = ${sim.rsa_break_demo.recovered_private_d}
              </div>
            </div>
            <div class="card" style="border-color:#14b8a6">
              <div class="label">Status ${escapeHtml(sim.pqc_comparison.ml_kem.algorithm)}</div>
              <div class="value" style="color:#2dd4bf;font-size:18px">QUANTUM-SAFE (Kategori ${sim.pqc_comparison.ml_kem.nist_category})</div>
              <div class="muted" style="font-size:11px;margin-top:4px">
                Module-LWE Rank k=${sim.pqc_comparison.ml_kem.lattice_rank_k} • PK ${sim.pqc_comparison.ml_kem.pk_bytes}B • CT ${sim.pqc_comparison.ml_kem.ct_bytes}B
              </div>
            </div>
            <div class="card" style="border-color:#14b8a6">
              <div class="label">Status ${escapeHtml(sim.pqc_comparison.ml_dsa.algorithm)}</div>
              <div class="value" style="color:#2dd4bf;font-size:18px">QUANTUM-SAFE (Kategori ${sim.pqc_comparison.ml_dsa.nist_category})</div>
              <div class="muted" style="font-size:11px;margin-top:4px">
                Module-SIS/LWE • PK ${sim.pqc_comparison.ml_dsa.pk_bytes}B • Sig ${sim.pqc_comparison.ml_dsa.sig_bytes}B
              </div>
            </div>
          </div>
          <div style="margin-top:10px;padding:10px;background:var(--surface-2);border-radius:8px;font-size:12px">
            <strong>Demonstrasi Dekripsi Paksa RSA oleh Komputer Kuantum:</strong>
            Pesan Rahasia <code>M = ${sim.rsa_break_demo.original_message}</code> dienkripsi menjadi Ciphertext <code>C = ${sim.rsa_break_demo.ciphertext}</code>.
            Dengan faktor prima hasil QFT <code>${sim.shor_simulation.recovered_factors.join(' × ')}</code>, penyerang menghitung <code>d = ${sim.rsa_break_demo.recovered_private_d}</code>
            dan memulihkan pesan asli <code>M' = ${sim.rsa_break_demo.decrypted_by_attacker}</code> dalam ${sim.elapsed_ms} ms.<br/>
            <strong>Mengapa PERISAI-Q Tahan:</strong> ${escapeHtml(sim.pqc_comparison.ml_kem.reason)}
          </div>
        ` : ''}
      </div>

      ${bench ? `
        <div class="panel">
          <h2>2. Hasil Benchmark Performa Standar NIST PQC (Target &lt; 50 ms)</h2>
          <div style="overflow:auto">
          <table class="table">
            <thead>
              <tr>
                <th>Algoritma</th>
                <th>Standar NIST</th>
                <th>Kategori</th>
                <th>Ukuran Kunci Publik</th>
                <th>Ukuran CT / Signature</th>
                <th>KeyGen</th>
                <th>Encap / Sign</th>
                <th>Decap / Verify</th>
                <th>Total Latensi</th>
              </tr>
            </thead>
            <tbody>
              ${(bench.ml_kem || []).map((r) => `
                <tr>
                  <td class="mono"><strong>${escapeHtml(r.algorithm)}</strong></td>
                  <td>${escapeHtml(r.standard)}</td>
                  <td>Kat. ${r.nist_category} (${escapeHtml(r.security_equivalent)})</td>
                  <td class="mono">${r.public_key_bytes} B</td>
                  <td class="mono">${r.ciphertext_bytes} B</td>
                  <td class="mono">${r.keygen_ms} ms</td>
                  <td class="mono">${r.encapsulate_ms} ms</td>
                  <td class="mono">${r.decapsulate_ms} ms</td>
                  <td class="mono" style="color:#2dd4bf"><strong>${r.total_ms} ms ✓</strong></td>
                </tr>
              `).join('')}
              ${(bench.ml_dsa || []).map((r) => `
                <tr>
                  <td class="mono"><strong>${escapeHtml(r.algorithm)}</strong></td>
                  <td>${escapeHtml(r.standard)}</td>
                  <td>Kat. ${r.nist_category} (${escapeHtml(r.security_equivalent)})</td>
                  <td class="mono">${r.public_key_bytes} B</td>
                  <td class="mono">${r.signature_bytes} B</td>
                  <td class="mono">${r.keygen_ms} ms</td>
                  <td class="mono">${r.sign_ms} ms</td>
                  <td class="mono">${r.verify_ms} ms</td>
                  <td class="mono" style="color:#2dd4bf"><strong>${r.total_ms} ms ✓</strong></td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          </div>
        </div>
      ` : ''}

      ${audit ? `
        <div class="panel">
          <h2>3. Laporan Audit Kesiapan Kriptografi Armada (${audit.summary.readiness_score_percent}% PQC Ready)</h2>
          <div class="cards" style="margin-bottom:14px">
            <div class="card"><div class="label">Skor Kesiapan PQC</div><div class="value" style="color:#2dd4bf">${audit.summary.readiness_score_percent}%</div></div>
            <div class="card"><div class="label">Perangkat PQC Aktif</div><div class="value">${audit.summary.pqc_ready_devices} / ${audit.summary.active_devices}</div></div>
            <div class="card"><div class="label">Pesan Hybrid PQC</div><div class="value">${audit.summary.hybrid_pqc_messages} / ${audit.summary.sampled_messages}</div></div>
            <div class="card"><div class="label">Artefak ML-DSA Aktif</div><div class="value">${audit.summary.active_signed_artifacts}</div></div>
          </div>
          <h3>Matriks Kerentanan Algoritma Klasik vs Mitigasi PERISAI-Q</h3>
          <div style="overflow:auto">
          <table class="table">
            <thead><tr><th>Algoritma</th><th>Penggunaan</th><th>Ancaman Kuantum</th><th>Status Risiko</th><th>Mitigasi PERISAI-Q</th></tr></thead>
            <tbody>
              ${(audit.legacy_vulnerability_matrix || []).map((m) => `
                <tr>
                  <td class="mono"><strong>${escapeHtml(m.algorithm)}</strong></td>
                  <td>${escapeHtml(m.usage)}</td>
                  <td>${escapeHtml(m.quantum_threat)}</td>
                  <td><span class="badge ${m.status.indexOf('SAFE') >= 0 ? 'active' : 'revoked'}">${escapeHtml(m.status)}</span></td>
                  <td>${escapeHtml(m.perisai_replacement)}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          </div>
        </div>
      ` : ''}
    `;
  }

  function settingsHtml() {
    const org = state.org || {};
    const admin = state.admin || {};
    const kemAlg = org.pqc_kem_alg || 'ML-KEM-768';
    const dsaAlg = org.pqc_dsa_alg || 'ML-DSA-65';
    return `
      <div class="cards">
        <div class="card"><div class="label">Organisasi</div><div class="value">${escapeHtml(org.organization_name || '-')}</div></div>
        <div class="card"><div class="label">Petugas</div><div class="value">${state.users.length}</div></div>
        <div class="card"><div class="label">Standar KEM (FIPS 203)</div><div class="value" style="font-size:17px;color:#2dd4bf">${escapeHtml(kemAlg)}</div></div>
        <div class="card"><div class="label">Standar DSA (FIPS 204)</div><div class="value" style="font-size:17px;color:#2dd4bf">${escapeHtml(dsaAlg)}</div></div>
      </div>
      <div class="panel">
        <h2>Informasi Organisasi & Kebijakan Kriptografi Pasca-Kuantum (NIST PQC)</h2>
        <form onsubmit="Actions.submitOrgName(event)">
          <div class="row wrap">
            <div class="grow">
              <label>Nama organisasi</label>
              <input name="organizationName" value="${escapeHtml(org.organization_name || '')}" required maxlength="150" />
            </div>
            <div class="grow">
              <label>Default ML-KEM (NIST FIPS 203)</label>
              <select name="pqcKemAlg">
                <option value="ML-KEM-512" ${kemAlg === 'ML-KEM-512' ? 'selected' : ''}>ML-KEM-512 (Kategori 1)</option>
                <option value="ML-KEM-768" ${kemAlg === 'ML-KEM-768' ? 'selected' : ''}>ML-KEM-768 (Kategori 3 - Rekomendasi)</option>
                <option value="ML-KEM-1024" ${kemAlg === 'ML-KEM-1024' ? 'selected' : ''}>ML-KEM-1024 (Kategori 5)</option>
              </select>
            </div>
            <div class="grow">
              <label>Default ML-DSA (NIST FIPS 204)</label>
              <select name="pqcDsaAlg">
                <option value="ML-DSA-44" ${dsaAlg === 'ML-DSA-44' ? 'selected' : ''}>ML-DSA-44 (Kategori 2)</option>
                <option value="ML-DSA-65" ${dsaAlg === 'ML-DSA-65' ? 'selected' : ''}>ML-DSA-65 (Kategori 3 - Rekomendasi)</option>
                <option value="ML-DSA-87" ${dsaAlg === 'ML-DSA-87' ? 'selected' : ''}>ML-DSA-87 (Kategori 5)</option>
              </select>
            </div>
          </div>
          <div style="margin-top:12px">
            <button type="submit" class="primary">Simpan Kebijakan Organisasi</button>
          </div>
        </form>
      </div>
      <div class="panel">
        <h2>Koneksi Backend</h2>
        <form onsubmit="Actions.submitBaseUrl(event)">
          <div class="row">
            <div class="grow"><label>API base URL</label><input name="baseUrl" value="${escapeHtml(state.baseUrl)}" required /></div>
            <button type="submit" class="primary">Simpan</button>
          </div>
        </form>
        <p class="muted" style="margin-top:10px">
          Token sesi administrator disimpan hanya di peramban ini. Kata sandi
          administrator tidak pernah disimpan.
        </p>
      </div>
      <div class="panel">
        <h2>Sesi Administrator</h2>
        <p class="muted">${escapeHtml(admin.email || '-')} • peran ${escapeHtml(admin.role || '-')}</p>
        <button class="danger" onclick="Actions.logout()">Keluar</button>
      </div>
    `;
  }

  // ---------------------------------------------------------------------------
  // Login
  // ---------------------------------------------------------------------------

  function loginHtml() {
    return `
      <div class="login-wrap">
        <div class="login-card">
          <div class="brand" style="padding:0;border:0;margin:0">
            <div class="brand-badge">SFC</div>
            <div><strong>Secure Field Comms</strong><span>Organization Console</span></div>
          </div>
          <h1>Masuk Administrator</h1>
          <p>Kelola pengguna, kredensial aktivasi, dan grup organisasi Anda.</p>
          ${state.error ? `<div class="error-box">${escapeHtml(state.error)}</div>` : ''}
          <form onsubmit="Actions.login(event)">
            <div>
              <label>Email administrator</label>
              <input name="email" type="email" required autocomplete="username" />
            </div>
            <div>
              <label>Kata sandi</label>
              <input name="password" type="password" required autocomplete="current-password" />
            </div>
            <div>
              <label>API base URL</label>
              <input name="baseUrl" value="${escapeHtml(state.baseUrl)}" required />
            </div>
            <button type="submit" class="primary" style="padding:12px">Masuk</button>
          </form>
        </div>
      </div>
    `;
  }

  // ---------------------------------------------------------------------------
  // Actions
  // ---------------------------------------------------------------------------

  const Actions = {
    async login(event) {
      event.preventDefault();
      const form = event.target;
      state.error = '';
      state.loading = true;
      setBaseUrl(form.baseUrl.value.trim());
      try {
        const data = await api('/organizations/auth/login', {
          method: 'POST',
          body: { email: form.email.value.trim(), password: form.password.value },
        });
        setToken(data.access_token);
        state.org = data.organization;
        state.admin = data.admin;
        await loadAll();
        render();
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    logout() {
      setToken(null);
      state.org = null;
      state.admin = null;
      state.users = [];
      state.groups = [];
      state.admins = [];
      state.directory = [];
      state.modal = null;
      state.groupDetail = null;
      state.error = '';
      state.success = '';
      render();
    },

    setView(view) {
      state.view = view;
      state.error = '';
      state.success = '';
      state.groupDetail = null;
      if (view === 'perisai_sign') {
        Actions.loadPerisaiSign();
        return;
      }
      if (view === 'perisai_lab' && !state.fleetAudit) {
        Actions.runFleetAudit();
        return;
      }
      render();
    },

    async loadPerisaiSign() {
      try {
        const [artifacts, logs, users, groups] = await Promise.all([
          api('/perisai/sign/artifacts'),
          api('/perisai/sign/audit-logs'),
          api('/organizations/users').catch(() => state.users || []),
          api('/groups').catch(() => state.groups || []),
        ]);
        state.signedArtifacts = artifacts || [];
        state.auditLogs = logs || [];
        state.users = users || [];
        state.groups = groups || [];
        renderView();
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    setSignMode(mode) {
      state.signMode = mode;
      state.selectedUploadFile = null;
      state.error = '';
      renderView();
    },

    handleArtifactFileSelect(event) {
      const file = event.target.files && event.target.files[0];
      if (!file) {
        state.selectedUploadFile = null;
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        const resultStr = String(reader.result || '');
        const commaIdx = resultStr.indexOf(',');
        const base64Data = commaIdx >= 0 ? resultStr.slice(commaIdx + 1) : resultStr;
        state.selectedUploadFile = {
          name: file.name,
          size: file.size,
          mime: file.type || 'application/octet-stream',
          base64: base64Data,
        };
        renderView();
      };
      reader.readAsDataURL(file);
    },

    async submitSignArtifact(event) {
      event.preventDefault();
      const form = event.target;
      const mode = form.artifactType ? form.artifactType.value : state.signMode;
      const body = {
        artifact_type: mode,
        algorithm: form.algorithm.value,
        title: form.title.value.trim(),
        content_text: form.contentText ? form.contentText.value.trim() : '',
      };

      if (form.recipientTarget && form.recipientTarget.value) {
        const rawTarget = form.recipientTarget.value;
        if (rawTarget.startsWith('agent|')) {
          const parts = rawTarget.split('|');
          body.recipient_scope = 'agent';
          body.recipient_identity_id = parts[1];
          body.recipient_display_name = parts.slice(2).join('|');
          body.encrypt_for_recipient = true;
          body.kem_algorithm = form.kemAlgorithm ? form.kemAlgorithm.value : 'ML-KEM-768';
        } else if (rawTarget.startsWith('group|')) {
          const parts = rawTarget.split('|');
          body.recipient_scope = 'group';
          body.recipient_group_id = parts[1];
          body.recipient_display_name = parts.slice(2).join('|');
          body.encrypt_for_recipient = true;
          body.kem_algorithm = form.kemAlgorithm ? form.kemAlgorithm.value : 'ML-KEM-768';
        } else {
          body.recipient_scope = 'all';
        }
      }

      if (mode === 'command_instruction') {
        body.classification = form.classification ? form.classification.value : 'RAHASIA';
        body.target_unit = form.targetUnit ? form.targetUnit.value : 'Semua Unit Lapangan';
        if (form.kemAlgorithm && form.kemAlgorithm.value) {
          body.kem_algorithm = form.kemAlgorithm.value;
        }
      } else if (mode === 'firmware_package') {
        if (!state.selectedUploadFile || !state.selectedUploadFile.base64) {
          state.error = 'Silakan pilih file biner/paket firmware terlebih dahulu.';
          render();
          return;
        }
        body.device_model = form.deviceModel ? form.deviceModel.value : 'OT-DEVICE';
        body.firmware_version = form.firmwareVersion ? form.firmwareVersion.value.trim() : 'v1.0.0';
        body.file_name = state.selectedUploadFile.name;
        body.file_mime = state.selectedUploadFile.mime;
        body.file_data_b64 = state.selectedUploadFile.base64;
      } else if (mode === 'field_report') {
        if (!state.selectedUploadFile || !state.selectedUploadFile.base64) {
          state.error = 'Silakan pilih file dari komputer untuk dienkripsi dengan ML-KEM.';
          render();
          return;
        }
        body.encrypt_with_kem = true;
        body.kem_algorithm = form.kemAlgorithm ? form.kemAlgorithm.value : 'ML-KEM-768';
        body.file_name = state.selectedUploadFile.name;
        body.file_mime = state.selectedUploadFile.mime;
        body.file_data_b64 = state.selectedUploadFile.base64;
      }

      try {
        const created = await api('/perisai/sign/artifacts', {
          method: 'POST',
          body,
        });
        state.selectedUploadFile = null;
        if (created && created.decryption_key_bundle) {
          state.lastGeneratedKeyBundle = created.decryption_key_bundle;
          if (created.decryption_key_bundle.bound_to_agent_kem) {
            state.success = `🎯 Komando/File berhasil DIENKRIPSI khusus dengan Public Key ${created.decryption_key_bundle.kem_algorithm} milik agen "${created.decryption_key_bundle.recipient_display_name}" dan disegel ${created.decryption_key_bundle.dsa_algorithm}!`;
          } else {
            state.success = `File "${created.decryption_key_bundle.file_name}" berhasil dienkripsi dengan ${created.decryption_key_bundle.kem_algorithm} dan disegel ${created.decryption_key_bundle.dsa_algorithm}! Simpan kunci dekripsi di bawah.`;
          }
        } else if (created && created.meta && created.meta.bound_to_group_kem) {
          state.success = `👥 Komando/File berhasil DIENKRIPSI khusus untuk ${created.meta.recipient_envelope_ids ? created.meta.recipient_envelope_ids.length : ''} anggota Grup "${created.meta.recipient_display_name}" (${created.meta.kem_algorithm} + ${created.algorithm})!`;
        } else if (mode === 'firmware_package') {
          state.success = 'Paket Firmware OT/IoT berhasil dihitung Hash SHA-256-nya dan disegel dengan ML-DSA.';
        } else {
          state.success = 'Instruksi Komando berhasil ditandatangani dengan ML-DSA dan diterbitkan.';
        }
        await Actions.loadPerisaiSign();
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    copyKemKey() {
      if (!state.lastGeneratedKeyBundle) return;
      Actions.copy(state.lastGeneratedKeyBundle.kem_secret_key_b64);
    },

    downloadKeyFile() {
      const b = state.lastGeneratedKeyBundle;
      if (!b) return;
      const jsonStr = JSON.stringify(b, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${(b.file_name || 'artifact').replace(/[^a-zA-Z0-9._-]/g, '_')}.pqc-key.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      Actions.toast('File kunci .pqc-key.json diunduh.');
    },

    clearKeyBundle() {
      state.lastGeneratedKeyBundle = null;
      renderView();
    },

    openDecryptModal(artifactId) {
      const artifact = (state.signedArtifacts || []).find((a) => a.artifact_id === artifactId);
      if (!artifact) return;
      let prefill = '';
      if (
        state.lastGeneratedKeyBundle &&
        state.lastGeneratedKeyBundle.artifact_id === artifactId
      ) {
        prefill = state.lastGeneratedKeyBundle.kem_secret_key_b64 || '';
      }
      state.modal = {
        type: 'decryptArtifact',
        artifact,
        prefillKey: prefill,
        decryptError: '',
      };
      render();
    },

    handleKeyFileImport(event) {
      const file = event.target.files && event.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const parsed = JSON.parse(String(reader.result || '{}'));
          const textarea = document.getElementById('decrypt-kem-key-input');
          if (textarea && parsed.kem_secret_key_b64) {
            textarea.value = parsed.kem_secret_key_b64;
            Actions.toast('Kunci privat ML-KEM berhasil dimuat dari file.');
          }
        } catch (_) {
          Actions.toast('Format file kunci tidak valid.', 'error');
        }
      };
      reader.readAsText(file);
    },

    fillFakeKemKey() {
      const textarea = document.getElementById('decrypt-kem-key-input');
      if (textarea) {
        textarea.value = btoa('FAKE-UNAUTHORIZED-ATTACKER-ML-KEM-SECRET-KEY-' + Date.now());
        Actions.toast('Kunci palsu dimasukkan — klik Dekripsi untuk melihat penolakan.');
      }
    },

    async decryptGroupPreview(artifactId) {
      try {
        const res = await api(`/perisai/sign/artifacts/${artifactId}/decrypt-agent`, {
          method: 'POST',
          body: { simulate_wrong_agent: false },
        });
        if (res.decrypted_text) {
          state.success = `🔓 Pratinjau Dekripsi Grup (${res.kem_algorithm}): "${res.decrypted_text}"`;
        } else {
          state.success = `🔓 Pratinjau Dekripsi Grup (${res.kem_algorithm}) berhasil untuk file "${res.file_name}" (${res.file_size} bytes).`;
        }
        await Actions.loadPerisaiSign();
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    async submitDecryptArtifact(event, artifactId) {
      event.preventDefault();
      const form = event.target;
      const kemKey = form.kemSecretKey.value.trim();
      try {
        const res = await api(`/perisai/sign/artifacts/${artifactId}/decrypt`, {
          method: 'POST',
          body: { kem_secret_key_b64: kemKey },
        });
        // Trigger browser download of decrypted original file
        const binStr = atob(res.file_data_b64);
        const bytes = new Uint8Array(binStr.length);
        for (let i = 0; i < binStr.length; i++) {
          bytes[i] = binStr.charCodeAt(i);
        }
        const blob = new Blob([bytes], { type: res.file_mime || 'application/octet-stream' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = res.file_name || 'decrypted-file';
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);

        state.modal = null;
        if (res.decrypted_text) {
          state.success = `✅ Dekripsi ${res.kem_algorithm} Berhasil! Isi perintah terbuka: "${res.decrypted_text}" (file ${res.file_name} juga diunduh).`;
        } else {
          state.success = `✅ Dekripsi ${res.kem_algorithm} & Verifikasi ${res.dsa_algorithm} Berhasil! File asli "${res.file_name}" (${res.file_size.toLocaleString()} bytes) telah diunduh.`;
        }
        await Actions.loadPerisaiSign();
      } catch (err) {
        if (state.modal && state.modal.type === 'decryptArtifact') {
          state.modal.decryptError = err.message;
        } else {
          state.error = err.message;
        }
        await Actions.loadPerisaiSign();
      }
    },

    openVerifyFileModal(artifactId) {
      const artifact = (state.signedArtifacts || []).find((a) => a.artifact_id === artifactId);
      if (!artifact) return;
      state.modal = {
        type: 'verifyFileArtifact',
        artifact,
        verifyFileBase64: null,
      };
      render();
    },

    handleVerifyFileSelect(event) {
      const file = event.target.files && event.target.files[0];
      if (!file || !state.modal) return;
      const reader = new FileReader();
      reader.onload = () => {
        const str = String(reader.result || '');
        const idx = str.indexOf(',');
        state.modal.verifyFileBase64 = idx >= 0 ? str.slice(idx + 1) : str;
      };
      reader.readAsDataURL(file);
    },

    async submitVerifyUploadedFile(event, artifactId) {
      event.preventDefault();
      if (!state.modal || !state.modal.verifyFileBase64) {
        Actions.toast('Pilih file terlebih dahulu.', 'error');
        return;
      }
      const b64 = state.modal.verifyFileBase64;
      state.modal = null;
      try {
        state.verifyResult = await api('/perisai/sign/verify', {
          method: 'POST',
          body: {
            artifact_id: artifactId,
            file_data_b64: b64,
          },
        });
        await Actions.loadPerisaiSign();
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    async downloadFirmware(artifactId) {
      try {
        const res = await api(`/perisai/sign/artifacts/${artifactId}/download-firmware`);
        const binStr = atob(res.file_data_b64);
        const bytes = new Uint8Array(binStr.length);
        for (let i = 0; i < binStr.length; i++) {
          bytes[i] = binStr.charCodeAt(i);
        }
        const blob = new Blob([bytes], { type: res.file_mime || 'application/octet-stream' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = res.file_name || 'firmware.bin';
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
        Actions.toast(`Paket firmware ${res.file_name} diunduh.`);
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    async verifyArtifact(artifactId, tamper) {
      try {
        const target = (state.signedArtifacts || []).find((a) => a.artifact_id === artifactId);
        const body = { artifact_id: artifactId };
        if (tamper && target) {
          body.content_text = target.content_text + ' [1-BIT-TAMPERED]';
        }
        state.verifyResult = await api('/perisai/sign/verify', {
          method: 'POST',
          body,
        });
        await Actions.loadPerisaiSign();
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    clearVerifyResult() {
      state.verifyResult = null;
      renderView();
    },

    async revokeArtifact(artifactId) {
      if (!confirm('Cabut sertifikat tanda tangan artefak ini?')) return;
      try {
        await api(`/perisai/sign/artifacts/${artifactId}/revoke`, { method: 'POST' });
        state.success = 'Artefak berhasil dicabut.';
        await Actions.loadPerisaiSign();
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    async submitQuantumSim(event) {
      event.preventDefault();
      const form = event.target;
      try {
        state.quantumSim = await api('/perisai/lab/simulate-rsa', {
          method: 'POST',
          body: {
            rsa_modulus_n: Number(form.rsaModulusN.value),
            public_exponent_e: 17,
            sample_message: 42,
            compare_kem_alg: form.compareKemAlg.value,
            compare_dsa_alg: form.compareDsaAlg.value,
          },
        });
        state.success = 'Simulasi serangan kuantum Shor & QUBO selesai.';
        renderView();
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    async runFleetAudit() {
      try {
        state.fleetAudit = await api('/perisai/lab/audit');
        renderView();
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    async runBenchmark() {
      try {
        state.benchmark = await api('/perisai/lab/benchmark', { method: 'POST' });
        state.success = 'Benchmark keenam varian standar NIST PQC selesai.';
        renderView();
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    async loadUsers() {
      state.users = await api('/organizations/users');
      renderView();
    },

    async loadGroups() {
      state.groups = await api('/groups');
      if (state.groupDetail) {
        const refreshed = state.groups.find(
          (g) => g.conversation_id === state.groupDetail.conversation_id,
        );
        if (refreshed) await Actions.openGroup(refreshed.conversation_id);
      } else {
        renderView();
      }
    },

    async loadAdmins() {
      state.admins = await api('/organizations/admins');
      renderView();
    },

    async loadDirectory() {
      state.directory = await api('/directory/members');
    },

    openCreateUser() {
      state.modal = { type: 'createUser' };
      render();
    },

    async submitCreateUser(event) {
      event.preventDefault();
      const form = event.target;
      try {
        const created = await api('/organizations/users', {
          method: 'POST',
          body: { display_name: form.displayName.value.trim() },
        });
        if (created && created.identity_id) {
          const cred = await api(`/organizations/users/${created.identity_id}/credentials`, {
            method: 'POST',
          });
          state.modal = {
            type: 'credential',
            code: cred.activation_code,
            expiresAt: formatDate(cred.expires_at),
          };
          state.success = `Akun petugas "${created.display_name}" dan Kode Aktivasi berhasil dibuat!`;
        } else {
          state.modal = null;
          state.success = 'Akun petugas dibuat.';
        }
        await Actions.loadUsers();
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    async issueCredential(userId) {
      try {
        const data = await api(`/organizations/users/${userId}/credentials`, {
          method: 'POST',
        });
        state.modal = {
          type: 'credential',
          code: data.activation_code,
          expiresAt: formatDate(data.expires_at),
        };
        await Actions.loadUsers();
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    async openUserDetail(userId) {
      try {
        const user = await api(`/organizations/users/${userId}`);
        state.modal = { type: 'userDetail', user };
        render();
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    async suspendUser(userId) {
      try {
        await api(`/organizations/users/${userId}`, {
          method: 'PATCH',
          body: { status: 'suspended' },
        });
        state.success = 'Akun ditangguhkan.';
        await Actions.loadUsers();
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    async activateUser(userId) {
      try {
        await api(`/organizations/users/${userId}`, {
          method: 'PATCH',
          body: { status: 'active' },
        });
        state.success = 'Akun diaktifkan kembali.';
        await Actions.loadUsers();
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    async revokeUser(userId) {
      if (!confirm('Cabut akun ini? Perangkat dan kredensial aktif akan dicabut.')) return;
      try {
        await api(`/organizations/users/${userId}/revoke`, { method: 'POST' });
        state.success = 'Akun dicabut.';
        await Actions.loadUsers();
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    openCreateGroup() {
      if (!state.directory.length) {
        Actions.loadDirectory().then(() => {
          state.modal = { type: 'createGroup' };
          render();
        });
        return;
      }
      state.modal = { type: 'createGroup' };
      render();
    },

    async submitCreateGroup(event) {
      event.preventDefault();
      const form = event.target;
      const groupAdminId = form.groupAdminId.value;
      const members = Array.from(form.querySelectorAll('input[name="members"]:checked'))
        .map((input) => input.value)
        .filter((id) => id !== groupAdminId);
      try {
        await api('/groups', {
          method: 'POST',
          body: {
            title: form.title.value.trim(),
            members,
            group_admin_identity_id: groupAdminId,
          },
        });
        state.modal = null;
        state.success = 'Grup dibuat.';
        await Actions.loadGroups();
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    async openGroup(groupId) {
      try {
        state.groupDetail = await api(`/groups/${groupId}`);
        await Actions.loadDirectory();
        renderView();
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    closeGroupDetail() {
      state.groupDetail = null;
      renderView();
    },

    async renameGroup(groupId) {
      const title = prompt('Nama grup baru:', state.groupDetail ? state.groupDetail.title : '');
      if (!title || !title.trim()) return;
      try {
        await api(`/groups/${groupId}`, {
          method: 'PATCH',
          body: { title: title.trim() },
        });
        state.success = 'Nama grup diperbarui.';
        await Actions.loadGroups();
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    async addGroupMember(groupId) {
      const select = document.getElementById('add-member-select');
      if (!select || !select.value) return;
      try {
        await api(`/groups/${groupId}/members`, {
          method: 'POST',
          body: { identity_id: select.value, member_role: 'member' },
        });
        state.success = 'Anggota ditambahkan dan epoch kunci dinaikkan.';
        await Actions.loadGroups();
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    async removeGroupMember(groupId, identityId) {
      if (!confirm('Keluarkan anggota ini dari grup?')) return;
      try {
        await api(`/groups/${groupId}/members/${identityId}`, { method: 'DELETE' });
        state.success = 'Anggota dikeluarkan dan epoch kunci dinaikkan.';
        await Actions.loadGroups();
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    openCreateAdmin() {
      state.modal = { type: 'createAdmin' };
      render();
    },

    async submitCreateAdmin(event) {
      event.preventDefault();
      const form = event.target;
      try {
        await api('/organizations/admins', {
          method: 'POST',
          body: {
            email: form.email.value.trim(),
            display_name: form.displayName.value.trim(),
            password: form.password.value,
            role: form.role.value,
          },
        });
        state.modal = null;
        state.success = 'Administrator ditambahkan.';
        await Actions.loadAdmins();
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    async setAdminStatus(adminId, status) {
      try {
        await api(`/organizations/admins/${adminId}`, {
          method: 'PATCH',
          body: { status },
        });
        state.success = 'Status administrator diperbarui.';
        await Actions.loadAdmins();
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    async resetAdminPassword(adminId) {
      const password = prompt('Kata sandi baru (min. 10 karakter):');
      if (!password || password.length < 10) {
        state.error = 'Kata sandi baru harus minimal 10 karakter.';
        render();
        return;
      }
      try {
        await api(`/organizations/admins/${adminId}`, {
          method: 'PATCH',
          body: { password },
        });
        state.success = 'Kata sandi administrator direset.';
        renderView();
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    async submitOrgName(event) {
      event.preventDefault();
      const form = event.target;
      try {
        const body = { organization_name: form.organizationName.value.trim() };
        if (form.pqcKemAlg) body.pqc_kem_alg = form.pqcKemAlg.value;
        if (form.pqcDsaAlg) body.pqc_dsa_alg = form.pqcDsaAlg.value;
        const data = await api('/organizations/me', {
          method: 'PATCH',
          body,
        });
        state.org = data.organization;
        state.success = 'Informasi dan kebijakan NIST PQC organisasi diperbarui.';
        render();
      } catch (err) {
        state.error = err.message;
        render();
      }
    },

    submitBaseUrl(event) {
      event.preventDefault();
      setBaseUrl(event.target.baseUrl.value.trim());
      state.success = 'Alamat backend disimpan.';
      render();
    },

    closeModal() {
      state.modal = null;
      render();
    },

    copy(text) {
      if (!text) return;
      navigator.clipboard.writeText(text).then(
        () => Actions.toast('Kode aktivasi disalin.'),
        () => Actions.toast('Gagal menyalin.', 'error'),
      );
    },

    toast(message, type) {
      const existing = document.querySelector('.toast');
      if (existing) existing.remove();
      const el = document.createElement('div');
      el.className = `toast ${type || ''}`;
      el.textContent = message;
      document.body.appendChild(el);
      setTimeout(() => el.remove(), 3500);
    },
  };

  window.Actions = Actions;

  // ---------------------------------------------------------------------------
  // Rendering helpers
  // ---------------------------------------------------------------------------

  function render() {
    const app = document.getElementById('app');
    app.innerHTML = state.token && state.org ? shellHtml() : loginHtml();
  }

  function renderView() {
    render();
  }

  async function loadAll() {
    const [users, groups, admins, directory] = await Promise.all([
      api('/organizations/users'),
      api('/groups'),
      api('/organizations/admins'),
      api('/directory/members'),
    ]);
    state.users = users || [];
    state.groups = groups || [];
    state.admins = admins || [];
    state.directory = directory || [];
  }

  function escapeHtml(value) {
    return String(value === null || value === undefined ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function formatDate(value) {
    if (!value) return '-';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value);
    return date.toLocaleString('id-ID', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  // ---------------------------------------------------------------------------
  // Bootstrap
  // ---------------------------------------------------------------------------

  async function bootstrap() {
    if (!state.token) {
      render();
      return;
    }
    try {
      const me = await api('/organizations/me');
      state.org = me.organization;
      state.admin = me.admin;
      await loadAll();
      render();
    } catch (err) {
      if (err.message && err.message.indexOf('401') >= 0) {
        Actions.logout();
        return;
      }
      state.error = err.message;
      render();
    }
  }

  bootstrap();
})();
