/* PERISAI-Q Mobile Agent Bridge for Precompiled Flutter Web Build
 * Provides interactive PERISAI-Sign (verify & ML-KEM file decrypt),
 * PERISAI-Vault, and PERISAI-Lab (Crypto-Agility key rotation & Shor simulator)
 * directly inside build/web without requiring a local Flutter SDK installation.
 */
(function () {
  'use strict';

  function getFlutterString(key) {
    const raw = localStorage.getItem('flutter.' + key);
    if (!raw) return null;
    try {
      return JSON.parse(raw);
    } catch (_) {
      return raw;
    }
  }

  function getBaseUrl() {
    return getFlutterString('sec_field_api_url') || 'http://localhost:8000/api/v1';
  }

  function getToken() {
    return getFlutterString('sec_field_token');
  }

  function getIdentity() {
    const str = getFlutterString('sec_field_identity');
    if (!str) return null;
    try {
      return typeof str === 'string' ? JSON.parse(str) : str;
    } catch (_) {
      return null;
    }
  }

  async function api(path, options = {}) {
    const token = getToken();
    const headers = { Accept: 'application/json' };
    if (options.body !== undefined) headers['Content-Type'] = 'application/json';
    if (token) headers['Authorization'] = 'Bearer ' + token;

    const res = await fetch(getBaseUrl() + path, {
      method: options.method || 'GET',
      headers,
      body: options.body !== undefined ? JSON.stringify(options.body) : undefined,
    });
    const json = await res.json().catch(() => null);
    if (!res.ok) {
      const msg = (json && json.error && json.error.message) || ('HTTP ' + res.status);
      throw new Error(msg);
    }
    return json ? json.data : null;
  }

  function escapeHtml(v) {
    return String(v == null ? '' : v)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  const state = {
    open: false,
    tab: 'sign', // 'sign' | 'vault' | 'lab'
    artifacts: [],
    vaultItems: JSON.parse(localStorage.getItem('perisai_agent_vault_v1') || '[]'),
    kemAlg: localStorage.getItem('perisai_agent_kem') || 'ML-KEM-768',
    dsaAlg: localStorage.getItem('perisai_agent_dsa') || 'ML-DSA-65',
    verifyResult: null,
    simResult: null,
    benchResult: null,
    decryptTargetId: null,
    unlockedByArtifactId: {},
    message: '',
    error: '',
  };

  function injectStyles() {
    const style = document.createElement('style');
    style.textContent = `
      #perisai-fab {
        position: fixed;
        right: 18px;
        bottom: 76px;
        z-index: 99998;
        background: linear-gradient(135deg, #0f766e, #14b8a6);
        color: #fff;
        border: 1px solid rgba(45, 212, 191, 0.6);
        border-radius: 999px;
        padding: 11px 16px;
        font-family: system-ui, -apple-system, sans-serif;
        font-size: 13px;
        font-weight: 700;
        cursor: pointer;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.5);
        display: flex;
        align-items: center;
        gap: 8px;
      }
      #perisai-fab:hover {
        filter: brightness(1.08);
      }
      #perisai-drawer-backdrop {
        position: fixed;
        inset: 0;
        background: rgba(2, 6, 23, 0.78);
        z-index: 99999;
        display: none;
        place-items: center;
        padding: 16px;
        font-family: system-ui, -apple-system, sans-serif;
        color: #e2e8f0;
      }
      #perisai-drawer-backdrop.open {
        display: grid;
      }
      .pq-modal {
        width: 100%;
        max-width: 780px;
        max-height: 90vh;
        background: #0f172a;
        border: 1px solid #1e293b;
        border-radius: 16px;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        box-shadow: 0 20px 50px rgba(0,0,0,0.65);
      }
      .pq-header {
        padding: 14px 18px;
        background: #111c30;
        border-bottom: 1px solid #1e293b;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .pq-tabs {
        display: flex;
        gap: 6px;
        padding: 10px 18px;
        background: #0b1220;
        border-bottom: 1px solid #1e293b;
      }
      .pq-tab {
        padding: 8px 14px;
        border-radius: 8px;
        border: 1px solid #1e293b;
        background: transparent;
        color: #94a3b8;
        cursor: pointer;
        font-size: 12.5px;
        font-weight: 600;
      }
      .pq-tab.active {
        background: rgba(45, 212, 191, 0.15);
        color: #2dd4bf;
        border-color: #14b8a6;
      }
      .pq-body {
        padding: 16px 18px;
        overflow-y: auto;
        font-size: 13px;
      }
      .pq-card {
        background: #111c30;
        border: 1px solid #1e293b;
        border-radius: 10px;
        padding: 12px 14px;
        margin-bottom: 12px;
      }
      .pq-btn {
        padding: 7px 12px;
        border-radius: 8px;
        border: 1px solid #334155;
        background: #1e293b;
        color: #e2e8f0;
        cursor: pointer;
        font-size: 12px;
        font-weight: 600;
      }
      .pq-btn.primary {
        background: #0f766e;
        border-color: #14b8a6;
        color: #fff;
      }
      .pq-btn.danger {
        background: rgba(239, 68, 68, 0.15);
        border-color: #ef4444;
        color: #f87171;
      }
      .pq-input, .pq-select, .pq-textarea {
        width: 100%;
        background: #0b1220;
        border: 1px solid #334155;
        color: #e2e8f0;
        border-radius: 8px;
        padding: 8px 10px;
        font-size: 12.5px;
        margin-top: 4px;
        box-sizing: border-box;
      }
      .pq-badge {
        display: inline-block;
        padding: 2px 8px;
        border-radius: 99px;
        font-size: 10.5px;
        font-weight: 700;
        background: rgba(45, 212, 191, 0.15);
        color: #2dd4bf;
        border: 1px solid rgba(45, 212, 191, 0.35);
      }
    `;
    document.head.appendChild(style);
  }

  async function loadArtifacts() {
    if (!getToken()) return;
    try {
      state.artifacts = (await api('/perisai/sign/artifacts')) || [];
      render();
    } catch (e) {
      state.error = e.message;
      render();
    }
  }

  function renderSignTab() {
    const list = state.artifacts || [];
    const v = state.verifyResult;
    const ident = getIdentity();
    const myIdentityId = ident && ident.identityId ? String(ident.identityId) : '';
    return `
      ${v ? `
        <div class="pq-card" style="border-color:${v.verified ? '#14b8a6' : '#ef4444'}">
          <div style="display:flex;justify-content:space-between;align-items:center">
            <strong style="color:${v.verified ? '#2dd4bf' : '#f87171'}">
              ${v.verified ? '✅ VERIFIKASI ML-DSA VALID & OTENTIK' : '🚨 PERINGATAN INTEGRITAS: INSTRUKSI DITOLAK!'}
            </strong>
            <button class="pq-btn" onclick="window.PerisaiAgent.clearVerify()">Tutup</button>
          </div>
          <div style="margin-top:6px;font-size:12px">${escapeHtml(v.message)}</div>
          <div style="margin-top:6px;font-family:monospace;font-size:11px;color:#94a3b8">
            Algoritma: ${escapeHtml(v.algorithm)} • Signature Valid: ${v.crypto_signature_valid} • Hash Cocok: ${v.content_hash_matches}
          </div>
        </div>
      ` : ''}

      ${state.decryptTargetId ? `
        <div class="pq-card" style="border-color:#2dd4bf">
          <strong>🔓 Masukkan Kunci Dekripsi ML-KEM untuk Membuka File Rahasia</strong>
          <p style="margin:4px 0 8px;font-size:11.5px;color:#94a3b8">
            Tempel Kunci Privat ML-KEM (Base64) atau unggah file <code>.pqc-key.json</code> yang diberikan oleh Admin Komando:
          </p>
          <input type="file" accept=".json,application/json" class="pq-input" onchange="window.PerisaiAgent.importKeyFile(event)" />
          <textarea id="pq-agent-decrypt-key" rows="3" class="pq-textarea" style="font-family:monospace;font-size:11px;margin-top:8px" placeholder="Tempel kem_secret_key_b64 di sini..."></textarea>
          <div style="margin-top:8px;display:flex;gap:8px;justify-content:flex-end">
            <button class="pq-btn danger" onclick="window.PerisaiAgent.fillFakeKey()">🧪 Tes Kunci Palsu</button>
            <button class="pq-btn" onclick="window.PerisaiAgent.closeDecrypt()">Batal</button>
            <button class="pq-btn primary" onclick="window.PerisaiAgent.submitDecrypt()">🔓 Dekripsi & Unduh File Asli</button>
          </div>
        </div>
      ` : ''}

      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
        <strong>📥 Instruksi Komando, Firmware & File Terenkripsi dari Markas (${list.length})</strong>
        <button class="pq-btn" onclick="window.PerisaiAgent.reload()">🔄 Muat Ulang</button>
      </div>

      ${list.length === 0 ? `
        <div class="pq-card" style="text-align:center;color:#94a3b8">
          Belum ada instruksi atau file dari Markas Komando.
        </div>
      ` : list.map((a) => {
        const meta = a.meta || {};
        const isEnc = Boolean(meta.encrypted_with_kem);
        const isAgentBound = Boolean(meta.bound_to_agent_kem);
        const isGroupBound = Boolean(meta.bound_to_group_kem);
        const isFw = a.artifact_type === 'firmware_package';
        const isForMeAgent = meta.recipient_scope === 'agent' && myIdentityId && meta.recipient_identity_id === myIdentityId;
        const isForMyGroup = meta.recipient_scope === 'group' && myIdentityId && Array.isArray(meta.recipient_envelope_ids) && meta.recipient_envelope_ids.includes(myIdentityId);
        const unlocked = state.unlockedByArtifactId[a.artifact_id];

        let recipientBadgeHtml = '<span class="pq-badge">🌐 Broadcast Organisasi</span>';
        if (isForMeAgent) {
          recipientBadgeHtml = `<span class="pq-badge" style="background:rgba(16,185,129,0.22);color:#34d399;border-color:#10b981">🎯 KHUSUS UNTUK ANDA (${escapeHtml(meta.recipient_display_name || 'Anda')})</span>`;
        } else if (meta.recipient_scope === 'agent') {
          recipientBadgeHtml = `<span class="pq-badge" style="background:rgba(245,158,11,0.18);color:#fbbf24;border-color:#f59e0b">🔒 KHUSUS AGEN: ${escapeHtml(meta.recipient_display_name || 'Agen Lain')}</span>`;
        } else if (isForMyGroup) {
          recipientBadgeHtml = `<span class="pq-badge" style="background:rgba(16,185,129,0.22);color:#34d399;border-color:#10b981">👥 KHUSUS GRUP ANDA (${escapeHtml(meta.recipient_display_name || 'Grup')})</span>`;
        } else if (meta.recipient_scope === 'group') {
          recipientBadgeHtml = `<span class="pq-badge" style="background:rgba(245,158,11,0.18);color:#fbbf24;border-color:#f59e0b">👥 KHUSUS GRUP: ${escapeHtml(meta.recipient_display_name || 'Grup')}</span>`;
        }

        const typeLabel = isAgentBound && meta.is_text_command
          ? '🔒 KOMANDO TERENKRIPSI ' + escapeHtml(meta.kem_algorithm || 'ML-KEM')
          : (isEnc ? '🔒 FILE TERENKRIPSI ' + escapeHtml(meta.kem_algorithm || 'ML-KEM') : (isFw ? '📡 FIRMWARE OT/IoT' : '📋 INSTRUKSI KOMANDO'));

        return `
          <div class="pq-card" style="${isForMeAgent || isForMyGroup ? 'border-color:#14b8a6;' : ''}">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;flex-wrap:wrap">
              <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
                <span class="pq-badge">${typeLabel}</span>
                ${recipientBadgeHtml}
                <strong style="font-size:14px">${escapeHtml(a.title)}</strong>
              </div>
              <span class="pq-badge">${escapeHtml(a.algorithm)}</span>
            </div>
            <div style="font-size:11.5px;color:#94a3b8;margin-top:4px">
              Pengirim: ${escapeHtml(a.signer_display_name)} • Status: <strong>${escapeHtml(a.status.toUpperCase())}</strong>
              ${meta.file_name ? ' • File: <code>' + escapeHtml(meta.file_name) + '</code>' : ''}
            </div>
            <div style="margin-top:8px;padding:8px;background:#0b1220;border-radius:6px;font-size:12px">
              ${escapeHtml(a.content_text)}
            </div>
            ${unlocked ? `
              <div style="margin-top:8px;padding:10px;background:rgba(16,185,129,0.12);border:1px solid #10b981;border-radius:8px">
                <div style="font-size:11px;font-weight:700;color:#34d399;margin-bottom:4px">
                  🔓 ISI PERINTAH / PAYLOAD ASLI TERBUKA (${escapeHtml(unlocked.kem_algorithm)} + AES-256-GCM • Segel ${escapeHtml(unlocked.dsa_algorithm)} VALID)
                </div>
                ${unlocked.decrypted_text ? `
                  <div style="padding:8px;background:#022c22;border-radius:6px;color:#ecfdf5;font-size:13px;white-space:pre-wrap">${escapeHtml(unlocked.decrypted_text)}</div>
                ` : `
                  <div style="font-size:12px;color:#ecfdf5">File <strong>${escapeHtml(unlocked.file_name)}</strong> (${(unlocked.file_size || 0).toLocaleString()} bytes) telah didekripsi.</div>
                `}
                <div style="margin-top:6px">
                  <button class="pq-btn" onclick="window.PerisaiAgent.downloadUnlocked('${escapeHtml(a.artifact_id)}')">⬇️ Unduh Salinan Dekripsi (${escapeHtml(unlocked.file_name || 'payload')})</button>
                </div>
              </div>
            ` : ''}
            <div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap">
              ${isAgentBound ? `
                <button class="pq-btn primary" onclick="window.PerisaiAgent.decryptAgent('${escapeHtml(a.artifact_id)}', false)">🔓 Dekripsi dengan Kunci ML-KEM Perangkat Saya</button>
                <button class="pq-btn danger" onclick="window.PerisaiAgent.decryptAgent('${escapeHtml(a.artifact_id)}', true)">🧪 Simulasi Buka Sebagai Agen Lain (Tanpa Kunci)</button>
              ` : (isEnc ? `<button class="pq-btn primary" onclick="window.PerisaiAgent.openDecrypt('${escapeHtml(a.artifact_id)}')">🔓 Buka / Dekripsi File (ML-KEM)</button>` : '')}
              ${isFw && meta.has_binary_payload ? `<button class="pq-btn primary" onclick="window.PerisaiAgent.downloadFw('${escapeHtml(a.artifact_id)}')">⬇️ Unduh Firmware</button>` : ''}
              <button class="pq-btn ${isEnc ? '' : 'primary'}" onclick="window.PerisaiAgent.verify('${escapeHtml(a.artifact_id)}', false)">✅ Verifikasi Segel ML-DSA</button>
              <button class="pq-btn danger" onclick="window.PerisaiAgent.verify('${escapeHtml(a.artifact_id)}', true)">🧪 Simulasi Tamper 1-Bit</button>
            </div>
          </div>
        `;
      }).join('')}
    `;
  }

  function renderVaultTab() {
    const items = state.vaultItems || [];
    return `
      <div class="pq-card">
        <strong>🔐 PERISAI-Vault — Brankas Lokal Agen (${escapeHtml(state.kemAlg)} + AES-256-GCM + ${escapeHtml(state.dsaAlg)})</strong>
        <p style="font-size:11.5px;color:#94a3b8;margin:4px 0 8px">
          Simpan koordinat taktis atau catatan rahasia di perangkat agen dengan perlindungan pasca-kuantum.
        </p>
        <input id="pq-vault-title" class="pq-input" placeholder="Judul Arsip / Koordinat Taktis..." />
        <textarea id="pq-vault-content" rows="2" class="pq-textarea" placeholder="Isi rahasia yang akan dikunci di PERISAI-Vault..."></textarea>
        <div style="margin-top:8px">
          <button class="pq-btn primary" onclick="window.PerisaiAgent.addVault()">🔒 Enkripsi & Simpan ke PERISAI-Vault</button>
        </div>
      </div>
      ${items.map((it, idx) => `
        <div class="pq-card">
          <div style="display:flex;justify-content:space-between">
            <strong>${escapeHtml(it.title)}</strong>
            <span class="pq-badge">${escapeHtml(it.kem)} + ${escapeHtml(it.dsa)}</span>
          </div>
          <div style="margin-top:6px;padding:8px;background:#0b1220;border-radius:6px;font-size:12px">
            ${escapeHtml(it.content)}
          </div>
          <div style="margin-top:6px;display:flex;justify-content:space-between;align-items:center">
            <span style="font-family:monospace;font-size:10.5px;color:#94a3b8">AEAD: AES-256-GCM • Disimpan: ${escapeHtml(it.time)}</span>
            <button class="pq-btn danger" onclick="window.PerisaiAgent.removeVault(${idx})">Hapus</button>
          </div>
        </div>
      `).join('')}
    `;
  }

  function renderLabTab() {
    const sim = state.simResult;
    return `
      <div class="pq-card">
        <strong>⚡ Crypto-Agility: Rotasi Profil Standar NIST PQC Perangkat Agen</strong>
        <p style="font-size:11.5px;color:#94a3b8;margin:4px 0 8px">
          Ganti varian algoritma <strong>ML-KEM (512/768/1024)</strong> dan <strong>ML-DSA (44/65/87)</strong> perangkat ini secara langsung tanpa ganti akun:
        </p>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
          <div>
            <label style="font-size:11px;color:#94a3b8">NIST FIPS 203 (ML-KEM)</label>
            <select id="pq-rot-kem" class="pq-select">
              <option value="ML-KEM-512" ${state.kemAlg === 'ML-KEM-512' ? 'selected' : ''}>ML-KEM-512 (Kategori 1)</option>
              <option value="ML-KEM-768" ${state.kemAlg === 'ML-KEM-768' ? 'selected' : ''}>ML-KEM-768 (Kategori 3 - Rekomendasi)</option>
              <option value="ML-KEM-1024" ${state.kemAlg === 'ML-KEM-1024' ? 'selected' : ''}>ML-KEM-1024 (Kategori 5)</option>
            </select>
          </div>
          <div>
            <label style="font-size:11px;color:#94a3b8">NIST FIPS 204 (ML-DSA)</label>
            <select id="pq-rot-dsa" class="pq-select">
              <option value="ML-DSA-44" ${state.dsaAlg === 'ML-DSA-44' ? 'selected' : ''}>ML-DSA-44 (Kategori 2)</option>
              <option value="ML-DSA-65" ${state.dsaAlg === 'ML-DSA-65' ? 'selected' : ''}>ML-DSA-65 (Kategori 3 - Rekomendasi)</option>
              <option value="ML-DSA-87" ${state.dsaAlg === 'ML-DSA-87' ? 'selected' : ''}>ML-DSA-87 (Kategori 5)</option>
            </select>
          </div>
        </div>
        <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap">
          <button class="pq-btn primary" onclick="window.PerisaiAgent.rotateKeys()">🔄 Putar (Rotate) Kunci PQC Perangkat</button>
          <button class="pq-btn" onclick="window.PerisaiAgent.runSim()">🧪 Jalankan Simulasi Serangan Kuantum Shor/QUBO</button>
        </div>
      </div>

      ${sim ? `
        <div class="pq-card" style="border-color:#14b8a6">
          <strong>Hasil Simulasi Serangan Kuantum (Shor + QUBO):</strong>
          <div style="margin-top:6px;font-size:12px">
            • <strong>RSA (N=${sim.shor_simulation.modulus_n})</strong>: <span style="color:#f87171">JEBOL</span> (Faktor ditemukan: ${sim.shor_simulation.recovered_factors.join(' × ')}, kunci privat d=${sim.rsa_break_demo.recovered_private_d})<br/>
            • <strong>${escapeHtml(sim.pqc_comparison.ml_kem.algorithm)} & ${escapeHtml(sim.pqc_comparison.ml_dsa.algorithm)}</strong>: <span style="color:#2dd4bf">AMAN (QUANTUM-SAFE)</span>
          </div>
        </div>
      ` : ''}
    `;
  }

  function render() {
    let backdrop = document.getElementById('perisai-drawer-backdrop');
    if (!backdrop) return;
    backdrop.className = state.open ? 'open' : '';
    if (!state.open) return;

    const token = getToken();
    const ident = getIdentity();

    backdrop.innerHTML = `
      <div class="pq-modal" onclick="event.stopPropagation()">
        <div class="pq-header">
          <div>
            <div style="font-weight:800;font-size:15px;color:#2dd4bf">🛡️ PERISAI-Q — Panel Kriptografi Pasca-Kuantum Agen Lapangan</div>
            <div style="font-size:11.5px;color:#94a3b8">
              ${ident ? 'Agen: ' + escapeHtml(ident.displayName || ident.publicIdentity || 'Aktif') + ' • ' : ''}
              Profil Aktif: <strong>${escapeHtml(state.kemAlg)} + ${escapeHtml(state.dsaAlg)}</strong>
            </div>
          </div>
          <button class="pq-btn" onclick="window.PerisaiAgent.toggle(false)">✕ Tutup</button>
        </div>
        <div class="pq-tabs">
          <button class="pq-tab ${state.tab === 'sign' ? 'active' : ''}" onclick="window.PerisaiAgent.setTab('sign')">📜 PERISAI-Sign (Komando & Dekripsi File)</button>
          <button class="pq-tab ${state.tab === 'vault' ? 'active' : ''}" onclick="window.PerisaiAgent.setTab('vault')">🔐 PERISAI-Vault (Brankas Lokal)</button>
          <button class="pq-tab ${state.tab === 'lab' ? 'active' : ''}" onclick="window.PerisaiAgent.setTab('lab')">🧪 PERISAI-Lab & Rotasi Kunci</button>
        </div>
        <div class="pq-body">
          ${!token ? `
            <div class="pq-card" style="border-color:#fbbf24;color:#fbbf24">
              ⚠️ Silakan lakukan <strong>Aktivasi Akun Agen</strong> terlebih dahulu pada layar utama aplikasi menggunakan <strong>Kode Aktivasi</strong> dari Web Console Admin.
            </div>
          ` : ''}
          ${state.error ? `<div class="pq-card" style="border-color:#ef4444;color:#f87171">${escapeHtml(state.error)}</div>` : ''}
          ${state.message ? `<div class="pq-card" style="border-color:#14b8a6;color:#2dd4bf">${escapeHtml(state.message)}</div>` : ''}
          ${state.tab === 'sign' ? renderSignTab() : (state.tab === 'vault' ? renderVaultTab() : renderLabTab())}
        </div>
      </div>
    `;
  }

  window.PerisaiAgent = {
    toggle(open) {
      state.open = open !== undefined ? open : !state.open;
      state.error = '';
      state.message = '';
      if (state.open) loadArtifacts();
      render();
    },
    setTab(tab) {
      state.tab = tab;
      state.error = '';
      state.message = '';
      render();
    },
    reload() {
      loadArtifacts();
    },
    clearVerify() {
      state.verifyResult = null;
      render();
    },
    async verify(artifactId, tamper) {
      state.error = '';
      try {
        const target = (state.artifacts || []).find((a) => a.artifact_id === artifactId);
        const body = { artifact_id: artifactId };
        if (tamper && target) {
          body.content_text = target.content_text + ' [1-BIT-TAMPERED]';
        }
        state.verifyResult = await api('/perisai/sign/verify', { method: 'POST', body });
        render();
      } catch (e) {
        state.error = e.message;
        render();
      }
    },
    openDecrypt(artifactId) {
      state.decryptTargetId = artifactId;
      state.error = '';
      state.message = '';
      render();
    },
    closeDecrypt() {
      state.decryptTargetId = null;
      render();
    },
    importKeyFile(event) {
      const f = event.target.files && event.target.files[0];
      if (!f) return;
      const r = new FileReader();
      r.onload = () => {
        try {
          const parsed = JSON.parse(String(r.result || '{}'));
          const el = document.getElementById('pq-agent-decrypt-key');
          if (el && parsed.kem_secret_key_b64) {
            el.value = parsed.kem_secret_key_b64;
          }
        } catch (_) {}
      };
      r.readAsText(f);
    },
    fillFakeKey() {
      const el = document.getElementById('pq-agent-decrypt-key');
      if (el) el.value = btoa('WRONG-KEM-SECRET-KEY-' + Date.now());
    },
    async submitDecrypt() {
      const el = document.getElementById('pq-agent-decrypt-key');
      const key = el ? el.value.trim() : '';
      if (!key || !state.decryptTargetId) return;
      state.error = '';
      try {
        const res = await api('/perisai/sign/artifacts/' + state.decryptTargetId + '/decrypt', {
          method: 'POST',
          body: { kem_secret_key_b64: key },
        });
        window.PerisaiAgent._triggerDownload(res.file_data_b64, res.file_mime, res.file_name || 'decrypted-file');
        state.decryptTargetId = null;
        state.message = '✅ File "' + res.file_name + '" berhasil didekripsi dengan ' + res.kem_algorithm + ' dan diunduh!';
        render();
      } catch (e) {
        state.error = e.message;
        render();
      }
    },
    _triggerDownload(b64, mime, fileName) {
      const binStr = atob(b64);
      const bytes = new Uint8Array(binStr.length);
      for (let i = 0; i < binStr.length; i++) bytes[i] = binStr.charCodeAt(i);
      const blob = new Blob([bytes], { type: mime || 'application/octet-stream' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName || 'decrypted-file';
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    },
    downloadUnlocked(artifactId) {
      const unlocked = state.unlockedByArtifactId[artifactId];
      if (!unlocked || !unlocked.file_data_b64) return;
      window.PerisaiAgent._triggerDownload(unlocked.file_data_b64, unlocked.file_mime, unlocked.file_name);
    },
    async decryptAgent(artifactId, simulateWrongAgent) {
      state.error = '';
      state.message = '';
      try {
        const res = await api('/perisai/sign/artifacts/' + artifactId + '/decrypt-agent', {
          method: 'POST',
          body: { simulate_wrong_agent: Boolean(simulateWrongAgent) },
        });
        state.unlockedByArtifactId[artifactId] = res;
        if (!res.is_text_command && res.file_data_b64) {
          window.PerisaiAgent._triggerDownload(res.file_data_b64, res.file_mime, res.file_name);
        }
        state.message = '🔓 ' + (res.message || 'Dekripsi ML-KEM berhasil!');
        render();
      } catch (e) {
        delete state.unlockedByArtifactId[artifactId];
        state.error = e.message;
        render();
      }
    },
    async downloadFw(artifactId) {
      try {
        const res = await api('/perisai/sign/artifacts/' + artifactId + '/download-firmware');
        const binStr = atob(res.file_data_b64);
        const bytes = new Uint8Array(binStr.length);
        for (let i = 0; i < binStr.length; i++) bytes[i] = binStr.charCodeAt(i);
        const blob = new Blob([bytes], { type: res.file_mime || 'application/octet-stream' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = res.file_name || 'firmware.bin';
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
        state.message = '📦 Paket firmware "' + res.file_name + '" berhasil diunduh.';
        render();
      } catch (e) {
        state.error = e.message;
        render();
      }
    },
    addVault() {
      const t = document.getElementById('pq-vault-title');
      const c = document.getElementById('pq-vault-content');
      if (!t || !c || !t.value.trim() || !c.value.trim()) return;
      state.vaultItems.unshift({
        title: t.value.trim(),
        content: c.value.trim(),
        kem: state.kemAlg,
        dsa: state.dsaAlg,
        time: new Date().toLocaleTimeString(),
      });
      localStorage.setItem('perisai_agent_vault_v1', JSON.stringify(state.vaultItems));
      state.message = '🔒 Arsip dienkripsi dengan ' + state.kemAlg + ' + AES-256-GCM dan disimpan di PERISAI-Vault.';
      render();
    },
    removeVault(idx) {
      state.vaultItems.splice(idx, 1);
      localStorage.setItem('perisai_agent_vault_v1', JSON.stringify(state.vaultItems));
      render();
    },
    async rotateKeys() {
      const kemEl = document.getElementById('pq-rot-kem');
      const dsaEl = document.getElementById('pq-rot-dsa');
      const kem = kemEl ? kemEl.value : 'ML-KEM-768';
      const dsa = dsaEl ? dsaEl.value : 'ML-DSA-65';
      try {
        await api('/devices/me/pqc-keys', {
          method: 'POST',
          body: { pqc_kem_alg: kem, pqc_dsa_alg: dsa },
        });
        state.kemAlg = kem;
        state.dsaAlg = dsa;
        localStorage.setItem('perisai_agent_kem', kem);
        localStorage.setItem('perisai_agent_dsa', dsa);
        state.message = '✅ Kunci PQC perangkat berhasil dirotasi ke ' + kem + ' + ' + dsa + '!';
        render();
      } catch (e) {
        state.error = e.message;
        render();
      }
    },
    async runSim() {
      try {
        state.simResult = await api('/perisai/lab/simulate-rsa', {
          method: 'POST',
          body: {
            rsa_modulus_n: 3233,
            public_exponent_e: 17,
            sample_message: 42,
            compare_kem_alg: state.kemAlg,
            compare_dsa_alg: state.dsaAlg,
          },
        });
        render();
      } catch (e) {
        state.error = e.message;
        render();
      }
    },
  };

  function init() {
    injectStyles();
    const fab = document.createElement('button');
    fab.id = 'perisai-fab';
    fab.innerHTML = '🛡️ PERISAI-Q (PQC)';
    fab.onclick = () => window.PerisaiAgent.toggle(true);
    document.body.appendChild(fab);

    const backdrop = document.createElement('div');
    backdrop.id = 'perisai-drawer-backdrop';
    backdrop.onclick = () => window.PerisaiAgent.toggle(false);
    document.body.appendChild(backdrop);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
