import 'dart:async';
import 'dart:convert';

import 'package:web_socket_channel/web_socket_channel.dart';

import 'storage_service.dart';

class WebSocketService {
  static final WebSocketService _instance = WebSocketService._internal();
  factory WebSocketService() => _instance;
  WebSocketService._internal();

  final _storage = StorageService();
  WebSocketChannel? _channel;
  StreamSubscription? _subscription;
  Timer? _reconnectTimer;
  bool _isConnected = false;
  bool _manualClose = false;
  bool _connecting = false;

  /// Called with (messageId, conversationId) when a new message is available.
  void Function(String messageId, String conversationId)? onMessageAvailable;

  /// Called when a group membership change requires a member-device refresh.
  void Function(String groupId, int keyEpoch)? onGroupMembershipChanged;

  /// Called when another member starts a personal conversation with us.
  void Function()? onConversationStarted;

  bool get isConnected => _isConnected;

  Future<void> connect() async {
    if (_isConnected || _connecting) return;
    _connecting = true;
    _manualClose = false;

    final token = await _storage.getToken();
    if (token == null || token.isEmpty) {
      _connecting = false;
      return;
    }

    final wsUrl = await _storage.getWsUrl();
    final uri = Uri.parse('$wsUrl?token=$token');

    try {
      _channel = WebSocketChannel.connect(uri);
      await _channel!.ready;
      _isConnected = true;

      _subscription = _channel!.stream.listen(
        (message) {
          try {
            final data = jsonDecode(message.toString());
            final event = data['event'];
            final eventData = data['data'] ?? {};
            if (event == 'message_available') {
              final msgId = eventData['message_id'];
              final convId = eventData['conversation_id'];
              if (msgId != null && convId != null) {
                onMessageAvailable?.call(msgId.toString(), convId.toString());
              }
            } else if (event == 'group_membership_changed') {
              final groupId = eventData['group_id']?.toString();
              final epochRaw = eventData['key_epoch'];
              final epoch = epochRaw is int
                  ? epochRaw
                  : int.tryParse(epochRaw?.toString() ?? '') ?? 1;
              if (groupId != null) {
                onGroupMembershipChanged?.call(groupId, epoch);
              }
            } else if (event == 'conversation_started') {
              onConversationStarted?.call();
            }
          } catch (_) {
            // Ignore malformed relay events.
          }
        },
        onError: (_) => _handleDisconnect(),
        onDone: _handleDisconnect,
        cancelOnError: true,
      );
    } catch (_) {
      _isConnected = false;
      _scheduleReconnect();
    } finally {
      _connecting = false;
    }
  }

  void acknowledgeMessage(String messageId) {
    if (_channel != null && _isConnected) {
      try {
        _channel!.sink.add(
          jsonEncode({
            'event': 'message_acknowledged',
            'data': {'message_id': messageId},
          }),
        );
      } catch (_) {
        // Best effort only.
      }
    }
  }

  void _handleDisconnect() {
    _isConnected = false;
    _channel = null;
    _subscription?.cancel();
    _subscription = null;
    if (!_manualClose) _scheduleReconnect();
  }

  void _scheduleReconnect() {
    if (_manualClose) return;
    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(const Duration(seconds: 5), () {
      if (!_isConnected) connect();
    });
  }

  void disconnect() {
    _manualClose = true;
    _reconnectTimer?.cancel();
    _subscription?.cancel();
    _subscription = null;
    _channel?.sink.close();
    _channel = null;
    _isConnected = false;
  }
}
