import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/identity.dart';
import '../models/perisai_models.dart';

class StorageService {
  static const _keyIdentity = 'sec_field_identity';
  static const _keyToken = 'sec_field_token';
  static const _keyBaseUrl = 'sec_field_api_url';
  static const _keyVaultItems = 'perisai_vault_items_v1';
  static const _keyOutboxItems = 'perisai_outbox_items_v1';

  static final StorageService _instance = StorageService._internal();
  factory StorageService() => _instance;
  StorageService._internal();

  /// Android emulators reach the host machine through 10.0.2.2.
  static String get defaultBaseUrl {
    if (kIsWeb) return 'http://localhost:8000/api/v1';
    if (defaultTargetPlatform == TargetPlatform.android) {
      return 'http://10.0.2.2:8000/api/v1';
    }
    return 'http://localhost:8000/api/v1';
  }

  Future<void> saveIdentity(LocalIdentity identity) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyIdentity, jsonEncode(identity.toJson()));
  }

  Future<LocalIdentity?> getIdentity() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_keyIdentity);
    if (raw == null) return null;
    try {
      return LocalIdentity.fromJson(jsonDecode(raw));
    } catch (_) {
      return null;
    }
  }

  Future<void> clearIdentity() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_keyIdentity);
    await prefs.remove(_keyToken);
  }

  Future<void> saveToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyToken, token);
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyToken);
  }

  Future<void> clearToken() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_keyToken);
  }

  Future<void> saveBaseUrl(String url) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyBaseUrl, normalizeBaseUrl(url));
  }

  Future<String> getBaseUrl() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(_keyBaseUrl);
    if (saved == null || saved.trim().isEmpty) return defaultBaseUrl;
    return normalizeBaseUrl(saved);
  }

  static String normalizeBaseUrl(String url) {
    var value = url.trim();
    while (value.endsWith('/')) {
      value = value.substring(0, value.length - 1);
    }
    return value;
  }

  Future<String> getWsUrl() async {
    final baseUrl = await getBaseUrl();
    final uri = Uri.parse(baseUrl);
    final wsScheme = uri.scheme == 'https' ? 'wss' : 'ws';
    return Uri(
      scheme: wsScheme,
      host: uri.host,
      port: uri.hasPort ? uri.port : null,
      path: '/ws/v1/relay',
    ).toString();
  }

  // ---------------------------------------------------------------------------
  // PERISAI-Vault & Offline Outbox Queue Persistence
  // ---------------------------------------------------------------------------

  Future<List<VaultItem>> getVaultItems() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_keyVaultItems);
    if (raw == null || raw.isEmpty) return [];
    try {
      final list = jsonDecode(raw) as List<dynamic>;
      return list
          .map((e) => VaultItem.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> saveVaultItems(List<VaultItem> items) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _keyVaultItems,
      jsonEncode(items.map((e) => e.toJson()).toList()),
    );
  }

  Future<List<OutboxQueueItem>> getOutboxItems() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_keyOutboxItems);
    if (raw == null || raw.isEmpty) return [];
    try {
      final list = jsonDecode(raw) as List<dynamic>;
      return list
          .map(
            (e) =>
                OutboxQueueItem.fromJson(Map<String, dynamic>.from(e as Map)),
          )
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> saveOutboxItems(List<OutboxQueueItem> items) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _keyOutboxItems,
      jsonEncode(items.map((e) => e.toJson()).toList()),
    );
  }
}
