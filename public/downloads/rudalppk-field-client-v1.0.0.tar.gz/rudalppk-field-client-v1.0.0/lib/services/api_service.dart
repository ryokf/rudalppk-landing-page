import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import 'storage_service.dart';

class ApiException implements Exception {
  final String message;
  final String? code;
  final int? statusCode;
  final Map<String, dynamic>? details;

  ApiException(
    this.message, {
    this.code,
    this.statusCode,
    this.details,
  });

  @override
  String toString() => message;
}

class ApiService {
  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;
  ApiService._internal();

  final _storage = StorageService();
  final _client = http.Client();

  Future<Map<String, String>> _headers({bool authenticated = true}) async {
    final headers = <String, String>{
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };
    if (authenticated) {
      final token = await _storage.getToken();
      if (token != null && token.isNotEmpty) {
        headers['Authorization'] = 'Bearer $token';
      }
    }
    return headers;
  }

  Future<dynamic> _request(
    String method,
    String path, {
    Map<String, dynamic>? body,
    bool authenticated = true,
  }) async {
    final baseUrl = await _storage.getBaseUrl();
    final uri = Uri.parse('$baseUrl$path');
    final headers = await _headers(authenticated: authenticated);

    http.Response response;
    try {
      switch (method) {
        case 'GET':
          response = await _client
              .get(uri, headers: headers)
              .timeout(const Duration(seconds: 20));
          break;
        case 'POST':
          response = await _client
              .post(uri, headers: headers, body: jsonEncode(body ?? {}))
              .timeout(const Duration(seconds: 20));
          break;
        case 'PATCH':
          response = await _client
              .patch(uri, headers: headers, body: jsonEncode(body ?? {}))
              .timeout(const Duration(seconds: 20));
          break;
        case 'DELETE':
          response = await _client
              .delete(uri, headers: headers)
              .timeout(const Duration(seconds: 20));
          break;
        default:
          throw ApiException('Metode HTTP tidak didukung');
      }
    } on TimeoutException {
      throw ApiException(
        'Server tidak merespons. Periksa koneksi dan alamat server.',
      );
    } catch (e) {
      if (e is ApiException) rethrow;
      throw ApiException('Tidak dapat terhubung ke server: $e');
    }

    dynamic json;
    try {
      json = jsonDecode(utf8.decode(response.bodyBytes));
    } catch (_) {
      throw ApiException(
        'Respons server tidak valid (HTTP ${response.statusCode})',
        statusCode: response.statusCode,
      );
    }

    if (response.statusCode >= 200 && response.statusCode < 300) {
      return json is Map<String, dynamic> ? json['data'] : json;
    }

    final error = json is Map<String, dynamic> ? json['error'] : null;
    throw ApiException(
      error is Map
          ? (error['message'] ?? 'Permintaan gagal')
          : 'Permintaan gagal',
      code: error is Map ? error['code'] as String? : null,
      statusCode: response.statusCode,
      details: error is Map && error['details'] is Map
          ? Map<String, dynamic>.from(error['details'] as Map)
          : null,
    );
  }

  // ---------------------------------------------------------------------------
  // Activation & device authentication
  // ---------------------------------------------------------------------------

  Future<Map<String, dynamic>> verifyActivation(String code) async {
    final data = await _request(
      'POST',
      '/activation/verify',
      authenticated: false,
      body: {'code': code},
    );
    return Map<String, dynamic>.from(data as Map);
  }

  Future<Map<String, dynamic>> completeActivation({
    required String code,
    required String identityFingerprint,
    required String deviceName,
    required String publicDeviceKey,
    required String authPublicKey,
    String pqcKemAlg = 'ML-KEM-768',
    String? pqcKemPublicKey,
    String pqcDsaAlg = 'ML-DSA-65',
    String? pqcDsaPublicKey,
  }) async {
    final data = await _request(
      'POST',
      '/activation/complete',
      authenticated: false,
      body: {
        'code': code,
        'identity_fingerprint': identityFingerprint,
        'device_name': deviceName,
        'public_device_key': publicDeviceKey,
        'auth_public_key': authPublicKey,
        'pqc_kem_alg': pqcKemAlg,
        if (pqcKemPublicKey != null && pqcKemPublicKey.isNotEmpty)
          'pqc_kem_public_key': pqcKemPublicKey,
        'pqc_dsa_alg': pqcDsaAlg,
        if (pqcDsaPublicKey != null && pqcDsaPublicKey.isNotEmpty)
          'pqc_dsa_public_key': pqcDsaPublicKey,
      },
    );
    return Map<String, dynamic>.from(data as Map);
  }

  Future<Map<String, dynamic>> requestChallengeById(String deviceId) async {
    final data = await _request(
      'POST',
      '/auth/challenge',
      authenticated: false,
      body: {'device_id': deviceId},
    );
    return Map<String, dynamic>.from(data as Map);
  }

  Future<Map<String, dynamic>> requestChallengeByPublicKey(
    String authPublicKey,
  ) async {
    final data = await _request(
      'POST',
      '/auth/challenge',
      authenticated: false,
      body: {'auth_public_key': authPublicKey},
    );
    return Map<String, dynamic>.from(data as Map);
  }

  Future<Map<String, dynamic>> verifyChallenge({
    required String challengeId,
    required String deviceId,
    required String signature,
    String? pqcSignature,
  }) async {
    final data = await _request(
      'POST',
      '/auth/verify',
      authenticated: false,
      body: {
        'challenge_id': challengeId,
        'device_id': deviceId,
        'signature': signature,
        if (pqcSignature != null && pqcSignature.isNotEmpty)
          'pqc_signature': pqcSignature,
      },
    );
    final map = Map<String, dynamic>.from(data as Map);
    final token = map['access_token'] as String?;
    if (token != null && token.isNotEmpty) {
      await _storage.saveToken(token);
    }
    return map;
  }

  Future<Map<String, dynamic>> getMe() async {
    final data = await _request('GET', '/me');
    return Map<String, dynamic>.from(data as Map);
  }

  // ---------------------------------------------------------------------------
  // Devices
  // ---------------------------------------------------------------------------

  Future<List<Map<String, dynamic>>> getMyDevices() async {
    final data = await _request('GET', '/devices') as List<dynamic>;
    return data.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<void> revokeDevice(String deviceId) async {
    await _request('POST', '/devices/$deviceId/revoke');
  }

  Future<Map<String, dynamic>> updateDevicePqcKeys(
    String deviceId, {
    required String pqcKemAlg,
    required String pqcKemPublicKey,
    required String pqcDsaAlg,
    required String pqcDsaPublicKey,
  }) async {
    final data = await _request(
      'PATCH',
      '/devices/$deviceId/pqc-keys',
      body: {
        'pqc_kem_alg': pqcKemAlg,
        'pqc_kem_public_key': pqcKemPublicKey,
        'pqc_dsa_alg': pqcDsaAlg,
        'pqc_dsa_public_key': pqcDsaPublicKey,
      },
    );
    return Map<String, dynamic>.from(data as Map);
  }

  // ---------------------------------------------------------------------------
  // Directory & contacts
  // ---------------------------------------------------------------------------

  Future<List<Map<String, dynamic>>> getDirectoryMembers({
    String? search,
  }) async {
    final query = search != null && search.trim().isNotEmpty
        ? '?search=${Uri.encodeQueryComponent(search.trim())}'
        : '';
    final data = await _request('GET', '/directory/members$query')
        as List<dynamic>;
    return data.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<List<Map<String, dynamic>>> getContacts() async {
    final data = await _request('GET', '/contacts') as List<dynamic>;
    return data.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<Map<String, dynamic>> addContact({
    required String contactIdentityId,
    String verificationStatus = 'unverified',
  }) async {
    final data = await _request(
      'POST',
      '/contacts',
      body: {
        'contact_identity_id': contactIdentityId,
        'verification_status': verificationStatus,
      },
    );
    return Map<String, dynamic>.from(data as Map);
  }

  Future<void> deleteContact(String contactId) async {
    await _request('DELETE', '/contacts/$contactId');
  }

  // ---------------------------------------------------------------------------
  // Personal conversations
  // ---------------------------------------------------------------------------

  Future<List<Map<String, dynamic>>> getPersonalConversations() async {
    final data = await _request('GET', '/conversations/direct')
        as List<dynamic>;
    return data.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<Map<String, dynamic>> createDirectConversation(
    String peerIdentityId,
  ) async {
    final data = await _request(
      'POST',
      '/conversations/direct',
      body: {'peer_identity_id': peerIdentityId},
    );
    return Map<String, dynamic>.from(data as Map);
  }

  Future<Map<String, dynamic>> getConversationDetail(
    String conversationId,
  ) async {
    final data = await _request('GET', '/conversations/$conversationId');
    return Map<String, dynamic>.from(data as Map);
  }

  // ---------------------------------------------------------------------------
  // Groups
  // ---------------------------------------------------------------------------

  Future<List<Map<String, dynamic>>> getGroups() async {
    final data = await _request('GET', '/groups') as List<dynamic>;
    return data.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<Map<String, dynamic>> getGroupDetail(String groupId) async {
    final data = await _request('GET', '/groups/$groupId');
    return Map<String, dynamic>.from(data as Map);
  }

  Future<Map<String, dynamic>> createGroup({
    required String title,
    required List<String> memberIdentityIds,
  }) async {
    final data = await _request(
      'POST',
      '/groups',
      body: {'title': title, 'members': memberIdentityIds},
    );
    return Map<String, dynamic>.from(data as Map);
  }

  Future<Map<String, dynamic>> updateGroupTitle(
    String groupId,
    String title,
  ) async {
    final data = await _request(
      'PATCH',
      '/groups/$groupId',
      body: {'title': title},
    );
    return Map<String, dynamic>.from(data as Map);
  }

  Future<Map<String, dynamic>> addGroupMember(
    String groupId,
    String identityId, {
    String memberRole = 'member',
  }) async {
    final data = await _request(
      'POST',
      '/groups/$groupId/members',
      body: {'identity_id': identityId, 'member_role': memberRole},
    );
    return Map<String, dynamic>.from(data as Map);
  }

  Future<Map<String, dynamic>> updateGroupMemberRole(
    String groupId,
    String identityId,
    String memberRole,
  ) async {
    final data = await _request(
      'PATCH',
      '/groups/$groupId/members/$identityId',
      body: {'identity_id': identityId, 'member_role': memberRole},
    );
    return Map<String, dynamic>.from(data as Map);
  }

  Future<Map<String, dynamic>> removeGroupMember(
    String groupId,
    String identityId,
  ) async {
    final data = await _request(
      'DELETE',
      '/groups/$groupId/members/$identityId',
    );
    return Map<String, dynamic>.from(data as Map);
  }

  Future<Map<String, dynamic>> leaveGroup(String groupId) async {
    final data = await _request('POST', '/groups/$groupId/leave');
    return Map<String, dynamic>.from(data as Map);
  }

  // ---------------------------------------------------------------------------
  // Messages
  // ---------------------------------------------------------------------------

  Future<Map<String, dynamic>> sendMessage({
    required String conversationId,
    required String clientMessageId,
    required String ciphertext,
    required int keyEpoch,
    String protocolVersion = '2',
    String messageType = 'text',
  }) async {
    final data = await _request(
      'POST',
      '/messages',
      body: {
        'conversation_id': conversationId,
        'client_message_id': clientMessageId,
        'protocol_version': protocolVersion,
        'key_epoch': keyEpoch,
        'message_type': messageType,
        'ciphertext': ciphertext,
      },
    );
    return Map<String, dynamic>.from(data as Map);
  }

  Future<List<Map<String, dynamic>>> getPendingMessages() async {
    final data = await _request('GET', '/messages/pending') as List<dynamic>;
    return data.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<List<Map<String, dynamic>>> getConversationMessages(
    String conversationId, {
    int limit = 100,
  }) async {
    final data = await _request(
      'GET',
      '/messages/conversation/$conversationId?limit=$limit',
    ) as List<dynamic>;
    return data.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<void> acknowledgeMessage(
    String messageId, {
    String status = 'delivered',
  }) async {
    await _request(
      'POST',
      '/messages/$messageId/ack',
      body: {'delivery_status': status},
    );
  }

  Future<void> updateReceipt(String messageId, String status) async {
    await _request(
      'POST',
      '/messages/$messageId/receipt',
      body: {'delivery_status': status},
    );
  }

  Future<void> deleteMessage(String messageId) async {
    await _request('DELETE', '/messages/$messageId');
  }

  // ---------------------------------------------------------------------------
  // PERISAI-Sign (ML-DSA Command, Firmware & Field Report Signing)
  // ---------------------------------------------------------------------------

  Future<List<Map<String, dynamic>>> getSignedArtifacts({
    String? artifactType,
  }) async {
    final query = artifactType != null && artifactType.isNotEmpty
        ? '?artifact_type=${Uri.encodeQueryComponent(artifactType)}'
        : '';
    final data =
        await _request('GET', '/perisai/sign/artifacts$query') as List<dynamic>;
    return data.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<Map<String, dynamic>> createSignedArtifact({
    required String artifactType,
    required String title,
    required String contentText,
    required String algorithm,
    String? contentHashSha256,
    String? signatureB64,
    String? signerPublicKeyB64,
  }) async {
    final data = await _request(
      'POST',
      '/perisai/sign/artifacts',
      body: {
        'artifact_type': artifactType,
        'title': title,
        'content_text': contentText,
        'algorithm': algorithm,
        if (contentHashSha256 != null) 'content_hash_sha256': contentHashSha256,
        if (signatureB64 != null) 'signature_b64': signatureB64,
        if (signerPublicKeyB64 != null)
          'signer_public_key_b64': signerPublicKeyB64,
      },
    );
    return Map<String, dynamic>.from(data as Map);
  }

  Future<Map<String, dynamic>> verifySignedArtifact({
    String? artifactId,
    String? algorithm,
    String? contentText,
    String? signatureB64,
    String? signerPublicKeyB64,
  }) async {
    final data = await _request(
      'POST',
      '/perisai/sign/verify',
      body: {
        if (artifactId != null) 'artifact_id': artifactId,
        if (algorithm != null) 'algorithm': algorithm,
        if (contentText != null) 'content_text': contentText,
        if (signatureB64 != null) 'signature_b64': signatureB64,
        if (signerPublicKeyB64 != null)
          'signer_public_key_b64': signerPublicKeyB64,
      },
    );
    return Map<String, dynamic>.from(data as Map);
  }

  Future<Map<String, dynamic>> revokeSignedArtifact(String artifactId) async {
    final data = await _request(
      'POST',
      '/perisai/sign/artifacts/$artifactId/revoke',
    );
    return Map<String, dynamic>.from(data as Map);
  }

  Future<Map<String, dynamic>> decryptSignedArtifact({
    required String artifactId,
    required String kemSecretKeyB64,
  }) async {
    final data = await _request(
      'POST',
      '/perisai/sign/artifacts/$artifactId/decrypt',
      body: {'kem_secret_key_b64': kemSecretKeyB64},
    );
    return Map<String, dynamic>.from(data as Map);
  }

  Future<List<Map<String, dynamic>>> getSignAuditLogs() async {
    final data =
        await _request('GET', '/perisai/sign/audit-logs') as List<dynamic>;
    return data.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  // ---------------------------------------------------------------------------
  // PERISAI-Lab (Quantum Simulation, Readiness Audit & Benchmark)
  // ---------------------------------------------------------------------------

  Future<Map<String, dynamic>> getPqcSpecs() async {
    final data = await _request('GET', '/perisai/lab/specs');
    return Map<String, dynamic>.from(data as Map);
  }

  Future<Map<String, dynamic>> simulateQuantumRsaAttack({
    int rsaModulusN = 3233,
    int publicExponentE = 17,
    int sampleMessage = 42,
    String compareKemAlg = 'ML-KEM-768',
    String compareDsaAlg = 'ML-DSA-65',
  }) async {
    final data = await _request(
      'POST',
      '/perisai/lab/simulate-rsa',
      body: {
        'rsa_modulus_n': rsaModulusN,
        'public_exponent_e': publicExponentE,
        'sample_message': sampleMessage,
        'compare_kem_alg': compareKemAlg,
        'compare_dsa_alg': compareDsaAlg,
      },
    );
    return Map<String, dynamic>.from(data as Map);
  }

  Future<Map<String, dynamic>> getPqcFleetAudit() async {
    final data = await _request('GET', '/perisai/lab/audit');
    return Map<String, dynamic>.from(data as Map);
  }

  Future<Map<String, dynamic>> runPqcBenchmark() async {
    final data = await _request('POST', '/perisai/lab/benchmark');
    return Map<String, dynamic>.from(data as Map);
  }
}
