import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';

import '../models/perisai_models.dart';
import 'pqc_service.dart';

class DecryptedMessageResult {
  final String plaintext;
  final bool isHybridPqc;
  final String? pqcKemAlg;
  final String? pqcDsaAlg;
  final bool? pqcSignatureVerified;

  const DecryptedMessageResult({
    required this.plaintext,
    this.isHybridPqc = false,
    this.pqcKemAlg,
    this.pqcDsaAlg,
    this.pqcSignatureVerified,
  });
}

/// Client-side cryptographic operations for Secure Field Communication + PERISAI-Q.
///
/// Security model implemented here:
/// - Ed25519 + ML-DSA-(44/65/87) hybrid key pairs for device authentication & signing.
/// - X25519 + ML-KEM-(512/768/1024) hybrid key pairs for quantum-resistant E2EE key agreement.
/// - A random AES-256-GCM message key per message wrapped with both Hybrid
///   (X25519 || ML-KEM -> HKDF-SHA256) and classical fallback keys.
/// - PERISAI-Vault local storage encryption using ML-KEM + AES-256-GCM + ML-DSA.
class CryptoService {
  static final CryptoService _instance = CryptoService._internal();
  factory CryptoService() => _instance;
  CryptoService._internal();

  final _ed25519 = Ed25519();
  final _x25519 = X25519();
  final _aesGcm = AesGcm.with256bits();
  final _sha256 = Sha256();
  final _pqc = PqcService();

  static const String _kdfSalt = 'secure-field-communication/v1';
  static const int _envelopeVersion = 2;

  /// Legacy key retained only so messages created by older app builds can
  /// still be displayed. New messages always use per-device envelopes.
  static const String _legacyKeySeed = 'field_secure_comm_default_key_32b';

  /// Standard BIP-39 word list fragment (384 words) used for a 12-word
  /// recovery phrase. 12 words give roughly 100 bits of entropy here.
  static const List<String> _words = [
    'abandon',
    'ability',
    'able',
    'about',
    'above',
    'absent',
    'absorb',
    'abstract',
    'absurd',
    'abuse',
    'access',
    'accident',
    'account',
    'accuse',
    'achieve',
    'acid',
    'acoustic',
    'acquire',
    'across',
    'act',
    'action',
    'actor',
    'actress',
    'actual',
    'adapt',
    'add',
    'addict',
    'address',
    'adjust',
    'admit',
    'adult',
    'advance',
    'advice',
    'aerobic',
    'affair',
    'afford',
    'afraid',
    'again',
    'age',
    'agent',
    'agree',
    'ahead',
    'aim',
    'air',
    'airport',
    'aisle',
    'alarm',
    'album',
    'alcohol',
    'alert',
    'alien',
    'all',
    'alley',
    'allow',
    'almost',
    'alone',
    'alpha',
    'already',
    'also',
    'alter',
    'always',
    'amateur',
    'amazing',
    'among',
    'amount',
    'amused',
    'analyst',
    'anchor',
    'ancient',
    'anger',
    'angle',
    'angry',
    'animal',
    'ankle',
    'announce',
    'annual',
    'another',
    'answer',
    'antenna',
    'antique',
    'anxiety',
    'any',
    'apart',
    'apology',
    'appear',
    'apple',
    'approve',
    'april',
    'arch',
    'arctic',
    'area',
    'arena',
    'argue',
    'arm',
    'armed',
    'armor',
    'army',
    'around',
    'arrange',
    'arrest',
    'arrive',
    'arrow',
    'art',
    'artefact',
    'artist',
    'artwork',
    'ask',
    'aspect',
    'assault',
    'asset',
    'assist',
    'assume',
    'asthma',
    'athlete',
    'atom',
    'attack',
    'attend',
    'attitude',
    'attract',
    'auction',
    'audit',
    'august',
    'aunt',
    'author',
    'auto',
    'autumn',
    'average',
    'avocado',
    'avoid',
    'awake',
    'aware',
    'away',
    'awesome',
    'awful',
    'awkward',
    'axis',
    'baby',
    'bachelor',
    'bacon',
    'badge',
    'bag',
    'balance',
    'balcony',
    'ball',
    'bamboo',
    'banana',
    'banner',
    'bar',
    'barely',
    'bargain',
    'barrel',
    'base',
    'basic',
    'basket',
    'battle',
    'beach',
    'bean',
    'beauty',
    'because',
    'become',
    'beef',
    'before',
    'begin',
    'behave',
    'behind',
    'believe',
    'below',
    'belt',
    'bench',
    'benefit',
    'best',
    'betray',
    'better',
    'between',
    'beyond',
    'bicycle',
    'bid',
    'bike',
    'bind',
    'biology',
    'bird',
    'birth',
    'bitter',
    'black',
    'blade',
    'blame',
    'blanket',
    'blast',
    'bleak',
    'bless',
    'blind',
    'blood',
    'blossom',
    'blouse',
    'blue',
    'blur',
    'blush',
    'board',
    'boat',
    'body',
    'boil',
    'bomb',
    'bone',
    'bonus',
    'book',
    'boost',
    'border',
    'boring',
    'borrow',
    'boss',
    'bottom',
    'bounce',
    'box',
    'boy',
    'bracket',
    'brain',
    'brand',
    'brass',
    'brave',
    'bread',
    'breeze',
    'brick',
    'bridge',
    'brief',
    'bright',
    'bring',
    'brisk',
    'broccoli',
    'broken',
    'bronze',
    'broom',
    'brother',
    'brown',
    'brush',
    'bubble',
    'buddy',
    'budget',
    'buffalo',
    'build',
    'bulb',
    'bulk',
    'bullet',
    'bundle',
    'bunker',
    'burden',
    'burger',
    'burst',
    'bus',
    'business',
    'busy',
    'butter',
    'buyer',
    'buzz',
    'cabbage',
    'cabin',
    'cable',
    'cactus',
    'cage',
    'cake',
    'call',
    'calm',
    'camera',
    'camp',
    'can',
    'canal',
    'cancel',
    'candy',
    'cannon',
    'canoe',
    'canvas',
    'canyon',
    'capable',
  ];

  /// Generate a 12-word recovery phrase.
  String generateRecoveryPhrase() {
    final random = Random.secure();
    final phrase = List<String>.generate(
      12,
      (_) => _words[random.nextInt(_words.length)],
    );
    return phrase.join(' ');
  }

  String normalizePhrase(String phrase) =>
      phrase.trim().toLowerCase().replaceAll(RegExp(r'\s+'), ' ');

  bool isValidPhrase(String phrase) {
    final parts = normalizePhrase(phrase).split(' ');
    return parts.length == 12 && parts.every((w) => w.isNotEmpty);
  }

  Future<SimpleKeyPair> generateAuthKeyPair() => _ed25519.newKeyPair();

  Future<SimpleKeyPair> generateDeviceKeyPair() => _x25519.newKeyPair();

  Future<SimpleKeyPair> authKeyPairFromPhrase(String phrase) async {
    final seed = await _deriveSeed(phrase, 'auth');
    return _ed25519.newKeyPairFromSeed(seed);
  }

  Future<SimpleKeyPair> deviceKeyPairFromPhrase(String phrase) async {
    final seed = await _deriveSeed(phrase, 'device');
    return _x25519.newKeyPairFromSeed(seed);
  }

  /// Deterministically derive a NIST FIPS 203 ML-KEM-(512/768/1024) key pair
  /// from the 12-word Sheetphrase recovery phrase.
  Future<MlKemKeyPair> pqcKemKeyPairFromPhrase(
    String phrase, {
    String algorithm = 'ML-KEM-768',
  }) async {
    final seed = await _deriveSeed(phrase, 'pqc-kem:$algorithm');
    return _pqc.mlKemKeygen(algorithm, seed: seed);
  }

  /// Deterministically derive a NIST FIPS 204 ML-DSA-(44/65/87) key pair
  /// from the 12-word Sheetphrase recovery phrase.
  Future<MlDsaKeyPair> pqcDsaKeyPairFromPhrase(
    String phrase, {
    String algorithm = 'ML-DSA-65',
  }) async {
    final seed = await _deriveSeed(phrase, 'pqc-dsa:$algorithm');
    return _pqc.mlDsaKeygen(algorithm, seed: seed);
  }

  Future<List<int>> _deriveSeed(String phrase, String purpose) async {
    final pbkdf2 = Pbkdf2(
      macAlgorithm: Hmac.sha256(),
      iterations: 100000,
      bits: 256,
    );
    final derived = await pbkdf2.deriveKey(
      secretKey: SecretKey(utf8.encode(normalizePhrase(phrase))),
      nonce: utf8.encode('$_kdfSalt:$purpose'),
    );
    return derived.extractBytes();
  }

  Future<String> publicKeyToBase64(SimpleKeyPair keyPair) async {
    final publicKey = await keyPair.extractPublicKey();
    return base64Encode(publicKey.bytes);
  }

  Future<String> privateKeyToBase64(SimpleKeyPair keyPair) async {
    final privateBytes = await keyPair.extractPrivateKeyBytes();
    return base64Encode(privateBytes);
  }

  Future<SimpleKeyPair> restoreAuthKeyPair(String base64PrivateKey) async {
    final seed = base64Decode(base64PrivateKey);
    if (seed.length != 32) {
      throw ArgumentError('Invalid Ed25519 private key length');
    }
    return _ed25519.newKeyPairFromSeed(seed);
  }

  Future<SimpleKeyPair> restoreDeviceKeyPair(String base64PrivateKey) async {
    final seed = base64Decode(base64PrivateKey);
    if (seed.length != 32) {
      throw ArgumentError('Invalid X25519 private key length');
    }
    return _x25519.newKeyPairFromSeed(seed);
  }

  Future<String> computeFingerprint(String publicIdentity) async {
    final hash = await _sha256.hash(utf8.encode(publicIdentity));
    return _hex(hash.bytes).substring(0, 32);
  }

  /// SHA-256 fingerprint of a Base64 encoded public key.
  Future<String> fingerprintForPublicKey(String base64PublicKey) async {
    final hash = await _sha256.hash(base64Decode(base64PublicKey));
    return _hex(hash.bytes).substring(0, 32);
  }

  Future<String> sha256Hex(String text) async {
    final hash = await _sha256.hash(utf8.encode(text));
    return _hex(hash.bytes);
  }

  Future<String> signNonce(String nonce, SimpleKeyPair keyPair) async {
    final signature = await _ed25519.sign(utf8.encode(nonce), keyPair: keyPair);
    return base64Encode(signature.bytes);
  }

  Future<String> signNoncePqc(
    String nonce, {
    required String dsaAlgorithm,
    required String dsaPrivateKeyB64,
  }) async {
    if (dsaPrivateKeyB64.isEmpty) return '';
    return _pqc.mlDsaSign(dsaAlgorithm, dsaPrivateKeyB64, utf8.encode(nonce));
  }

  /// Encrypt [plaintext] once with a random AES-256-GCM message key and wrap
  /// that key for every recipient device using both:
  /// 1) Hybrid Post-Quantum X25519 + ML-KEM-(512/768/1024) + HKDF-SHA256
  /// 2) Classical X25519 + HKDF-SHA256 fallback
  /// Plus an ML-DSA-(44/65/87) digital signature over the message ciphertext.
  Future<String> encryptForDevices(
    String plaintext, {
    required String conversationId,
    required String myPrivateKey,
    required Map<String, String> recipientPublicKeys,
    int keyEpoch = 1,
    Map<String, String>? recipientPqcKemPublicKeys,
    Map<String, String>? recipientPqcKemAlgs,
    String myPqcKemAlg = 'ML-KEM-768',
    String myPqcDsaAlg = 'ML-DSA-65',
    String myPqcDsaPrivateKey = '',
    String myPqcDsaPublicKey = '',
  }) async {
    if (myPrivateKey.isEmpty || recipientPublicKeys.isEmpty) {
      return _encryptLegacy(plaintext);
    }

    final messageKeyBytes = _randomBytes(32);
    final messageKey = SecretKey(messageKeyBytes);
    final contentBox = await _aesGcm.encrypt(
      utf8.encode(plaintext),
      secretKey: messageKey,
    );
    final ctB64 = base64Encode(contentBox.concatenation());

    final wrappedKeys = <String, String>{};
    final pqcWrappedKeys = <String, String>{};
    final pqcKemCiphertexts = <String, String>{};
    final pqcKemAlgsUsed = <String, String>{};

    for (final entry in recipientPublicKeys.entries) {
      final deviceId = entry.key;
      final peerX25519Pub = entry.value;
      if (deviceId.isEmpty || peerX25519Pub.isEmpty) continue;
      try {
        final pairwiseKey = await _pairwiseKey(
          myPrivateKey,
          peerX25519Pub,
          conversationId,
          keyEpoch,
        );
        final keyBox = await _aesGcm.encrypt(
          messageKeyBytes,
          secretKey: pairwiseKey,
        );
        wrappedKeys[deviceId] = base64Encode(keyBox.concatenation());

        // Hybrid X25519 + ML-KEM encapsulation when recipient has PQC KEM key
        final peerKemPub = recipientPqcKemPublicKeys?[deviceId] ?? '';
        final peerKemAlg =
            recipientPqcKemAlgs?[deviceId] ?? myPqcKemAlg;
        if (peerKemPub.isNotEmpty) {
          final enc = await _pqc.mlKemEncapsulate(peerKemAlg, peerKemPub);
          final hybridKey = await _hybridPairwiseKey(
            myPrivateKey,
            peerX25519Pub,
            enc.sharedSecretBytes,
            conversationId,
            keyEpoch,
            peerKemAlg,
          );
          final hybridBox = await _aesGcm.encrypt(
            messageKeyBytes,
            secretKey: hybridKey,
          );
          pqcWrappedKeys[deviceId] = base64Encode(hybridBox.concatenation());
          pqcKemCiphertexts[deviceId] = enc.ciphertextB64;
          pqcKemAlgsUsed[deviceId] = enc.algorithm;
        }
      } catch (_) {
        // Skip malformed device keys instead of failing the whole message.
      }
    }

    if (wrappedKeys.isEmpty) {
      return _encryptLegacy(plaintext);
    }

    String? pqcSigB64;
    if (myPqcDsaPrivateKey.isNotEmpty) {
      try {
        final sigPayload = utf8.encode(
          'PERISAI-MSG-V2|$conversationId|$keyEpoch|$ctB64',
        );
        pqcSigB64 = await _pqc.mlDsaSign(
          myPqcDsaAlg,
          myPqcDsaPrivateKey,
          sigPayload,
        );
      } catch (_) {}
    }

    final hasHybrid = pqcWrappedKeys.isNotEmpty;
    final envelope = <String, dynamic>{
      'v': _envelopeVersion,
      'alg': hasHybrid
          ? 'x25519-mlkem-hybrid-aes256gcm'
          : 'x25519-hkdf-aes256gcm',
      'epoch': keyEpoch,
      'ct': ctB64,
      'keys': wrappedKeys,
      if (hasHybrid) 'pqc_keys': pqcWrappedKeys,
      if (hasHybrid) 'pqc_kem_ct': pqcKemCiphertexts,
      if (hasHybrid) 'pqc_kem_algs': pqcKemAlgsUsed,
      'pqc_kem_alg': myPqcKemAlg,
      if (pqcSigB64 != null && pqcSigB64.isNotEmpty) ...{
        'pqc_dsa_alg': myPqcDsaAlg,
        'pqc_sig': pqcSigB64,
        'pqc_signer_pub': myPqcDsaPublicKey,
      },
    };
    return base64Encode(utf8.encode(jsonEncode(envelope)));
  }

  /// Decrypt an envelope addressed to [myDeviceId] and return PQC metadata.
  Future<DecryptedMessageResult> decryptEnvelopeForDevice(
    String ciphertextBase64, {
    required String conversationId,
    required String myDeviceId,
    required String myPrivateKey,
    String? senderPublicKey,
    String myPqcKemPrivateKey = '',
    String myPqcKemAlg = 'ML-KEM-768',
    String? senderPqcDsaPublicKey,
  }) async {
    try {
      final decoded = utf8.decode(base64Decode(ciphertextBase64));
      final envelope = jsonDecode(decoded);
      if (envelope is Map<String, dynamic> && envelope['keys'] is Map) {
        final keys = Map<String, dynamic>.from(envelope['keys'] as Map);
        final pqcKeys = envelope['pqc_keys'] is Map
            ? Map<String, dynamic>.from(envelope['pqc_keys'] as Map)
            : <String, dynamic>{};
        final pqcKemCtMap = envelope['pqc_kem_ct'] is Map
            ? Map<String, dynamic>.from(envelope['pqc_kem_ct'] as Map)
            : <String, dynamic>{};
        final pqcKemAlgsMap = envelope['pqc_kem_algs'] is Map
            ? Map<String, dynamic>.from(envelope['pqc_kem_algs'] as Map)
            : <String, dynamic>{};

        final hasEpoch = envelope.containsKey('epoch');
        final envelopeEpochRaw = envelope['epoch'];
        final envelopeEpoch = !hasEpoch
            ? 0
            : envelopeEpochRaw is int
            ? envelopeEpochRaw
            : (envelopeEpochRaw is num ? envelopeEpochRaw.toInt() : 1);

        final ctB64 = envelope['ct'] as String? ?? '';
        final envKemAlg =
            (pqcKemAlgsMap[myDeviceId] as String?) ??
            (envelope['pqc_kem_alg'] as String?) ??
            myPqcKemAlg;
        final envDsaAlg = envelope['pqc_dsa_alg'] as String?;
        final envSig = envelope['pqc_sig'] as String?;
        final envSignerPub =
            (senderPqcDsaPublicKey != null && senderPqcDsaPublicKey.isNotEmpty)
            ? senderPqcDsaPublicKey
            : (envelope['pqc_signer_pub'] as String?);

        bool? sigVerified;
        if (envDsaAlg != null &&
            envSig != null &&
            envSig.isNotEmpty &&
            envSignerPub != null &&
            envSignerPub.isNotEmpty) {
          final sigPayload = utf8.encode(
            'PERISAI-MSG-V2|$conversationId|$envelopeEpoch|$ctB64',
          );
          sigVerified = await _pqc.mlDsaVerify(
            envDsaAlg,
            envSignerPub,
            sigPayload,
            envSig,
          );
        }

        List<int>? messageKeyBytes;
        var usedHybridPqc = false;

        // 1. Try Hybrid X25519 + ML-KEM decapsulation first
        final pqcWrapped = pqcKeys[myDeviceId] as String?;
        final kemCtB64 = pqcKemCtMap[myDeviceId] as String?;
        if (pqcWrapped != null &&
            kemCtB64 != null &&
            myPqcKemPrivateKey.isNotEmpty &&
            myPrivateKey.isNotEmpty &&
            senderPublicKey != null &&
            senderPublicKey.isNotEmpty) {
          try {
            final kemShared = await _pqc.mlKemDecapsulate(
              envKemAlg,
              myPqcKemPrivateKey,
              kemCtB64,
            );
            final hybridKey = await _hybridPairwiseKey(
              myPrivateKey,
              senderPublicKey,
              kemShared,
              conversationId,
              envelopeEpoch,
              envKemAlg,
            );
            final keyBox = SecretBox.fromConcatenation(
              base64Decode(pqcWrapped),
              nonceLength: 12,
              macLength: 16,
            );
            messageKeyBytes = await _aesGcm.decrypt(
              keyBox,
              secretKey: hybridKey,
            );
            usedHybridPqc = true;
          } catch (_) {
            messageKeyBytes = null;
          }
        }

        // 2. Fallback to classical X25519 key unwrap if hybrid wasn't used
        if (messageKeyBytes == null) {
          final wrapped = keys[myDeviceId] as String?;
          if (wrapped == null) {
            return const DecryptedMessageResult(
              plaintext: '[Pesan terenkripsi untuk perangkat lain]',
            );
          }
          if (myPrivateKey.isEmpty ||
              senderPublicKey == null ||
              senderPublicKey.isEmpty) {
            return const DecryptedMessageResult(
              plaintext: '[Kunci perangkat tidak tersedia]',
            );
          }
          final pairwiseKey = await _pairwiseKey(
            myPrivateKey,
            senderPublicKey,
            conversationId,
            envelopeEpoch,
          );
          final keyBox = SecretBox.fromConcatenation(
            base64Decode(wrapped),
            nonceLength: 12,
            macLength: 16,
          );
          messageKeyBytes = await _aesGcm.decrypt(
            keyBox,
            secretKey: pairwiseKey,
          );
          // Do NOT mark this as hybrid PQC: the classical X25519 path was used
          // because ML-KEM decapsulation was unavailable or failed. Reporting
          // hybrid protection here would hide a silent downgrade.
        }

        final contentBox = SecretBox.fromConcatenation(
          base64Decode(ctB64),
          nonceLength: 12,
          macLength: 16,
        );
        final clearBytes = await _aesGcm.decrypt(
          contentBox,
          secretKey: SecretKey(messageKeyBytes),
        );
        return DecryptedMessageResult(
          plaintext: utf8.decode(clearBytes),
          isHybridPqc: usedHybridPqc,
          pqcKemAlg: usedHybridPqc ? envKemAlg : null,
          pqcDsaAlg: envDsaAlg,
          pqcSignatureVerified: sigVerified,
        );
      }
    } catch (_) {
      // Fall through to legacy decryption
    }

    try {
      final key = SecretKey(_legacyKeyBytes());
      final box = SecretBox.fromConcatenation(
        base64Decode(ciphertextBase64),
        nonceLength: 12,
        macLength: 16,
      );
      final clearBytes = await _aesGcm.decrypt(box, secretKey: key);
      return DecryptedMessageResult(plaintext: utf8.decode(clearBytes));
    } catch (_) {
      return const DecryptedMessageResult(
        plaintext: '[Tidak dapat mendekripsi pesan]',
      );
    }
  }

  /// Backward-compatible decrypt method returning plaintext string.
  Future<String> decryptForDevice(
    String ciphertextBase64, {
    required String conversationId,
    required String myDeviceId,
    required String myPrivateKey,
    String? senderPublicKey,
    String myPqcKemPrivateKey = '',
    String myPqcKemAlg = 'ML-KEM-768',
  }) async {
    final res = await decryptEnvelopeForDevice(
      ciphertextBase64,
      conversationId: conversationId,
      myDeviceId: myDeviceId,
      myPrivateKey: myPrivateKey,
      senderPublicKey: senderPublicKey,
      myPqcKemPrivateKey: myPqcKemPrivateKey,
      myPqcKemAlg: myPqcKemAlg,
    );
    return res.plaintext;
  }

  // ---------------------------------------------------------------------------
  // PERISAI-Vault Local At-Rest PQC Encryption (ML-KEM + AES-256-GCM + ML-DSA)
  // ---------------------------------------------------------------------------

  Future<VaultItem> encryptVaultItem({
    required String title,
    required String category,
    required String contentText,
    required String kemAlgorithm,
    required String kemPublicKeyB64,
    required String dsaAlgorithm,
    required String dsaPrivateKeyB64,
  }) async {
    final enc = await _pqc.mlKemEncapsulate(kemAlgorithm, kemPublicKeyB64);
    final hkdf = Hkdf(hmac: Hmac.sha256(), outputLength: 32);
    final aesKey = await hkdf.deriveKey(
      secretKey: SecretKey(enc.sharedSecretBytes),
      nonce: utf8.encode('perisai-vault-salt-v1'),
      info: utf8.encode('PERISAI-VAULT|$kemAlgorithm|$category'),
    );

    final clearBytes = utf8.encode(contentText);
    final box = await _aesGcm.encrypt(clearBytes, secretKey: aesKey);
    final aesCtB64 = base64Encode(box.concatenation());
    final shaHex = await sha256Hex(contentText);

    final sigMsg = utf8.encode(
      'PERISAI-VAULT-SIG|$title|$category|$kemAlgorithm|$shaHex|$aesCtB64',
    );
    final sigB64 = await _pqc.mlDsaSign(dsaAlgorithm, dsaPrivateKeyB64, sigMsg);

    final idBytes = _randomBytes(8);
    return VaultItem(
      vaultItemId: _hex(idBytes),
      title: title.trim(),
      category: category,
      kemAlgorithm: kemAlgorithm,
      dsaAlgorithm: dsaAlgorithm,
      kemCiphertextB64: enc.ciphertextB64,
      aesCiphertextB64: aesCtB64,
      signatureB64: sigB64,
      contentSha256: shaHex,
      plaintextBytes: clearBytes.length,
      createdAt: DateTime.now(),
    );
  }

  Future<Map<String, dynamic>> decryptVaultItem({
    required VaultItem item,
    required String kemPrivateKeyB64,
    required String dsaPublicKeyB64,
  }) async {
    final sharedSecret = await _pqc.mlKemDecapsulate(
      item.kemAlgorithm,
      kemPrivateKeyB64,
      item.kemCiphertextB64,
    );
    final hkdf = Hkdf(hmac: Hmac.sha256(), outputLength: 32);
    final aesKey = await hkdf.deriveKey(
      secretKey: SecretKey(sharedSecret),
      nonce: utf8.encode('perisai-vault-salt-v1'),
      info: utf8.encode('PERISAI-VAULT|${item.kemAlgorithm}|${item.category}'),
    );

    final box = SecretBox.fromConcatenation(
      base64Decode(item.aesCiphertextB64),
      nonceLength: 12,
      macLength: 16,
    );
    final clearBytes = await _aesGcm.decrypt(box, secretKey: aesKey);
    final plaintext = utf8.decode(clearBytes);

    final sigMsg = utf8.encode(
      'PERISAI-VAULT-SIG|${item.title}|${item.category}|${item.kemAlgorithm}|${item.contentSha256}|${item.aesCiphertextB64}',
    );
    final sigValid = await _pqc.mlDsaVerify(
      item.dsaAlgorithm,
      dsaPublicKeyB64,
      sigMsg,
      item.signatureB64,
    );

    return {
      'plaintext': plaintext,
      'signature_valid': sigValid,
      'kem_algorithm': item.kemAlgorithm,
      'dsa_algorithm': item.dsaAlgorithm,
      'sha256': item.contentSha256,
    };
  }

  // ---------------------------------------------------------------------------
  // Pairwise Key Agreement Helpers
  // ---------------------------------------------------------------------------

  Future<SecretKey> _pairwiseKey(
    String myPrivateKey,
    String peerPublicKey,
    String conversationId,
    int keyEpoch,
  ) async {
    final keyPair = await restoreDeviceKeyPair(myPrivateKey);
    final peerBytes = base64Decode(peerPublicKey);
    final sharedSecret = await _x25519.sharedSecretKey(
      keyPair: keyPair,
      remotePublicKey: SimplePublicKey(peerBytes, type: KeyPairType.x25519),
    );
    final hkdf = Hkdf(hmac: Hmac.sha256(), outputLength: 32);
    final info = keyEpoch > 0
        ? utf8.encode('sfp-message-key/v2:$keyEpoch')
        : utf8.encode('sfp-message-key/v1');
    return hkdf.deriveKey(
      secretKey: sharedSecret,
      nonce: utf8.encode(conversationId),
      info: info,
    );
  }

  Future<SecretKey> _hybridPairwiseKey(
    String myPrivateKey,
    String peerPublicKey,
    Uint8List mlKemSharedSecret,
    String conversationId,
    int keyEpoch,
    String kemAlgorithm,
  ) async {
    final keyPair = await restoreDeviceKeyPair(myPrivateKey);
    final peerBytes = base64Decode(peerPublicKey);
    final x25519Shared = await _x25519.sharedSecretKey(
      keyPair: keyPair,
      remotePublicKey: SimplePublicKey(peerBytes, type: KeyPairType.x25519),
    );
    final x25519Bytes = await x25519Shared.extractBytes();
    final combinedIkm = <int>[...x25519Bytes, ...mlKemSharedSecret];
    final hkdf = Hkdf(hmac: Hmac.sha256(), outputLength: 32);
    return hkdf.deriveKey(
      secretKey: SecretKey(combinedIkm),
      nonce: utf8.encode(conversationId),
      info: utf8.encode('sfp-hybrid-pqc/v2:$kemAlgorithm:$keyEpoch'),
    );
  }

  Future<String> _encryptLegacy(String plaintext) async {
    final secretBox = await _aesGcm.encrypt(
      utf8.encode(plaintext),
      secretKey: SecretKey(_legacyKeyBytes()),
    );
    return base64Encode(secretBox.concatenation());
  }

  List<int> _legacyKeyBytes() {
    return utf8.encode(_legacyKeySeed.padRight(32, '0')).sublist(0, 32);
  }

  List<int> _randomBytes(int length) {
    final random = Random.secure();
    return List<int>.generate(length, (_) => random.nextInt(256));
  }

  String _hex(List<int> bytes) =>
      bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
}
