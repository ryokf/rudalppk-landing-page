import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';

/// Specification metadata for NIST FIPS 203 (ML-KEM) and FIPS 204 (ML-DSA).
class PqcAlgorithmSpec {
  final String name;
  final String standard;
  final int nistCategory;
  final String securityEquivalent;
  final int publicKeyBytes;
  final int secretKeyBytes;
  final int ciphertextOrSigBytes;
  final int k;
  final int l;
  final int eta1;
  final int eta2;
  final String description;

  const PqcAlgorithmSpec({
    required this.name,
    required this.standard,
    required this.nistCategory,
    required this.securityEquivalent,
    required this.publicKeyBytes,
    required this.secretKeyBytes,
    required this.ciphertextOrSigBytes,
    required this.k,
    this.l = 0,
    required this.eta1,
    this.eta2 = 2,
    required this.description,
  });
}

class MlKemKeyPair {
  final String algorithm;
  final String publicKeyB64;
  final String secretKeyB64;
  final int publicKeyBytes;
  final int secretKeyBytes;

  const MlKemKeyPair({
    required this.algorithm,
    required this.publicKeyB64,
    required this.secretKeyB64,
    required this.publicKeyBytes,
    required this.secretKeyBytes,
  });
}

class MlKemEncapsulationResult {
  final String algorithm;
  final String ciphertextB64;
  final String sharedSecretB64;
  final Uint8List sharedSecretBytes;
  final int ciphertextBytes;

  const MlKemEncapsulationResult({
    required this.algorithm,
    required this.ciphertextB64,
    required this.sharedSecretB64,
    required this.sharedSecretBytes,
    required this.ciphertextBytes,
  });
}

class MlDsaKeyPair {
  final String algorithm;
  final String publicKeyB64;
  final String secretKeyB64;
  final int publicKeyBytes;
  final int secretKeyBytes;

  const MlDsaKeyPair({
    required this.algorithm,
    required this.publicKeyB64,
    required this.secretKeyB64,
    required this.publicKeyBytes,
    required this.secretKeyBytes,
  });
}

/// Client-side cryptography service for the prototype's custom ML-KEM/ML-DSA
/// look-alike scheme.
///
/// !!! SECURITY WARNING — NOT FIPS 203/204 COMPLIANT !!!
/// This is NOT a NIST FIPS 203 (ML-KEM) or FIPS 204 (ML-DSA) implementation.
/// It uses a custom ring-LWE construction (Z_3329[X]/(X^64 + 1)) padded to
/// NIST-like byte lengths, and its "ML-DSA" path is Ed25519-backed. It is
/// bit-for-bit interoperable with `app/core/pqc.py` only because both sides
/// implement the same custom scheme; it is not interoperable with real
/// FIPS 203/204 implementations. Replace with a reviewed PQC library before
/// operational use.
class PqcService {
  static final PqcService _instance = PqcService._internal();
  factory PqcService() => _instance;
  PqcService._internal();

  static const int _q = 3329;
  static const int _halfQ = 1665;
  static const int _n = 64;

  final _sha256 = Sha256();
  final _ed25519 = Ed25519();

  static const Map<String, PqcAlgorithmSpec> mlKemSpecs = {
    'ML-KEM-512': PqcAlgorithmSpec(
      name: 'ML-KEM-512',
      standard: 'NIST FIPS 203',
      nistCategory: 1,
      securityEquivalent: 'AES-128 Quantum Security',
      publicKeyBytes: 800,
      secretKeyBytes: 1632,
      ciphertextOrSigBytes: 768,
      k: 2,
      eta1: 3,
      eta2: 2,
      description:
          'Profil ringan untuk perangkat IoT/taktis bandwidth sangat rendah (Kategori 1).',
    ),
    'ML-KEM-768': PqcAlgorithmSpec(
      name: 'ML-KEM-768',
      standard: 'NIST FIPS 203',
      nistCategory: 3,
      securityEquivalent: 'AES-192 Quantum Security',
      publicKeyBytes: 1184,
      secretKeyBytes: 2400,
      ciphertextOrSigBytes: 1088,
      k: 3,
      eta1: 2,
      eta2: 2,
      description:
          'Rekomendasi utama NIST (Default PERISAI-Q) — keseimbangan optimal keamanan & kecepatan (Kategori 3).',
    ),
    'ML-KEM-1024': PqcAlgorithmSpec(
      name: 'ML-KEM-1024',
      standard: 'NIST FIPS 203',
      nistCategory: 5,
      securityEquivalent: 'AES-256 Quantum Security',
      publicKeyBytes: 1568,
      secretKeyBytes: 3168,
      ciphertextOrSigBytes: 1568,
      k: 4,
      eta1: 2,
      eta2: 2,
      description:
          'Keamanan maksimum tingkat strategis/komando tinggi (Kategori 5).',
    ),
  };

  static const Map<String, PqcAlgorithmSpec> mlDsaSpecs = {
    'ML-DSA-44': PqcAlgorithmSpec(
      name: 'ML-DSA-44',
      standard: 'NIST FIPS 204',
      nistCategory: 2,
      securityEquivalent: 'SHA-256 / AES-128 Collision & Preimage Resistance',
      publicKeyBytes: 1312,
      secretKeyBytes: 2560,
      ciphertextOrSigBytes: 2420,
      k: 4,
      l: 4,
      eta1: 2,
      description:
          'Tanda tangan digital PQC ukuran kompak untuk otentikasi cepat (Kategori 2).',
    ),
    'ML-DSA-65': PqcAlgorithmSpec(
      name: 'ML-DSA-65',
      standard: 'NIST FIPS 204',
      nistCategory: 3,
      securityEquivalent: 'SHA-384 / AES-192 Quantum Security',
      publicKeyBytes: 1952,
      secretKeyBytes: 4032,
      ciphertextOrSigBytes: 3309,
      k: 6,
      l: 5,
      eta1: 4,
      description:
          'Rekomendasi utama NIST (Default PERISAI-Sign) untuk instruksi komando & dokumen (Kategori 3).',
    ),
    'ML-DSA-87': PqcAlgorithmSpec(
      name: 'ML-DSA-87',
      standard: 'NIST FIPS 204',
      nistCategory: 5,
      securityEquivalent: 'SHA-512 / AES-256 Quantum Security',
      publicKeyBytes: 2592,
      secretKeyBytes: 4896,
      ciphertextOrSigBytes: 4627,
      k: 8,
      l: 7,
      eta1: 2,
      description:
          'Keamanan tertinggi untuk paket firmware OT/IoT kritis & perintah strategis (Kategori 5).',
    ),
  };

  // ---------------------------------------------------------------------------
  // Deterministic SHA-256 XOF & Polynomial Ring Z_3329[X]/(X^64 + 1)
  // ---------------------------------------------------------------------------

  Future<Uint8List> _sha256Bytes(List<int> input) async {
    final hash = await _sha256.hash(input);
    return Uint8List.fromList(hash.bytes);
  }

  Future<Uint8List> _expandXof(
    List<int> seed,
    String domain,
    int length,
  ) async {
    final out = BytesBuilder(copy: false);
    var counter = 0;
    final domainBytes = utf8.encode(domain);
    final prefix = <int>[...seed, 0x7C, ...domainBytes, 0x7C];
    while (out.length < length) {
      final ctrBytes = <int>[
        (counter >> 24) & 0xFF,
        (counter >> 16) & 0xFF,
        (counter >> 8) & 0xFF,
        counter & 0xFF,
      ];
      final digest = await _sha256Bytes(<int>[...prefix, ...ctrBytes]);
      out.add(digest);
      counter++;
    }
    return Uint8List.fromList(out.takeBytes().sublist(0, length));
  }

  int _modQ(int val) {
    final r = val % _q;
    return r < 0 ? r + _q : r;
  }

  Future<List<int>> _sampleUniformPoly(List<int> seed, String domain) async {
    final raw = await _expandXof(seed, domain, _n * 2);
    return List<int>.generate(
      _n,
      (i) => ((raw[2 * i] << 8) | raw[2 * i + 1]) % _q,
    );
  }

  Future<List<int>> _sampleSmallPoly(List<int> seed, String domain) async {
    final raw = await _expandXof(seed, domain, _n);
    return List<int>.generate(_n, (i) => _modQ((raw[i] % 3) - 1));
  }

  List<int> _polyAdd(List<int> a, List<int> b) =>
      List<int>.generate(_n, (i) => (a[i] + b[i]) % _q);

  List<int> _polySub(List<int> a, List<int> b) =>
      List<int>.generate(_n, (i) => _modQ(a[i] - b[i]));

  List<int> _polyMulNegacyclic(List<int> a, List<int> b) {
    final res = List<int>.filled(_n, 0);
    for (var i = 0; i < _n; i++) {
      final ai = a[i];
      if (ai == 0) continue;
      for (var j = 0; j < _n; j++) {
        final idx = i + j;
        if (idx < _n) {
          res[idx] = (res[idx] + ai * b[j]) % _q;
        } else {
          res[idx - _n] = _modQ(res[idx - _n] - ai * b[j]);
        }
      }
    }
    return res;
  }

  Uint8List _encodePoly16(List<int> poly) {
    final out = Uint8List(poly.length * 2);
    for (var i = 0; i < poly.length; i++) {
      final val = _modQ(poly[i]);
      out[i * 2] = (val >> 8) & 0xFF;
      out[i * 2 + 1] = val & 0xFF;
    }
    return out;
  }

  List<int> _decodePoly16(Uint8List data, [int count = _n]) {
    return List<int>.generate(
      count,
      (i) => ((data[i * 2] << 8) | data[i * 2 + 1]) % _q,
    );
  }

  Uint8List _header12(String algName) {
    final bytes = ascii.encode(algName);
    final out = Uint8List(12);
    for (var i = 0; i < bytes.length && i < 12; i++) {
      out[i] = bytes[i];
    }
    return out;
  }

  String _parseHeader12(Uint8List data) {
    var end = 12;
    while (end > 0 && data[end - 1] == 0) {
      end--;
    }
    return ascii.decode(data.sublist(0, end), allowInvalid: true);
  }

  Uint8List _randomBytes(int length) {
    final rng = Random.secure();
    return Uint8List.fromList(
      List<int>.generate(length, (_) => rng.nextInt(256)),
    );
  }

  bool _constantTimeEquals(List<int> a, List<int> b) {
    if (a.length != b.length) return false;
    var diff = 0;
    for (var i = 0; i < a.length; i++) {
      diff |= a[i] ^ b[i];
    }
    return diff == 0;
  }

  // ---------------------------------------------------------------------------
  // NIST FIPS 203: ML-KEM (512, 768, 1024) — Interoperable with app/core/pqc.py
  // ---------------------------------------------------------------------------

  Future<MlKemKeyPair> mlKemKeygen(
    String algorithm, {
    List<int>? seed,
  }) async {
    final spec = mlKemSpecs[algorithm] ?? mlKemSpecs['ML-KEM-768']!;
    final algName = spec.name;
    final pkLen = spec.publicKeyBytes;
    final skLen = spec.secretKeyBytes;

    Uint8List dSeed;
    if (seed != null) {
      dSeed = seed.length == 32
          ? Uint8List.fromList(seed)
          : await _sha256Bytes(seed);
    } else {
      dSeed = _randomBytes(32);
    }

    final rho = await _sha256Bytes(<int>[
      ...utf8.encode('ML-KEM-RHO|$algName|'),
      ...dSeed,
    ]);
    final sigma = await _sha256Bytes(<int>[
      ...utf8.encode('ML-KEM-SIGMA|$algName|'),
      ...dSeed,
    ]);
    final zReject = await _sha256Bytes(<int>[
      ...utf8.encode('ML-KEM-Z|$algName|'),
      ...dSeed,
    ]);

    final aPoly = await _sampleUniformPoly(rho, 'A0');
    final sPoly = await _sampleSmallPoly(sigma, 'S0');
    final ePoly = await _sampleSmallPoly(sigma, 'E0');
    final tPoly = _polyAdd(_polyMulNegacyclic(aPoly, sPoly), ePoly);

    final header = _header12(algName);
    final tEncoded = _encodePoly16(tPoly);
    final corePk = Uint8List.fromList(<int>[...header, ...rho, ...tEncoded]);
    final pkPad = await _expandXof(
      <int>[...rho, ...tEncoded],
      'PK-PAD-$algName',
      pkLen - corePk.length - 32,
    );
    final pkBody = Uint8List.fromList(<int>[...corePk, ...pkPad]);
    final pkChecksum = await _sha256Bytes(<int>[
      ...utf8.encode('ML-KEM-PK-CHK|'),
      ...pkBody,
    ]);
    final pkBytes = Uint8List.fromList(<int>[...pkBody, ...pkChecksum]);

    final pkHash = await _sha256Bytes(pkBytes);
    final coreSk = Uint8List.fromList(<int>[
      ...header,
      ...dSeed,
      ...zReject,
      ..._encodePoly16(sPoly),
      ...pkHash,
      ...pkBytes,
    ]);
    final skPad = await _expandXof(
      dSeed,
      'SK-PAD-$algName',
      skLen - coreSk.length,
    );
    final skBytes = Uint8List.fromList(<int>[...coreSk, ...skPad]);

    return MlKemKeyPair(
      algorithm: algName,
      publicKeyB64: base64Encode(pkBytes),
      secretKeyB64: base64Encode(skBytes),
      publicKeyBytes: pkBytes.length,
      secretKeyBytes: skBytes.length,
    );
  }

  Future<MlKemEncapsulationResult> mlKemEncapsulate(
    String algorithm,
    String publicKeyB64, {
    List<int>? coin,
  }) async {
    final pkBytes = base64Decode(publicKeyB64);
    final headerAlg = pkBytes.length >= 12 ? _parseHeader12(pkBytes) : '';
    final spec =
        mlKemSpecs[algorithm] ??
        mlKemSpecs[headerAlg] ??
        mlKemSpecs['ML-KEM-768']!;
    final algName = spec.name;

    if (pkBytes.length != spec.publicKeyBytes) {
      throw ArgumentError('Invalid $algName public key length');
    }

    final expectedChk = await _sha256Bytes(<int>[
      ...utf8.encode('ML-KEM-PK-CHK|'),
      ...pkBytes.sublist(0, pkBytes.length - 32),
    ]);
    if (!_constantTimeEquals(
      pkBytes.sublist(pkBytes.length - 32),
      expectedChk,
    )) {
      throw ArgumentError('Corrupted $algName public key checksum');
    }

    final rho = pkBytes.sublist(12, 44);
    final tPoly = _decodePoly16(pkBytes.sublist(44, 172), _n);
    final pkHash = await _sha256Bytes(pkBytes);

    final randCoin = (coin != null && coin.length == 32)
        ? Uint8List.fromList(coin)
        : _randomBytes(32);
    final mFull = await _sha256Bytes(<int>[
      ...utf8.encode('ML-KEM-M|'),
      ...randCoin,
      0x7C,
      ...pkHash,
    ]);
    final mSeed = mFull.sublist(0, 8);
    final kBar = await _sha256Bytes(<int>[
      ...utf8.encode('ML-KEM-K|'),
      ...mSeed,
      0x7C,
      ...pkHash,
    ]);
    final rCoin = await _sha256Bytes(<int>[
      ...utf8.encode('ML-KEM-R|'),
      ...mSeed,
      0x7C,
      ...pkHash,
    ]);

    final aPoly = await _sampleUniformPoly(rho, 'A0');
    final rPoly = await _sampleSmallPoly(rCoin, 'R0');
    final e1Poly = await _sampleSmallPoly(rCoin, 'E1');
    final e2Poly = await _sampleSmallPoly(rCoin, 'E2');

    final uPoly = _polyAdd(_polyMulNegacyclic(aPoly, rPoly), e1Poly);
    final mPoly = List<int>.generate(_n, (i) {
      final bit = (mSeed[i ~/ 8] >> (i % 8)) & 1;
      return bit == 1 ? _halfQ : 0;
    });
    final vPoly = _polyAdd(
      _polyAdd(_polyMulNegacyclic(tPoly, rPoly), e2Poly),
      mPoly,
    );

    final header = _header12(algName);
    final uEnc = _encodePoly16(uPoly);
    final vEnc = _encodePoly16(vPoly);
    final foTag = await _sha256Bytes(<int>[
      ...utf8.encode('ML-KEM-FO|'),
      ...mSeed,
      0x7C,
      ...pkHash,
      0x7C,
      ...uEnc,
      ...vEnc,
    ]);
    final coreCt = Uint8List.fromList(<int>[
      ...header,
      ...uEnc,
      ...vEnc,
      ...foTag,
    ]);
    final ctLen = spec.ciphertextOrSigBytes;
    final ctPad = await _expandXof(
      foTag,
      'CT-PAD-$algName',
      ctLen - coreCt.length,
    );
    final ctBytes = Uint8List.fromList(<int>[...coreCt, ...ctPad]);
    final ctHash = await _sha256Bytes(ctBytes);
    final sharedSecret = await _sha256Bytes(<int>[
      ...utf8.encode('ML-KEM-SS|'),
      ...kBar,
      0x7C,
      ...ctHash,
    ]);

    return MlKemEncapsulationResult(
      algorithm: algName,
      ciphertextB64: base64Encode(ctBytes),
      sharedSecretB64: base64Encode(sharedSecret),
      sharedSecretBytes: sharedSecret,
      ciphertextBytes: ctBytes.length,
    );
  }

  Future<Uint8List> mlKemDecapsulate(
    String algorithm,
    String secretKeyB64,
    String ciphertextB64,
  ) async {
    final ctBytes = base64Decode(ciphertextB64);
    final skBytes = base64Decode(secretKeyB64);
    final headerAlg = skBytes.length >= 12 ? _parseHeader12(skBytes) : '';
    final spec =
        mlKemSpecs[algorithm] ??
        mlKemSpecs[headerAlg] ??
        mlKemSpecs['ML-KEM-768']!;
    final algName = spec.name;

    final sPoly = _decodePoly16(skBytes.sublist(76, 204), _n);
    final pkHash = skBytes.sublist(204, 236);
    final pkLen = spec.publicKeyBytes;
    final pkBytes = skBytes.sublist(236, 236 + pkLen);

    final uPoly = _decodePoly16(ctBytes.sublist(12, 140), _n);
    final vPoly = _decodePoly16(ctBytes.sublist(140, 268), _n);
    final foTag = ctBytes.sublist(268, 300);

    final suPoly = _polyMulNegacyclic(sPoly, uPoly);
    final wPoly = _polySub(vPoly, suPoly);

    final mSeed = Uint8List(8);
    for (var i = 0; i < _n; i++) {
      final coeff = wPoly[i] % _q;
      final distOne = (coeff - _halfQ).abs();
      final distZero = coeff < (_q - coeff) ? coeff : (_q - coeff);
      if (distOne < distZero) {
        mSeed[i ~/ 8] |= (1 << (i % 8));
      }
    }

    final kBar = await _sha256Bytes(<int>[
      ...utf8.encode('ML-KEM-K|'),
      ...mSeed,
      0x7C,
      ...pkHash,
    ]);
    final rCoin = await _sha256Bytes(<int>[
      ...utf8.encode('ML-KEM-R|'),
      ...mSeed,
      0x7C,
      ...pkHash,
    ]);

    final rho = pkBytes.sublist(12, 44);
    final tPoly = _decodePoly16(pkBytes.sublist(44, 172), _n);
    final aPoly = await _sampleUniformPoly(rho, 'A0');
    final rPoly = await _sampleSmallPoly(rCoin, 'R0');
    final e1Poly = await _sampleSmallPoly(rCoin, 'E1');
    final e2Poly = await _sampleSmallPoly(rCoin, 'E2');

    final uCheck = _polyAdd(_polyMulNegacyclic(aPoly, rPoly), e1Poly);
    final mPoly = List<int>.generate(
      _n,
      (i) => ((mSeed[i ~/ 8] >> (i % 8)) & 1) == 1 ? _halfQ : 0,
    );
    final vCheck = _polyAdd(
      _polyAdd(_polyMulNegacyclic(tPoly, rPoly), e2Poly),
      mPoly,
    );
    final uCheckEnc = _encodePoly16(uCheck);
    final vCheckEnc = _encodePoly16(vCheck);
    final expectedFo = await _sha256Bytes(<int>[
      ...utf8.encode('ML-KEM-FO|'),
      ...mSeed,
      0x7C,
      ...pkHash,
      0x7C,
      ...uCheckEnc,
      ...vCheckEnc,
    ]);
    final expectedPad = await _expandXof(
      expectedFo,
      'CT-PAD-$algName',
      spec.ciphertextOrSigBytes - 300,
    );

    if (!_constantTimeEquals(foTag, expectedFo) ||
        !_constantTimeEquals(ctBytes.sublist(300), expectedPad)) {
      throw ArgumentError('$algName decapsulation integrity check failed');
    }

    final ctHash = await _sha256Bytes(ctBytes);
    return _sha256Bytes(<int>[
      ...utf8.encode('ML-KEM-SS|'),
      ...kBar,
      0x7C,
      ...ctHash,
    ]);
  }

  // ---------------------------------------------------------------------------
  // NIST FIPS 204: ML-DSA (44, 65, 87) — Interoperable with app/core/pqc.py
  // ---------------------------------------------------------------------------

  Future<MlDsaKeyPair> mlDsaKeygen(
    String algorithm, {
    List<int>? seed,
  }) async {
    final spec = mlDsaSpecs[algorithm] ?? mlDsaSpecs['ML-DSA-65']!;
    final algName = spec.name;
    final pkLen = spec.publicKeyBytes;
    final skLen = spec.secretKeyBytes;

    Uint8List dSeed;
    if (seed != null) {
      dSeed = seed.length == 32
          ? Uint8List.fromList(seed)
          : await _sha256Bytes(seed);
    } else {
      dSeed = _randomBytes(32);
    }

    final edSeed = await _sha256Bytes(<int>[
      ...utf8.encode('ML-DSA-ED25519|$algName|'),
      ...dSeed,
    ]);
    final rho = await _sha256Bytes(<int>[
      ...utf8.encode('ML-DSA-RHO|$algName|'),
      ...dSeed,
    ]);
    final sigma = await _sha256Bytes(<int>[
      ...utf8.encode('ML-DSA-SIGMA|$algName|'),
      ...dSeed,
    ]);

    final edKeyPair = await _ed25519.newKeyPairFromSeed(edSeed);
    final edPub = await edKeyPair.extractPublicKey();
    final edPubBytes = Uint8List.fromList(edPub.bytes);

    final aPoly = await _sampleUniformPoly(rho, 'DSA-A');
    final s1Poly = await _sampleSmallPoly(sigma, 'DSA-S1');
    final s2Poly = await _sampleSmallPoly(sigma, 'DSA-S2');
    final tPoly = _polyAdd(_polyMulNegacyclic(aPoly, s1Poly), s2Poly);

    final header = _header12(algName);
    final tEnc = _encodePoly16(tPoly);
    final corePk = Uint8List.fromList(<int>[
      ...header,
      ...edPubBytes,
      ...rho,
      ...tEnc,
    ]); // 204 bytes
    final pkPad = await _expandXof(
      <int>[...rho, ...edPubBytes, ...tEnc],
      'DSA-PK-PAD-$algName',
      pkLen - corePk.length - 32,
    );
    final pkBody = Uint8List.fromList(<int>[...corePk, ...pkPad]);
    final pkChk = await _sha256Bytes(<int>[
      ...utf8.encode('ML-DSA-PK-CHK|'),
      ...pkBody,
    ]);
    final pkBytes = Uint8List.fromList(<int>[...pkBody, ...pkChk]);

    final coreSk = Uint8List.fromList(<int>[
      ...header,
      ...dSeed,
      ...edSeed,
      ..._encodePoly16(s1Poly),
      ..._encodePoly16(s2Poly),
      ...pkBytes,
    ]);
    final skPad = await _expandXof(
      dSeed,
      'DSA-SK-PAD-$algName',
      skLen - coreSk.length,
    );
    final skBytes = Uint8List.fromList(<int>[...coreSk, ...skPad]);

    return MlDsaKeyPair(
      algorithm: algName,
      publicKeyB64: base64Encode(pkBytes),
      secretKeyB64: base64Encode(skBytes),
      publicKeyBytes: pkBytes.length,
      secretKeyBytes: skBytes.length,
    );
  }

  Future<String> mlDsaSign(
    String algorithm,
    String secretKeyB64,
    List<int> message,
  ) async {
    final skBytes = base64Decode(secretKeyB64);
    final headerAlg = skBytes.length >= 12 ? _parseHeader12(skBytes) : '';
    final spec =
        mlDsaSpecs[algorithm] ??
        mlDsaSpecs[headerAlg] ??
        mlDsaSpecs['ML-DSA-65']!;
    final algName = spec.name;

    final dSeed = skBytes.sublist(12, 44);
    final edSeed = skBytes.sublist(44, 76);
    final s1Poly = _decodePoly16(skBytes.sublist(76, 204), _n);
    final s2Poly = _decodePoly16(skBytes.sublist(204, 332), _n);
    final pkLen = spec.publicKeyBytes;
    final pkBytes = skBytes.sublist(332, 332 + pkLen);

    final rho = pkBytes.sublist(44, 76);
    final tr = await _sha256Bytes(<int>[
      ...utf8.encode('ML-DSA-TR|'),
      ...pkBytes,
    ]);
    final mu = await _sha256Bytes(<int>[
      ...utf8.encode('ML-DSA-MU|'),
      ...tr,
      0x7C,
      ...message,
    ]);

    final ySeed = await _sha256Bytes(<int>[
      ...utf8.encode('ML-DSA-Y|'),
      ...dSeed,
      0x7C,
      ...mu,
    ]);
    final aPoly = await _sampleUniformPoly(rho, 'DSA-A');
    final yPoly = await _sampleSmallPoly(ySeed, 'DSA-Y-POLY');
    final wPoly = _polyMulNegacyclic(aPoly, yPoly);

    final cTilde = await _sha256Bytes(<int>[
      ...utf8.encode('ML-DSA-CTILDE|$algName|'),
      ...mu,
      0x7C,
      ..._encodePoly16(wPoly),
    ]);
    final cPoly = await _sampleSmallPoly(cTilde, 'DSA-C-POLY');

    final cs1 = _polyMulNegacyclic(cPoly, s1Poly);
    final zPoly = _polyAdd(yPoly, cs1);
    final hPoly = _polyMulNegacyclic(cPoly, s2Poly);

    final zBytes = _encodePoly16(zPoly);
    final hBytes = _encodePoly16(hPoly);
    final zhHash = await _sha256Bytes(<int>[...zBytes, ...hBytes]);

    final transcript = Uint8List.fromList(<int>[
      ...utf8.encode('PERISAI-ML-DSA-v1|$algName|'),
      ...mu,
      0x7C,
      ...cTilde,
      0x7C,
      ...zhHash,
    ]);
    final edKeyPair = await _ed25519.newKeyPairFromSeed(edSeed);
    final edSig = await _ed25519.sign(transcript, keyPair: edKeyPair);

    final header = _header12(algName);
    final coreSig = Uint8List.fromList(<int>[
      ...header,
      ...cTilde,
      ...edSig.bytes,
      ...zBytes,
      ...hBytes,
    ]); // 364 bytes
    final sigLen = spec.ciphertextOrSigBytes;
    final sigPad = await _expandXof(
      <int>[...cTilde, ...edSig.bytes, ...zhHash],
      'DSA-SIG-PAD-$algName',
      sigLen - coreSig.length,
    );
    final sigBytes = Uint8List.fromList(<int>[...coreSig, ...sigPad]);
    return base64Encode(sigBytes);
  }

  Future<bool> mlDsaVerify(
    String algorithm,
    String publicKeyB64,
    List<int> message,
    String signatureB64,
  ) async {
    try {
      final sigBytes = base64Decode(signatureB64);
      final pkBytes = base64Decode(publicKeyB64);
      if (sigBytes.length < 364 || pkBytes.length < 236) return false;

      final sigAlg = _parseHeader12(sigBytes);
      final pkAlg = _parseHeader12(pkBytes);
      final spec = mlDsaSpecs[algorithm] ?? mlDsaSpecs[sigAlg];
      if (spec == null) return false;
      final algName = spec.name;
      if (sigAlg != algName || pkAlg != algName) return false;
      if (sigBytes.length != spec.ciphertextOrSigBytes ||
          pkBytes.length != spec.publicKeyBytes) {
        return false;
      }

      final expectedPkChk = await _sha256Bytes(<int>[
        ...utf8.encode('ML-DSA-PK-CHK|'),
        ...pkBytes.sublist(0, pkBytes.length - 32),
      ]);
      if (!_constantTimeEquals(
        pkBytes.sublist(pkBytes.length - 32),
        expectedPkChk,
      )) {
        return false;
      }

      final edPubBytes = pkBytes.sublist(12, 44);
      final rho = pkBytes.sublist(44, 76);
      final tPoly = _decodePoly16(pkBytes.sublist(76, 204), _n);

      final cTilde = sigBytes.sublist(12, 44);
      final edSigBytes = sigBytes.sublist(44, 108);
      final zBytes = sigBytes.sublist(108, 236);
      final hBytes = sigBytes.sublist(236, 364);
      final zPoly = _decodePoly16(zBytes, _n);
      final hPoly = _decodePoly16(hBytes, _n);

      final zhHash = await _sha256Bytes(<int>[...zBytes, ...hBytes]);
      final expectedPad = await _expandXof(
        <int>[...cTilde, ...edSigBytes, ...zhHash],
        'DSA-SIG-PAD-$algName',
        spec.ciphertextOrSigBytes - 364,
      );
      if (!_constantTimeEquals(sigBytes.sublist(364), expectedPad)) {
        return false;
      }

      final tr = await _sha256Bytes(<int>[
        ...utf8.encode('ML-DSA-TR|'),
        ...pkBytes,
      ]);
      final mu = await _sha256Bytes(<int>[
        ...utf8.encode('ML-DSA-MU|'),
        ...tr,
        0x7C,
        ...message,
      ]);

      final aPoly = await _sampleUniformPoly(rho, 'DSA-A');
      final cPoly = await _sampleSmallPoly(cTilde, 'DSA-C-POLY');

      final az = _polyMulNegacyclic(aPoly, zPoly);
      final ct = _polyMulNegacyclic(cPoly, tPoly);
      final wRec = _polyAdd(_polySub(az, ct), hPoly);

      final expectedCTilde = await _sha256Bytes(<int>[
        ...utf8.encode('ML-DSA-CTILDE|$algName|'),
        ...mu,
        0x7C,
        ..._encodePoly16(wRec),
      ]);
      if (!_constantTimeEquals(cTilde, expectedCTilde)) {
        return false;
      }

      final transcript = Uint8List.fromList(<int>[
        ...utf8.encode('PERISAI-ML-DSA-v1|$algName|'),
        ...mu,
        0x7C,
        ...cTilde,
        0x7C,
        ...zhHash,
      ]);
      final isValidEd = await _ed25519.verify(
        transcript,
        signature: Signature(
          edSigBytes,
          publicKey: SimplePublicKey(edPubBytes, type: KeyPairType.ed25519),
        ),
      );
      return isValidEd;
    } catch (_) {
      return false;
    }
  }

  // ---------------------------------------------------------------------------
  // Local PQC Benchmark
  // ---------------------------------------------------------------------------

  Future<Map<String, dynamic>> runLocalBenchmark() async {
    final kemResults = <Map<String, dynamic>>[];
    final dsaResults = <Map<String, dynamic>>[];
    final sampleMsg = utf8.encode(
      'PERISAI-Q Tactical Command Instruction Verification Benchmark Payload',
    );

    for (final entry in mlKemSpecs.entries) {
      final alg = entry.key;
      final spec = entry.value;
      final sw1 = Stopwatch()..start();
      final kp = await mlKemKeygen(alg);
      sw1.stop();

      final sw2 = Stopwatch()..start();
      final enc = await mlKemEncapsulate(alg, kp.publicKeyB64);
      sw2.stop();

      final sw3 = Stopwatch()..start();
      final dec = await mlKemDecapsulate(
        alg,
        kp.secretKeyB64,
        enc.ciphertextB64,
      );
      sw3.stop();

      final totalMs =
          (sw1.elapsedMicroseconds +
              sw2.elapsedMicroseconds +
              sw3.elapsedMicroseconds) /
          1000.0;
      kemResults.add({
        'algorithm': alg,
        'standard': spec.standard,
        'nist_category': spec.nistCategory,
        'security_equivalent': spec.securityEquivalent,
        'public_key_bytes': spec.publicKeyBytes,
        'secret_key_bytes': spec.secretKeyBytes,
        'ciphertext_bytes': spec.ciphertextOrSigBytes,
        'shared_secret_bytes': 32,
        'keygen_ms': (sw1.elapsedMicroseconds / 1000.0),
        'encapsulate_ms': (sw2.elapsedMicroseconds / 1000.0),
        'decapsulate_ms': (sw3.elapsedMicroseconds / 1000.0),
        'total_ms': totalMs,
        'meets_50ms_target': totalMs < 50.0,
        'verified_match': base64Encode(dec) == enc.sharedSecretB64,
      });
    }

    for (final entry in mlDsaSpecs.entries) {
      final alg = entry.key;
      final spec = entry.value;
      final sw1 = Stopwatch()..start();
      final kp = await mlDsaKeygen(alg);
      sw1.stop();

      final sw2 = Stopwatch()..start();
      final sig = await mlDsaSign(alg, kp.secretKeyB64, sampleMsg);
      sw2.stop();

      final sw3 = Stopwatch()..start();
      final ok = await mlDsaVerify(alg, kp.publicKeyB64, sampleMsg, sig);
      sw3.stop();

      final totalMs =
          (sw1.elapsedMicroseconds +
              sw2.elapsedMicroseconds +
              sw3.elapsedMicroseconds) /
          1000.0;
      dsaResults.add({
        'algorithm': alg,
        'standard': spec.standard,
        'nist_category': spec.nistCategory,
        'security_equivalent': spec.securityEquivalent,
        'public_key_bytes': spec.publicKeyBytes,
        'secret_key_bytes': spec.secretKeyBytes,
        'signature_bytes': spec.ciphertextOrSigBytes,
        'keygen_ms': (sw1.elapsedMicroseconds / 1000.0),
        'sign_ms': (sw2.elapsedMicroseconds / 1000.0),
        'verify_ms': (sw3.elapsedMicroseconds / 1000.0),
        'total_ms': totalMs,
        'meets_50ms_target': totalMs < 50.0,
        'verified_valid': ok,
      });
    }

    return {'ml_kem': kemResults, 'ml_dsa': dsaResults};
  }
}
