import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/perisai_models.dart';
import '../services/pqc_service.dart';
import '../state/chat_state.dart';

class PerisaiScreen extends StatefulWidget {
  final ChatState state;

  const PerisaiScreen({super.key, required this.state});

  @override
  State<PerisaiScreen> createState() => _PerisaiScreenState();
}

class _PerisaiScreenState extends State<PerisaiScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    final state = widget.state;
    final id = state.identity;
    if (id == null) return const SizedBox.shrink();

    return Column(
      children: [
        Container(
          color: const Color(0xFF0F172A),
          child: TabBar(
            controller: _tabController,
            indicatorColor: Colors.tealAccent,
            labelColor: Colors.tealAccent,
            unselectedLabelColor: Colors.white60,
            labelStyle: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
            tabs: [
              Tab(
                icon: Badge(
                  isLabelVisible: state.queuedOutboxCount > 0,
                  label: Text('${state.queuedOutboxCount}'),
                  child: const Icon(Icons.enhanced_encryption_outlined, size: 18),
                ),
                text: 'PERISAI-Vault',
              ),
              const Tab(
                icon: Icon(Icons.verified_outlined, size: 18),
                text: 'PERISAI-Sign',
              ),
              const Tab(
                icon: Icon(Icons.science_outlined, size: 18),
                text: 'PERISAI-Lab',
              ),
            ],
          ),
        ),
        Expanded(
          child: TabBarView(
            controller: _tabController,
            children: [
              _VaultAndOutboxView(state: state, onSnack: _snack),
              _PerisaiSignView(state: state, onSnack: _snack),
              _PerisaiLabView(state: state, onSnack: _snack),
            ],
          ),
        ),
      ],
    );
  }
}

// =============================================================================
// TAB 1: PERISAI-VAULT & OFFLINE OUTBOX QUEUE
// =============================================================================

class _VaultAndOutboxView extends StatelessWidget {
  final ChatState state;
  final void Function(String) onSnack;

  const _VaultAndOutboxView({required this.state, required this.onSnack});

  @override
  Widget build(BuildContext context) {
    final id = state.identity!;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
      children: [
        // Active PQC Shield Card
        Card(
          margin: EdgeInsets.zero,
          color: const Color(0xFF0F292A),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(
                      Icons.security,
                      color: Colors.tealAccent,
                      size: 22,
                    ),
                    const SizedBox(width: 8),
                    const Expanded(
                      child: Text(
                        'Perlindungan Pasca-Kuantum Aktif (NIST FIPS 203 & 204)',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                          color: Colors.tealAccent,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 6,
                  children: [
                    _PillBadge(
                      label: 'KEM: ${id.pqcKemAlg}',
                      color: Colors.tealAccent,
                    ),
                    _PillBadge(
                      label: 'DSA: ${id.pqcDsaAlg}',
                      color: Colors.cyanAccent,
                    ),
                    const _PillBadge(
                      label: 'AEAD: AES-256-GCM',
                      color: Colors.amberAccent,
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  title: const Text(
                    'Simulasi Mode Taktis Offline (Blank-Spot)',
                    style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600),
                  ),
                  subtitle: Text(
                    state.isOfflineSimulated
                        ? 'OFFLINE AKTIF — Pesan baru otomatis dienkripsi PQC & masuk Offline Outbox Queue'
                        : 'ONLINE — Terhubung ke Relay Server',
                    style: TextStyle(
                      fontSize: 11,
                      color: state.isOfflineSimulated
                          ? Colors.orangeAccent
                          : Colors.white70,
                    ),
                  ),
                  value: state.isOfflineSimulated,
                  onChanged: (val) async {
                    await state.toggleOfflineMode(val);
                    onSnack(
                      val
                          ? 'Mode Taktis Offline diaktifkan. Pesan akan disimpan di Outbox Queue.'
                          : 'Kembali Online — Menyinkronkan antrean pesan PQC...',
                    );
                  },
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),

        // Offline Outbox Queue Section
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'OFFLINE OUTBOX QUEUE (${state.outboxItems.length})',
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.1,
                color: Colors.white70,
              ),
            ),
            if (state.outboxItems.isNotEmpty)
              Row(
                children: [
                  TextButton.icon(
                    onPressed: state.isOfflineSimulated
                        ? null
                        : () async {
                            final n = await state.syncOutboxQueue();
                            onSnack(
                              n > 0
                                  ? '$n pesan terenkripsi PQC berhasil disinkronkan ke Relay!'
                                  : 'Tidak ada antrean pesan yang tertunda.',
                            );
                          },
                    icon: const Icon(Icons.sync, size: 15),
                    label: const Text('Sinkronkan', style: TextStyle(fontSize: 11)),
                  ),
                  TextButton(
                    onPressed: state.clearSyncedOutboxItems,
                    child: const Text('Bersihkan', style: TextStyle(fontSize: 11)),
                  ),
                ],
              ),
          ],
        ),
        if (state.outboxItems.isEmpty)
          Card(
            margin: EdgeInsets.zero,
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Text(
                'Antrean kosong. Saat perangkat berada di area tanpa sinyal (atau mode Offline diaktifkan), pesan tetap dienkripsi dengan ${id.pqcKemAlg} + ${id.pqcDsaAlg} dan disimpan di sini hingga koneksi kembali tersedia.',
                style: const TextStyle(fontSize: 11.5, color: Colors.white60),
              ),
            ),
          )
        else
          ...state.outboxItems.map(
            (item) => Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                dense: true,
                leading: Icon(
                  item.status == 'QUEUED'
                      ? Icons.schedule_send
                      : Icons.cloud_done_outlined,
                  color: item.status == 'QUEUED'
                      ? Colors.orangeAccent
                      : Colors.greenAccent,
                ),
                title: Text(
                  '${item.conversationTitle}: "${item.plaintextPreview}"',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
                subtitle: Text(
                  'Status: ${item.status} • ${item.pqcKemAlg} + ${item.pqcDsaAlg} • ${DateFormat('HH:mm:ss').format(item.queuedAt)}',
                  style: const TextStyle(fontSize: 10.5),
                ),
              ),
            ),
          ),

        const SizedBox(height: 18),

        // PERISAI-Vault Local Encrypted Files Section
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'BRANKAS LOKAL PERISAI-VAULT (${state.vaultItems.length})',
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.1,
                color: Colors.white70,
              ),
            ),
            FilledButton.tonalIcon(
              onPressed: () => _showAddVaultDialog(context),
              icon: const Icon(Icons.add_moderator_outlined, size: 16),
              label: const Text('Enkripsi Arsip Baru', style: TextStyle(fontSize: 11.5)),
            ),
          ],
        ),
        const SizedBox(height: 8),
        if (state.vaultItems.isEmpty)
          const Card(
            margin: EdgeInsets.zero,
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text('Belum ada arsip di PERISAI-Vault.'),
            ),
          )
        else
          ...state.vaultItems.map(
            (item) => Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: const Color(0xFF134E4A),
                  child: Icon(_categoryIcon(item.category), color: Colors.tealAccent, size: 20),
                ),
                title: Text(
                  item.title,
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13.5),
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 3),
                    Text(
                      '${item.categoryLabel} • ${item.plaintextBytes} B • ${DateFormat('dd MMM HH:mm').format(item.createdAt)}',
                      style: const TextStyle(fontSize: 11),
                    ),
                    const SizedBox(height: 4),
                    Wrap(
                      spacing: 6,
                      children: [
                        _PillBadge(label: item.kemAlgorithm, color: Colors.tealAccent),
                        _PillBadge(label: item.dsaAlgorithm, color: Colors.cyanAccent),
                        _PillBadge(
                          label: 'SHA256: ${item.contentSha256.substring(0, 10)}…',
                          color: Colors.white70,
                        ),
                      ],
                    ),
                  ],
                ),
                trailing: IconButton(
                  tooltip: 'Dekripsi & Buka',
                  icon: const Icon(Icons.lock_open_outlined, color: Colors.tealAccent),
                  onPressed: () => _openVaultItem(context, item),
                ),
                onTap: () => _openVaultItem(context, item),
              ),
            ),
          ),
      ],
    );
  }

  IconData _categoryIcon(String category) {
    switch (category) {
      case 'document_pdf':
        return Icons.picture_as_pdf_outlined;
      case 'map_coords':
        return Icons.map_outlined;
      case 'intel_photo':
        return Icons.perm_media_outlined;
      case 'voice_note':
        return Icons.mic_none_outlined;
      default:
        return Icons.folder_special_outlined;
    }
  }

  Future<void> _openVaultItem(BuildContext context, VaultItem item) async {
    final res = await state.decryptVaultItem(item);
    if (res == null || !context.mounted) return;
    final valid = res['signature_valid'] == true;
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(item.title, style: const TextStyle(fontSize: 15)),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: (valid ? Colors.green : Colors.red).withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Icon(
                      valid ? Icons.verified_user : Icons.gpp_bad,
                      size: 18,
                      color: valid ? Colors.greenAccent : Colors.redAccent,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        valid
                            ? 'Dekripsi ${item.kemAlgorithm} + AES-256-GCM Berhasil & Tanda Tangan ${item.dsaAlgorithm} Valid'
                            : 'Peringatan: Tanda tangan tidak cocok!',
                        style: const TextStyle(fontSize: 11),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              const Text(
                'ISI ARSIP TERDEKRIPSI:',
                style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.white60),
              ),
              const SizedBox(height: 6),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.black26,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: SelectableText(
                  res['plaintext']?.toString() ?? '',
                  style: const TextStyle(fontSize: 12.5, height: 1.45),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'SHA-256: ${item.contentSha256}',
                style: const TextStyle(fontSize: 10, fontFamily: 'monospace', color: Colors.white54),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () async {
              Navigator.of(ctx).pop();
              await state.deleteVaultItem(item.vaultItemId);
              onSnack('Arsip dihapus dari PERISAI-Vault.');
            },
            child: const Text('Hapus', style: TextStyle(color: Colors.redAccent)),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
  }

  Future<void> _showAddVaultDialog(BuildContext context) async {
    final titleCtrl = TextEditingController();
    final contentCtrl = TextEditingController();
    var category = 'document_pdf';

    final saved = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('Simpan ke PERISAI-Vault'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  initialValue: category,
                  decoration: const InputDecoration(labelText: 'Kategori Taktis'),
                  items: const [
                    DropdownMenuItem(
                      value: 'document_pdf',
                      child: Text('Dokumen Taktis / PDF'),
                    ),
                    DropdownMenuItem(
                      value: 'map_coords',
                      child: Text('Peta & Koordinat GPS'),
                    ),
                    DropdownMenuItem(
                      value: 'intel_photo',
                      child: Text('Metadata Foto Intelijen'),
                    ),
                    DropdownMenuItem(
                      value: 'voice_note',
                      child: Text('Transkrip Rekaman Suara'),
                    ),
                  ],
                  onChanged: (v) {
                    if (v != null) setDialogState(() => category = v);
                  },
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: titleCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Judul Arsip',
                    hintText: 'Contoh: Koordinat Pos Pantau Bravo',
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: contentCtrl,
                  minLines: 3,
                  maxLines: 6,
                  decoration: const InputDecoration(
                    labelText: 'Isi / Koordinat / Data Rahasia',
                    hintText: 'Data akan dienkripsi dengan ML-KEM + AES-256-GCM',
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(false),
              child: const Text('Batal'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(ctx).pop(true),
              child: const Text('Enkripsi & Simpan'),
            ),
          ],
        ),
      ),
    );

    if (saved == true &&
        titleCtrl.text.trim().isNotEmpty &&
        contentCtrl.text.trim().isNotEmpty) {
      final item = await state.addVaultItem(
        title: titleCtrl.text.trim(),
        category: category,
        contentText: contentCtrl.text.trim(),
      );
      if (item != null) {
        onSnack('Arsip berhasil dienkripsi dengan ${item.kemAlgorithm} & ${item.dsaAlgorithm}!');
      }
    }
    titleCtrl.dispose();
    contentCtrl.dispose();
  }
}

// =============================================================================
// TAB 2: PERISAI-SIGN (ML-DSA-44, ML-DSA-65, ML-DSA-87)
// =============================================================================

class _PerisaiSignView extends StatelessWidget {
  final ChatState state;
  final void Function(String) onSnack;

  const _PerisaiSignView({required this.state, required this.onSnack});

  @override
  Widget build(BuildContext context) {
    final id = state.identity!;
    return RefreshIndicator(
      onRefresh: state.refreshSignedArtifacts,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
        children: [
          Card(
            margin: EdgeInsets.zero,
            color: const Color(0xFF0F292A),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'PERISAI-Sign • Otentikasi Instruksi & Firmware (NIST FIPS 204)',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                      color: Colors.tealAccent,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Tanda tangani laporan lapangan, instruksi komando, atau paket firmware OT/IoT dengan ${id.pqcDsaAlg} (mendukung varian 44, 65, dan 87). Modifikasi 1-bit pada payload pasti terdeteksi dan ditolak.',
                    style: const TextStyle(fontSize: 11.5, color: Colors.white70),
                  ),
                  const SizedBox(height: 10),
                  FilledButton.icon(
                    onPressed: () => _showSignDialog(context),
                    icon: const Icon(Icons.draw_outlined, size: 17),
                    label: const Text('Tanda Tangani Dokumen / Instruksi Baru'),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'DAFTAR INSTRUKSI & ARTEFAK TERTANDA TANGAN (${state.signedArtifacts.length})',
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.1,
              color: Colors.white70,
            ),
          ),
          const SizedBox(height: 8),
          if (state.signedArtifacts.isEmpty)
            const Card(
              margin: EdgeInsets.zero,
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'Belum ada instruksi atau paket firmware yang ditandatangani. Tekan tombol di atas untuk membuat tanda tangan ML-DSA pertama.',
                  style: TextStyle(fontSize: 12),
                ),
              ),
            )
          else
            ...state.signedArtifacts.map(
              (art) => Card(
                margin: const EdgeInsets.only(bottom: 10),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(
                            art.status == 'revoked'
                                ? Icons.cancel_outlined
                                : Icons.verified_outlined,
                            color: art.status == 'revoked'
                                ? Colors.redAccent
                                : Colors.tealAccent,
                            size: 20,
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              art.title,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                              ),
                            ),
                          ),
                          if (art.isEncryptedWithKem) ...[
                            _PillBadge(
                              label: art.kemAlgorithm,
                              color: Colors.tealAccent,
                            ),
                            const SizedBox(width: 4),
                          ],
                          _PillBadge(
                            label: art.algorithm,
                            color: Colors.cyanAccent,
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(
                        '${art.typeLabel} • Penanda tangan: ${art.signerDisplayName} • Status: ${art.status.toUpperCase()}',
                        style: const TextStyle(fontSize: 11, color: Colors.white70),
                      ),
                      const SizedBox(height: 6),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.black26,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          art.contentText,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 12),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'SHA-256: ${art.contentHashSha256.substring(0, 24)}…',
                        style: const TextStyle(
                          fontSize: 10,
                          fontFamily: 'monospace',
                          color: Colors.white54,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        runSpacing: 6,
                        children: [
                          if (art.isEncryptedWithKem)
                            FilledButton.icon(
                              onPressed: () => _showDecryptArtifactDialog(context, art),
                              icon: const Icon(Icons.lock_open_outlined, size: 16),
                              label: Text(
                                'Buka / Dekripsi (${art.kemAlgorithm})',
                                style: const TextStyle(fontSize: 11.5),
                              ),
                            ),
                          FilledButton.tonalIcon(
                            onPressed: () => _verifyArtifact(context, art, tamper: false),
                            icon: const Icon(Icons.check_circle_outline, size: 16),
                            label: const Text('Verifikasi Otentik', style: TextStyle(fontSize: 11.5)),
                          ),
                          OutlinedButton.icon(
                            onPressed: () => _verifyArtifact(context, art, tamper: true),
                            icon: const Icon(Icons.bug_report_outlined, size: 16, color: Colors.orangeAccent),
                            label: const Text(
                              'Uji Tamper 1-Bit',
                              style: TextStyle(fontSize: 11.5, color: Colors.orangeAccent),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Future<void> _showDecryptArtifactDialog(
    BuildContext context,
    SignedArtifactModel art,
  ) async {
    final keyCtrl = TextEditingController();
    final submitted = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(
          'Dekripsi File (${art.kemAlgorithm})',
          style: const TextStyle(fontSize: 15),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Tempel Kunci Privat ${art.kemAlgorithm} yang dibuat saat file "${art.fileName.isNotEmpty ? art.fileName : art.title}" dienkripsi:',
              style: const TextStyle(fontSize: 12, color: Colors.white70),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: keyCtrl,
              maxLines: 4,
              style: const TextStyle(fontSize: 11, fontFamily: 'monospace'),
              decoration: InputDecoration(
                labelText: 'Kunci Privat ${art.kemAlgorithm} (Base64)',
                hintText: 'Tempel kem_secret_key_b64 di sini...',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Dekripsi & Buka'),
          ),
        ],
      ),
    );

    final secretKey = keyCtrl.text.trim();
    keyCtrl.dispose();
    if (submitted != true || secretKey.isEmpty || !context.mounted) return;

    final res = await state.decryptArtifactWithKemKey(
      artifactId: art.artifactId,
      kemSecretKeyB64: secretKey,
    );
    if (!context.mounted) return;

    if (res == null) {
      onSnack(state.errorMessage ?? 'Dekripsi gagal: Kunci ML-KEM tidak cocok.');
      return;
    }

    final b64 = res['file_data_b64']?.toString() ?? '';
    String previewText;
    try {
      final bytes = base64Decode(b64);
      previewText = utf8.decode(bytes, allowMalformed: true);
    } catch (_) {
      previewText = '[Data Biner Terdekripsi: ${res['file_size']} bytes]';
    }

    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Row(
          children: [
            const Icon(Icons.lock_open, color: Colors.tealAccent),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                'Dekripsi ${res['kem_algorithm']} Berhasil!',
                style: const TextStyle(fontSize: 15),
              ),
            ),
          ],
        ),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'File: ${res['file_name']} (${res['file_size']} bytes)\nSegel: ${res['dsa_algorithm']} Valid ✓',
                style: const TextStyle(fontSize: 12, color: Colors.tealAccent),
              ),
              const SizedBox(height: 10),
              const Text(
                'ISI FILE TERDEKRIPSI:',
                style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.white60),
              ),
              const SizedBox(height: 6),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.black26,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: SelectableText(
                  previewText.length > 2000
                      ? '${previewText.substring(0, 2000)}\n… [terpotong untuk pratinjau]'
                      : previewText,
                  style: const TextStyle(fontSize: 12, fontFamily: 'monospace'),
                ),
              ),
            ],
          ),
        ),
        actions: [
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
  }

  Future<void> _verifyArtifact(
    BuildContext context,
    SignedArtifactModel art, {
    required bool tamper,
  }) async {
    final tamperedContent = tamper
        ? '${art.contentText} [TAMPERED-1-BIT]'
        : null;
    final res = await state.verifyArtifact(
      art,
      overriddenContentText: tamperedContent,
    );
    if (!context.mounted) return;
    final verified = res['verified'] == true;
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Row(
          children: [
            Icon(
              verified ? Icons.verified_user : Icons.gpp_bad,
              color: verified ? Colors.greenAccent : Colors.redAccent,
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                verified
                    ? 'Verifikasi ML-DSA Berhasil'
                    : 'DITOLAK: Integritas Gagal!',
                style: const TextStyle(fontSize: 15),
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              res['message']?.toString() ?? '',
              style: TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w600,
                color: verified ? Colors.greenAccent : Colors.redAccent,
              ),
            ),
            const SizedBox(height: 12),
            Text('Algoritma: ${res['algorithm']} (NIST FIPS 204)', style: const TextStyle(fontSize: 11.5)),
            Text('Signature Valid: ${res['crypto_signature_valid']}', style: const TextStyle(fontSize: 11.5)),
            Text('Hash Payload Cocok: ${res['content_hash_matches']}', style: const TextStyle(fontSize: 11.5)),
            Text('Status Penanda Tangan Dicabut: ${res['signer_revoked']}', style: const TextStyle(fontSize: 11.5)),
            const SizedBox(height: 8),
            Text(
              'Expected SHA-256:\n${res['expected_sha256']}\n\nTested SHA-256:\n${res['tested_sha256']}',
              style: const TextStyle(fontSize: 10, fontFamily: 'monospace', color: Colors.white60),
            ),
          ],
        ),
        actions: [
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
  }

  Future<void> _showSignDialog(BuildContext context) async {
    final titleCtrl = TextEditingController();
    final contentCtrl = TextEditingController();
    var artifactType = 'field_report';
    var algorithm = state.identity?.pqcDsaAlg ?? 'ML-DSA-65';

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('Tanda Tangani dengan ML-DSA'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  initialValue: artifactType,
                  decoration: const InputDecoration(labelText: 'Jenis Artefak'),
                  items: const [
                    DropdownMenuItem(
                      value: 'field_report',
                      child: Text('Laporan Intelijen Lapangan'),
                    ),
                    DropdownMenuItem(
                      value: 'command_instruction',
                      child: Text('Instruksi Komando Operasi'),
                    ),
                    DropdownMenuItem(
                      value: 'firmware_package',
                      child: Text('Manifes Firmware OT/IoT'),
                    ),
                  ],
                  onChanged: (v) {
                    if (v != null) setDialogState(() => artifactType = v);
                  },
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  initialValue: algorithm,
                  decoration: const InputDecoration(
                    labelText: 'Varian Standar NIST FIPS 204',
                  ),
                  items: const [
                    DropdownMenuItem(
                      value: 'ML-DSA-44',
                      child: Text('ML-DSA-44 (Kategori 2 - Ringkas)'),
                    ),
                    DropdownMenuItem(
                      value: 'ML-DSA-65',
                      child: Text('ML-DSA-65 (Kategori 3 - Rekomendasi)'),
                    ),
                    DropdownMenuItem(
                      value: 'ML-DSA-87',
                      child: Text('ML-DSA-87 (Kategori 5 - Maksimum)'),
                    ),
                  ],
                  onChanged: (v) {
                    if (v != null) setDialogState(() => algorithm = v);
                  },
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: titleCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Judul Instruksi / Laporan',
                    hintText: 'Contoh: SITREP Sektor Utara #04',
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: contentCtrl,
                  minLines: 3,
                  maxLines: 6,
                  decoration: const InputDecoration(
                    labelText: 'Isi Instruksi / Hash Firmware',
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(false),
              child: const Text('Batal'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(ctx).pop(true),
              child: const Text('Tanda Tangani & Publikasikan'),
            ),
          ],
        ),
      ),
    );

    if (ok == true &&
        titleCtrl.text.trim().isNotEmpty &&
        contentCtrl.text.trim().isNotEmpty) {
      final created = await state.createAndSignArtifact(
        artifactType: artifactType,
        title: titleCtrl.text.trim(),
        contentText: contentCtrl.text.trim(),
        customAlgorithm: algorithm,
      );
      if (created != null) {
        onSnack('Berhasil ditandatangani dengan ${created.algorithm}!');
      } else {
        onSnack(state.errorMessage ?? 'Gagal menandatangani artefak.');
      }
    }
    titleCtrl.dispose();
    contentCtrl.dispose();
  }
}

// =============================================================================
// TAB 3: PERISAI-LAB (CRYPTO-AGILITY, QUANTUM SIMULATOR, AUDIT & BENCHMARK)
// =============================================================================

class _PerisaiLabView extends StatefulWidget {
  final ChatState state;
  final void Function(String) onSnack;

  const _PerisaiLabView({required this.state, required this.onSnack});

  @override
  State<_PerisaiLabView> createState() => _PerisaiLabViewState();
}

class _PerisaiLabViewState extends State<_PerisaiLabView> {
  late String _selectedKem;
  late String _selectedDsa;
  int _selectedRsaN = 3233;

  @override
  void initState() {
    super.initState();
    _selectedKem = widget.state.identity?.pqcKemAlg ?? 'ML-KEM-768';
    _selectedDsa = widget.state.identity?.pqcDsaAlg ?? 'ML-DSA-65';
  }

  @override
  Widget build(BuildContext context) {
    final state = widget.state;
    final sim = state.lastQuantumSimulation;
    final bench = state.lastBenchmark;
    final audit = state.lastFleetAudit;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
      children: [
        // 1. Crypto-Agility Selector Card (NIST 512/768/1024 & 44/65/87)
        Card(
          margin: EdgeInsets.zero,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Crypto-Agility: Profil Standar NIST (ML-KEM & ML-DSA)',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13.5),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Pilih varian parameter NIST FIPS 203 (512, 768, 1024) dan FIPS 204 (44, 65, 87) untuk perangkat ini:',
                  style: TextStyle(fontSize: 11.5, color: Colors.white70),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  initialValue: _selectedKem,
                  decoration: const InputDecoration(
                    labelText: 'Key Encapsulation Mechanism (FIPS 203)',
                  ),
                  items: PqcService.mlKemSpecs.values
                      .map(
                        (s) => DropdownMenuItem(
                          value: s.name,
                          child: Text(
                            '${s.name} (Kat. ${s.nistCategory} • PK ${s.publicKeyBytes}B • CT ${s.ciphertextOrSigBytes}B)',
                            style: const TextStyle(fontSize: 12),
                          ),
                        ),
                      )
                      .toList(),
                  onChanged: (v) {
                    if (v != null) setState(() => _selectedKem = v);
                  },
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  initialValue: _selectedDsa,
                  decoration: const InputDecoration(
                    labelText: 'Digital Signature Algorithm (FIPS 204)',
                  ),
                  items: PqcService.mlDsaSpecs.values
                      .map(
                        (s) => DropdownMenuItem(
                          value: s.name,
                          child: Text(
                            '${s.name} (Kat. ${s.nistCategory} • PK ${s.publicKeyBytes}B • Sig ${s.ciphertextOrSigBytes}B)',
                            style: const TextStyle(fontSize: 12),
                          ),
                        ),
                      )
                      .toList(),
                  onChanged: (v) {
                    if (v != null) setState(() => _selectedDsa = v);
                  },
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: state.isBusy
                        ? null
                        : () async {
                            final ok = await state.rotatePqcProfile(
                              kemAlg: _selectedKem,
                              dsaAlg: _selectedDsa,
                            );
                            widget.onSnack(
                              ok
                                  ? 'Kunci PQC perangkat diputar ke $_selectedKem & $_selectedDsa!'
                                  : 'Gagal memutar kunci PQC.',
                            );
                          },
                    icon: const Icon(Icons.autorenew, size: 18),
                    label: const Text('Terapkan & Putar Kunci PQC (Rotate Keys)'),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),

        // 2. Quantum Attack Simulator (Shor's Algorithm & QUBO vs ML-KEM/ML-DSA)
        Card(
          margin: EdgeInsets.zero,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Simulator Serangan Kuantum (Shor & QUBO vs Lattice PQC)',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13.5),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Simulasikan bagaimana algoritma Shor (QFT Period Finding) & optimasi QUBO memfaktorkan kunci RSA, sementara kisi Module-LWE ML-KEM & ML-DSA tetap aman.',
                  style: TextStyle(fontSize: 11.5, color: Colors.white70),
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<int>(
                  initialValue: _selectedRsaN,
                  decoration: const InputDecoration(
                    labelText: 'Modulus Uji RSA (N = p × q)',
                  ),
                  items: const [
                    DropdownMenuItem(
                      value: 3233,
                      child: Text('RSA N = 3233 (61 × 53) - Standar Demo Shor'),
                    ),
                    DropdownMenuItem(
                      value: 143,
                      child: Text('RSA N = 143 (11 × 13) - Sirkuit Kuantum Ringkas'),
                    ),
                    DropdownMenuItem(
                      value: 10403,
                      child: Text('RSA N = 10403 (101 × 103) - 14-bit Semiprime'),
                    ),
                  ],
                  onChanged: (v) {
                    if (v != null) setState(() => _selectedRsaN = v);
                  },
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.tonalIcon(
                    onPressed: state.isBusy
                        ? null
                        : () => state.runQuantumRsaSimulation(
                              rsaModulusN: _selectedRsaN,
                              compareKemAlg: _selectedKem,
                              compareDsaAlg: _selectedDsa,
                            ),
                    icon: const Icon(Icons.bolt, size: 18),
                    label: const Text('Jalankan Simulasi Serangan Kuantum'),
                  ),
                ),
                if (sim != null) ...[
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.redAccent.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.redAccent.withValues(alpha: 0.4)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'HASIL SERANGAN SHOR PADA RSA (N=${sim['shor_simulation']?['modulus_n']}): DITEMBUS!',
                          style: const TextStyle(
                            fontSize: 11.5,
                            fontWeight: FontWeight.bold,
                            color: Colors.redAccent,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '• Faktor Prima Ditemukan: p × q = ${sim['shor_simulation']?['recovered_factors']}\n'
                          '• Periode Kuantum (r): ${sim['shor_simulation']?['period_r']} (${sim['shor_simulation']?['quantum_circuit_qubits']} Qubits)\n'
                          '• Kunci Privat RSA (d): ${sim['rsa_break_demo']?['recovered_private_d']}\n'
                          '• Pesan Rahasia (${sim['rsa_break_demo']?['original_message']}) -> Ciphertext (${sim['rsa_break_demo']?['ciphertext']}) -> Berhasil Didekripsi Penyerang: ${sim['rsa_break_demo']?['decrypted_by_attacker']}',
                          style: const TextStyle(fontSize: 11, height: 1.4),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.tealAccent.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.tealAccent.withValues(alpha: 0.4)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'PERTAHANAN PERISAI-Q ($_selectedKem & $_selectedDsa): AMAN (QUANTUM-SAFE)',
                          style: const TextStyle(
                            fontSize: 11.5,
                            fontWeight: FontWeight.bold,
                            color: Colors.tealAccent,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          sim['pqc_comparison']?['ml_kem']?['reason']?.toString() ?? '',
                          style: const TextStyle(fontSize: 11, height: 1.35),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),

        // 3. Benchmark & Fleet Readiness Audit Card
        Card(
          margin: EdgeInsets.zero,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Benchmark NIST PQC (< 50 ms) & Audit Kesiapan Armada',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13.5),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: state.isBusy ? null : state.runPqcBenchmark,
                        icon: const Icon(Icons.speed, size: 16),
                        label: const Text('Uji Benchmark', style: TextStyle(fontSize: 11.5)),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: state.isBusy ? null : state.runFleetPqcAudit,
                        icon: const Icon(Icons.policy_outlined, size: 16),
                        label: const Text('Audit Armada', style: TextStyle(fontSize: 11.5)),
                      ),
                    ),
                  ],
                ),
                if (bench != null) ...[
                  const SizedBox(height: 12),
                  const Text(
                    'HASIL BENCHMARK ML-KEM (512 / 768 / 1024) & ML-DSA (44 / 65 / 87):',
                    style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.bold, color: Colors.tealAccent),
                  ),
                  const SizedBox(height: 6),
                  ...(bench['ml_kem'] as List<dynamic>? ?? []).map(
                    (row) => Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: Text(
                        '• ${row['algorithm']}: Total ${row['total_ms']} ms (KeyGen ${row['keygen_ms']}ms, Encap ${row['encapsulate_ms']}ms, Decap ${row['decapsulate_ms']}ms) • PK ${row['public_key_bytes']}B',
                        style: const TextStyle(fontSize: 11),
                      ),
                    ),
                  ),
                  ...(bench['ml_dsa'] as List<dynamic>? ?? []).map(
                    (row) => Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: Text(
                        '• ${row['algorithm']}: Total ${row['total_ms']} ms (KeyGen ${row['keygen_ms']}ms, Sign ${row['sign_ms']}ms, Verify ${row['verify_ms']}ms) • Sig ${row['signature_bytes']}B',
                        style: const TextStyle(fontSize: 11),
                      ),
                    ),
                  ),
                ],
                if (audit != null) ...[
                  const SizedBox(height: 12),
                  Text(
                    'SKOR KESIAPAN KUANTUM ORGANISASI: ${audit['summary']?['readiness_score_percent']}%',
                    style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.cyanAccent),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '• Perangkat PQC Aktif: ${audit['summary']?['pqc_ready_devices']} / ${audit['summary']?['active_devices']}\n'
                    '• Pesan Hybrid PQC: ${audit['summary']?['hybrid_pqc_messages']} / ${audit['summary']?['sampled_messages']}\n'
                    '• Artefak Tertanda Tangan ML-DSA: ${audit['summary']?['active_signed_artifacts']}',
                    style: const TextStyle(fontSize: 11, height: 1.4),
                  ),
                ],
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _PillBadge extends StatelessWidget {
  final String label;
  final Color color;

  const _PillBadge({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2.5),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: color.withValues(alpha: 0.35)),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.bold,
          color: color,
        ),
      ),
    );
  }
}
