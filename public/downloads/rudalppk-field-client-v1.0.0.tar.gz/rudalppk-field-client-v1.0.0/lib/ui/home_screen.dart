import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import '../models/contact.dart';
import '../models/conversation.dart';
import '../services/storage_service.dart';
import '../state/chat_state.dart';
import 'chat_screen.dart';
import 'directory_picker.dart';
import 'perisai_screen.dart';

class HomeScreen extends StatefulWidget {
  final ChatState state;

  const HomeScreen({super.key, required this.state});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;
  String _serverUrl = '';

  @override
  void initState() {
    super.initState();
    _loadServerUrl();
  }

  Future<void> _loadServerUrl() async {
    final url = await StorageService().getBaseUrl();
    if (!mounted) return;
    setState(() => _serverUrl = url);
  }

  void _openChat(ConversationModel conversation) {
    widget.state.selectConversation(conversation);
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) =>
            ChatScreen(conversation: conversation, state: widget.state),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = widget.state;
    final identity = state.identity;

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Secure Field Comms',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
            ),
            if (identity != null)
              Text(
                state.organizationName ?? identity.publicIdentity,
                style: TextStyle(
                  fontSize: 11,
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
          ],
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 4),
            child: Center(
              child: _ConnectionPill(connected: state.isWsConnected),
            ),
          ),
          IconButton(
            tooltip: 'Sinkronkan',
            onPressed: state.isBusy ? null : state.ensureReady,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: Column(
        children: [
          if (state.errorMessage != null)
            _ErrorBanner(
              message: state.errorMessage!,
              onClose: state.clearError,
            ),
          Expanded(
            child: IndexedStack(
              index: _index,
              children: [
                _PersonalTab(
                  state: state,
                  onOpen: _openChat,
                  onCompose: _startPersonalChat,
                ),
                _GroupsTab(
                  state: state,
                  onOpen: _openChat,
                  onCreate: _createGroup,
                ),
                PerisaiScreen(state: state),
                _ProfileTab(
                  state: state,
                  serverUrl: _serverUrl,
                  onEditServer: _editServerUrl,
                  onShowRecovery: _showRecoveryPhrase,
                  onAddContact: _addContact,
                  onChatContact: _chatContact,
                  onLogout: _logout,
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: switch (_index) {
        0 => FloatingActionButton.extended(
          onPressed: _startPersonalChat,
          icon: const Icon(Icons.chat_bubble_outline),
          label: const Text('Pesan Baru'),
        ),
        1 => FloatingActionButton.extended(
          onPressed: _createGroup,
          icon: const Icon(Icons.group_add_outlined),
          label: const Text('Grup Baru'),
        ),
        _ => null,
      },
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (index) => setState(() => _index = index),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.forum_outlined),
            selectedIcon: Icon(Icons.forum),
            label: 'Personal',
          ),
          NavigationDestination(
            icon: Icon(Icons.groups_outlined),
            selectedIcon: Icon(Icons.groups),
            label: 'Grup',
          ),
          NavigationDestination(
            icon: Icon(Icons.shield_outlined),
            selectedIcon: Icon(Icons.shield),
            label: 'PERISAI-Q',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'Profil',
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Actions
  // ---------------------------------------------------------------------------

  Future<void> _startPersonalChat() async {
    final selected = await showDirectoryPicker(
      context,
      state: widget.state,
      multiSelect: false,
      title: 'Pilih Kontak Personal',
    );
    if (selected == null || selected.isEmpty || !mounted) return;
    final conversation = await widget.state.createDirectConversation(
      selected.first,
    );
    if (!mounted) return;
    if (conversation != null) {
      _openChat(conversation);
    } else {
      _snack(widget.state.errorMessage ?? 'Gagal membuat percakapan.');
    }
  }

  Future<void> _createGroup() async {
    final selected = await showDirectoryPicker(
      context,
      state: widget.state,
      multiSelect: true,
      title: 'Pilih Anggota Grup',
    );
    if (selected == null || !mounted) return;
    if (selected.isEmpty) {
      _snack('Pilih minimal satu anggota grup.');
      return;
    }

    final titleController = TextEditingController();
    final title = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Nama Grup'),
        content: TextField(
          controller: titleController,
          autofocus: true,
          decoration: const InputDecoration(
            labelText: 'Nama grup',
            hintText: 'Contoh: Tim Operasi Lapangan',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(titleController.text),
            child: const Text('Buat'),
          ),
        ],
      ),
    );
    titleController.dispose();
    if (!mounted) return;

    final group = await widget.state.createGroup(
      title: (title == null || title.trim().isEmpty)
          ? 'Grup Operasional'
          : title,
      memberIdentityIds: selected,
    );
    if (!mounted) return;
    if (group != null) {
      _openChat(group);
    } else {
      _snack(widget.state.errorMessage ?? 'Gagal membuat grup.');
    }
  }

  Future<void> _addContact() async {
    final selected = await showDirectoryPicker(
      context,
      state: widget.state,
      multiSelect: false,
      title: 'Tambah Kontak',
    );
    if (selected == null || selected.isEmpty || !mounted) return;
    final ok = await widget.state.addContactByIdentityId(selected.first);
    if (!mounted) return;
    _snack(
      ok
          ? 'Kontak berhasil ditambahkan.'
          : (widget.state.errorMessage ?? 'Gagal menambahkan kontak.'),
    );
  }

  Future<void> _chatContact(ContactModel contact) async {
    final conversation = await widget.state.createDirectConversation(
      contact.contactIdentityId,
    );
    if (!mounted) return;
    if (conversation != null) {
      _openChat(conversation);
    } else {
      _snack(widget.state.errorMessage ?? 'Gagal membuka percakapan.');
    }
  }

  Future<void> _editServerUrl() async {
    final controller = TextEditingController(text: _serverUrl);
    final value = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Alamat Server Backend'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: controller,
              keyboardType: TextInputType.url,
              autocorrect: false,
              decoration: const InputDecoration(
                hintText: 'http://10.0.2.2:8000/api/v1',
                prefixIcon: Icon(Icons.link),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              'Android emulator menggunakan 10.0.2.2. '
              'Perangkat fisik menggunakan IP LAN komputer.',
              style: TextStyle(
                fontSize: 11,
                height: 1.4,
                color: Theme.of(dialogContext).colorScheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(controller.text),
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
    controller.dispose();

    if (value == null || !mounted) return;
    final ok = await widget.state.applyServerUrl(value);
    if (!mounted) return;
    if (ok) {
      await _loadServerUrl();
      _snack('Alamat server diperbarui dan sesi diautentikasi ulang.');
    } else {
      _snack(widget.state.errorMessage ?? 'Gagal memperbarui alamat server.');
    }
  }

  void _showRecoveryPhrase() {
    final phrase = widget.state.identity?.recoveryPhrase ?? '';
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Frasa Pemulihan'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Jangan bagikan frasa ini. Siapa pun yang memilikinya dapat '
              'memulihkan identitas Anda.',
              style: TextStyle(fontSize: 12, color: Colors.orangeAccent),
            ),
            const SizedBox(height: 14),
            SelectableText(
              phrase,
              style: const TextStyle(
                fontSize: 14,
                height: 1.7,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Clipboard.setData(ClipboardData(text: phrase));
              Navigator.of(dialogContext).pop();
              _snack('Frasa pemulihan disalin.');
            },
            child: const Text('Salin'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
  }

  Future<void> _logout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Keluar dari perangkat?'),
        content: const Text(
          'Kunci privat akan dihapus dari perangkat ini. Pastikan Anda sudah '
          'menyimpan frasa pemulihan sebelum keluar.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Batal'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.redAccent),
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Keluar'),
          ),
        ],
      ),
    );

    if (confirmed == true) await widget.state.logout();
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }
}

// -----------------------------------------------------------------------------
// Personal tab
// -----------------------------------------------------------------------------

class _PersonalTab extends StatelessWidget {
  final ChatState state;
  final void Function(ConversationModel) onOpen;
  final VoidCallback onCompose;

  const _PersonalTab({
    required this.state,
    required this.onOpen,
    required this.onCompose,
  });

  @override
  Widget build(BuildContext context) {
    if (state.personalConversations.isEmpty) {
      return _EmptyState(
        icon: Icons.forum_outlined,
        title: 'Belum ada percakapan personal',
        body: 'Mulai percakapan terenkripsi satu-lawan-satu dengan anggota '
            'organisasi Anda.',
        actionLabel: 'Pesan Baru',
        onAction: onCompose,
      );
    }

    return RefreshIndicator(
      onRefresh: state.refreshPersonal,
      child: ListView.separated(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 96),
        physics: const AlwaysScrollableScrollPhysics(),
        itemCount: state.personalConversations.length,
        separatorBuilder: (_, _) => const SizedBox(height: 8),
        itemBuilder: (context, index) {
          final conversation = state.personalConversations[index];
          return Card(
            margin: EdgeInsets.zero,
            clipBehavior: Clip.antiAlias,
            child: ListTile(
              onTap: () => onOpen(conversation),
              leading: const CircleAvatar(
                backgroundColor: Color(0xFF134E4A),
                child: Icon(Icons.person_outline, color: Colors.tealAccent),
              ),
              title: Text(
                state.titleFor(conversation),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
              subtitle: Row(
                children: [
                  const Icon(Icons.lock_outline, size: 12),
                  const SizedBox(width: 4),
                  Flexible(
                    child: Text(
                      state.subtitleFor(conversation),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 11),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    DateFormat('dd MMM').format(conversation.createdAt),
                    style: const TextStyle(fontSize: 10),
                  ),
                ],
              ),
              trailing: const Icon(Icons.chevron_right, size: 20),
            ),
          );
        },
      ),
    );
  }
}

// -----------------------------------------------------------------------------
// Groups tab
// -----------------------------------------------------------------------------

class _GroupsTab extends StatelessWidget {
  final ChatState state;
  final void Function(ConversationModel) onOpen;
  final VoidCallback onCreate;

  const _GroupsTab({
    required this.state,
    required this.onOpen,
    required this.onCreate,
  });

  @override
  Widget build(BuildContext context) {
    if (state.groups.isEmpty) {
      return _EmptyState(
        icon: Icons.groups_outlined,
        title: 'Belum ada grup',
        body: 'Buat grup operasional dan kelola anggotanya. Perubahan '
            'keanggotaan otomatis memutar epoch kunci grup.',
        actionLabel: 'Grup Baru',
        onAction: onCreate,
      );
    }

    return RefreshIndicator(
      onRefresh: state.refreshGroups,
      child: ListView.separated(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 96),
        physics: const AlwaysScrollableScrollPhysics(),
        itemCount: state.groups.length,
        separatorBuilder: (_, _) => const SizedBox(height: 8),
        itemBuilder: (context, index) {
          final group = state.groups[index];
          return Card(
            margin: EdgeInsets.zero,
            clipBehavior: Clip.antiAlias,
            child: ListTile(
              onTap: () => onOpen(group),
              leading: CircleAvatar(
                backgroundColor: Colors.amber.withValues(alpha: 0.2),
                child: const Icon(Icons.groups, color: Colors.amber),
              ),
              title: Text(
                state.titleFor(group),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
              subtitle: Row(
                children: [
                  const Icon(Icons.lock_outline, size: 12),
                  const SizedBox(width: 4),
                  Flexible(
                    child: Text(
                      state.subtitleFor(group),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 11),
                    ),
                  ),
                ],
              ),
              trailing: const Icon(Icons.chevron_right, size: 20),
            ),
          );
        },
      ),
    );
  }
}

// -----------------------------------------------------------------------------
// Profile tab
// -----------------------------------------------------------------------------

class _ProfileTab extends StatelessWidget {
  final ChatState state;
  final String serverUrl;
  final VoidCallback onEditServer;
  final VoidCallback onShowRecovery;
  final VoidCallback onAddContact;
  final Future<void> Function(ContactModel) onChatContact;
  final VoidCallback onLogout;

  const _ProfileTab({
    required this.state,
    required this.serverUrl,
    required this.onEditServer,
    required this.onShowRecovery,
    required this.onAddContact,
    required this.onChatContact,
    required this.onLogout,
  });

  @override
  Widget build(BuildContext context) {
    final identity = state.identity;
    if (identity == null) return const SizedBox.shrink();

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
      children: [
        Card(
          margin: EdgeInsets.zero,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const CircleAvatar(
                      backgroundColor: Color(0xFF134E4A),
                      child: Icon(
                        Icons.shield_outlined,
                        color: Colors.tealAccent,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            identity.displayName,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            identity.publicIdentity,
                            style: const TextStyle(fontSize: 11),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    Chip(
                      avatar: const Icon(Icons.business_outlined, size: 14),
                      label: Text(
                        state.organizationName ?? 'Organisasi',
                        style: const TextStyle(fontSize: 11),
                      ),
                      visualDensity: VisualDensity.compact,
                    ),
                    Chip(
                      avatar: const Icon(Icons.verified_user_outlined, size: 14),
                      label: Text(
                        identity.accountStatus.toUpperCase(),
                        style: const TextStyle(fontSize: 11),
                      ),
                      visualDensity: VisualDensity.compact,
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                _InfoRow(
                  label: 'Fingerprint',
                  value: identity.identityFingerprint,
                  mono: true,
                ),
                const SizedBox(height: 8),
                _InfoRow(
                  label: 'Identity ID',
                  value: identity.identityId,
                  mono: true,
                ),
                const SizedBox(height: 8),
                _InfoRow(
                  label: 'Device ID',
                  value: identity.deviceId,
                  mono: true,
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    OutlinedButton.icon(
                      onPressed: () {
                        Clipboard.setData(
                          ClipboardData(text: identity.identityId),
                        );
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Identity ID disalin.')),
                        );
                      },
                      icon: const Icon(Icons.copy, size: 16),
                      label: const Text('Salin Identity ID'),
                    ),
                    OutlinedButton.icon(
                      onPressed: () {
                        Clipboard.setData(
                          ClipboardData(text: identity.identityFingerprint),
                        );
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Fingerprint disalin.')),
                        );
                      },
                      icon: const Icon(Icons.fingerprint, size: 16),
                      label: const Text('Salin Fingerprint'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 20),
        const _SectionLabel('KONTAK'),
        Card(
          margin: EdgeInsets.zero,
          child: Column(
            children: [
              ListTile(
                leading: const Icon(Icons.person_add_alt_1),
                title: const Text('Tambah Kontak'),
                subtitle: const Text('Cari anggota organisasi'),
                trailing: const Icon(Icons.chevron_right),
                onTap: onAddContact,
              ),
              if (state.contacts.isNotEmpty) ...[
                const Divider(height: 1),
                ...state.contacts.map(
                  (contact) => ListTile(
                    leading: const Icon(Icons.person_outline),
                    title: Text(
                      contact.publicIdentity,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    subtitle: Text(
                      'FP ${contact.identityFingerprint}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 10.5),
                    ),
                    trailing: IconButton(
                      tooltip: 'Hapus kontak',
                      icon: const Icon(Icons.person_remove_outlined, size: 20),
                      onPressed: () async {
                        final ok = await state.deleteContact(contact);
                        if (!context.mounted) return;
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              ok
                                  ? 'Kontak dihapus.'
                                  : (state.errorMessage ??
                                        'Gagal menghapus kontak.'),
                            ),
                          ),
                        );
                      },
                    ),
                    onTap: () => onChatContact(contact),
                  ),
                ),
              ],
            ],
          ),
        ),
        const SizedBox(height: 20),
        const _SectionLabel('KEAMANAN'),
        Card(
          margin: EdgeInsets.zero,
          child: Column(
            children: [
              ListTile(
                leading: const Icon(Icons.key_outlined),
                title: const Text('Frasa Pemulihan'),
                subtitle: const Text('12 kata untuk memulihkan identitas'),
                trailing: const Icon(Icons.chevron_right),
                onTap: onShowRecovery,
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.lock_outline),
                title: const Text('Enkripsi Hybrid Pasca-Kuantum (PERISAI-Q)'),
                subtitle: Text(
                  'X25519 + ${identity.pqcKemAlg} (FIPS 203) + AES-256-GCM\n'
                  'Signature: Ed25519 + ${identity.pqcDsaAlg} (FIPS 204)',
                ),
                trailing: const Icon(
                  Icons.verified_user_outlined,
                  color: Colors.tealAccent,
                ),
              ),
              const Divider(height: 1),
              const ListTile(
                leading: Icon(Icons.groups_outlined),
                title: Text('Rotasi Kunci Grup'),
                subtitle: Text(
                  'Epoch kunci naik setiap perubahan keanggotaan grup',
                ),
                trailing: Icon(
                  Icons.verified_user_outlined,
                  color: Colors.tealAccent,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        const _SectionLabel('KONEKSI'),
        Card(
          margin: EdgeInsets.zero,
          child: ListTile(
            leading: const Icon(Icons.dns_outlined),
            title: const Text('Alamat Server Backend'),
            subtitle: Text(
              serverUrl,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            trailing: const Icon(Icons.edit_outlined),
            onTap: onEditServer,
          ),
        ),
        const SizedBox(height: 20),
        const _SectionLabel('SESI'),
        Card(
          margin: EdgeInsets.zero,
          child: ListTile(
            leading: const Icon(Icons.logout, color: Colors.redAccent),
            title: const Text(
              'Keluar dari Perangkat',
              style: TextStyle(color: Colors.redAccent),
            ),
            subtitle: const Text('Hapus kunci privat dari penyimpanan lokal'),
            onTap: onLogout,
          ),
        ),
        const SizedBox(height: 24),
        Center(
          child: Text(
            'Secure Field Communication • v2.0\n'
            'Backend hanya menyimpan ciphertext.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 11,
              height: 1.5,
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
          ),
        ),
      ],
    );
  }
}

// -----------------------------------------------------------------------------
// Small shared widgets
// -----------------------------------------------------------------------------

class _ConnectionPill extends StatelessWidget {
  final bool connected;

  const _ConnectionPill({required this.connected});

  @override
  Widget build(BuildContext context) {
    final color = connected ? Colors.greenAccent : Colors.orangeAccent;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: 0.4)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          const SizedBox(width: 5),
          Text(
            connected ? 'LIVE' : 'OFFLINE',
            style: TextStyle(
              fontSize: 9,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.5,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String body;
  final String actionLabel;
  final VoidCallback onAction;

  const _EmptyState({
    required this.icon,
    required this.title,
    required this.body,
    required this.actionLabel,
    required this.onAction,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              size: 58,
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
            const SizedBox(height: 16),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              body,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 12.5,
                height: 1.5,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: onAction,
              icon: const Icon(Icons.add),
              label: Text(actionLabel),
            ),
          ],
        ),
      ),
    );
  }
}

class _ErrorBanner extends StatelessWidget {
  final String message;
  final VoidCallback onClose;

  const _ErrorBanner({required this.message, required this.onClose});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: Colors.redAccent.withValues(alpha: 0.14),
      padding: const EdgeInsets.fromLTRB(14, 8, 4, 8),
      child: Row(
        children: [
          const Icon(Icons.error_outline, color: Colors.redAccent, size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              message,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 11.5, color: Colors.redAccent),
            ),
          ),
          IconButton(
            onPressed: onClose,
            icon: const Icon(Icons.close, size: 18),
            visualDensity: VisualDensity.compact,
          ),
        ],
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String text;

  const _SectionLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 8),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 10.5,
          fontWeight: FontWeight.bold,
          letterSpacing: 1.2,
          color: Theme.of(context).colorScheme.onSurfaceVariant,
        ),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  final bool mono;

  const _InfoRow({required this.label, required this.value, this.mono = false});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 92,
          child: Text(
            label,
            style: TextStyle(
              fontSize: 11,
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
          ),
        ),
        Expanded(
          child: SelectableText(
            value,
            style: TextStyle(
              fontSize: 11,
              fontFamily: mono ? 'monospace' : null,
              height: 1.4,
            ),
          ),
        ),
      ],
    );
  }
}
