import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/conversation.dart';
import '../models/message.dart';
import '../state/chat_state.dart';
import 'group_management_sheet.dart';

class ChatScreen extends StatefulWidget {
  final ConversationModel conversation;
  final ChatState state;
  final bool isEmbedded;

  const ChatScreen({
    super.key,
    required this.conversation,
    required this.state,
    this.isEmbedded = false,
  });

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _textController = TextEditingController();
  final _scrollController = ScrollController();
  int _lastMessageCount = 0;

  @override
  void initState() {
    super.initState();
    widget.state.addListener(_onStateChanged);
    _lastMessageCount = widget.state.messages.length;
    WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
  }

  @override
  void dispose() {
    widget.state.removeListener(_onStateChanged);
    _textController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _onStateChanged() {
    final count = widget.state.messages.length;
    if (count != _lastMessageCount) {
      _lastMessageCount = count;
      WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
    }
  }

  void _scrollToBottom() {
    if (!mounted || !_scrollController.hasClients) return;
    _scrollController.animateTo(
      _scrollController.position.maxScrollExtent,
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOut,
    );
  }

  Future<void> _send() async {
    final text = _textController.text.trim();
    if (text.isEmpty || widget.state.isSending) return;

    final sent = await widget.state.sendMessage(text);
    if (sent) _textController.clear();
  }

  Future<void> _confirmDelete(ChatMessage message) async {
    if (!message.isMe || message.messageId.startsWith('temp-')) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Hapus pesan?'),
        content: const Text(
          'Pesan ini akan dihapus dari riwayat percakapan untuk semua peserta.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Batal'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.redAccent),
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await widget.state.deleteMessage(message);
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = widget.state;

    return AnimatedBuilder(
      animation: state,
      builder: (context, _) {
        return Scaffold(
          appBar: AppBar(
            automaticallyImplyLeading: !widget.isEmbedded,
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  state.titleFor(widget.conversation),
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                Row(
                  children: [
                    const Icon(
                      Icons.lock_outline,
                      size: 11,
                      color: Colors.tealAccent,
                    ),
                    const SizedBox(width: 4),
                    Flexible(
                      child: Text(
                        widget.conversation.conversationType == 'group'
                            ? 'Grup E2EE • ${state.identity?.pqcKemAlg ?? "ML-KEM-768"} • Epoch ${widget.conversation.keyEpoch}'
                            : 'Hybrid X25519 + ${state.identity?.pqcKemAlg ?? "ML-KEM-768"} + ${state.identity?.pqcDsaAlg ?? "ML-DSA-65"}',
                        style: const TextStyle(
                          fontSize: 10.5,
                          color: Colors.tealAccent,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: state.isWsConnected
                            ? Colors.greenAccent
                            : Colors.orangeAccent,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      state.isWsConnected ? 'Live relay' : 'Store & forward',
                      style: TextStyle(
                        fontSize: 10,
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            actions: [
              if (widget.conversation.conversationType == 'group')
                IconButton(
                  tooltip: 'Kelola Grup',
                  icon: const Icon(Icons.group_outlined),
                  onPressed: () => showGroupManagementSheet(
                    context,
                    state: state,
                    groupId: widget.conversation.conversationId,
                  ),
                ),
            ],
          ),
          body: Column(
            children: [
              if (state.errorMessage != null)
                _ChatErrorBanner(
                  message: state.errorMessage!,
                  onClose: state.clearError,
                ),
              Expanded(
                child: state.messages.isEmpty
                    ? const _EmptyChat()
                    : ListView.builder(
                        controller: _scrollController,
                        padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
                        itemCount: state.messages.length,
                        itemBuilder: (context, index) {
                          final message = state.messages[index];
                          return _MessageBubble(
                            message: message,
                            showSenderName:
                                widget.conversation.conversationType == 'group',
                            onLongPress:
                                message.isMe &&
                                    !message.messageId.startsWith('temp-')
                                ? () => _confirmDelete(message)
                                : null,
                          );
                        },
                      ),
              ),
              _buildComposer(state),
            ],
          ),
        );
      },
    );
  }

  Widget _buildComposer(ChatState state) {
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
      decoration: BoxDecoration(
        color: const Color(0xFF0F172A),
        border: Border(
          top: BorderSide(color: Theme.of(context).colorScheme.outlineVariant),
        ),
      ),
      child: SafeArea(
        top: false,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Expanded(
              child: TextField(
                controller: _textController,
                minLines: 1,
                maxLines: 5,
                textCapitalization: TextCapitalization.sentences,
                decoration: const InputDecoration(
                  hintText: 'Tulis pesan terenkripsi...',
                  contentPadding: EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 10,
                  ),
                ),
                onSubmitted: (_) => _send(),
              ),
            ),
            const SizedBox(width: 8),
            SizedBox(
              width: 46,
              height: 46,
              child: FilledButton(
                onPressed: state.isSending ? null : _send,
                style: FilledButton.styleFrom(
                  padding: EdgeInsets.zero,
                  shape: const CircleBorder(),
                ),
                child: state.isSending
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.send, size: 20),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  final ChatMessage message;
  final bool showSenderName;
  final VoidCallback? onLongPress;

  const _MessageBubble({
    required this.message,
    required this.showSenderName,
    this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isMe = message.isMe;
    final time = DateFormat('HH:mm').format(message.createdAt);

    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onLongPress: onLongPress,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 3),
          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
          constraints: BoxConstraints(
            maxWidth: MediaQuery.of(context).size.width * 0.78,
          ),
          decoration: BoxDecoration(
            color: isMe ? const Color(0xFF0F766E) : const Color(0xFF1E293B),
            borderRadius: BorderRadius.only(
              topLeft: const Radius.circular(14),
              topRight: const Radius.circular(14),
              bottomLeft: Radius.circular(isMe ? 14 : 3),
              bottomRight: Radius.circular(isMe ? 3 : 14),
            ),
            border: isMe
                ? null
                : Border.all(color: theme.colorScheme.outlineVariant),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (!isMe && showSenderName && message.senderName != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 3),
                  child: Text(
                    message.senderName!,
                    style: const TextStyle(
                      fontSize: 10.5,
                      fontWeight: FontWeight.bold,
                      color: Colors.tealAccent,
                    ),
                  ),
                ),
              Text(
                message.decryptedText,
                style: const TextStyle(fontSize: 14.5, height: 1.35),
              ),
              const SizedBox(height: 4),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(
                    Icons.lock_outline,
                    size: 10,
                    color: Colors.white54,
                  ),
                  const SizedBox(width: 3),
                  Text(
                    time,
                    style: const TextStyle(
                      color: Colors.white54,
                      fontSize: 9.5,
                    ),
                  ),
                  if (message.isHybridPqc) ...[
                    const SizedBox(width: 6),
                    Text(
                      '${message.pqcKemAlg ?? "ML-KEM"}${message.pqcSignatureVerified == true ? " • ${message.pqcDsaAlg ?? "ML-DSA"} ✓" : ""}',
                      style: const TextStyle(
                        color: Colors.tealAccent,
                        fontSize: 9,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                  if (isMe) ...[
                    const SizedBox(width: 4),
                    _StatusIcon(status: message.deliveryStatus),
                  ],
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatusIcon extends StatelessWidget {
  final String status;

  const _StatusIcon({required this.status});

  @override
  Widget build(BuildContext context) {
    switch (status) {
      case 'queued_offline':
        return const Icon(
          Icons.schedule_send,
          size: 12,
          color: Colors.orangeAccent,
        );
      case 'pending':
        return const Icon(Icons.schedule, size: 11, color: Colors.white54);
      case 'read':
        return const Icon(Icons.done_all, size: 12, color: Colors.cyanAccent);
      case 'delivered':
        return const Icon(Icons.done_all, size: 12, color: Colors.white70);
      default:
        return const Icon(Icons.done, size: 12, color: Colors.white70);
    }
  }
}

class _EmptyChat extends StatelessWidget {
  const _EmptyChat();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.shield_outlined,
              size: 52,
              color: Theme.of(context).colorScheme.primary,
            ),
            const SizedBox(height: 12),
            const Text(
              'Percakapan terlindungi',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            Text(
              'Pesan dienkripsi di perangkat ini. Server hanya menerima ciphertext.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 12,
                height: 1.5,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ChatErrorBanner extends StatelessWidget {
  final String message;
  final VoidCallback onClose;

  const _ChatErrorBanner({required this.message, required this.onClose});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: Colors.redAccent.withValues(alpha: 0.14),
      padding: const EdgeInsets.fromLTRB(14, 8, 4, 8),
      child: Row(
        children: [
          const Icon(Icons.error_outline, color: Colors.redAccent, size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              message,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 11.5, color: Colors.redAccent),
            ),
          ),
          IconButton(
            onPressed: onClose,
            icon: const Icon(Icons.close, size: 18),
            visualDensity: VisualDensity.compact,
          ),
        ],
      ),
    );
  }
}
