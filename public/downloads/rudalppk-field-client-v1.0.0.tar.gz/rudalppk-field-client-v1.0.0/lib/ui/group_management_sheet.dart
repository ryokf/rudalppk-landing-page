import 'package:flutter/material.dart';

import '../models/conversation_detail.dart';
import '../state/chat_state.dart';
import 'directory_picker.dart';

Future<void> showGroupManagementSheet(
  BuildContext context, {
  required ChatState state,
  required String groupId,
}) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (_) => _GroupManagementSheet(state: state, groupId: groupId),
  );
}

class _GroupManagementSheet extends StatefulWidget {
  final ChatState state;
  final String groupId;

  const _GroupManagementSheet({required this.state, required this.groupId});

  @override
  State<_GroupManagementSheet> createState() => _GroupManagementSheetState();
}

class _GroupManagementSheetState extends State<_GroupManagementSheet> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      widget.state.refreshGroupDetail(widget.groupId);
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = widget.state;
    final maxHeight = MediaQuery.of(context).size.height * 0.82;

    return AnimatedBuilder(
      animation: state,
      builder: (context, _) {
        final detail = state.detailFor(widget.groupId);
        final myId = state.identity?.identityId;
        final isAdmin =
            detail != null &&
            detail.groupAdminIdentityId != null &&
            detail.groupAdminIdentityId == myId;

        return SizedBox(
          height: maxHeight,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  _groupTitle(state),
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Text(
                  'Epoch kunci: ${detail?.keyEpoch ?? '-'} • '
                  '${detail?.members.length ?? 0} anggota',
                  style: TextStyle(
                    fontSize: 12,
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: detail == null
                      ? const Center(child: CircularProgressIndicator())
                      : detail.members.isEmpty
                      ? const Center(child: Text('Tidak ada anggota.'))
                      : ListView.builder(
                          itemCount: detail.members.length,
                          itemBuilder: (context, index) {
                            final member = detail.members[index];
                            final isSelf = member.identityId == myId;
                            return ListTile(
                              contentPadding: EdgeInsets.zero,
                              leading: CircleAvatar(
                                child: Text(_initials(member)),
                              ),
                              title: Text(
                                member.displayName ?? member.publicIdentity,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              subtitle: Text(
                                '${member.memberRole.toUpperCase()} • '
                                '${member.devices.length} perangkat',
                                style: const TextStyle(fontSize: 11),
                              ),
                              trailing: isAdmin && !isSelf
                                  ? IconButton(
                                      tooltip: 'Keluarkan anggota',
                                      icon: const Icon(
                                        Icons.person_remove_outlined,
                                        color: Colors.redAccent,
                                      ),
                                      onPressed: () => _confirmRemove(member),
                                    )
                                  : null,
                            );
                          },
                        ),
                ),
                const SizedBox(height: 8),
                if (isAdmin) ...[
                  FilledButton.icon(
                    onPressed: state.isBusy ? null : _addMember,
                    icon: const Icon(Icons.person_add_alt_1),
                    label: const Text('Tambah Anggota'),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: state.isBusy ? null : _renameGroup,
                    icon: const Icon(Icons.edit_outlined, size: 18),
                    label: const Text('Ubah Nama Grup'),
                  ),
                  const SizedBox(height: 8),
                ],
                OutlinedButton.icon(
                  onPressed: state.isBusy ? null : _leaveGroup,
                  icon: const Icon(
                    Icons.logout,
                    size: 18,
                    color: Colors.redAccent,
                  ),
                  label: const Text(
                    'Keluar dari Grup',
                    style: TextStyle(color: Colors.redAccent),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  String _groupTitle(ChatState state) {
    for (final group in state.groups) {
      if (group.conversationId == widget.groupId) return state.titleFor(group);
    }
    final active = state.activeConversation;
    if (active != null && active.conversationId == widget.groupId) {
      return state.titleFor(active);
    }
    return 'Kelola Grup';
  }

  String _initials(ConversationMemberInfo member) {
    final label = member.displayName?.trim().isNotEmpty == true
        ? member.displayName!.trim()
        : member.publicIdentity;
    return label.isEmpty ? '?' : label.substring(0, 1).toUpperCase();
  }

  Future<void> _addMember() async {
    final existing =
        widget.state
            .detailFor(widget.groupId)
            ?.members
            .map((member) => member.identityId)
            .toSet() ??
        <String>{};
    final selected = await showDirectoryPicker(
      context,
      state: widget.state,
      multiSelect: false,
      title: 'Tambah Anggota Grup',
      excludeIds: existing,
    );
    if (selected == null || selected.isEmpty) return;
    final ok = await widget.state.addGroupMember(
      widget.groupId,
      selected.first,
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          ok
              ? 'Anggota ditambahkan dan epoch kunci dinaikkan.'
              : (widget.state.errorMessage ?? 'Gagal menambahkan anggota.'),
        ),
      ),
    );
  }

  Future<void> _confirmRemove(ConversationMemberInfo member) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Keluarkan anggota?'),
        content: Text(
          '${member.displayName ?? member.publicIdentity} tidak akan menerima '
          'pesan grup baru setelah dikeluarkan.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Batal'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.redAccent),
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Keluarkan'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    final ok = await widget.state.removeGroupMember(
      widget.groupId,
      member.identityId,
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          ok
              ? 'Anggota dikeluarkan dan epoch kunci dinaikkan.'
              : (widget.state.errorMessage ?? 'Gagal mengeluarkan anggota.'),
        ),
      ),
    );
  }

  Future<void> _renameGroup() async {
    final controller = TextEditingController(
      text: widget.state.detailFor(widget.groupId)?.title ?? '',
    );
    final value = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Ubah Nama Grup'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'Nama grup'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(controller.text),
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (value == null || value.trim().isEmpty) return;
    await widget.state.renameGroup(widget.groupId, value);
  }

  Future<void> _leaveGroup() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Keluar dari grup?'),
        content: const Text(
          'Anda tidak akan menerima pesan grup baru setelah keluar.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Batal'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.redAccent),
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Keluar'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    final ok = await widget.state.leaveGroup(widget.groupId);
    if (!mounted) return;
    Navigator.of(context).pop();
    if (!ok) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(widget.state.errorMessage ?? 'Gagal keluar dari grup.'),
        ),
      );
    }
  }
}
