import 'dart:async';

import 'package:flutter/material.dart';

import '../models/directory_member.dart';
import '../state/chat_state.dart';

/// Opens the organization directory picker.
///
/// Returns the selected identity IDs, or null when the sheet is dismissed.
Future<List<String>?> showDirectoryPicker(
  BuildContext context, {
  required ChatState state,
  required bool multiSelect,
  String title = 'Pilih Anggota',
  Set<String> excludeIds = const {},
}) {
  return showModalBottomSheet<List<String>>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (_) => _DirectoryPicker(
      state: state,
      multiSelect: multiSelect,
      title: title,
      excludeIds: excludeIds,
    ),
  );
}

class _DirectoryPicker extends StatefulWidget {
  final ChatState state;
  final bool multiSelect;
  final String title;
  final Set<String> excludeIds;

  const _DirectoryPicker({
    required this.state,
    required this.multiSelect,
    required this.title,
    required this.excludeIds,
  });

  @override
  State<_DirectoryPicker> createState() => _DirectoryPickerState();
}

class _DirectoryPickerState extends State<_DirectoryPicker> {
  final _searchController = TextEditingController();
  final _selected = <String>{};
  Timer? _debounce;
  bool _loading = true;
  List<DirectoryMember> _members = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _load({String? query}) async {
    setState(() => _loading = true);
    try {
      final members = (await widget.state.searchDirectory(query))
          .where((member) => !widget.excludeIds.contains(member.identityId))
          .toList();
      if (!mounted) return;
      setState(() {
        _members = members;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _loading = false);
    }
  }

  void _onSearchChanged(String value) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 300), () {
      _load(query: value);
    });
  }

  @override
  Widget build(BuildContext context) {
    final maxHeight = MediaQuery.of(context).size.height * 0.78;
    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: SizedBox(
        height: maxHeight,
        child: Column(
          children: [
            Text(
              widget.title,
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _searchController,
              onChanged: _onSearchChanged,
              autocorrect: false,
              decoration: const InputDecoration(
                hintText: 'Cari nama atau identitas...',
                prefixIcon: Icon(Icons.search),
                isDense: true,
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: _loading
                  ? const Center(child: CircularProgressIndicator())
                  : _members.isEmpty
                  ? const _EmptyDirectory()
                  : ListView.separated(
                      itemCount: _members.length,
                      separatorBuilder: (_, _) => const SizedBox(height: 4),
                      itemBuilder: (context, index) {
                        final member = _members[index];
                        final checked = _selected.contains(member.identityId);
                        return ListTile(
                          contentPadding: EdgeInsets.zero,
                          leading: widget.multiSelect
                              ? Icon(
                                  checked
                                      ? Icons.check_circle
                                      : Icons.circle_outlined,
                                  color: checked
                                      ? Theme.of(context).colorScheme.primary
                                      : null,
                                )
                              : const Icon(Icons.person_outline),
                          title: Text(
                            member.label,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w600),
                          ),
                          subtitle: Text(
                            '${member.publicIdentity} • ${member.activeDeviceCount} perangkat aktif',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 11),
                          ),
                          onTap: () {
                            if (widget.multiSelect) {
                              setState(() {
                                if (checked) {
                                  _selected.remove(member.identityId);
                                } else {
                                  _selected.add(member.identityId);
                                }
                              });
                            } else {
                              Navigator.of(context).pop([member.identityId]);
                            }
                          },
                        );
                      },
                    ),
            ),
            if (widget.multiSelect) ...[
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: _selected.isEmpty
                    ? null
                    : () => Navigator.of(context).pop(_selected.toList()),
                icon: const Icon(Icons.check),
                label: Text('Pilih ${_selected.length} Anggota'),
                style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _EmptyDirectory extends StatelessWidget {
  const _EmptyDirectory();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.person_search_outlined,
              size: 44,
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
            const SizedBox(height: 12),
            const Text(
              'Tidak ada anggota organisasi yang cocok.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }
}
