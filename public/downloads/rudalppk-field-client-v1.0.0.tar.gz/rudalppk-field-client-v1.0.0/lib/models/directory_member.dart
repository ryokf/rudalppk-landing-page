class DirectoryMember {
  final String identityId;
  final String? displayName;
  final String publicIdentity;
  final String identityFingerprint;
  final String status;
  final int deviceCount;
  final int activeDeviceCount;

  DirectoryMember({
    required this.identityId,
    required this.publicIdentity,
    required this.identityFingerprint,
    required this.status,
    required this.deviceCount,
    required this.activeDeviceCount,
    this.displayName,
  });

  factory DirectoryMember.fromJson(Map<String, dynamic> json) =>
      DirectoryMember(
        identityId: json['identity_id'] ?? '',
        displayName: json['display_name']?.toString(),
        publicIdentity: json['public_identity'] ?? '',
        identityFingerprint: json['identity_fingerprint'] ?? '',
        status: json['status'] ?? 'active',
        deviceCount: (json['device_count'] as num?)?.toInt() ?? 0,
        activeDeviceCount: (json['active_device_count'] as num?)?.toInt() ?? 0,
      );

  String get label {
    final name = displayName?.trim();
    if (name != null && name.isNotEmpty) return name;
    return publicIdentity;
  }
}
