class ChatMessage {
  final String messageId;
  final String conversationId;
  final String senderDeviceId;
  final String clientMessageId;
  final String messageType;
  final String ciphertext;
  final String decryptedText;
  final DateTime createdAt;
  final bool isMe;
  final String? senderName;
  final String deliveryStatus;
  final int keyEpoch;
  final bool isHybridPqc;
  final String? pqcKemAlg;
  final String? pqcDsaAlg;
  final bool? pqcSignatureVerified;

  ChatMessage({
    required this.messageId,
    required this.conversationId,
    required this.senderDeviceId,
    required this.clientMessageId,
    required this.messageType,
    required this.ciphertext,
    required this.decryptedText,
    required this.createdAt,
    required this.isMe,
    this.senderName,
    this.deliveryStatus = 'sent',
    this.keyEpoch = 1,
    this.isHybridPqc = false,
    this.pqcKemAlg,
    this.pqcDsaAlg,
    this.pqcSignatureVerified,
  });

  factory ChatMessage.fromJson(
    Map<String, dynamic> json, {
    required String myDeviceId,
    required String decrypted,
    String? senderName,
    String deliveryStatus = 'sent',
    bool isHybridPqc = false,
    String? pqcKemAlg,
    String? pqcDsaAlg,
    bool? pqcSignatureVerified,
  }) => ChatMessage(
    messageId: json['message_id'] ?? '',
    conversationId: json['conversation_id'] ?? '',
    senderDeviceId: json['sender_device_id'] ?? '',
    clientMessageId: json['client_message_id'] ?? '',
    messageType: json['message_type'] ?? 'text',
    ciphertext: json['ciphertext'] ?? '',
    decryptedText: decrypted,
    createdAt: DateTime.tryParse(json['created_at'] ?? '') ?? DateTime.now(),
    isMe: (json['sender_device_id'] ?? '') == myDeviceId,
    senderName: senderName,
    deliveryStatus: deliveryStatus,
    keyEpoch: (json['key_epoch'] as num?)?.toInt() ?? 1,
    isHybridPqc: isHybridPqc,
    pqcKemAlg: pqcKemAlg,
    pqcDsaAlg: pqcDsaAlg,
    pqcSignatureVerified: pqcSignatureVerified,
  );
}
