class MemberDevice {
  final String deviceId;
  final String publicDeviceKey;
  final String deviceName;
  final String pqcKemAlg;
  final String pqcKemPublicKey;
  final String pqcDsaAlg;
  final String pqcDsaPublicKey;

  MemberDevice({
    required this.deviceId,
    required this.publicDeviceKey,
    required this.deviceName,
    this.pqcKemAlg = 'ML-KEM-768',
    this.pqcKemPublicKey = '',
    this.pqcDsaAlg = 'ML-DSA-65',
    this.pqcDsaPublicKey = '',
  });

  factory MemberDevice.fromJson(Map<String, dynamic> json) => MemberDevice(
    deviceId: json['device_id'] ?? '',
    publicDeviceKey: json['public_device_key'] ?? '',
    deviceName: json['device_name'] ?? '',
    pqcKemAlg: json['pqc_kem_alg'] ?? 'ML-KEM-768',
    pqcKemPublicKey: json['pqc_kem_public_key'] ?? '',
    pqcDsaAlg: json['pqc_dsa_alg'] ?? 'ML-DSA-65',
    pqcDsaPublicKey: json['pqc_dsa_public_key'] ?? '',
  );
}

class ConversationMemberInfo {
  final String identityId;
  final String publicIdentity;
  final String? displayName;
  final String memberRole;
  final List<MemberDevice> devices;

  ConversationMemberInfo({
    required this.identityId,
    required this.publicIdentity,
    required this.memberRole,
    required this.devices,
    this.displayName,
  });

  factory ConversationMemberInfo.fromJson(Map<String, dynamic> json) =>
      ConversationMemberInfo(
        identityId: json['identity_id'] ?? '',
        publicIdentity: json['public_identity'] ?? '',
        displayName: json['display_name']?.toString(),
        memberRole: json['member_role'] ?? 'member',
        devices: (json['devices'] as List<dynamic>? ?? [])
            .map(
              (d) => MemberDevice.fromJson(Map<String, dynamic>.from(d as Map)),
            )
            .toList(),
      );
}

class ConversationDetail {
  final String conversationId;
  final String conversationType;
  final String? title;
  final int keyEpoch;
  final List<ConversationMemberInfo> members;
  final Map<String, dynamic>? peer;

  ConversationDetail({
    required this.conversationId,
    required this.conversationType,
    required this.title,
    required this.members,
    this.keyEpoch = 1,
    this.peer,
  });

  factory ConversationDetail.fromJson(Map<String, dynamic> json) =>
      ConversationDetail(
        conversationId: json['conversation_id'] ?? '',
        conversationType: json['conversation_type'] ?? 'direct',
        title: json['title'],
        keyEpoch: (json['key_epoch'] as num?)?.toInt() ?? 1,
        members: (json['members'] as List<dynamic>? ?? [])
            .map(
              (m) => ConversationMemberInfo.fromJson(
                Map<String, dynamic>.from(m as Map),
              ),
            )
            .toList(),
        peer: json['peer'] is Map
            ? Map<String, dynamic>.from(json['peer'] as Map)
            : null,
      );

  bool get isDirect => conversationType == 'direct';
  bool get isGroup => conversationType == 'group';

  String? directPeerIdentityId(String myIdentityId) {
    for (final member in members) {
      if (member.identityId != myIdentityId) return member.identityId;
    }
    return null;
  }

  String? get groupAdminIdentityId {
    for (final member in members) {
      if (member.memberRole == 'admin') return member.identityId;
    }
    return null;
  }

  /// device UUID -> X25519 public key.
  Map<String, String> get devicePublicKeys {
    final result = <String, String>{};
    for (final member in members) {
      for (final device in member.devices) {
        if (device.deviceId.isNotEmpty && device.publicDeviceKey.isNotEmpty) {
          result[device.deviceId] = device.publicDeviceKey;
        }
      }
    }
    return result;
  }

  /// device UUID -> ML-KEM public key.
  Map<String, String> get devicePqcKemPublicKeys {
    final result = <String, String>{};
    for (final member in members) {
      for (final device in member.devices) {
        if (device.deviceId.isNotEmpty && device.pqcKemPublicKey.isNotEmpty) {
          result[device.deviceId] = device.pqcKemPublicKey;
        }
      }
    }
    return result;
  }

  /// device UUID -> ML-KEM algorithm (512, 768, 1024).
  Map<String, String> get devicePqcKemAlgs {
    final result = <String, String>{};
    for (final member in members) {
      for (final device in member.devices) {
        if (device.deviceId.isNotEmpty) {
          result[device.deviceId] = device.pqcKemAlg;
        }
      }
    }
    return result;
  }

  /// device UUID -> ML-DSA public key.
  Map<String, String> get devicePqcDsaPublicKeys {
    final result = <String, String>{};
    for (final member in members) {
      for (final device in member.devices) {
        if (device.deviceId.isNotEmpty && device.pqcDsaPublicKey.isNotEmpty) {
          result[device.deviceId] = device.pqcDsaPublicKey;
        }
      }
    }
    return result;
  }

  /// device UUID -> ML-DSA algorithm (44, 65, 87).
  Map<String, String> get devicePqcDsaAlgs {
    final result = <String, String>{};
    for (final member in members) {
      for (final device in member.devices) {
        if (device.deviceId.isNotEmpty) {
          result[device.deviceId] = device.pqcDsaAlg;
        }
      }
    }
    return result;
  }

  /// device UUID -> owning identity UUID.
  Map<String, String> get deviceOwnerIdentityIds {
    final result = <String, String>{};
    for (final member in members) {
      for (final device in member.devices) {
        result[device.deviceId] = member.identityId;
      }
    }
    return result;
  }

  /// identity UUID -> display name (falls back to public identity).
  Map<String, String> get identityNames {
    final result = <String, String>{};
    for (final member in members) {
      final label = (member.displayName?.trim().isNotEmpty ?? false)
          ? member.displayName!.trim()
          : member.publicIdentity;
      result[member.identityId] = label;
    }
    return result;
  }
}
