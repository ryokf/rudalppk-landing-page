/// Data models for PERISAI-Vault, Offline Outbox, PERISAI-Sign, and PERISAI-Lab.
class VaultItem {
  final String vaultItemId;
  final String title;
  final String category; // 'document_pdf', 'map_coords', 'intel_photo', 'voice_note'
  final String kemAlgorithm; // 'ML-KEM-512', 'ML-KEM-768', 'ML-KEM-1024'
  final String dsaAlgorithm; // 'ML-DSA-44', 'ML-DSA-65', 'ML-DSA-87'
  final String kemCiphertextB64;
  final String aesCiphertextB64;
  final String signatureB64;
  final String contentSha256;
  final int plaintextBytes;
  final DateTime createdAt;

  VaultItem({
    required this.vaultItemId,
    required this.title,
    required this.category,
    required this.kemAlgorithm,
    required this.dsaAlgorithm,
    required this.kemCiphertextB64,
    required this.aesCiphertextB64,
    required this.signatureB64,
    required this.contentSha256,
    required this.plaintextBytes,
    required this.createdAt,
  });

  String get categoryLabel {
    switch (category) {
      case 'document_pdf':
        return 'Dokumen Taktis / PDF';
      case 'map_coords':
        return 'Peta & Koordinat GPS';
      case 'intel_photo':
        return 'Foto Intelijen Lapangan';
      case 'voice_note':
        return 'Transkrip / Rekaman Suara';
      default:
        return 'Arsip Terenkripsi';
    }
  }

  Map<String, dynamic> toJson() => {
    'vaultItemId': vaultItemId,
    'title': title,
    'category': category,
    'kemAlgorithm': kemAlgorithm,
    'dsaAlgorithm': dsaAlgorithm,
    'kemCiphertextB64': kemCiphertextB64,
    'aesCiphertextB64': aesCiphertextB64,
    'signatureB64': signatureB64,
    'contentSha256': contentSha256,
    'plaintextBytes': plaintextBytes,
    'createdAt': createdAt.toIso8601String(),
  };

  factory VaultItem.fromJson(Map<String, dynamic> json) => VaultItem(
    vaultItemId: json['vaultItemId'] ?? '',
    title: json['title'] ?? '',
    category: json['category'] ?? 'document_pdf',
    kemAlgorithm: json['kemAlgorithm'] ?? 'ML-KEM-768',
    dsaAlgorithm: json['dsaAlgorithm'] ?? 'ML-DSA-65',
    kemCiphertextB64: json['kemCiphertextB64'] ?? '',
    aesCiphertextB64: json['aesCiphertextB64'] ?? '',
    signatureB64: json['signatureB64'] ?? '',
    contentSha256: json['contentSha256'] ?? '',
    plaintextBytes: (json['plaintextBytes'] as num?)?.toInt() ?? 0,
    createdAt: DateTime.tryParse(json['createdAt'] ?? '') ?? DateTime.now(),
  );
}

class OutboxQueueItem {
  final String clientMessageId;
  final String conversationId;
  final String conversationTitle;
  final String ciphertext;
  final String plaintextPreview;
  final int keyEpoch;
  final String pqcKemAlg;
  final String pqcDsaAlg;
  final String status; // 'QUEUED', 'SYNCING', 'RELAY_ACCEPTED', 'FAILED'
  final DateTime queuedAt;
  final DateTime? syncedAt;

  OutboxQueueItem({
    required this.clientMessageId,
    required this.conversationId,
    required this.conversationTitle,
    required this.ciphertext,
    required this.plaintextPreview,
    required this.keyEpoch,
    required this.pqcKemAlg,
    required this.pqcDsaAlg,
    this.status = 'QUEUED',
    required this.queuedAt,
    this.syncedAt,
  });

  OutboxQueueItem copyWith({
    String? status,
    DateTime? syncedAt,
  }) => OutboxQueueItem(
    clientMessageId: clientMessageId,
    conversationId: conversationId,
    conversationTitle: conversationTitle,
    ciphertext: ciphertext,
    plaintextPreview: plaintextPreview,
    keyEpoch: keyEpoch,
    pqcKemAlg: pqcKemAlg,
    pqcDsaAlg: pqcDsaAlg,
    status: status ?? this.status,
    queuedAt: queuedAt,
    syncedAt: syncedAt ?? this.syncedAt,
  );

  Map<String, dynamic> toJson() => {
    'clientMessageId': clientMessageId,
    'conversationId': conversationId,
    'conversationTitle': conversationTitle,
    'ciphertext': ciphertext,
    'plaintextPreview': plaintextPreview,
    'keyEpoch': keyEpoch,
    'pqcKemAlg': pqcKemAlg,
    'pqcDsaAlg': pqcDsaAlg,
    'status': status,
    'queuedAt': queuedAt.toIso8601String(),
    'syncedAt': syncedAt?.toIso8601String(),
  };

  factory OutboxQueueItem.fromJson(Map<String, dynamic> json) =>
      OutboxQueueItem(
        clientMessageId: json['clientMessageId'] ?? '',
        conversationId: json['conversationId'] ?? '',
        conversationTitle: json['conversationTitle'] ?? 'Percakapan',
        ciphertext: json['ciphertext'] ?? '',
        plaintextPreview: json['plaintextPreview'] ?? '',
        keyEpoch: (json['keyEpoch'] as num?)?.toInt() ?? 1,
        pqcKemAlg: json['pqcKemAlg'] ?? 'ML-KEM-768',
        pqcDsaAlg: json['pqcDsaAlg'] ?? 'ML-DSA-65',
        status: json['status'] ?? 'QUEUED',
        queuedAt: DateTime.tryParse(json['queuedAt'] ?? '') ?? DateTime.now(),
        syncedAt: json['syncedAt'] != null
            ? DateTime.tryParse(json['syncedAt'])
            : null,
      );
}

class SignedArtifactModel {
  final String artifactId;
  final String artifactType;
  final String title;
  final String contentText;
  final String contentHashSha256;
  final String algorithm;
  final String nistStandard;
  final int securityCategory;
  final String signatureB64;
  final String signerType;
  final String signerId;
  final String signerDisplayName;
  final String signerPublicKeyB64;
  final String status;
  final DateTime createdAt;
  final Map<String, dynamic> meta;

  SignedArtifactModel({
    required this.artifactId,
    required this.artifactType,
    required this.title,
    required this.contentText,
    required this.contentHashSha256,
    required this.algorithm,
    required this.nistStandard,
    required this.securityCategory,
    required this.signatureB64,
    required this.signerType,
    required this.signerId,
    required this.signerDisplayName,
    required this.signerPublicKeyB64,
    required this.status,
    required this.createdAt,
    this.meta = const {},
  });

  bool get isEncryptedWithKem => meta['encrypted_with_kem'] == true;
  String get kemAlgorithm => (meta['kem_algorithm'] ?? 'ML-KEM-768').toString();
  String get fileName => (meta['file_name'] ?? '').toString();

  String get typeLabel {
    if (isEncryptedWithKem) return 'File Terenkripsi PQC ($kemAlgorithm)';
    switch (artifactType) {
      case 'command_instruction':
        return 'Instruksi Komando';
      case 'firmware_package':
        return 'Paket Firmware OT/IoT';
      case 'field_report':
        return 'Laporan Intelijen Lapangan';
      default:
        return artifactType;
    }
  }

  factory SignedArtifactModel.fromJson(Map<String, dynamic> json) =>
      SignedArtifactModel(
        artifactId: json['artifact_id'] ?? '',
        artifactType: json['artifact_type'] ?? 'command_instruction',
        title: json['title'] ?? '',
        contentText: json['content_text'] ?? '',
        contentHashSha256: json['content_hash_sha256'] ?? '',
        algorithm: json['algorithm'] ?? 'ML-DSA-65',
        nistStandard: json['nist_standard'] ?? 'NIST FIPS 204',
        securityCategory: (json['security_category'] as num?)?.toInt() ?? 3,
        signatureB64: json['signature_b64'] ?? '',
        signerType: json['signer_type'] ?? 'admin',
        signerId: json['signer_id'] ?? '',
        signerDisplayName: json['signer_display_name'] ?? '',
        signerPublicKeyB64: json['signer_public_key_b64'] ?? '',
        status: json['status'] ?? 'active',
        createdAt:
            DateTime.tryParse(json['created_at'] ?? '') ?? DateTime.now(),
        meta: json['meta'] is Map
            ? Map<String, dynamic>.from(json['meta'] as Map)
            : const {},
      );
}
