class ConversationModel {
  final String conversationId;
  final String conversationType; // 'direct' or 'group'
  final String? title;
  final DateTime createdAt;
  final List<String> memberIdentityIds;
  final int keyEpoch;
  final int memberCount;
  final String? organizationId;
  final Map<String, dynamic>? peer;

  ConversationModel({
    required this.conversationId,
    required this.conversationType,
    this.title,
    required this.createdAt,
    required this.memberIdentityIds,
    this.keyEpoch = 1,
    this.memberCount = 0,
    this.organizationId,
    this.peer,
  });

  factory ConversationModel.fromJson(Map<String, dynamic> json) {
    final rawMembers = json['members'] as List<dynamic>? ?? [];
    final memberIds = <String>[];
    for (final member in rawMembers) {
      if (member is Map) {
        final id = member['identity_id']?.toString();
        if (id != null && id.isNotEmpty) memberIds.add(id);
      } else {
        memberIds.add(member.toString());
      }
    }

    return ConversationModel(
      conversationId: json['conversation_id'] ?? '',
      conversationType: json['conversation_type'] ?? 'direct',
      title: json['title'],
      createdAt:
          DateTime.tryParse(json['created_at'] ?? '') ?? DateTime.now(),
      memberIdentityIds: memberIds,
      keyEpoch: (json['key_epoch'] as num?)?.toInt() ?? 1,
      memberCount:
          (json['member_count'] as num?)?.toInt() ?? memberIds.length,
      organizationId: json['organization_id']?.toString(),
      peer: json['peer'] is Map
          ? Map<String, dynamic>.from(json['peer'] as Map)
          : null,
    );
  }

  String? get peerIdentityId => peer?['identity_id']?.toString();

  String? get peerDisplayName {
    final name = peer?['display_name']?.toString();
    if (name != null && name.isNotEmpty) return name;
    return peer?['public_identity']?.toString();
  }
}
