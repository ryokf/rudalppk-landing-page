class ContactModel {
  final String contactId;
  final String contactIdentityId;
  final String publicIdentity;
  final String identityFingerprint;
  final String verificationStatus;
  final DateTime addedAt;

  ContactModel({
    required this.contactId,
    required this.contactIdentityId,
    required this.publicIdentity,
    required this.identityFingerprint,
    required this.verificationStatus,
    required this.addedAt,
  });

  factory ContactModel.fromJson(Map<String, dynamic> json) => ContactModel(
    contactId: json['contact_id'] ?? '',
    contactIdentityId: json['contact_identity_id'] ?? '',
    publicIdentity: json['public_identity'] ?? '',
    identityFingerprint: json['identity_fingerprint'] ?? '',
    verificationStatus: json['verification_status'] ?? 'unverified',
    addedAt: DateTime.tryParse(json['added_at'] ?? '') ?? DateTime.now(),
  );
}
