class LocalIdentity {
  final String identityId;
  final String deviceId;
  final String publicIdentity;
  final String identityFingerprint;
  final String publicDeviceKey;
  final String authPublicKey;

  /// X25519 private key seed (Base64). Never sent to the backend.
  final String devicePrivateKey;

  /// Ed25519 private key seed (Base64). Never sent to the backend.
  final String authPrivateKey;

  /// NIST FIPS 203 ML-KEM (512, 768, 1024) key material.
  final String pqcKemAlg;
  final String pqcKemPublicKey;
  final String pqcKemPrivateKey;

  /// NIST FIPS 204 ML-DSA (44, 65, 87) key material.
  final String pqcDsaAlg;
  final String pqcDsaPublicKey;
  final String pqcDsaPrivateKey;

  final String recoveryPhrase;
  final String displayName;

  /// False until the user confirms they stored the recovery phrase.
  final bool recoveryConfirmed;

  final String? organizationId;
  final String? organizationName;
  final String accountStatus;

  LocalIdentity({
    required this.identityId,
    required this.deviceId,
    required this.publicIdentity,
    required this.identityFingerprint,
    required this.publicDeviceKey,
    required this.authPublicKey,
    required this.authPrivateKey,
    required this.recoveryPhrase,
    this.devicePrivateKey = '',
    this.pqcKemAlg = 'ML-KEM-768',
    this.pqcKemPublicKey = '',
    this.pqcKemPrivateKey = '',
    this.pqcDsaAlg = 'ML-DSA-65',
    this.pqcDsaPublicKey = '',
    this.pqcDsaPrivateKey = '',
    this.displayName = 'Field Agent',
    this.recoveryConfirmed = true,
    this.organizationId,
    this.organizationName,
    this.accountStatus = 'active',
  });

  bool get hasPqcKeys =>
      pqcKemPublicKey.isNotEmpty &&
      pqcKemPrivateKey.isNotEmpty &&
      pqcDsaPublicKey.isNotEmpty &&
      pqcDsaPrivateKey.isNotEmpty;

  LocalIdentity copyWith({
    String? identityId,
    String? deviceId,
    String? publicIdentity,
    String? identityFingerprint,
    String? publicDeviceKey,
    String? authPublicKey,
    String? devicePrivateKey,
    String? authPrivateKey,
    String? pqcKemAlg,
    String? pqcKemPublicKey,
    String? pqcKemPrivateKey,
    String? pqcDsaAlg,
    String? pqcDsaPublicKey,
    String? pqcDsaPrivateKey,
    String? recoveryPhrase,
    String? displayName,
    bool? recoveryConfirmed,
    String? organizationId,
    String? organizationName,
    String? accountStatus,
  }) {
    return LocalIdentity(
      identityId: identityId ?? this.identityId,
      deviceId: deviceId ?? this.deviceId,
      publicIdentity: publicIdentity ?? this.publicIdentity,
      identityFingerprint: identityFingerprint ?? this.identityFingerprint,
      publicDeviceKey: publicDeviceKey ?? this.publicDeviceKey,
      authPublicKey: authPublicKey ?? this.authPublicKey,
      devicePrivateKey: devicePrivateKey ?? this.devicePrivateKey,
      authPrivateKey: authPrivateKey ?? this.authPrivateKey,
      pqcKemAlg: pqcKemAlg ?? this.pqcKemAlg,
      pqcKemPublicKey: pqcKemPublicKey ?? this.pqcKemPublicKey,
      pqcKemPrivateKey: pqcKemPrivateKey ?? this.pqcKemPrivateKey,
      pqcDsaAlg: pqcDsaAlg ?? this.pqcDsaAlg,
      pqcDsaPublicKey: pqcDsaPublicKey ?? this.pqcDsaPublicKey,
      pqcDsaPrivateKey: pqcDsaPrivateKey ?? this.pqcDsaPrivateKey,
      recoveryPhrase: recoveryPhrase ?? this.recoveryPhrase,
      displayName: displayName ?? this.displayName,
      recoveryConfirmed: recoveryConfirmed ?? this.recoveryConfirmed,
      organizationId: organizationId ?? this.organizationId,
      organizationName: organizationName ?? this.organizationName,
      accountStatus: accountStatus ?? this.accountStatus,
    );
  }

  Map<String, dynamic> toJson() => {
    'identityId': identityId,
    'deviceId': deviceId,
    'publicIdentity': publicIdentity,
    'identityFingerprint': identityFingerprint,
    'publicDeviceKey': publicDeviceKey,
    'authPublicKey': authPublicKey,
    'devicePrivateKey': devicePrivateKey,
    'authPrivateKey': authPrivateKey,
    'pqcKemAlg': pqcKemAlg,
    'pqcKemPublicKey': pqcKemPublicKey,
    'pqcKemPrivateKey': pqcKemPrivateKey,
    'pqcDsaAlg': pqcDsaAlg,
    'pqcDsaPublicKey': pqcDsaPublicKey,
    'pqcDsaPrivateKey': pqcDsaPrivateKey,
    'recoveryPhrase': recoveryPhrase,
    'displayName': displayName,
    'recoveryConfirmed': recoveryConfirmed,
    'organizationId': organizationId,
    'organizationName': organizationName,
    'accountStatus': accountStatus,
  };

  factory LocalIdentity.fromJson(Map<String, dynamic> json) => LocalIdentity(
    identityId: json['identityId'] ?? '',
    deviceId: json['deviceId'] ?? '',
    publicIdentity: json['publicIdentity'] ?? '',
    identityFingerprint: json['identityFingerprint'] ?? '',
    publicDeviceKey: json['publicDeviceKey'] ?? '',
    authPublicKey: json['authPublicKey'] ?? '',
    devicePrivateKey: json['devicePrivateKey'] ?? '',
    authPrivateKey: json['authPrivateKey'] ?? '',
    pqcKemAlg: json['pqcKemAlg'] ?? 'ML-KEM-768',
    pqcKemPublicKey: json['pqcKemPublicKey'] ?? '',
    pqcKemPrivateKey: json['pqcKemPrivateKey'] ?? '',
    pqcDsaAlg: json['pqcDsaAlg'] ?? 'ML-DSA-65',
    pqcDsaPublicKey: json['pqcDsaPublicKey'] ?? '',
    pqcDsaPrivateKey: json['pqcDsaPrivateKey'] ?? '',
    recoveryPhrase: json['recoveryPhrase'] ?? '',
    displayName: json['displayName'] ?? 'Field Agent',
    recoveryConfirmed: json['recoveryConfirmed'] ?? true,
    organizationId: json['organizationId'],
    organizationName: json['organizationName'],
    accountStatus: json['accountStatus'] ?? 'active',
  );
}
