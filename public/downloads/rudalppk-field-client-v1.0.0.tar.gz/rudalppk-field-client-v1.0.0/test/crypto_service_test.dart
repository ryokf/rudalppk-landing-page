import 'package:flutter_test/flutter_test.dart';

import 'package:flutter_application_chat/services/crypto_service.dart';

void main() {
  final crypto = CryptoService();

  const phrase =
      'abandon ability able about above absent absorb abstract absurd abuse access accident';

  group('CryptoService recovery phrase', () {
    test('generates a 12 word phrase', () {
      final generated = crypto.generateRecoveryPhrase();
      expect(crypto.isValidPhrase(generated), isTrue);
      expect(generated.split(' ').length, 12);
    });

    test('rejects malformed phrases', () {
      expect(crypto.isValidPhrase('too short'), isFalse);
      expect(crypto.isValidPhrase(''), isFalse);
    });

    test('normalizes case and whitespace', () {
      expect(
        crypto.normalizePhrase('  ABANDON   ability\n able '),
        'abandon ability able',
      );
    });
  });

  group('CryptoService deterministic keys', () {
    test('same phrase derives the same auth public key', () async {
      final first = await crypto.authKeyPairFromPhrase(phrase);
      final second = await crypto.authKeyPairFromPhrase(phrase);

      expect(
        await crypto.publicKeyToBase64(first),
        await crypto.publicKeyToBase64(second),
      );
      expect(
        await crypto.privateKeyToBase64(first),
        await crypto.privateKeyToBase64(second),
      );
    });

    test('same phrase derives the same device public key', () async {
      final first = await crypto.deviceKeyPairFromPhrase(phrase);
      final second = await crypto.deviceKeyPairFromPhrase(phrase);

      expect(
        await crypto.publicKeyToBase64(first),
        await crypto.publicKeyToBase64(second),
      );
    });

    test('auth and device keys are domain separated', () async {
      final auth = await crypto.authKeyPairFromPhrase(phrase);
      final device = await crypto.deviceKeyPairFromPhrase(phrase);

      expect(
        await crypto.privateKeyToBase64(auth),
        isNot(await crypto.privateKeyToBase64(device)),
      );
    });

    test('different phrases derive different keys', () async {
      final first = await crypto.authKeyPairFromPhrase(phrase);
      final second = await crypto.authKeyPairFromPhrase(
        'zoo zone zero youth young yellow year wrong write wrist wrestle wisdom',
      );

      expect(
        await crypto.publicKeyToBase64(first),
        isNot(await crypto.publicKeyToBase64(second)),
      );
    });
  });

  group('CryptoService per-device envelopes', () {
    test('encrypts for and decrypts by each recipient device', () async {
      final aliceDevice = await crypto.deviceKeyPairFromPhrase(
        'abandon ability able about above absent absorb abstract absurd abuse access accident',
      );
      final bobDevice = await crypto.deviceKeyPairFromPhrase(
        'zoo zone zero youth young yellow year wrong write wrist wrestle wisdom',
      );

      final alicePrivate = await crypto.privateKeyToBase64(aliceDevice);
      final alicePublic = await crypto.publicKeyToBase64(aliceDevice);
      final bobPrivate = await crypto.privateKeyToBase64(bobDevice);
      final bobPublic = await crypto.publicKeyToBase64(bobDevice);

      const plaintext = 'Rendezvous at grid 7-Alpha, 0400 hours.';
      const conversationId = 'conv-test-1';

      final ciphertext = await crypto.encryptForDevices(
        plaintext,
        conversationId: conversationId,
        myPrivateKey: alicePrivate,
        recipientPublicKeys: {
          'alice-device': alicePublic,
          'bob-device': bobPublic,
        },
      );

      expect(ciphertext, isNot(contains(plaintext)));

      final alicePlaintext = await crypto.decryptForDevice(
        ciphertext,
        conversationId: conversationId,
        myDeviceId: 'alice-device',
        myPrivateKey: alicePrivate,
        senderPublicKey: alicePublic,
      );
      final bobPlaintext = await crypto.decryptForDevice(
        ciphertext,
        conversationId: conversationId,
        myDeviceId: 'bob-device',
        myPrivateKey: bobPrivate,
        senderPublicKey: alicePublic,
      );

      expect(alicePlaintext, plaintext);
      expect(bobPlaintext, plaintext);
    });

    test('returns a placeholder for a device without a wrapped key', () async {
      final aliceDevice = await crypto.deviceKeyPairFromPhrase(phrase);
      final alicePrivate = await crypto.privateKeyToBase64(aliceDevice);
      final alicePublic = await crypto.publicKeyToBase64(aliceDevice);

      final ciphertext = await crypto.encryptForDevices(
        'secret',
        conversationId: 'conv-test-2',
        myPrivateKey: alicePrivate,
        recipientPublicKeys: {'alice-device': alicePublic},
      );

      final plaintext = await crypto.decryptForDevice(
        ciphertext,
        conversationId: 'conv-test-2',
        myDeviceId: 'unknown-device',
        myPrivateKey: alicePrivate,
        senderPublicKey: alicePublic,
      );

      expect(plaintext, '[Pesan terenkripsi untuk perangkat lain]');
    });

    test('returns a placeholder for undecryptable payloads', () async {
      final plaintext = await crypto.decryptForDevice(
        'not-a-valid-envelope',
        conversationId: 'conv-test-3',
        myDeviceId: 'device',
        myPrivateKey: '',
      );

      expect(plaintext, '[Tidak dapat mendekripsi pesan]');
    });
  });
}
