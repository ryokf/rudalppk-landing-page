import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:flutter_application_chat/main.dart';

void main() {
  testWidgets('shows onboarding when no identity is stored', (tester) async {
    SharedPreferences.setMockInitialValues({});

    await tester.pumpWidget(const SecureFieldApp());
    await tester.pumpAndSettle();

    expect(find.text('Secure Field Communication'), findsOneWidget);
    expect(find.text('Aktivasi'), findsOneWidget);
    expect(find.text('Kode Aktivasi Organisasi'), findsOneWidget);
    expect(find.text('Aktifkan Akun'), findsOneWidget);
  });
}
