import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_application_chat/services/crypto_service.dart';
import 'package:flutter_application_chat/services/pqc_service.dart';

void main() {
  final pqc = PqcService();
  final crypto = CryptoService();

  group('NIST FIPS 203 ML-KEM (512, 768, 1024)', () {
    for (final alg in ['ML-KEM-512', 'ML-KEM-768', 'ML-KEM-1024']) {
      test('$alg keygen, encapsulate, and decapsulate match shared secret', () async {
        final spec = PqcService.mlKemSpecs[alg]!;
        final kp = await pqc.mlKemKeygen(alg, seed: utf8.encode('test-seed-$alg'));
        expect(kp.publicKeyBytes, spec.publicKeyBytes);
        expect(kp.secretKeyBytes, spec.secretKeyBytes);

        final enc = await pqc.mlKemEncapsulate(alg, kp.publicKeyB64);
        expect(enc.ciphertextBytes, spec.ciphertextOrSigBytes);

        final dec = await pqc.mlKemDecapsulate(
          alg,
          kp.secretKeyB64,
          enc.ciphertextB64,
        );
        expect(base64Encode(dec), enc.sharedSecretB64);
      });
    }
  });

  group('NIST FIPS 204 ML-DSA (44, 65, 87)', () {
    for (final alg in ['ML-DSA-44', 'ML-DSA-65', 'ML-DSA-87']) {
      test('$alg sign, verify, and 1-bit tamper rejection', () async {
        final spec = PqcService.mlDsaSpecs[alg]!;
        final kp = await pqc.mlDsaKeygen(alg, seed: utf8.encode('dsa-seed-$alg'));
        expect(kp.publicKeyBytes, spec.publicKeyBytes);
        expect(kp.secretKeyBytes, spec.secretKeyBytes);

        final msg = utf8.encode('PERINTAH OPERASI TAKTIS SEKTOR ALPHA');
        final sig = await pqc.mlDsaSign(alg, kp.secretKeyB64, msg);
        expect(base64Decode(sig).length, spec.ciphertextOrSigBytes);

        final valid = await pqc.mlDsaVerify(alg, kp.publicKeyB64, msg, sig);
        expect(valid, isTrue);

        // 1-bit tamper on message must fail verification
        final tamperedMsg = utf8.encode('PERINTAH OPERASI TAKTIS SEKTOR ALPHB');
        final tamperedValid = await pqc.mlDsaVerify(
          alg,
          kp.publicKeyB64,
          tamperedMsg,
          sig,
        );
        expect(tamperedValid, isFalse);
      });
    }
  });

  test('Hybrid X25519 + ML-KEM-768 + ML-DSA-65 E2EE envelope & PERISAI-Vault', () async {
    final phraseA = crypto.generateRecoveryPhrase();
    final phraseB = crypto.generateRecoveryPhrase();

    final devA = await crypto.deviceKeyPairFromPhrase(phraseA);
    final devB = await crypto.deviceKeyPairFromPhrase(phraseB);
    final kemA = await crypto.pqcKemKeyPairFromPhrase(phraseA, algorithm: 'ML-KEM-768');
    final kemB = await crypto.pqcKemKeyPairFromPhrase(phraseB, algorithm: 'ML-KEM-768');
    final dsaA = await crypto.pqcDsaKeyPairFromPhrase(phraseA, algorithm: 'ML-DSA-65');

    final privA = await crypto.privateKeyToBase64(devA);
    final pubA = await crypto.publicKeyToBase64(devA);
    final privB = await crypto.privateKeyToBase64(devB);
    final pubB = await crypto.publicKeyToBase64(devB);

    final ct = await crypto.encryptForDevices(
      'Pesan Rahasia Anti-Kuantum PERISAI-Q',
      conversationId: 'conv-123',
      myPrivateKey: privA,
      recipientPublicKeys: {'device-b': pubB},
      recipientPqcKemPublicKeys: {'device-b': kemB.publicKeyB64},
      recipientPqcKemAlgs: {'device-b': 'ML-KEM-768'},
      myPqcKemAlg: 'ML-KEM-768',
      myPqcDsaAlg: 'ML-DSA-65',
      myPqcDsaPrivateKey: dsaA.secretKeyB64,
      myPqcDsaPublicKey: dsaA.publicKeyB64,
    );

    final dec = await crypto.decryptEnvelopeForDevice(
      ct,
      conversationId: 'conv-123',
      myDeviceId: 'device-b',
      myPrivateKey: privB,
      senderPublicKey: pubA,
      myPqcKemPrivateKey: kemB.secretKeyB64,
      myPqcKemAlg: 'ML-KEM-768',
      senderPqcDsaPublicKey: dsaA.publicKeyB64,
    );

    expect(dec.plaintext, 'Pesan Rahasia Anti-Kuantum PERISAI-Q');
    expect(dec.isHybridPqc, isTrue);
    expect(dec.pqcKemAlg, 'ML-KEM-768');
    expect(dec.pqcDsaAlg, 'ML-DSA-65');
    expect(dec.pqcSignatureVerified, isTrue);

    // Test PERISAI-Vault local encryption & decryption
    final vaultItem = await crypto.encryptVaultItem(
      title: 'Koordinat Rahasia',
      category: 'map_coords',
      contentText: '-6.175392, 106.827153',
      kemAlgorithm: 'ML-KEM-1024',
      kemPublicKeyB64: (await crypto.pqcKemKeyPairFromPhrase(phraseA, algorithm: 'ML-KEM-1024')).publicKeyB64,
      dsaAlgorithm: 'ML-DSA-87',
      dsaPrivateKeyB64: (await crypto.pqcDsaKeyPairFromPhrase(phraseA, algorithm: 'ML-DSA-87')).secretKeyB64,
    );

    final vaultDec = await crypto.decryptVaultItem(
      item: vaultItem,
      kemPrivateKeyB64: (await crypto.pqcKemKeyPairFromPhrase(phraseA, algorithm: 'ML-KEM-1024')).secretKeyB64,
      dsaPublicKeyB64: (await crypto.pqcDsaKeyPairFromPhrase(phraseA, algorithm: 'ML-DSA-87')).publicKeyB64,
    );
    expect(vaultDec['plaintext'], '-6.175392, 106.827153');
    expect(vaultDec['signature_valid'], isTrue);
    expect(vaultItem.kemAlgorithm, 'ML-KEM-1024');
    expect(vaultItem.dsaAlgorithm, 'ML-DSA-87');
  });
}
