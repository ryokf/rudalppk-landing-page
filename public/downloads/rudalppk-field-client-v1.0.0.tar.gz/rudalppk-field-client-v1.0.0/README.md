# Secure Field Communication — Field Agent Mobile App

Flutter mobile/web client for field agents (SAD v2.0). It is independent from
the organization web console and shares only the FastAPI backend.

## Features

- Organization-issued account activation with a one-time `SFC-XXXX-...` code.
- 12-word recovery phrase generated on-device; restore by phrase.
- Separate **Personal** and **Groups** tabs, plus a **Profile** tab.
- Direct personal conversations (exactly two organization members).
- Group creation and membership management (group admin).
- Per-message E2EE envelopes: X25519 + HKDF-SHA256 + AES-256-GCM, wrapped per
  recipient device.
- Group key epoch: membership changes bump `key_epoch`; stale-epoch messages
  are rejected by the backend and the client refreshes member devices.
- Organization directory search for contacts, personal chats, and group members.
- Ed25519 device challenge/response authentication and `device_session` JWT.
- Device revocation and account status are enforced by the backend on every
  request and WebSocket connection.
- WebSocket relay plus 5-second polling fallback for offline delivery.

## Requirements

- Flutter 3.47+ / Dart 3.13+
- Running backend (see `../Backend`)
- Android emulator/device, Chrome, or another Flutter target

## Run

```bash
flutter pub get
flutter run -d chrome        # or android / web-server
```

For a release web build:

```bash
flutter build web --release
```

The backend URL can be changed on the activation screen and later from
**Profile → Alamat Server Backend**. The default is:

- Web/desktop: `http://localhost:8000/api/v1`
- Android emulator: `http://10.0.2.2:8000/api/v1`

## Activation Flow

1. An organization administrator creates a field-agent account in the web
   console and issues an activation code.
2. The agent opens this app, chooses **Aktivasi**, enters their name and the
   code, and taps **Buat Frasa Baru**.
3. The app derives Ed25519/X25519 keys from the phrase, sends only public keys
   and the SHA-256 fingerprint, and completes activation.
4. The app then performs device authentication (challenge/response) and stores
   only the JWT and local private keys.

Self-registration is disabled. Existing identities can be restored from the
**Pulihkan** tab.

## Security Notes

- Private keys and the recovery phrase never leave the device.
- The backend stores ciphertext only.
- Group messages use the same per-device envelope wrapping as personal chat;
  the group `key_epoch` forces re-wrapping after membership changes.
- Administrators can manage accounts and groups but cannot read messages.

## Tests

```bash
flutter analyze
flutter test
```
