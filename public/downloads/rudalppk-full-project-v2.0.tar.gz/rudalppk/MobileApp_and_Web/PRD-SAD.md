# Secure Field Communication Platform
## Product Requirements Document (PRD) & Software Architecture Document (SAD)

**Document Version:** 1.0  
**Document Status:** Initial Draft  
**Project Category:** Core Infra — Secure Communication  
**Platform:** Android-first, with potential iOS support

---

# PART I — PRODUCT REQUIREMENTS DOCUMENT (PRD)

## 1. Product Overview

### 1.1 Product Description

Secure Field Communication Platform adalah aplikasi komunikasi mobile yang dirancang untuk mendukung komunikasi privat antara field agent melalui pesan teks, percakapan grup, voice note, dan panggilan suara.

Aplikasi mengutamakan identitas digital yang tidak bergantung pada nomor telepon atau email sebagai identitas utama. Pengguna dapat membuat identitas secara lokal melalui mekanisme cryptographic identity dan menggunakan recovery phrase untuk memulihkan identitas ketika perangkat hilang atau diganti.

Sistem dirancang dengan pendekatan End-to-End Encryption (E2EE), sehingga isi komunikasi hanya dapat dibaca oleh perangkat pengirim dan penerima yang berwenang.

### 1.2 Problem Statement

Aplikasi komunikasi konvensional umumnya memiliki ketergantungan terhadap:
- Nomor telepon atau email sebagai identitas utama.
- Infrastruktur akun terpusat.
- Penyimpanan metadata komunikasi pada penyedia layanan.
- Ketergantungan terhadap konektivitas internet.
- Risiko kompromi akun dan perangkat.

Kebutuhan komunikasi field agent memerlukan sistem yang mengutamakan privasi, keamanan identitas, dan kemampuan berkomunikasi secara aman dalam kondisi operasional yang beragam.

### 1.3 Product Objectives

1. Menyediakan komunikasi privat berbasis identitas kriptografis.
2. Mengimplementasikan E2EE untuk pesan dan media komunikasi.
3. Memungkinkan komunikasi personal dan grup.
4. Menyediakan mekanisme pemulihan identitas tanpa ketergantungan pada email atau nomor telepon.
5. Meminimalkan informasi sensitif yang dapat diakses server.
6. Mendukung pengiriman pesan ketika penerima sedang offline.

### 1.4 Target Users

- Field agents.
- Tim operasional lapangan.
- Tim investigasi dan respons insiden.
- Organisasi yang membutuhkan komunikasi privat.
- Tim yang bekerja dalam lingkungan dengan risiko kebocoran informasi.

## 2. Functional Requirements

| ID | Requirement | Priority |
|---|---|---|
| FR-01 | Pengguna dapat membuat identitas tanpa email atau nomor telepon | High |
| FR-02 | Sistem menghasilkan recovery phrase untuk pemulihan identitas | High |
| FR-03 | Pengguna dapat menambahkan kontak melalui pertukaran public identity | High |
| FR-04 | Pengguna dapat mengirim dan menerima pesan terenkripsi | High |
| FR-05 | Pengguna dapat membuat percakapan grup | High |
| FR-06 | Pengguna dapat mengirim voice note terenkripsi | Medium |
| FR-07 | Pengguna dapat melakukan panggilan suara | Medium |
| FR-08 | Sistem dapat menyimpan pesan terenkripsi sementara ketika penerima offline | High |
| FR-09 | Pengguna dapat menghapus atau mencabut akses perangkat yang hilang | Medium |
| FR-10 | Sistem mendukung pengelolaan anggota grup | Medium |

## 3. Non-Functional Requirements

| ID | Requirement |
|---|---|
| NFR-01 | Isi pesan harus dilindungi menggunakan E2EE |
| NFR-02 | Private key tidak boleh dikirim atau disimpan pada backend |
| NFR-03 | Recovery phrase tidak boleh dikirim ke server |
| NFR-04 | Sistem harus mendukung koneksi terenkripsi menggunakan TLS |
| NFR-05 | Sistem harus meminimalkan metadata yang disimpan |
| NFR-06 | Aplikasi harus mendukung Android sebagai platform awal |
| NFR-07 | Arsitektur harus dapat dikembangkan untuk mendukung iOS |
| NFR-08 | Komponen backend harus dapat dijalankan menggunakan Docker |

## 4. MVP Scope

### Included in MVP

- Pembuatan identitas lokal.
- Recovery phrase.
- Pertukaran identitas publik.
- Direct message dengan E2EE.
- Group messaging dasar.
- Offline message delivery.
- Demonstrasi bahwa backend tidak dapat membaca isi pesan.

### Future Development

- Encrypted voice notes.
- Real-time voice calls.
- Multi-device identity.
- Device revocation yang lebih lengkap.
- Wi-Fi Direct atau local-network communication.
- Mesh communication untuk lingkungan tanpa internet.

## 5. Acceptance Criteria

MVP dianggap berhasil apabila:

1. Dua perangkat dapat membuat identitas tanpa email dan nomor telepon.
2. Kedua perangkat dapat bertukar identitas publik.
3. Pengguna dapat mengirim dan menerima pesan terenkripsi.
4. Pesan tetap dapat diterima ketika penerima sebelumnya offline.
5. Backend hanya menerima dan menyimpan ciphertext, bukan plaintext.
6. Identitas dapat dipulihkan melalui mekanisme recovery yang telah ditentukan.

---

# PART II — SOFTWARE ARCHITECTURE DOCUMENT (SAD)

## 6. Architecture Overview

Sistem menggunakan arsitektur client-server dengan cryptographic operations yang dilakukan pada perangkat pengguna.

Backend berfungsi sebagai relay dan penyimpanan sementara ciphertext. Backend tidak bertanggung jawab untuk mengenkripsi atau mendekripsi isi pesan.

### 6.1 High-Level Architecture

```mermaid
flowchart TD
    A[Flutter Client A] <-->|Encrypted Communication| B[Backend API]
    C[Flutter Client B] <-->|Encrypted Communication| B
    B --> D[FastAPI]
    D --> E[PostgreSQL]
    D --> F[WebSocket Relay]
    D --> G[Encrypted Object Storage]
    A <-->|WebRTC E2EE Media| C
```

## 7. Technology Stack

| Layer | Technology |
|---|---|
| Mobile Application | Flutter / Dart |
| Backend API | Python / FastAPI |
| Database | PostgreSQL |
| Real-time Communication | WebSocket |
| Cryptographic Protocol | Signal Protocol for 1:1 messaging; evaluate MLS for groups |
| Key Protection | Android Keystore / iOS Keychain |
| Voice Communication | WebRTC / Opus |
| NAT Traversal | STUN / TURN (coturn) |
| Object Storage | SeaweedFS (S3-compatible) |
| Containerization | Docker / Docker Compose |
| Reverse Proxy | Nginx |

Cryptographic implementation harus menggunakan library dan protokol yang telah diaudit. Jangan membuat algoritma enkripsi sendiri.

## 8. System Components

### 8.1 Mobile Client

Tanggung jawab:
- Membuat dan mengelola identitas kriptografis.
- Menyimpan private key secara lokal.
- Mengenkripsi dan mendekripsi pesan.
- Mengelola percakapan personal dan grup.
- Mengelola voice notes dan panggilan suara.
- Mengelola recovery dan device security.

### 8.2 Backend API

Tanggung jawab:
- Menerima permintaan dari client.
- Mengelola public identity dan informasi routing yang diperlukan.
- Meneruskan ciphertext.
- Menyimpan pesan sementara.
- Mengelola membership dan distribusi pesan grup sesuai protokol yang dipilih.
- Menyediakan signaling untuk WebRTC.

Backend tidak boleh memiliki akses terhadap private key atau recovery phrase pengguna.

### 8.3 Database

PostgreSQL menyimpan data operasional, seperti:

- Public identity.
- Device registration dan status.
- Conversation metadata.
- Group membership.
- Encrypted message payload.
- Message delivery status.

Metadata tetap dapat mengungkap pola komunikasi. Karena itu, penyimpanannya harus diminimalkan dan memiliki kebijakan retensi.

### 8.4 Object Storage

SeaweedFS digunakan untuk menyimpan file voice note dalam bentuk ciphertext dengan antarmuka S3 API yang ringan dan mendukung arsitektur multi-arch (ARM64/Apple Silicon dan AMD64).

Alur:
1. Client merekam audio.
2. Audio dikompresi menggunakan Opus.
3. Client mengenkripsi audio.
4. Ciphertext dikirim ke object storage.
5. Penerima mengunduh ciphertext.
6. Client penerima mendekripsi dan memutar audio.

## 9. Identity and Key Management

### 9.1 Identity Creation

1. Pengguna membuat identitas baru.
2. Client menghasilkan cryptographic key material secara lokal.
3. Client menghasilkan recovery phrase melalui mekanisme yang terdefinisi dengan baik.
4. Private key disimpan secara lokal.
5. Public identity digunakan untuk pertukaran kontak.

### 9.2 Recovery Mechanism

Recovery phrase berfungsi sebagai recovery secret, bukan password yang dikirim ke server.

Proses pemulihan harus dirancang menggunakan standar derivasi dan backup key yang sesuai. Phrase tidak boleh langsung digunakan sebagai encryption key tanpa mekanisme derivasi yang aman.

### 9.3 Device Revocation

Jika perangkat hilang:
- Pengguna memulihkan identitas melalui recovery mechanism.
- Perangkat lama ditandai sebagai tidak tepercaya.
- Key atau session yang terdampak harus dirotasi.
- Kontak dan grup diberi pembaruan status keamanan yang sesuai.

## 10. Message Flow

### 10.1 Direct Message

1. Pengirim membuat pesan.
2. Client mengenkripsi pesan menggunakan protokol E2EE.
3. Ciphertext dikirim melalui HTTPS atau WebSocket.
4. Backend menyimpan atau meneruskan ciphertext.
5. Penerima mengambil ciphertext.
6. Client penerima melakukan dekripsi secara lokal.

### 10.2 Group Messaging

Group messaging memerlukan pengelolaan key untuk seluruh anggota.

Ketika anggota baru ditambahkan atau anggota lama dikeluarkan, sistem harus memperbarui key material sesuai protokol group messaging yang dipilih.

MLS dapat dievaluasi untuk kebutuhan ini.

### 10.3 Voice Call

1. Client memulai panggilan.
2. Backend membantu proses signaling.
3. WebRTC melakukan koneksi antarperangkat.
4. STUN/TURN membantu mengatasi NAT traversal.
5. Media suara dikirim dengan proteksi E2EE yang sesuai.

WebRTC tidak otomatis menjamin seluruh arsitektur server-blind E2EE, khususnya apabila menggunakan SFU. Desain media encryption perlu ditentukan secara eksplisit.

## 11. Security Considerations

| Threat | Mitigation |
|---|---|
| Server compromise | E2EE dan minimisasi data |
| Private key theft | Secure local storage |
| Device loss | Recovery dan device revocation |
| Replay attack | Sequence number dan mekanisme anti-replay protokol |
| Unauthorized group access | Membership verification dan key rotation |
| Metadata exposure | Data minimization dan retention policy |
| Man-in-the-middle | Identity verification dan authenticated key exchange |
| Network interception | TLS dan E2EE |

## 12. Deployment Architecture

Seluruh backend dapat dijalankan menggunakan Docker Compose.

Komponen deployment awal:

```text
secure-communication/
├── mobile/
│   └── Flutter application
├── backend/
│   ├── main.py
│   ├── api/
│   ├── services/
│   └── requirements.txt
├── database/
│   └── init.sql
├── storage/
├── nginx/
│   └── nginx.conf
├── docker-compose.yml
└── .env
```

Container services:

- `api`: FastAPI backend.
- `db`: PostgreSQL.
- `storage`: SeaweedFS (S3-compatible).
- `proxy`: Nginx.
- `turn`: coturn, ketika fitur voice call mulai dikembangkan.

## 13. Development Roadmap

| Phase | Development Target |
|---|---|
| Phase 1 | Identity creation dan recovery |
| Phase 2 | Direct E2EE messaging |
| Phase 3 | Offline message delivery |
| Phase 4 | Group messaging |
| Phase 5 | Encrypted voice notes |
| Phase 6 | WebRTC voice calls |
| Phase 7 | Security testing dan hardening |

## 14. Open Technical Decisions

Hal-hal yang harus diputuskan sebelum implementasi penuh:

1. Standar dan format recovery phrase.
2. Library cryptographic yang kompatibel dengan Flutter.
3. Pemilihan protokol untuk group messaging.
4. Mekanisme verifikasi identitas antarperangkat.
5. Kebijakan retensi pesan dan metadata.
6. Mekanisme backup dan pemulihan identitas.
7. Apakah komunikasi offline tanpa internet menjadi kebutuhan MVP atau pengembangan lanjutan.

---

**End of Document — Version 1.0**

**Note:** Dokumen ini merupakan rancangan awal untuk kebutuhan perencanaan dan pengembangan hackathon. Implementasi keamanan harus melalui threat modeling, pemilihan library kriptografi yang tervalidasi, serta pengujian keamanan sebelum digunakan dalam operasi nyata.