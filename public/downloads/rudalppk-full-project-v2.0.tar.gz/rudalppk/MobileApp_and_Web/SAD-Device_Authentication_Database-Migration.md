# SAD v1.4 — Device Authentication & Database Migration

**Project:** Secure Field Communication Platform  
**Backend:** FastAPI  
**Database:** PostgreSQL  
**ORM:** SQLAlchemy Async  
**Migration:** Alembic  
**Authentication:** Ed25519 Challenge–Response  
**Token:** JWT

---

# 1. Update Dependencies

Tambahkan ke `backend/requirements.txt`:

```txt
fastapi
uvicorn[standard]
sqlalchemy[asyncio]
asyncpg
alembic
pydantic-settings
python-multipart
cryptography
PyJWT
```

Build ulang:

```bash
docker compose up -d --build
```

# 2. Update Environment Configuration

Tambahkan variabel berikut ke `.env`:

```env
JWT_SECRET_KEY=REPLACE_WITH_A_RANDOM_SECRET
JWT_ACCESS_TOKEN_MINUTES=15
```

Buat secret menggunakan:

```bash
python -c "import secrets; print(secrets.token_urlsafe(48))"
```

Simpan hasilnya sebagai `JWT_SECRET_KEY`. Jangan menggunakan nilai contoh atau memasukkan secret tersebut ke Git.

# 3. Update Device Model

Tambahkan public authentication key ke tabel perangkat.

`backend/app/models/device.py`

```python
import uuid
from datetime import datetime, timezone

from sqlalchemy import String, DateTime, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class Device(Base):
    __tablename__ = "devices"

    device_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4
    )

    identity_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("identities.identity_id"),
        nullable=False
    )

    device_name: Mapped[str] = mapped_column(
        String(100)
    )

    public_device_key: Mapped[str] = mapped_column(
        String,
        nullable=False
    )

    auth_public_key: Mapped[str] = mapped_column(
        String,
        nullable=False,
        unique=True
    )

    status: Mapped[str] = mapped_column(
        String(20),
        default="active"
    )

    registered_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc)
    )

    revoked_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True
    )
```

**Pemisahan key:**

- `public_device_key`: public key untuk kebutuhan identitas/enkripsi perangkat.
- `auth_public_key`: public key khusus untuk membuktikan kepemilikan perangkat saat autentikasi.

Private key untuk autentikasi disimpan pada perangkat, bukan pada PostgreSQL.

# 4. Update Identity Registration Schema

`backend/app/schemas/identity.py`

```python
from pydantic import BaseModel, Field


class DeviceCreate(BaseModel):
    device_name: str = Field(min_length=1, max_length=100)
    public_device_key: str = Field(min_length=1)
    auth_public_key: str = Field(min_length=1)


class IdentityCreate(BaseModel):
    public_identity: str = Field(min_length=1)
    identity_fingerprint: str = Field(min_length=16, max_length=128)
    device: DeviceCreate
```

Kemudian update bagian pembuatan `Device` dalam `backend/app/routers/identity.py`:

```python
device = Device(
    identity_id=identity.identity_id,
    device_name=payload.device.device_name,
    public_device_key=payload.device.public_device_key,
    auth_public_key=payload.device.auth_public_key
)
```

# 5. Create Authentication Challenge Model

Buat `backend/app/models/auth_challenge.py`:

```python
import uuid
from datetime import datetime, timezone

from sqlalchemy import DateTime, String, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class AuthChallenge(Base):
    __tablename__ = "auth_challenges"

    challenge_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4
    )

    device_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("devices.device_id"),
        nullable=False
    )

    nonce: Mapped[str] = mapped_column(
        String(128),
        nullable=False
    )

    expires_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False
    )

    consumed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc)
    )
```

Tambahkan ke `backend/app/models/__init__.py`:

```python
from app.models.identity import Identity
from app.models.device import Device
from app.models.auth_challenge import AuthChallenge
```

# 6. Configure JWT

Update `backend/app/core/config.py`:

```python
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    database_url: str

    jwt_secret_key: str
    jwt_access_token_minutes: int = 15

    model_config = SettingsConfigDict(
        env_file=".env",
        extra="ignore"
    )


settings = Settings()
```

# 7. Configure Alembic

Dari root proyek:

```bash
docker compose exec api alembic init -t async alembic
```

Edit `backend/alembic/env.py`.

Gunakan konfigurasi berikut sebagai bagian utama file:

```python
import asyncio

from logging.config import fileConfig

from sqlalchemy import pool
from sqlalchemy.ext.asyncio import async_engine_from_config

from alembic import context

from app.core.database import Base
from app.core.config import settings

from app.models import Identity, Device, AuthChallenge


config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

config.set_main_option(
    "sqlalchemy.url",
    settings.database_url.replace("%", "%%")
)

target_metadata = Base.metadata


def run_migrations_offline():
    context.configure(
        url=settings.database_url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"}
    )

    with context.begin_transaction():
        context.run_migrations()


def do_run_migrations(connection):
    context.configure(
        connection=connection,
        target_metadata=target_metadata
    )

    with context.begin_transaction():
        context.run_migrations()


async def run_migrations_online():
    connectable = async_engine_from_config(
        config.get_section(config.config_ini_section),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool
    )

    async with connectable.connect() as connection:
        await connection.run_sync(do_run_migrations)

    await connectable.dispose()


if context.is_offline_mode():
    run_migrations_offline()
else:
    asyncio.run(run_migrations_online())
```

Buat migration pertama:

```bash
docker compose exec api alembic revision --autogenerate -m "initial identity and device schema"
```

Periksa file migration yang dihasilkan, kemudian jalankan:

```bash
docker compose exec api alembic upgrade head
```

Untuk database yang sudah memiliki tabel hasil `create_all`, jangan langsung menjalankan initial migration. Gunakan database development baru atau buat baseline migration yang mencerminkan schema aktual sebelum menerapkan perubahan. Jangan menghapus volume database hanya untuk mengatasi konflik migration.

# 8. Authentication Schemas

Buat `backend/app/schemas/auth.py`:

```python
import uuid

from pydantic import BaseModel, Field


class ChallengeRequest(BaseModel):
    device_id: uuid.UUID


class ChallengeResponse(BaseModel):
    challenge_id: uuid.UUID
    nonce: str
    expires_at: str


class VerifyRequest(BaseModel):
    challenge_id: uuid.UUID
    signature: str = Field(min_length=1)
```

# 9. Authentication Router

Buat `backend/app/routers/auth.py`:

```python
import base64
import binascii
import secrets
import uuid

from datetime import datetime, timedelta, timezone

import jwt

from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PublicKey
)

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.config import settings

from app.models.device import Device
from app.models.auth_challenge import AuthChallenge

from app.schemas.auth import (
    ChallengeRequest,
    ChallengeResponse,
    VerifyRequest
)


router = APIRouter(
    prefix="/api/v1/auth",
    tags=["Authentication"]
)


def challenge_message(challenge_id, nonce):
    return (
        f"securechat-auth-v1\n"
        f"{challenge_id}\n"
        f"{nonce}"
    ).encode("utf-8")


@router.post("/challenge", response_model=ChallengeResponse)
async def create_challenge(
    payload: ChallengeRequest,
    db: AsyncSession = Depends(get_db)
):
    result = await db.execute(
        select(Device).where(
            Device.device_id == payload.device_id,
            Device.status == "active"
        )
    )

    device = result.scalar_one_or_none()

    if device is None:
        raise HTTPException(
            status_code=404,
            detail="Active device not found"
        )

    now = datetime.now(timezone.utc)

    challenge = AuthChallenge(
        device_id=device.device_id,
        nonce=secrets.token_urlsafe(32),
        expires_at=now + timedelta(minutes=2)
    )

    db.add(challenge)
    await db.commit()
    await db.refresh(challenge)

    return ChallengeResponse(
        challenge_id=challenge.challenge_id,
        nonce=challenge.nonce,
        expires_at=challenge.expires_at.isoformat()
    )


@router.post("/verify")
async def verify_challenge(
    payload: VerifyRequest,
    db: AsyncSession = Depends(get_db)
):
    result = await db.execute(
        select(AuthChallenge)
        .where(
            AuthChallenge.challenge_id == payload.challenge_id
        )
        .with_for_update()
    )

    challenge = result.scalar_one_or_none()

    if challenge is None:
        raise HTTPException(
            status_code=404,
            detail="Challenge not found"
        )

    now = datetime.now(timezone.utc)

    if challenge.consumed_at is not None:
        raise HTTPException(
            status_code=409,
            detail="Challenge already consumed"
        )

    if challenge.expires_at <= now:
        raise HTTPException(
            status_code=401,
            detail="Challenge expired"
        )

    result = await db.execute(
        select(Device).where(
            Device.device_id == challenge.device_id,
            Device.status == "active"
        )
    )

    device = result.scalar_one_or_none()

    if device is None:
        raise HTTPException(
            status_code=401,
            detail="Device is not active"
        )

    try:
        public_key_bytes = base64.b64decode(
            device.auth_public_key,
            validate=True
        )

        signature_bytes = base64.b64decode(
            payload.signature,
            validate=True
        )

        public_key = Ed25519PublicKey.from_public_bytes(
            public_key_bytes
        )

        public_key.verify(
            signature_bytes,
            challenge_message(
                challenge.challenge_id,
                challenge.nonce
            )
        )

    except (
        ValueError,
        binascii.Error,
        Exception
    ):
        await db.rollback()
        raise HTTPException(
            status_code=401,
            detail="Invalid device signature"
        )

    challenge.consumed_at = now

    token_payload = {
        "sub": str(device.device_id),
        "identity_id": str(device.identity_id),
        "jti": str(uuid.uuid4()),
        "iat": now,
        "exp": now + timedelta(
            minutes=settings.jwt_access_token_minutes
        )
    }

    access_token = jwt.encode(
        token_payload,
        settings.jwt_secret_key,
        algorithm="HS256"
    )

    await db.commit()

    return {
        "success": True,
        "data": {
            "access_token": access_token,
            "token_type": "bearer",
            "expires_in": settings.jwt_access_token_minutes * 60
        }
    }
```

Catatan implementasi: bagian `except` di atas dapat disederhanakan dan diperketat menjadi penanganan error khusus setelah pengujian. Dalam versi produksi, bedakan kegagalan format key dari signature yang tidak valid, tetapi jangan membocorkan detail sensitif kepada pemanggil.

# 10. Register Authentication Router

Update `backend/app/main.py`:

```python
from fastapi import FastAPI

from app.routers import identity, auth

app = FastAPI(
    title="Secure Field Communication API",
    version="1.4"
)

app.include_router(identity.router)
app.include_router(auth.router)


@app.get("/")
async def root():
    return {
        "application": "Secure Field Communication",
        "status": "running"
    }


@app.get("/health")
async def health():
    return {"status": "healthy"}
```

---

# 11. Authentication API Contract

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/v1/auth/challenge` | Generate authentication challenge |
| POST | `/api/v1/auth/verify` | Verify device signature |
 
### Request challenge

```json
{
  "device_id": "DEVICE_UUID"
}
```

Response:

```json
{
  "challenge_id": "CHALLENGE_UUID",
  "nonce": "RANDOM_NONCE",
  "expires_at": "2026-11-09T10:02:00+00:00"
}
```

### Verify challenge

```json
{
  "challenge_id": "CHALLENGE_UUID",
  "signature": "BASE64_SIGNATURE"
}
```

Response:

```json
{
  "success": true,
  "data": {
    "access_token": "JWT_TOKEN",
    "token_type": "bearer",
    "expires_in": 900
  }
}
```

# 12. Security Requirements

- Challenge hanya dapat digunakan satu kali.
- Challenge memiliki masa berlaku dua menit.
- Nonce harus dibuat menggunakan cryptographically secure random generator.
- Signature diverifikasi menggunakan Ed25519.
- Token memiliki masa berlaku terbatas.
- Private key tidak pernah dikirim ke server.
- Perangkat yang dicabut tidak boleh memperoleh challenge baru atau menyelesaikan autentikasi.
- Endpoint challenge harus diberi rate limiting sebelum deployment publik.
- JWT secret wajib disimpan secara aman.

**Important:** Token JWT di sini adalah access token untuk API, bukan pengganti E2EE. Server tetap tidak memiliki hak untuk mendekripsi pesan.

**End of Document — SAD v1.4**