# Database Schema & API Contract
## Secure Field Communication Platform

**Document ID:** SAD-DB-API-001  
**Version:** 1.2  
**Status:** Initial Technical Specification  
**Database:** PostgreSQL  
**Backend:** Python / FastAPI

---

# PART I — DATABASE DESIGN

## 1. Database Design Principles

Database dirancang dengan prinsip:

1. Tidak menyimpan plaintext pesan.
2. Tidak menyimpan private key pengguna.
3. Tidak menyimpan recovery phrase.
4. Memisahkan identitas pengguna dari perangkat.
5. Mendukung direct message dan group messaging.
6. Mendukung pengiriman pesan ketika penerima offline.
7. Memiliki mekanisme retensi data.

## 2. Entity Structure

Entitas utama:

| Entity | Responsibility |
|---|---|
| identities | Identitas publik pengguna |
| devices | Perangkat yang terhubung dengan identitas |
| device_prekeys | Public prekeys untuk proses key exchange |
| contacts | Daftar kontak pengguna |
| conversations | Percakapan personal atau grup |
| conversation_members | Anggota percakapan |
| messages | Payload pesan terenkripsi |
| delivery_receipts | Status pengiriman pesan |
| media_objects | Referensi file media terenkripsi |

## 3. PostgreSQL Schema

### 3.1 Initialize Database

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE identities (
    identity_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    public_identity TEXT NOT NULL UNIQUE,
    identity_fingerprint VARCHAR(128) NOT NULL UNIQUE,
    status VARCHAR(20) NOT NULL DEFAULT 'active'
        CHECK (status IN ('active', 'revoked')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

### 3.2 Devices

Satu identitas dapat memiliki beberapa perangkat.

```sql
CREATE TABLE devices (
    device_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    identity_id UUID NOT NULL REFERENCES identities(identity_id),
    device_name VARCHAR(100),
    public_device_key TEXT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'active'
        CHECK (status IN ('active', 'revoked')),
    registered_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    revoked_at TIMESTAMPTZ
);
```

### 3.3 Device Prekeys

Server dapat menyimpan public prekeys yang diperlukan untuk inisiasi sesi kriptografis. Private key tetap berada di perangkat.

```sql
CREATE TABLE device_prekeys (
    prekey_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    device_id UUID NOT NULL REFERENCES devices(device_id),
    prekey_type VARCHAR(30) NOT NULL,
    key_identifier VARCHAR(100) NOT NULL,
    public_key TEXT NOT NULL,
    signature TEXT,
    consumed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(device_id, key_identifier)
);
```

### 3.4 Contacts

```sql
CREATE TABLE contacts (
    contact_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_identity_id UUID NOT NULL REFERENCES identities(identity_id),
    contact_identity_id UUID NOT NULL REFERENCES identities(identity_id),
    verification_status VARCHAR(20) NOT NULL DEFAULT 'unverified'
        CHECK (verification_status IN ('unverified', 'verified')),
    added_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(owner_identity_id, contact_identity_id),
    CHECK (owner_identity_id <> contact_identity_id)
);
```

### 3.5 Conversations

```sql
CREATE TABLE conversations (
    conversation_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_type VARCHAR(20) NOT NULL
        CHECK (conversation_type IN ('direct', 'group')),
    title VARCHAR(150),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

### 3.6 Conversation Members

```sql
CREATE TABLE conversation_members (
    membership_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id UUID NOT NULL REFERENCES conversations(conversation_id),
    identity_id UUID NOT NULL REFERENCES identities(identity_id),
    member_role VARCHAR(20) NOT NULL DEFAULT 'member',
    joined_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    left_at TIMESTAMPTZ,
    UNIQUE(conversation_id, identity_id)
);
```

### 3.7 Messages

Pesan disimpan sebagai ciphertext. Format payload dan header mengikuti protokol kriptografi yang digunakan.

```sql
CREATE TABLE messages (
    message_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id UUID NOT NULL REFERENCES conversations(conversation_id),
    sender_device_id UUID NOT NULL REFERENCES devices(device_id),
    client_message_id UUID NOT NULL,
    protocol_version VARCHAR(30) NOT NULL,
    message_type VARCHAR(20) NOT NULL DEFAULT 'text',
    ciphertext BYTEA NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ,
    UNIQUE(sender_device_id, client_message_id)
);

CREATE INDEX idx_messages_conversation
ON messages(conversation_id, created_at);

CREATE INDEX idx_messages_expiration
ON messages(expires_at);
```

### 3.8 Delivery Receipts

```sql
CREATE TABLE delivery_receipts (
    receipt_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    message_id UUID NOT NULL REFERENCES messages(message_id),
    recipient_device_id UUID NOT NULL REFERENCES devices(device_id),
    delivery_status VARCHAR(20) NOT NULL DEFAULT 'pending'
        CHECK (delivery_status IN ('pending', 'delivered', 'read')),
    delivered_at TIMESTAMPTZ,
    read_at TIMESTAMPTZ,
    UNIQUE(message_id, recipient_device_id)
);
```

### 3.9 Media Objects

```sql
CREATE TABLE media_objects (
    media_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    message_id UUID NOT NULL REFERENCES messages(message_id),
    storage_reference TEXT NOT NULL,
    content_type VARCHAR(100),
    file_size BIGINT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

**Important:** `storage_reference` hanya merupakan referensi objek di SeaweedFS (S3-compatible). Encryption key untuk media harus disampaikan melalui kanal E2EE, bukan disimpan dalam tabel ini.

## 4. Database Relationship

```mermaid
erDiagram
    IDENTITIES ||--o{ DEVICES : owns
    DEVICES ||--o{ DEVICE_PREKEYS : publishes
    IDENTITIES ||--o{ CONTACTS : maintains
    CONVERSATIONS ||--o{ CONVERSATION_MEMBERS : contains
    IDENTITIES ||--o{ CONVERSATION_MEMBERS : participates
    CONVERSATIONS ||--o{ MESSAGES : contains
    DEVICES ||--o{ MESSAGES : sends
    MESSAGES ||--o{ DELIVERY_RECEIPTS : tracks
    DEVICES ||--o{ DELIVERY_RECEIPTS : receives
    MESSAGES ||--o| MEDIA_OBJECTS : references
```

## 5. Database Implementation Notes

Sebelum deployment produksi, tambahkan:

- Transaction management untuk operasi multi-tabel.
- Cleanup job untuk pesan yang kedaluwarsa.
- Validasi bahwa pengirim merupakan anggota percakapan.
- Validasi bahwa perangkat pengirim masih aktif.
- Kebijakan retensi untuk delivery receipts dan metadata.
- Pembatasan akses database berdasarkan kebutuhan service.

Untuk group messaging, perubahan membership harus disertai perubahan cryptographic group state sesuai protokol yang digunakan. Tabel membership saja tidak cukup untuk menjamin keamanan grup.

---

# PART II — API CONTRACT

## 6. API Convention

Base URL:

```text
/api/v1
```

Format:

- Protocol: HTTPS
- Request/Response: JSON
- Encoding: UTF-8
- Authentication: Device-based authentication
- Real-time: WebSocket

Contoh response sukses:

```json
{
  "success": true,
  "data": {},
  "error": null
}
```

Contoh response gagal:

```json
{
  "success": false,
  "data": null,
  "error": {
    "code": "INVALID_REQUEST",
    "message": "Request validation failed"
  }
}
```

## 7. Identity API

| Method | Endpoint | Description |
|---|---|---|
| POST | `/identity` | Register public identity |
| GET | `/identity/{identity_id}` | Retrieve public identity |
| POST | `/identity/challenge` | Request authentication challenge |
| POST | `/identity/verify` | Verify signed challenge |
| POST | `/identity/recover` | Register recovered identity/device |

### POST /identity

Request:

```json
{
  "public_identity": "PUBLIC_IDENTITY_DATA",
  "identity_fingerprint": "IDENTITY_FINGERPRINT",
  "device": {
    "device_name": "Field Agent Android",
    "public_device_key": "PUBLIC_DEVICE_KEY"
  }
}
```

Response:

```json
{
  "success": true,
  "data": {
    "identity_id": "UUID",
    "device_id": "UUID",
    "status": "active"
  },
  "error": null
}
```

Catatan: endpoint registrasi hanya menerima material publik. Recovery phrase dan private key tidak boleh menjadi bagian dari request.

## 8. Contact API

| Method | Endpoint | Description |
|---|---|---|
| POST | `/contacts` | Add contact |
| GET | `/contacts` | List contacts |
| GET | `/contacts/{contact_id}` | Contact detail |
| DELETE | `/contacts/{contact_id}` | Remove contact |

Contoh request:

```json
{
  "contact_identity_id": "UUID",
  "verification_status": "unverified"
}
```

Status `verified` hanya boleh diberikan setelah proses verifikasi identitas kriptografis berhasil.

## 9. Conversation API

| Method | Endpoint | Description |
|---|---|---|
| POST | `/conversations` | Create conversation |
| GET | `/conversations` | List conversations |
| GET | `/conversations/{id}` | Conversation detail |
| POST | `/conversations/{id}/members` | Add group member |
| DELETE | `/conversations/{id}/members/{identity_id}` | Remove group member |

Contoh create conversation:

```json
{
  "conversation_type": "direct",
  "members": [
    "IDENTITY_A",
    "IDENTITY_B"
  ]
}
```

Untuk group:

```json
{
  "conversation_type": "group",
  "title": "Field Operation Team",
  "members": [
    "IDENTITY_A",
    "IDENTITY_B",
    "IDENTITY_C"
  ]
}
```

Server harus memastikan pemanggil memiliki hak untuk membuat atau mengubah percakapan.

## 10. Messaging API

| Method | Endpoint | Description |
|---|---|---|
| POST | `/messages` | Submit encrypted message |
| GET | `/messages/pending` | Retrieve pending messages |
| POST | `/messages/{id}/receipt` | Update delivery receipt |
| DELETE | `/messages/{id}` | Request message deletion |

Contoh request:

```json
{
  "conversation_id": "UUID",
  "client_message_id": "UUID",
  "protocol_version": "1",
  "message_type": "text",
  "ciphertext": "BASE64_ENCODED_CIPHERTEXT"
}
```

Contoh response:

```json
{
  "success": true,
  "data": {
    "message_id": "UUID",
    "status": "accepted",
    "created_at": "2026-11-09T10:00:00Z"
  },
  "error": null
}
```

Server tidak perlu mengetahui isi plaintext pesan untuk memprosesnya.

## 11. Media API

| Method | Endpoint | Description |
|---|---|---|
| POST | `/media/upload-url` | Request upload authorization |
| POST | `/media/complete` | Confirm encrypted upload |
| GET | `/media/{media_id}/download-url` | Request download authorization |

Alur:

1. Client meminta izin upload.
2. Server memvalidasi hak akses.
3. Client mengunggah ciphertext ke object storage.
4. Client mengirim konfirmasi upload.
5. Referensi objek dikaitkan dengan pesan.
6. Penerima memperoleh akses untuk mengunduh ciphertext.

Gunakan signed URL dengan masa berlaku pendek dan pembatasan ukuran file.

## 12. WebSocket Contract

Endpoint:

```text
/ws/v1/relay
```

Event dari server:

```json
{
  "event": "message_available",
  "data": {
    "message_id": "UUID",
    "conversation_id": "UUID"
  }
}
```

Event dari client:

```json
{
  "event": "message_acknowledged",
  "data": {
    "message_id": "UUID"
  }
}
```

WebSocket hanya digunakan untuk notifikasi dan relay. Pengambilan payload tetap harus melewati pemeriksaan otorisasi.

---

# PART III — SECURITY & VALIDATION

## 13. Device Authentication

Rancangan autentikasi:

1. Client meminta challenge dari server.
2. Server menghasilkan nonce acak dengan masa berlaku singkat.
3. Client menandatangani nonce menggunakan private authentication key.
4. Client mengirim signature ke server.
5. Server memverifikasi signature dengan public key perangkat.
6. Server memberikan session token berumur terbatas.

Private key tidak pernah dikirim ke server.

## 14. Authorization Rules

| Action | Required Condition |
|---|---|
| Retrieve message | Device belongs to conversation member |
| Send message | Device is active and sender is a member |
| Add group member | Authorized group administrator |
| Remove group member | Authorized group administrator |
| Download media | Authorized conversation member |
| Revoke device | Authorized identity owner |

## 15. Error Codes

| Code | Meaning |
|---|---|
| `INVALID_REQUEST` | Request format invalid |
| `UNAUTHORIZED` | Authentication failed |
| `FORBIDDEN` | Insufficient permission |
| `IDENTITY_NOT_FOUND` | Identity unavailable |
| `DEVICE_REVOKED` | Device is no longer active |
| `CONVERSATION_NOT_FOUND` | Conversation unavailable |
| `MESSAGE_NOT_FOUND` | Message unavailable |
| `DUPLICATE_MESSAGE` | Duplicate client message |
| `RATE_LIMITED` | Too many requests |
| `SERVER_ERROR` | Internal server error |

## 16. Implementation Sequence

| Stage | Work Item | Deliverable |
|---|---|---|
| 1 | PostgreSQL initialization | Database ready |
| 2 | SQLAlchemy models / migrations | Database models |
| 3 | Identity API | Identity registration |
| 4 | Device authentication | Device session |
| 5 | Contact API | Contact management |
| 6 | Conversation API | Direct/group conversation |
| 7 | Message API | Ciphertext relay |
| 8 | WebSocket | Real-time notification |
| 9 | Media API | Encrypted file transfer |

## 17. Outstanding Decisions

Sebelum implementasi kriptografi, beberapa keputusan harus ditetapkan:

1. Format dan standar recovery phrase.
2. Implementasi Signal Protocol yang kompatibel dengan Flutter.
3. Mekanisme multi-device dan key synchronization.
4. Format payload terenkripsi.
5. Pilihan MLS atau protokol lain untuk group messaging.
6. Kebijakan penghapusan pesan dan metadata.
7. Strategi anti-spam dan rate limiting.

**End of Document — SAD-DB-API-001, Version 1.2**