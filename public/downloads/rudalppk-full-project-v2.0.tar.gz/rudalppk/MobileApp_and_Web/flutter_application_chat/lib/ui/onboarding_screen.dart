import 'package:flutter/material.dart';

import '../services/crypto_service.dart';
import '../services/storage_service.dart';
import '../state/chat_state.dart';

class OnboardingScreen extends StatefulWidget {
  final ChatState state;

  const OnboardingScreen({super.key, required this.state});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

enum _OnboardingMode { activate, restore }

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _nameController = TextEditingController();
  final _phraseController = TextEditingController();
  final _codeController = TextEditingController();
  final _serverController = TextEditingController();

  _OnboardingMode _mode = _OnboardingMode.activate;
  bool _serverLoaded = false;
  bool _obscurePhrase = true;
  String _selectedKemAlg = 'ML-KEM-768';
  String _selectedDsaAlg = 'ML-DSA-65';

  @override
  void initState() {
    super.initState();
    _loadServerUrl();
  }

  Future<void> _loadServerUrl() async {
    final url = await StorageService().getBaseUrl();
    if (!mounted) return;
    _serverController.text = url;
    setState(() => _serverLoaded = true);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phraseController.dispose();
    _codeController.dispose();
    _serverController.dispose();
    super.dispose();
  }

  Future<bool> _saveServer() async {
    final value = _serverController.text.trim();
    if (value.isEmpty) {
      _showSnack('Alamat server tidak boleh kosong.');
      return false;
    }
    final ok = await widget.state.applyServerUrl(value);
    if (!ok) {
      _showSnack(widget.state.errorMessage ?? 'Alamat server tidak valid.');
    }
    return ok;
  }

  void _showSnack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  void _generatePhrase() {
    setState(() {
      _phraseController.text = CryptoService().generateRecoveryPhrase();
      _obscurePhrase = false;
    });
  }

  Future<void> _submitActivation() async {
    final code = _codeController.text.trim();
    final phrase = _phraseController.text.trim();
    if (code.isEmpty) {
      _showSnack('Masukkan kode aktivasi dari organisasi Anda.');
      return;
    }
    if (phrase.isEmpty) {
      _showSnack('Buat atau masukkan frasa pemulihan 12 kata.');
      return;
    }
    if (!await _saveServer()) return;
    final ok = await widget.state.activateAccount(
      activationCode: code,
      recoveryPhrase: phrase,
      displayName: _nameController.text,
      pqcKemAlg: _selectedKemAlg,
      pqcDsaAlg: _selectedDsaAlg,
    );
    if (!ok && mounted) {
      _showSnack(widget.state.errorMessage ?? 'Aktivasi gagal.');
    }
  }

  Future<void> _submitRestore() async {
    final phrase = _phraseController.text.trim();
    if (phrase.isEmpty) {
      _showSnack('Masukkan 12 kata frasa pemulihan Anda.');
      return;
    }
    if (!await _saveServer()) return;
    final ok = await widget.state.restoreIdentity(
      phrase,
      _nameController.text,
      pqcKemAlg: _selectedKemAlg,
      pqcDsaAlg: _selectedDsaAlg,
    );
    if (!ok && mounted) {
      _showSnack(widget.state.errorMessage ?? 'Pemulihan identitas gagal.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 480),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const SizedBox(height: 12),
                  Icon(
                    Icons.shield_outlined,
                    size: 58,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Secure Field Communication',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      letterSpacing: -0.4,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Akun disediakan oleh organisasi Anda. Aktivasi '
                    'menggunakan kredensial organisasi dan frasa pemulihan '
                    'yang dibuat di perangkat ini.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                      fontSize: 13,
                      height: 1.5,
                    ),
                  ),
                  const SizedBox(height: 24),
                  SegmentedButton<_OnboardingMode>(
                    segments: const [
                      ButtonSegment(
                        value: _OnboardingMode.activate,
                        icon: Icon(Icons.vpn_key_outlined, size: 18),
                        label: Text('Aktivasi'),
                      ),
                      ButtonSegment(
                        value: _OnboardingMode.restore,
                        icon: Icon(Icons.restore, size: 18),
                        label: Text('Pulihkan'),
                      ),
                    ],
                    selected: {_mode},
                    onSelectionChanged: (selection) => setState(() {
                      _mode = selection.first;
                      widget.state.clearError();
                    }),
                  ),
                  const SizedBox(height: 20),
                  if (_mode == _OnboardingMode.activate)
                    _buildActivationForm()
                  else
                    _buildRestoreForm(),
                  const SizedBox(height: 16),
                  _buildPqcSelectorSection(),
                  const SizedBox(height: 12),
                  _buildServerSection(),
                  if (widget.state.errorMessage != null) ...[
                    const SizedBox(height: 16),
                    _ErrorBox(message: widget.state.errorMessage!),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildActivationForm() {
    final state = widget.state;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        TextField(
          controller: _nameController,
          textInputAction: TextInputAction.next,
          decoration: const InputDecoration(
            labelText: 'Nama / Call-sign Agen',
            hintText: 'Contoh: Alpha, Bravo, Delta',
            prefixIcon: Icon(Icons.badge_outlined),
          ),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: _codeController,
          textInputAction: TextInputAction.next,
          autocorrect: false,
          enableSuggestions: false,
          decoration: const InputDecoration(
            labelText: 'Kode Aktivasi Organisasi',
            hintText: 'SFC-XXXX-XXXX-XXXX-XXXX',
            prefixIcon: Icon(Icons.vpn_key_outlined),
          ),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: _phraseController,
          obscureText: _obscurePhrase,
          autocorrect: false,
          enableSuggestions: false,
          minLines: _obscurePhrase ? 1 : 2,
          maxLines: _obscurePhrase ? 1 : 4,
          decoration: InputDecoration(
            labelText: 'Frasa Pemulihan 12 Kata',
            hintText: 'Kata-kata akan dibuat otomatis di perangkat ini',
            alignLabelWithHint: true,
            prefixIcon: const Icon(Icons.key_outlined),
            suffixIcon: IconButton(
              tooltip: _obscurePhrase ? 'Tampilkan' : 'Sembunyikan',
              icon: Icon(
                _obscurePhrase
                    ? Icons.visibility_outlined
                    : Icons.visibility_off_outlined,
              ),
              onPressed: () =>
                  setState(() => _obscurePhrase = !_obscurePhrase),
            ),
          ),
        ),
        const SizedBox(height: 10),
        OutlinedButton.icon(
          onPressed: state.isBusy ? null : _generatePhrase,
          icon: const Icon(Icons.auto_awesome, size: 18),
          label: const Text('Buat Frasa Baru'),
        ),
        const SizedBox(height: 14),
        FilledButton.icon(
          onPressed: state.isBusy ? null : _submitActivation,
          icon: state.isBusy
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Icon(Icons.verified_user_outlined),
          label: const Text('Aktifkan Akun'),
          style: FilledButton.styleFrom(
            padding: const EdgeInsets.symmetric(vertical: 16),
          ),
        ),
        const SizedBox(height: 10),
        Text(
          'Kode aktivasi hanya dapat digunakan sekali dan berlaku selama '
          '72 jam. Kunci privat tidak pernah dikirim ke server.',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 11,
            height: 1.5,
            color: Theme.of(context).colorScheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }

  Widget _buildRestoreForm() {
    final state = widget.state;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        TextField(
          controller: _nameController,
          textInputAction: TextInputAction.next,
          decoration: const InputDecoration(
            labelText: 'Nama / Call-sign Agen',
            prefixIcon: Icon(Icons.badge_outlined),
          ),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: _phraseController,
          obscureText: _obscurePhrase,
          autocorrect: false,
          enableSuggestions: false,
          minLines: _obscurePhrase ? 1 : 3,
          maxLines: _obscurePhrase ? 1 : 4,
          decoration: InputDecoration(
            labelText: '12 Kata Frasa Pemulihan',
            hintText: 'word one word two ...',
            alignLabelWithHint: true,
            prefixIcon: const Icon(Icons.key_outlined),
            suffixIcon: IconButton(
              tooltip: _obscurePhrase ? 'Tampilkan' : 'Sembunyikan',
              icon: Icon(
                _obscurePhrase
                    ? Icons.visibility_outlined
                    : Icons.visibility_off_outlined,
              ),
              onPressed: () =>
                  setState(() => _obscurePhrase = !_obscurePhrase),
            ),
          ),
        ),
        const SizedBox(height: 18),
        FilledButton.icon(
          onPressed: state.isBusy ? null : _submitRestore,
          icon: state.isBusy
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Icon(Icons.restore),
          label: const Text('Pulihkan Identitas'),
          style: FilledButton.styleFrom(
            padding: const EdgeInsets.symmetric(vertical: 16),
          ),
        ),
        const SizedBox(height: 10),
        Text(
          'Frasa yang sama menghasilkan kunci Ed25519 dan X25519 yang sama, '
          'sehingga identitas dan riwayat pesan Anda dapat dipulihkan.',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 11,
            height: 1.5,
            color: Theme.of(context).colorScheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }

  Widget _buildPqcSelectorSection() {
    return Theme(
      data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
      child: ExpansionTile(
        tilePadding: EdgeInsets.zero,
        childrenPadding: const EdgeInsets.only(bottom: 8),
        leading: const Icon(
          Icons.enhanced_encryption_outlined,
          size: 20,
          color: Colors.tealAccent,
        ),
        title: const Text(
          'Profil Standar NIST PQC (PERISAI-Q)',
          style: TextStyle(fontSize: 13),
        ),
        subtitle: Text(
          '$_selectedKemAlg (FIPS 203) + $_selectedDsaAlg (FIPS 204)',
          style: const TextStyle(fontSize: 11, color: Colors.tealAccent),
        ),
        children: [
          DropdownButtonFormField<String>(
            initialValue: _selectedKemAlg,
            decoration: const InputDecoration(
              labelText: 'Key Encapsulation (NIST FIPS 203)',
            ),
            items: const [
              DropdownMenuItem(
                value: 'ML-KEM-512',
                child: Text('ML-KEM-512 (Kategori 1 - Ringan)'),
              ),
              DropdownMenuItem(
                value: 'ML-KEM-768',
                child: Text('ML-KEM-768 (Kategori 3 - Rekomendasi)'),
              ),
              DropdownMenuItem(
                value: 'ML-KEM-1024',
                child: Text('ML-KEM-1024 (Kategori 5 - Maksimum)'),
              ),
            ],
            onChanged: (v) {
              if (v != null) setState(() => _selectedKemAlg = v);
            },
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            initialValue: _selectedDsaAlg,
            decoration: const InputDecoration(
              labelText: 'Digital Signature (NIST FIPS 204)',
            ),
            items: const [
              DropdownMenuItem(
                value: 'ML-DSA-44',
                child: Text('ML-DSA-44 (Kategori 2 - Ringkas)'),
              ),
              DropdownMenuItem(
                value: 'ML-DSA-65',
                child: Text('ML-DSA-65 (Kategori 3 - Rekomendasi)'),
              ),
              DropdownMenuItem(
                value: 'ML-DSA-87',
                child: Text('ML-DSA-87 (Kategori 5 - Maksimum)'),
              ),
            ],
            onChanged: (v) {
              if (v != null) setState(() => _selectedDsaAlg = v);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildServerSection() {
    return Theme(
      data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
      child: ExpansionTile(
        tilePadding: EdgeInsets.zero,
        childrenPadding: const EdgeInsets.only(bottom: 8),
        leading: const Icon(Icons.dns_outlined, size: 20),
        title: const Text(
          'Alamat Server Backend',
          style: TextStyle(fontSize: 13),
        ),
        subtitle: Text(
          _serverLoaded ? _serverController.text : 'Memuat...',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontSize: 11,
            color: Theme.of(context).colorScheme.onSurfaceVariant,
          ),
        ),
        children: [
          TextField(
            controller: _serverController,
            keyboardType: TextInputType.url,
            autocorrect: false,
            decoration: const InputDecoration(
              hintText: 'http://10.0.2.2:8000/api/v1',
              prefixIcon: Icon(Icons.link),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Android emulator: http://10.0.2.2:8000/api/v1\n'
            'Web / desktop: http://localhost:8000/api/v1\n'
            'Perangkat fisik: gunakan IP LAN komputer Anda.',
            style: TextStyle(
              fontSize: 11,
              height: 1.5,
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}

class _ErrorBox extends StatelessWidget {
  final String message;

  const _ErrorBox({required this.message});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.redAccent.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.redAccent.withValues(alpha: 0.4)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.error_outline, color: Colors.redAccent, size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              message,
              style: const TextStyle(color: Colors.redAccent, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }
}
