import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

import '../models/contact.dart';
import '../models/conversation.dart';
import '../models/conversation_detail.dart';
import '../models/directory_member.dart';
import '../models/identity.dart';
import '../models/message.dart';
import '../models/perisai_models.dart';
import '../services/api_service.dart';
import '../services/crypto_service.dart';
import '../services/pqc_service.dart';
import '../services/storage_service.dart';
import '../services/websocket_service.dart';

typedef _DerivedKeys = ({
  String authPublic,
  String authPrivate,
  String devicePublic,
  String devicePrivate,
  String pqcKemAlg,
  String pqcKemPublic,
  String pqcKemPrivate,
  String pqcDsaAlg,
  String pqcDsaPublic,
  String pqcDsaPrivate,
  String fingerprint,
  String publicIdentity,
});

class ChatState extends ChangeNotifier {
  final _crypto = CryptoService();
  final _pqc = PqcService();
  final _storage = StorageService();
  final _api = ApiService();
  final _ws = WebSocketService();
  final _uuid = const Uuid();

  LocalIdentity? _identity;
  bool _bootstrapping = true;
  bool _busy = false;
  bool _sending = false;
  bool _syncing = false;
  bool _ensuringSession = false;
  bool _offlineSimulated = false;
  String? _errorMessage;

  List<ContactModel> _contacts = [];
  List<ConversationModel> _personal = [];
  List<ConversationModel> _groups = [];
  final Map<String, ConversationDetail> _details = {};
  final Map<String, String> _identityNames = {};

  ConversationModel? _activeConversation;
  List<ChatMessage> _messages = [];
  Timer? _pollingTimer;

  // PERISAI-Q State
  List<VaultItem> _vaultItems = [];
  List<OutboxQueueItem> _outboxItems = [];
  List<SignedArtifactModel> _signedArtifacts = [];
  List<Map<String, dynamic>> _signAuditLogs = [];
  Map<String, dynamic>? _lastQuantumSimulation;
  Map<String, dynamic>? _lastFleetAudit;
  Map<String, dynamic>? _lastBenchmark;

  LocalIdentity? get identity => _identity;
  bool get isBootstrapping => _bootstrapping;
  bool get isBusy => _busy;
  bool get isSending => _sending;
  bool get isOfflineSimulated => _offlineSimulated;
  String? get errorMessage => _errorMessage;
  List<ContactModel> get contacts => List.unmodifiable(_contacts);
  List<ConversationModel> get personalConversations =>
      List.unmodifiable(_personal);
  List<ConversationModel> get groups => List.unmodifiable(_groups);
  ConversationModel? get activeConversation => _activeConversation;
  List<ChatMessage> get messages => List.unmodifiable(_messages);
  bool get isWsConnected => _ws.isConnected && !_offlineSimulated;
  String? get organizationName => _identity?.organizationName;

  List<VaultItem> get vaultItems => List.unmodifiable(_vaultItems);
  List<OutboxQueueItem> get outboxItems => List.unmodifiable(_outboxItems);
  List<SignedArtifactModel> get signedArtifacts =>
      List.unmodifiable(_signedArtifacts);
  List<Map<String, dynamic>> get signAuditLogs =>
      List.unmodifiable(_signAuditLogs);
  Map<String, dynamic>? get lastQuantumSimulation => _lastQuantumSimulation;
  Map<String, dynamic>? get lastFleetAudit => _lastFleetAudit;
  Map<String, dynamic>? get lastBenchmark => _lastBenchmark;

  int get queuedOutboxCount =>
      _outboxItems.where((i) => i.status == 'QUEUED').length;

  // ---------------------------------------------------------------------------
  // Bootstrap / session
  // ---------------------------------------------------------------------------

  Future<void> init() async {
    try {
      _identity = await _storage.getIdentity();
      _vaultItems = await _storage.getVaultItems();
      _outboxItems = await _storage.getOutboxItems();

      // Auto-upgrade existing LocalIdentity with Sheetphrase PQC keys if missing
      if (_identity != null &&
          !_identity!.hasPqcKeys &&
          _identity!.recoveryPhrase.isNotEmpty) {
        final kemKp = await _crypto.pqcKemKeyPairFromPhrase(
          _identity!.recoveryPhrase,
          algorithm: _identity!.pqcKemAlg,
        );
        final dsaKp = await _crypto.pqcDsaKeyPairFromPhrase(
          _identity!.recoveryPhrase,
          algorithm: _identity!.pqcDsaAlg,
        );
        _identity = _identity!.copyWith(
          pqcKemPublicKey: kemKp.publicKeyB64,
          pqcKemPrivateKey: kemKp.secretKeyB64,
          pqcDsaPublicKey: dsaKp.publicKeyB64,
          pqcDsaPrivateKey: dsaKp.secretKeyB64,
        );
        await _storage.saveIdentity(_identity!);
      }
    } catch (e) {
      _errorMessage = _humanError(e);
    } finally {
      _bootstrapping = false;
      notifyListeners();
    }

    if (_identity != null && _identity!.recoveryConfirmed) {
      unawaited(ensureReady());
    }
  }

  Future<void> ensureReady() async {
    if (_identity == null || _ensuringSession) return;
    _ensuringSession = true;
    try {
      _errorMessage = null;
      await _authenticateAndConnect();
      await refreshAll();
      _startBackgroundSync();
    } catch (e) {
      _errorMessage = _humanError(e);
    } finally {
      _ensuringSession = false;
      notifyListeners();
    }
  }

  Future<void> _authenticateAndConnect() async {
    final identity = _identity;
    if (identity == null) return;

    final challenge = await _api.requestChallengeById(identity.deviceId);
    final challengeId = challenge['challenge_id'] as String;
    final nonce = challenge['nonce'] as String;
    final deviceId = challenge['device_id']?.toString() ?? identity.deviceId;

    final authKeyPair = await _crypto.restoreAuthKeyPair(
      identity.authPrivateKey,
    );
    final signature = await _crypto.signNonce(nonce, authKeyPair);
    final pqcSignature = identity.pqcDsaPrivateKey.isNotEmpty
        ? await _crypto.signNoncePqc(
            nonce,
            dsaAlgorithm: identity.pqcDsaAlg,
            dsaPrivateKeyB64: identity.pqcDsaPrivateKey,
          )
        : null;

    final verified = await _api.verifyChallenge(
      challengeId: challengeId,
      deviceId: deviceId,
      signature: signature,
      pqcSignature: pqcSignature,
    );

    _identity = identity.copyWith(
      deviceId: deviceId,
      publicIdentity:
          verified['public_identity']?.toString() ?? identity.publicIdentity,
      displayName: verified['display_name']?.toString() ?? identity.displayName,
      organizationId: verified['organization_id']?.toString(),
      organizationName: verified['organization_name']?.toString(),
      accountStatus: verified['account_status']?.toString() ?? 'active',
    );
    await _storage.saveIdentity(_identity!);

    // Ensure backend has this device's PQC public keys registered
    if (_identity!.hasPqcKeys && verified['pqc_kem_public_key'] == null) {
      try {
        await _api.updateDevicePqcKeys(
          deviceId,
          pqcKemAlg: _identity!.pqcKemAlg,
          pqcKemPublicKey: _identity!.pqcKemPublicKey,
          pqcDsaAlg: _identity!.pqcDsaAlg,
          pqcDsaPublicKey: _identity!.pqcDsaPublicKey,
        );
      } catch (_) {}
    }

    _ws.onMessageAvailable = (messageId, conversationId) {
      if (_activeConversation?.conversationId == conversationId) {
        loadConversationMessages(conversationId);
      } else {
        refreshAll();
      }
      _ws.acknowledgeMessage(messageId);
    };
    _ws.onGroupMembershipChanged = (groupId, keyEpoch) {
      refreshGroups();
      if (_activeConversation?.conversationId == groupId) {
        _loadConversation(groupId);
      }
    };
    _ws.onConversationStarted = () => refreshPersonal();

    if (!_offlineSimulated) {
      await _ws.connect();
    }
  }

  // ---------------------------------------------------------------------------
  // Activation, Restore & PQC Key Rotation (Crypto-Agility)
  // ---------------------------------------------------------------------------

  Future<_DerivedKeys> _deriveKeys(
    String phrase, {
    String kemAlg = 'ML-KEM-768',
    String dsaAlg = 'ML-DSA-65',
  }) async {
    final authKeyPair = await _crypto.authKeyPairFromPhrase(phrase);
    final deviceKeyPair = await _crypto.deviceKeyPairFromPhrase(phrase);
    final kemKeyPair = await _crypto.pqcKemKeyPairFromPhrase(
      phrase,
      algorithm: kemAlg,
    );
    final dsaKeyPair = await _crypto.pqcDsaKeyPairFromPhrase(
      phrase,
      algorithm: dsaAlg,
    );

    final authPublic = await _crypto.publicKeyToBase64(authKeyPair);
    final authPrivate = await _crypto.privateKeyToBase64(authKeyPair);
    final devicePublic = await _crypto.publicKeyToBase64(deviceKeyPair);
    final devicePrivate = await _crypto.privateKeyToBase64(deviceKeyPair);
    final fingerprint = await _crypto.fingerprintForPublicKey(authPublic);

    return (
      authPublic: authPublic,
      authPrivate: authPrivate,
      devicePublic: devicePublic,
      devicePrivate: devicePrivate,
      pqcKemAlg: kemKeyPair.algorithm,
      pqcKemPublic: kemKeyPair.publicKeyB64,
      pqcKemPrivate: kemKeyPair.secretKeyB64,
      pqcDsaAlg: dsaKeyPair.algorithm,
      pqcDsaPublic: dsaKeyPair.publicKeyB64,
      pqcDsaPrivate: dsaKeyPair.secretKeyB64,
      fingerprint: fingerprint,
      publicIdentity: 'AGENT_${fingerprint.substring(0, 10).toUpperCase()}',
    );
  }

  Future<bool> activateAccount({
    required String activationCode,
    required String recoveryPhrase,
    required String displayName,
    String pqcKemAlg = 'ML-KEM-768',
    String pqcDsaAlg = 'ML-DSA-65',
  }) async {
    _setBusy(true);
    _errorMessage = null;
    try {
      final normalized = _crypto.normalizePhrase(recoveryPhrase);
      if (!_crypto.isValidPhrase(normalized)) {
        throw ApiException('Frasa pemulihan harus terdiri dari 12 kata.');
      }
      final name = displayName.trim().isEmpty
          ? 'Field Agent'
          : displayName.trim();

      // Validate the code first so the user sees which organization issued it.
      await _api.verifyActivation(activationCode);

      final keys = await _deriveKeys(
        normalized,
        kemAlg: pqcKemAlg,
        dsaAlg: pqcDsaAlg,
      );
      final deviceName = name.length > 80 ? name.substring(0, 80) : name;

      final result = await _api.completeActivation(
        code: activationCode,
        identityFingerprint: keys.fingerprint,
        deviceName: '$deviceName Terminal',
        publicDeviceKey: keys.devicePublic,
        authPublicKey: keys.authPublic,
        pqcKemAlg: keys.pqcKemAlg,
        pqcKemPublicKey: keys.pqcKemPublic,
        pqcDsaAlg: keys.pqcDsaAlg,
        pqcDsaPublicKey: keys.pqcDsaPublic,
      );

      final identity = LocalIdentity(
        identityId: result['identity_id'] as String,
        deviceId: result['device_id'] as String,
        publicIdentity:
            result['public_identity']?.toString() ?? keys.publicIdentity,
        identityFingerprint:
            result['identity_fingerprint']?.toString() ?? keys.fingerprint,
        publicDeviceKey: keys.devicePublic,
        authPublicKey: keys.authPublic,
        devicePrivateKey: keys.devicePrivate,
        authPrivateKey: keys.authPrivate,
        pqcKemAlg: keys.pqcKemAlg,
        pqcKemPublicKey: keys.pqcKemPublic,
        pqcKemPrivateKey: keys.pqcKemPrivate,
        pqcDsaAlg: keys.pqcDsaAlg,
        pqcDsaPublicKey: keys.pqcDsaPublic,
        pqcDsaPrivateKey: keys.pqcDsaPrivate,
        recoveryPhrase: normalized,
        displayName: name,
        recoveryConfirmed: true,
        organizationId: result['organization_id']?.toString(),
        organizationName: result['organization_name']?.toString(),
        accountStatus: result['account_status']?.toString() ?? 'active',
      );
      _identity = identity;
      await _storage.saveIdentity(identity);

      await _authenticateAndConnect();
      await refreshAll();
      _startBackgroundSync();
      return true;
    } catch (e) {
      _errorMessage = _humanError(e);
      return false;
    } finally {
      _setBusy(false);
    }
  }

  Future<bool> restoreIdentity(
    String phrase,
    String displayName, {
    String pqcKemAlg = 'ML-KEM-768',
    String pqcDsaAlg = 'ML-DSA-65',
  }) async {
    _setBusy(true);
    _errorMessage = null;
    try {
      final normalized = _crypto.normalizePhrase(phrase);
      if (!_crypto.isValidPhrase(normalized)) {
        throw ApiException('Frasa pemulihan harus terdiri dari 12 kata.');
      }
      final name = displayName.trim().isEmpty
          ? 'Field Agent'
          : displayName.trim();

      final keys = await _deriveKeys(
        normalized,
        kemAlg: pqcKemAlg,
        dsaAlg: pqcDsaAlg,
      );
      final challenge = await _api.requestChallengeByPublicKey(keys.authPublic);

      final challengeId = challenge['challenge_id'] as String;
      final nonce = challenge['nonce'] as String;
      final deviceId = challenge['device_id']?.toString();
      if (deviceId == null || deviceId.isEmpty) {
        throw ApiException(
          'Perangkat untuk identitas ini tidak ditemukan atau sudah dicabut.',
        );
      }

      final authKeyPair = await _crypto.restoreAuthKeyPair(keys.authPrivate);
      final signature = await _crypto.signNonce(nonce, authKeyPair);
      await _api.verifyChallenge(
        challengeId: challengeId,
        deviceId: deviceId,
        signature: signature,
      );

      var publicIdentity =
          challenge['public_identity']?.toString() ?? keys.publicIdentity;
      var organizationId = challenge['organization_id']?.toString();
      var organizationName = challenge['organization_name']?.toString();
      var accountStatus = challenge['account_status']?.toString() ?? 'active';

      try {
        final me = await _api.getMe();
        final identityData = me['identity'];
        if (identityData is Map) {
          publicIdentity =
              identityData['public_identity']?.toString() ?? publicIdentity;
          organizationId = me['organization']?['organization_id']?.toString();
          organizationName = me['organization']?['organization_name']
              ?.toString();
          accountStatus = identityData['status']?.toString() ?? accountStatus;
        }
      } catch (_) {}

      final identity = LocalIdentity(
        identityId: challenge['identity_id']?.toString() ?? '',
        deviceId: deviceId,
        publicIdentity: publicIdentity,
        identityFingerprint: keys.fingerprint,
        publicDeviceKey: keys.devicePublic,
        authPublicKey: keys.authPublic,
        devicePrivateKey: keys.devicePrivate,
        authPrivateKey: keys.authPrivate,
        pqcKemAlg: keys.pqcKemAlg,
        pqcKemPublicKey: keys.pqcKemPublic,
        pqcKemPrivateKey: keys.pqcKemPrivate,
        pqcDsaAlg: keys.pqcDsaAlg,
        pqcDsaPublicKey: keys.pqcDsaPublic,
        pqcDsaPrivateKey: keys.pqcDsaPrivate,
        recoveryPhrase: normalized,
        displayName: name,
        recoveryConfirmed: true,
        organizationId: organizationId,
        organizationName: organizationName,
        accountStatus: accountStatus,
      );
      _identity = identity;
      await _storage.saveIdentity(identity);

      try {
        await _api.updateDevicePqcKeys(
          deviceId,
          pqcKemAlg: keys.pqcKemAlg,
          pqcKemPublicKey: keys.pqcKemPublic,
          pqcDsaAlg: keys.pqcDsaAlg,
          pqcDsaPublicKey: keys.pqcDsaPublic,
        );
      } catch (_) {}

      _ws.onMessageAvailable = (messageId, conversationId) {
        if (_activeConversation?.conversationId == conversationId) {
          loadConversationMessages(conversationId);
        } else {
          refreshAll();
        }
        _ws.acknowledgeMessage(messageId);
      };
      _ws.onGroupMembershipChanged = (groupId, keyEpoch) {
        refreshGroups();
        if (_activeConversation?.conversationId == groupId) {
          _loadConversation(groupId);
        }
      };
      _ws.onConversationStarted = () => refreshPersonal();
      await _ws.connect();

      await refreshAll();
      _startBackgroundSync();
      return true;
    } catch (e) {
      _errorMessage = _humanError(e);
      return false;
    } finally {
      _setBusy(false);
    }
  }

  /// Switch / rotate NIST PQC parameter sets (ML-KEM-512/768/1024 & ML-DSA-44/65/87).
  Future<bool> rotatePqcProfile({
    required String kemAlg,
    required String dsaAlg,
  }) async {
    final current = _identity;
    if (current == null) return false;
    _setBusy(true);
    _errorMessage = null;
    try {
      final kemKp = current.recoveryPhrase.isNotEmpty
          ? await _crypto.pqcKemKeyPairFromPhrase(
              current.recoveryPhrase,
              algorithm: kemAlg,
            )
          : await _pqc.mlKemKeygen(kemAlg);
      final dsaKp = current.recoveryPhrase.isNotEmpty
          ? await _crypto.pqcDsaKeyPairFromPhrase(
              current.recoveryPhrase,
              algorithm: dsaAlg,
            )
          : await _pqc.mlDsaKeygen(dsaAlg);

      _identity = current.copyWith(
        pqcKemAlg: kemKp.algorithm,
        pqcKemPublicKey: kemKp.publicKeyB64,
        pqcKemPrivateKey: kemKp.secretKeyB64,
        pqcDsaAlg: dsaKp.algorithm,
        pqcDsaPublicKey: dsaKp.publicKeyB64,
        pqcDsaPrivateKey: dsaKp.secretKeyB64,
      );
      await _storage.saveIdentity(_identity!);

      if (!_offlineSimulated) {
        try {
          await _api.updateDevicePqcKeys(
            current.deviceId,
            pqcKemAlg: kemKp.algorithm,
            pqcKemPublicKey: kemKp.publicKeyB64,
            pqcDsaAlg: dsaKp.algorithm,
            pqcDsaPublicKey: dsaKp.publicKeyB64,
          );
        } catch (_) {}
      }
      notifyListeners();
      return true;
    } catch (e) {
      _errorMessage = _humanError(e);
      return false;
    } finally {
      _setBusy(false);
    }
  }

  // ---------------------------------------------------------------------------
  // Data loading
  // ---------------------------------------------------------------------------

  Future<void> refreshAll() async {
    if (_offlineSimulated) return;
    await Future.wait([
      refreshContacts(),
      refreshPersonal(),
      refreshGroups(),
      refreshSignedArtifacts(),
    ]);
  }

  Future<void> refreshContacts() async {
    if (_identity == null || _offlineSimulated) return;
    try {
      final list = await _api.getContacts();
      _contacts = list.map(ContactModel.fromJson).toList();
      notifyListeners();
    } catch (e) {
      _errorMessage = _humanError(e);
      notifyListeners();
    }
  }

  Future<void> refreshPersonal() async {
    if (_identity == null || _offlineSimulated) return;
    try {
      final list = await _api.getPersonalConversations();
      final conversations = list.map(ConversationModel.fromJson).toList()
        ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
      _personal = conversations;

      final active = _activeConversation;
      if (active != null) {
        final updated = _findPersonal(active.conversationId);
        if (updated != null) _activeConversation = updated;
      }
      notifyListeners();
    } catch (e) {
      _errorMessage = _humanError(e);
      notifyListeners();
    }
  }

  Future<void> refreshGroups() async {
    if (_identity == null || _offlineSimulated) return;
    try {
      final list = await _api.getGroups();
      final conversations = list.map(ConversationModel.fromJson).toList()
        ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
      _groups = conversations;

      final active = _activeConversation;
      if (active != null && active.conversationType == 'group') {
        final updated = _findGroup(active.conversationId);
        if (updated != null) _activeConversation = updated;
      }
      notifyListeners();
    } catch (e) {
      _errorMessage = _humanError(e);
      notifyListeners();
    }
  }

  Future<List<DirectoryMember>> searchDirectory(String? query) async {
    final list = await _api.getDirectoryMembers(search: query);
    return list.map(DirectoryMember.fromJson).toList();
  }

  // ---------------------------------------------------------------------------
  // Contacts
  // ---------------------------------------------------------------------------

  Future<bool> addContactByIdentityId(String identityId) async {
    _setBusy(true);
    _errorMessage = null;
    try {
      await _api.addContact(contactIdentityId: identityId.trim());
      await refreshContacts();
      return true;
    } catch (e) {
      _errorMessage = _humanError(e);
      return false;
    } finally {
      _setBusy(false);
    }
  }

  Future<bool> deleteContact(ContactModel contact) async {
    _setBusy(true);
    _errorMessage = null;
    try {
      await _api.deleteContact(contact.contactId);
      await refreshContacts();
      return true;
    } catch (e) {
      _errorMessage = _humanError(e);
      return false;
    } finally {
      _setBusy(false);
    }
  }

  // ---------------------------------------------------------------------------
  // Personal conversations
  // ---------------------------------------------------------------------------

  Future<ConversationModel?> createDirectConversation(
    String peerIdentityId,
  ) async {
    _setBusy(true);
    _errorMessage = null;
    try {
      final data = await _api.createDirectConversation(peerIdentityId);
      final conversation = ConversationModel.fromJson(data);
      _upsertPersonal(conversation);
      selectConversation(conversation);
      return conversation;
    } catch (e) {
      _errorMessage = _humanError(e);
      return null;
    } finally {
      _setBusy(false);
    }
  }

  ConversationModel? _findPersonal(String conversationId) {
    for (final conversation in _personal) {
      if (conversation.conversationId == conversationId) return conversation;
    }
    return null;
  }

  void _upsertPersonal(ConversationModel conversation) {
    final index = _personal.indexWhere(
      (item) => item.conversationId == conversation.conversationId,
    );
    if (index >= 0) {
      _personal[index] = conversation;
    } else {
      _personal.insert(0, conversation);
    }
    _personal.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    notifyListeners();
  }

  // ---------------------------------------------------------------------------
  // Groups
  // ---------------------------------------------------------------------------

  Future<ConversationModel?> createGroup({
    required String title,
    required List<String> memberIdentityIds,
  }) async {
    _setBusy(true);
    _errorMessage = null;
    try {
      final data = await _api.createGroup(
        title: title.trim(),
        memberIdentityIds: memberIdentityIds,
      );
      final group = ConversationModel.fromJson(data);
      _upsertGroup(group);
      selectConversation(group);
      return group;
    } catch (e) {
      _errorMessage = _humanError(e);
      return null;
    } finally {
      _setBusy(false);
    }
  }

  ConversationModel? _findGroup(String groupId) {
    for (final group in _groups) {
      if (group.conversationId == groupId) return group;
    }
    return null;
  }

  void _upsertGroup(ConversationModel group) {
    final index = _groups.indexWhere(
      (item) => item.conversationId == group.conversationId,
    );
    if (index >= 0) {
      _groups[index] = group;
    } else {
      _groups.insert(0, group);
    }
    _groups.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    notifyListeners();
  }

  Future<bool> addGroupMember(String groupId, String identityId) async {
    _setBusy(true);
    _errorMessage = null;
    try {
      final data = await _api.addGroupMember(groupId, identityId);
      _upsertGroup(ConversationModel.fromJson(data));
      await _loadDetail(groupId);
      return true;
    } catch (e) {
      _errorMessage = _humanError(e);
      return false;
    } finally {
      _setBusy(false);
    }
  }

  Future<bool> removeGroupMember(String groupId, String identityId) async {
    _setBusy(true);
    _errorMessage = null;
    try {
      await _api.removeGroupMember(groupId, identityId);
      await refreshGroups();
      await _loadDetail(groupId);
      return true;
    } catch (e) {
      _errorMessage = _humanError(e);
      return false;
    } finally {
      _setBusy(false);
    }
  }

  Future<bool> leaveGroup(String groupId) async {
    _setBusy(true);
    _errorMessage = null;
    try {
      await _api.leaveGroup(groupId);
      if (_activeConversation?.conversationId == groupId) {
        _activeConversation = null;
        _messages = [];
      }
      await refreshGroups();
      return true;
    } catch (e) {
      _errorMessage = _humanError(e);
      return false;
    } finally {
      _setBusy(false);
    }
  }

  Future<bool> renameGroup(String groupId, String title) async {
    _setBusy(true);
    _errorMessage = null;
    try {
      final data = await _api.updateGroupTitle(groupId, title);
      _upsertGroup(ConversationModel.fromJson(data));
      await _loadDetail(groupId);
      return true;
    } catch (e) {
      _errorMessage = _humanError(e);
      return false;
    } finally {
      _setBusy(false);
    }
  }

  // ---------------------------------------------------------------------------
  // Active conversation & Hybrid PQC Messaging
  // ---------------------------------------------------------------------------

  void selectConversation(ConversationModel conversation) {
    _activeConversation = conversation;
    _messages = [];
    notifyListeners();
    unawaited(_loadConversation(conversation.conversationId));
  }

  void closeConversation() {
    _activeConversation = null;
    _messages = [];
    notifyListeners();
  }

  Future<void> _loadConversation(String conversationId) async {
    try {
      await _loadDetail(conversationId);
      await loadConversationMessages(conversationId);
    } catch (e) {
      _errorMessage = _humanError(e);
      notifyListeners();
    }
  }

  Future<ConversationDetail> _loadDetail(String conversationId) async {
    final active = _activeConversation;
    final isGroup =
        active?.conversationType == 'group' ||
        _findGroup(conversationId) != null;
    final data = isGroup
        ? await _api.getGroupDetail(conversationId)
        : await _api.getConversationDetail(conversationId);
    final detail = ConversationDetail.fromJson(data);
    _details[conversationId] = detail;
    _identityNames.addAll(detail.identityNames);
    notifyListeners();
    return detail;
  }

  ConversationDetail? detailFor(String conversationId) =>
      _details[conversationId];

  Future<void> refreshGroupDetail(String conversationId) =>
      _loadDetail(conversationId);

  Future<void> loadConversationMessages(String conversationId) async {
    final identity = _identity;
    if (identity == null || _offlineSimulated) return;

    try {
      final detail =
          _details[conversationId] ?? await _loadDetail(conversationId);
      final rawMessages = await _api.getConversationMessages(conversationId);
      final devicePublicKeys = detail.devicePublicKeys;
      final devicePqcDsaKeys = detail.devicePqcDsaPublicKeys;
      final deviceOwners = detail.deviceOwnerIdentityIds;

      final decrypted = <ChatMessage>[];
      for (final raw in rawMessages) {
        final senderDevice = raw['sender_device_id']?.toString() ?? '';
        final senderPublicKey = devicePublicKeys[senderDevice];
        final senderDsaPub = devicePqcDsaKeys[senderDevice];
        final decRes = await _crypto.decryptEnvelopeForDevice(
          raw['ciphertext']?.toString() ?? '',
          conversationId: conversationId,
          myDeviceId: identity.deviceId,
          myPrivateKey: identity.devicePrivateKey,
          senderPublicKey: senderPublicKey,
          myPqcKemPrivateKey: identity.pqcKemPrivateKey,
          myPqcKemAlg: identity.pqcKemAlg,
          senderPqcDsaPublicKey: senderDsaPub,
        );

        final ownerIdentityId = deviceOwners[senderDevice];
        final senderName = ownerIdentityId == null
            ? null
            : _displayNameFor(ownerIdentityId);

        decrypted.add(
          ChatMessage.fromJson(
            raw,
            myDeviceId: identity.deviceId,
            decrypted: decRes.plaintext,
            senderName: senderName,
            isHybridPqc: decRes.isHybridPqc,
            pqcKemAlg: decRes.pqcKemAlg,
            pqcDsaAlg: decRes.pqcDsaAlg,
            pqcSignatureVerified: decRes.pqcSignatureVerified,
          ),
        );
      }

      // Append any locally queued offline messages for this conversation
      for (final queued in _outboxItems.where(
        (q) => q.conversationId == conversationId && q.status == 'QUEUED',
      )) {
        decrypted.add(
          ChatMessage(
            messageId: 'queued-${queued.clientMessageId}',
            conversationId: conversationId,
            senderDeviceId: identity.deviceId,
            clientMessageId: queued.clientMessageId,
            messageType: 'text',
            ciphertext: queued.ciphertext,
            decryptedText: queued.plaintextPreview,
            createdAt: queued.queuedAt,
            isMe: true,
            senderName: identity.displayName,
            deliveryStatus: 'queued_offline',
            keyEpoch: queued.keyEpoch,
            isHybridPqc: true,
            pqcKemAlg: queued.pqcKemAlg,
            pqcDsaAlg: queued.pqcDsaAlg,
            pqcSignatureVerified: true,
          ),
        );
      }

      decrypted.sort((a, b) => a.createdAt.compareTo(b.createdAt));

      if (_activeConversation?.conversationId == conversationId) {
        _messages = decrypted;
        notifyListeners();
      }
    } catch (e) {
      _errorMessage = _humanError(e);
      notifyListeners();
    }
  }

  Future<bool> sendMessage(String text) async {
    final content = text.trim();
    final identity = _identity;
    final conversation = _activeConversation;
    if (content.isEmpty ||
        identity == null ||
        conversation == null ||
        _sending) {
      return false;
    }

    _sending = true;
    _errorMessage = null;
    final clientMessageId = _uuid.v4();
    final tempId = 'temp-$clientMessageId';
    notifyListeners();

    try {
      final detail =
          _details[conversation.conversationId] ??
          await _loadDetail(conversation.conversationId);

      final recipients = Map<String, String>.from(detail.devicePublicKeys);
      recipients[identity.deviceId] = identity.publicDeviceKey;

      final pqcKemRecipients = Map<String, String>.from(
        detail.devicePqcKemPublicKeys,
      );
      if (identity.pqcKemPublicKey.isNotEmpty) {
        pqcKemRecipients[identity.deviceId] = identity.pqcKemPublicKey;
      }

      final pqcKemAlgs = Map<String, String>.from(detail.devicePqcKemAlgs);
      pqcKemAlgs[identity.deviceId] = identity.pqcKemAlg;

      if (recipients.isEmpty) {
        throw ApiException('Tidak ada perangkat aktif di percakapan ini.');
      }

      final ciphertext = await _crypto.encryptForDevices(
        content,
        conversationId: conversation.conversationId,
        myPrivateKey: identity.devicePrivateKey,
        recipientPublicKeys: recipients,
        keyEpoch: detail.keyEpoch,
        recipientPqcKemPublicKeys: pqcKemRecipients,
        recipientPqcKemAlgs: pqcKemAlgs,
        myPqcKemAlg: identity.pqcKemAlg,
        myPqcDsaAlg: identity.pqcDsaAlg,
        myPqcDsaPrivateKey: identity.pqcDsaPrivateKey,
        myPqcDsaPublicKey: identity.pqcDsaPublicKey,
      );

      // If in simulated offline tactical mode, queue directly into Offline Outbox
      if (_offlineSimulated) {
        await _enqueueOutboxItem(
          clientMessageId: clientMessageId,
          conversation: conversation,
          ciphertext: ciphertext,
          plaintextPreview: content,
          keyEpoch: detail.keyEpoch,
          identity: identity,
        );
        return true;
      }

      _messages.add(
        ChatMessage(
          messageId: tempId,
          conversationId: conversation.conversationId,
          senderDeviceId: identity.deviceId,
          clientMessageId: clientMessageId,
          messageType: 'text',
          ciphertext: ciphertext,
          decryptedText: content,
          createdAt: DateTime.now(),
          isMe: true,
          senderName: identity.displayName,
          deliveryStatus: 'pending',
          keyEpoch: detail.keyEpoch,
          isHybridPqc: true,
          pqcKemAlg: identity.pqcKemAlg,
          pqcDsaAlg: identity.pqcDsaAlg,
          pqcSignatureVerified: true,
        ),
      );
      notifyListeners();

      await _api.sendMessage(
        conversationId: conversation.conversationId,
        clientMessageId: clientMessageId,
        ciphertext: ciphertext,
        keyEpoch: detail.keyEpoch,
      );
      await loadConversationMessages(conversation.conversationId);
      return true;
    } on ApiException catch (e) {
      _messages.removeWhere((message) => message.messageId == tempId);
      if (e.code == 'KEY_EPOCH_STALE') {
        await _loadDetail(conversation.conversationId);
        _errorMessage =
            'Keanggotaan grup berubah. Daftar anggota diperbarui, silakan '
            'kirim ulang pesan Anda.';
      } else if (e.statusCode == null) {
        // Network unreachable -> automatically store in Offline Outbox Queue!
        final detail = _details[conversation.conversationId];
        if (detail != null) {
          final recipients = Map<String, String>.from(detail.devicePublicKeys);
          recipients[identity.deviceId] = identity.publicDeviceKey;
          final pqcKemRecipients = Map<String, String>.from(
            detail.devicePqcKemPublicKeys,
          );
          if (identity.pqcKemPublicKey.isNotEmpty) {
            pqcKemRecipients[identity.deviceId] = identity.pqcKemPublicKey;
          }
          final ciphertext = await _crypto.encryptForDevices(
            content,
            conversationId: conversation.conversationId,
            myPrivateKey: identity.devicePrivateKey,
            recipientPublicKeys: recipients,
            keyEpoch: detail.keyEpoch,
            recipientPqcKemPublicKeys: pqcKemRecipients,
            myPqcKemAlg: identity.pqcKemAlg,
            myPqcDsaAlg: identity.pqcDsaAlg,
            myPqcDsaPrivateKey: identity.pqcDsaPrivateKey,
            myPqcDsaPublicKey: identity.pqcDsaPublicKey,
          );
          await _enqueueOutboxItem(
            clientMessageId: clientMessageId,
            conversation: conversation,
            ciphertext: ciphertext,
            plaintextPreview: content,
            keyEpoch: detail.keyEpoch,
            identity: identity,
          );
          return true;
        }
        _errorMessage = _humanError(e);
      } else {
        _errorMessage = _humanError(e);
      }
      notifyListeners();
      return false;
    } catch (e) {
      _messages.removeWhere((message) => message.messageId == tempId);
      _errorMessage = _humanError(e);
      notifyListeners();
      return false;
    } finally {
      _sending = false;
      notifyListeners();
    }
  }

  Future<void> _enqueueOutboxItem({
    required String clientMessageId,
    required ConversationModel conversation,
    required String ciphertext,
    required String plaintextPreview,
    required int keyEpoch,
    required LocalIdentity identity,
  }) async {
    final item = OutboxQueueItem(
      clientMessageId: clientMessageId,
      conversationId: conversation.conversationId,
      conversationTitle: titleFor(conversation),
      ciphertext: ciphertext,
      plaintextPreview: plaintextPreview,
      keyEpoch: keyEpoch,
      pqcKemAlg: identity.pqcKemAlg,
      pqcDsaAlg: identity.pqcDsaAlg,
      status: 'QUEUED',
      queuedAt: DateTime.now(),
    );
    _outboxItems.insert(0, item);
    await _storage.saveOutboxItems(_outboxItems);

    if (_activeConversation?.conversationId == conversation.conversationId) {
      _messages.add(
        ChatMessage(
          messageId: 'queued-$clientMessageId',
          conversationId: conversation.conversationId,
          senderDeviceId: identity.deviceId,
          clientMessageId: clientMessageId,
          messageType: 'text',
          ciphertext: ciphertext,
          decryptedText: plaintextPreview,
          createdAt: item.queuedAt,
          isMe: true,
          senderName: identity.displayName,
          deliveryStatus: 'queued_offline',
          keyEpoch: keyEpoch,
          isHybridPqc: true,
          pqcKemAlg: identity.pqcKemAlg,
          pqcDsaAlg: identity.pqcDsaAlg,
          pqcSignatureVerified: true,
        ),
      );
    }
    notifyListeners();
  }

  Future<void> toggleOfflineMode(bool value) async {
    _offlineSimulated = value;
    if (_offlineSimulated) {
      _ws.disconnect();
    } else {
      await _ws.connect();
      await syncOutboxQueue();
      await refreshAll();
    }
    notifyListeners();
  }

  Future<int> syncOutboxQueue() async {
    if (_offlineSimulated) return 0;
    var syncedCount = 0;
    for (var i = 0; i < _outboxItems.length; i++) {
      final item = _outboxItems[i];
      if (item.status != 'QUEUED') continue;
      try {
        await _api.sendMessage(
          conversationId: item.conversationId,
          clientMessageId: item.clientMessageId,
          ciphertext: item.ciphertext,
          keyEpoch: item.keyEpoch,
        );
        _outboxItems[i] = item.copyWith(
          status: 'RELAY_ACCEPTED',
          syncedAt: DateTime.now(),
        );
        syncedCount++;
      } catch (_) {}
    }
    if (syncedCount > 0) {
      await _storage.saveOutboxItems(_outboxItems);
      final activeId = _activeConversation?.conversationId;
      if (activeId != null) {
        await loadConversationMessages(activeId);
      }
      notifyListeners();
    }
    return syncedCount;
  }

  Future<void> clearSyncedOutboxItems() async {
    _outboxItems.removeWhere((item) => item.status == 'RELAY_ACCEPTED');
    await _storage.saveOutboxItems(_outboxItems);
    notifyListeners();
  }

  Future<void> deleteMessage(ChatMessage message) async {
    if (!message.isMe) return;
    try {
      await _api.deleteMessage(message.messageId);
      _messages.removeWhere((m) => m.messageId == message.messageId);
      notifyListeners();
    } catch (e) {
      _errorMessage = _humanError(e);
      notifyListeners();
    }
  }

  // ---------------------------------------------------------------------------
  // PERISAI-Vault Operations (Local PQC Encrypted Storage)
  // ---------------------------------------------------------------------------

  Future<VaultItem?> addVaultItem({
    required String title,
    required String category,
    required String contentText,
  }) async {
    final id = _identity;
    if (id == null || !id.hasPqcKeys) return null;
    _setBusy(true);
    try {
      final item = await _crypto.encryptVaultItem(
        title: title,
        category: category,
        contentText: contentText,
        kemAlgorithm: id.pqcKemAlg,
        kemPublicKeyB64: id.pqcKemPublicKey,
        dsaAlgorithm: id.pqcDsaAlg,
        dsaPrivateKeyB64: id.pqcDsaPrivateKey,
      );
      _vaultItems.insert(0, item);
      await _storage.saveVaultItems(_vaultItems);
      notifyListeners();
      return item;
    } catch (e) {
      _errorMessage = _humanError(e);
      notifyListeners();
      return null;
    } finally {
      _setBusy(false);
    }
  }

  Future<Map<String, dynamic>?> decryptVaultItem(VaultItem item) async {
    final id = _identity;
    if (id == null || !id.hasPqcKeys) return null;
    try {
      return await _crypto.decryptVaultItem(
        item: item,
        kemPrivateKeyB64: id.pqcKemPrivateKey,
        dsaPublicKeyB64: id.pqcDsaPublicKey,
      );
    } catch (e) {
      _errorMessage = 'Gagal mendekripsi arsip PERISAI-Vault: ${_humanError(e)}';
      notifyListeners();
      return null;
    }
  }

  Future<void> deleteVaultItem(String vaultItemId) async {
    _vaultItems.removeWhere((item) => item.vaultItemId == vaultItemId);
    await _storage.saveVaultItems(_vaultItems);
    notifyListeners();
  }

  // ---------------------------------------------------------------------------
  // PERISAI-Sign Operations (ML-DSA-44/65/87 Signing & Verification)
  // ---------------------------------------------------------------------------

  Future<void> refreshSignedArtifacts() async {
    if (_identity == null || _offlineSimulated) return;
    try {
      final list = await _api.getSignedArtifacts();
      _signedArtifacts = list.map(SignedArtifactModel.fromJson).toList();
      final logs = await _api.getSignAuditLogs();
      _signAuditLogs = logs;
      notifyListeners();
    } catch (_) {}
  }

  Future<SignedArtifactModel?> createAndSignArtifact({
    required String artifactType,
    required String title,
    required String contentText,
    String? customAlgorithm,
  }) async {
    final id = _identity;
    if (id == null) return null;
    _setBusy(true);
    _errorMessage = null;
    try {
      final alg = customAlgorithm ?? id.pqcDsaAlg;
      final contentHash = await _crypto.sha256Hex(contentText);
      final canonical = utf8.encode(
        'PERISAI-SIGN-V1|$artifactType|${title.trim()}|$contentHash',
      );

      String sigB64;
      String pubB64;
      if (alg == id.pqcDsaAlg && id.pqcDsaPrivateKey.isNotEmpty) {
        sigB64 = await _pqc.mlDsaSign(alg, id.pqcDsaPrivateKey, canonical);
        pubB64 = id.pqcDsaPublicKey;
      } else {
        final kp = await _crypto.pqcDsaKeyPairFromPhrase(
          id.recoveryPhrase,
          algorithm: alg,
        );
        sigB64 = await _pqc.mlDsaSign(alg, kp.secretKeyB64, canonical);
        pubB64 = kp.publicKeyB64;
      }

      final data = await _api.createSignedArtifact(
        artifactType: artifactType,
        title: title.trim(),
        contentText: contentText,
        algorithm: alg,
        contentHashSha256: contentHash,
        signatureB64: sigB64,
        signerPublicKeyB64: pubB64,
      );
      final created = SignedArtifactModel.fromJson(data);
      _signedArtifacts.insert(0, created);
      await refreshSignedArtifacts();
      return created;
    } catch (e) {
      _errorMessage = _humanError(e);
      return null;
    } finally {
      _setBusy(false);
    }
  }

  /// Verify an artifact either online (recording audit log) or offline on-device.
  Future<Map<String, dynamic>> verifyArtifact(
    SignedArtifactModel artifact, {
    String? overriddenContentText,
  }) async {
    final contentToVerify = overriddenContentText ?? artifact.contentText;
    final testedHash = await _crypto.sha256Hex(contentToVerify);
    final canonical = utf8.encode(
      'PERISAI-SIGN-V1|${artifact.artifactType}|${artifact.title.trim()}|$testedHash',
    );
    final localValid = await _pqc.mlDsaVerify(
      artifact.algorithm,
      artifact.signerPublicKeyB64,
      canonical,
      artifact.signatureB64,
    );

    if (!_offlineSimulated) {
      try {
        final remote = await _api.verifySignedArtifact(
          artifactId: artifact.artifactId,
          contentText: overriddenContentText,
        );
        await refreshSignedArtifacts();
        return remote;
      } catch (_) {}
    }

    final hashMatches =
        testedHash.toLowerCase() == artifact.contentHashSha256.toLowerCase();
    final isRevoked = artifact.status == 'revoked';
    final verified = localValid && hashMatches && !isRevoked;
    return {
      'verified': verified,
      'verdict': isRevoked
          ? 'REVOKED_SIGNER'
          : (verified ? 'VALID' : 'TAMPERED_OR_INVALID'),
      'message': verified
          ? 'Otentik & Utuh (Terverifikasi Offline dengan ${artifact.algorithm})'
          : 'PERINGATAN INTEGRITAS: Tanda tangan ${artifact.algorithm} gagal atau payload telah dimodifikasi (1-bit tamper detected)!',
      'algorithm': artifact.algorithm,
      'crypto_signature_valid': localValid,
      'content_hash_matches': hashMatches,
      'signer_revoked': isRevoked,
      'tested_sha256': testedHash,
      'expected_sha256': artifact.contentHashSha256,
    };
  }

  Future<Map<String, dynamic>?> decryptArtifactWithKemKey({
    required String artifactId,
    required String kemSecretKeyB64,
  }) async {
    _setBusy(true);
    _errorMessage = null;
    try {
      final res = await _api.decryptSignedArtifact(
        artifactId: artifactId,
        kemSecretKeyB64: kemSecretKeyB64,
      );
      await refreshSignedArtifacts();
      return res;
    } catch (e) {
      _errorMessage = _humanError(e);
      return null;
    } finally {
      _setBusy(false);
    }
  }

  // ---------------------------------------------------------------------------
  // PERISAI-Lab Operations (Quantum Simulation, Audit & Benchmark)
  // ---------------------------------------------------------------------------

  Future<Map<String, dynamic>?> runQuantumRsaSimulation({
    int rsaModulusN = 3233,
    int publicExponentE = 17,
    int sampleMessage = 42,
    String? compareKemAlg,
    String? compareDsaAlg,
  }) async {
    _setBusy(true);
    _errorMessage = null;
    try {
      final kem = compareKemAlg ?? (_identity?.pqcKemAlg ?? 'ML-KEM-768');
      final dsa = compareDsaAlg ?? (_identity?.pqcDsaAlg ?? 'ML-DSA-65');
      final res = await _api.simulateQuantumRsaAttack(
        rsaModulusN: rsaModulusN,
        publicExponentE: publicExponentE,
        sampleMessage: sampleMessage,
        compareKemAlg: kem,
        compareDsaAlg: dsa,
      );
      _lastQuantumSimulation = res;
      notifyListeners();
      return res;
    } catch (e) {
      _errorMessage = _humanError(e);
      return null;
    } finally {
      _setBusy(false);
    }
  }

  Future<Map<String, dynamic>?> runFleetPqcAudit() async {
    _setBusy(true);
    _errorMessage = null;
    try {
      final res = await _api.getPqcFleetAudit();
      _lastFleetAudit = res;
      notifyListeners();
      return res;
    } catch (e) {
      _errorMessage = _humanError(e);
      return null;
    } finally {
      _setBusy(false);
    }
  }

  Future<Map<String, dynamic>> runPqcBenchmark() async {
    _setBusy(true);
    _errorMessage = null;
    try {
      if (!_offlineSimulated) {
        try {
          final remote = await _api.runPqcBenchmark();
          _lastBenchmark = remote;
          notifyListeners();
          return remote;
        } catch (_) {}
      }
      final local = await _pqc.runLocalBenchmark();
      _lastBenchmark = local;
      notifyListeners();
      return local;
    } finally {
      _setBusy(false);
    }
  }

  // ---------------------------------------------------------------------------
  // Background sync
  // ---------------------------------------------------------------------------

  void _startBackgroundSync() {
    _pollingTimer?.cancel();
    _pollingTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      await _syncPending();
    });
  }

  Future<void> _syncPending() async {
    if (_identity == null || _syncing || _offlineSimulated) return;
    _syncing = true;
    try {
      if (queuedOutboxCount > 0) {
        await syncOutboxQueue();
      }

      final pending = await _api.getPendingMessages();
      if (pending.isEmpty) return;

      for (final message in pending) {
        final messageId = message['message_id']?.toString();
        if (messageId != null) {
          try {
            await _api.acknowledgeMessage(messageId);
          } catch (_) {}
        }
      }

      final activeId = _activeConversation?.conversationId;
      if (activeId != null &&
          pending.any((m) => m['conversation_id'] == activeId)) {
        await loadConversationMessages(activeId);
      }
      await refreshAll();
    } catch (_) {
      // Silent: the next poll retries.
    } finally {
      _syncing = false;
    }
  }

  // ---------------------------------------------------------------------------
  // Labels
  // ---------------------------------------------------------------------------

  String titleFor(ConversationModel conversation) {
    final customTitle = conversation.title?.trim();
    if (customTitle != null && customTitle.isNotEmpty) return customTitle;

    if (conversation.conversationType == 'group') {
      final count = conversation.memberCount > 0
          ? conversation.memberCount
          : conversation.memberIdentityIds.length;
      return 'Grup • $count anggota';
    }

    final peerName = conversation.peerDisplayName?.trim();
    if (peerName != null && peerName.isNotEmpty) return peerName;

    final peerId = conversation.peerIdentityId;
    if (peerId != null) {
      final name = _displayNameFor(peerId);
      if (name.isNotEmpty) return name;
    }
    return 'Percakapan Langsung';
  }

  String subtitleFor(ConversationModel conversation) {
    final kem = _identity?.pqcKemAlg ?? 'ML-KEM-768';
    if (conversation.conversationType == 'group') {
      final count = conversation.memberCount > 0
          ? conversation.memberCount
          : conversation.memberIdentityIds.length;
      return 'Grup • $count anggota • Epoch ${conversation.keyEpoch} • Hybrid $kem';
    }
    return 'E2EE Hybrid X25519 + $kem';
  }

  String _displayNameFor(String identityId) {
    final own = _identity;
    if (own != null && identityId == own.identityId) return own.displayName;

    for (final contact in _contacts) {
      if (contact.contactIdentityId == identityId) {
        return contact.publicIdentity;
      }
    }

    final known = _identityNames[identityId];
    if (known != null && known.isNotEmpty) return known;

    final short = identityId.length >= 8
        ? identityId.substring(0, 8)
        : identityId;
    return 'Agen $short';
  }

  // ---------------------------------------------------------------------------
  // Settings
  // ---------------------------------------------------------------------------

  Future<bool> applyServerUrl(String url) async {
    _setBusy(true);
    _errorMessage = null;
    try {
      var normalized = StorageService.normalizeBaseUrl(url);
      if (!normalized.startsWith('http://') &&
          !normalized.startsWith('https://')) {
        normalized = 'http://$normalized';
      }
      normalized = StorageService.normalizeBaseUrl(normalized);

      final uri = Uri.tryParse(normalized);
      if (uri == null ||
          uri.host.isEmpty ||
          (uri.scheme != 'http' && uri.scheme != 'https')) {
        throw ApiException(
          'Alamat server tidak valid. Contoh: http://10.0.2.2:8000/api/v1',
        );
      }

      await _storage.saveBaseUrl(normalized);
      await _storage.clearToken();
      _ws.disconnect();

      if (_identity?.recoveryConfirmed == true) {
        await _authenticateAndConnect();
        await refreshAll();
        _startBackgroundSync();
      }
      return true;
    } catch (e) {
      _errorMessage = _humanError(e);
      return false;
    } finally {
      _setBusy(false);
    }
  }

  Future<void> logout() async {
    _pollingTimer?.cancel();
    _pollingTimer = null;
    _ws.disconnect();
    await _storage.clearIdentity();
    _identity = null;
    _contacts = [];
    _personal = [];
    _groups = [];
    _details.clear();
    _identityNames.clear();
    _activeConversation = null;
    _messages = [];
    _errorMessage = null;
    notifyListeners();
  }

  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------

  void _setBusy(bool value) {
    _busy = value;
    notifyListeners();
  }

  String _humanError(Object error) {
    if (error is ApiException) {
      final code = error.code;
      return code == null ? error.message : '${error.message} ($code)';
    }
    return error.toString().replaceFirst('Exception: ', '');
  }

  @override
  void dispose() {
    _pollingTimer?.cancel();
    _ws.disconnect();
    super.dispose();
  }
}
