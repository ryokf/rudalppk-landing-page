# PERISAI-Q Security Audit & Fix Status

**Date:** 2026-11-13
**Scope:** `Backend/` and `flutter_application_chat/` in `MobileApp_and_Web`, tested against `AntiPostQuantum/PERISAI-Q_PRD.md` and `PERISAI-Q_SAD.md`.
**Verdict:** Feature coverage is broad and the happy-path tests pass. A real FIPS 203/204 backend is now available, but the **default** cryptographic path is still the non-compliant prototype and there are **critical key-management flaws**. The project is **not compliant** and **not production-ready**.

---

## 1. Test results

| Test | Result |
|---|---|
| `flutter test` | 18/18 passed |
| `test_auth_flow.py` | 11/11 passed |
| `test_full_platform.py` | 27/27 passed |
| PQC round-trip/length checks | Passed |
| Interop with real FIPS 203/204 (`kyber-py`, `dilithium-py`) | 0/12 passed |
| Runtime bug reproduction | 3 bugs confirmed, then fixed |
| PQC backend tests (`test_pqc_backend.py`) | 49/49 passed |
| Real-backend API test with a client-supplied ML-DSA signature | Create **200**, verify **VALID** |
| Live API re-test after fixes | Lab audit 200; agent-bound artifact 200; detached verify works |

Passing tests prove self-consistency only. They do **not** prove NIST compliance.

---

## 2. Fixed in this pass

| Fix | File |
|---|---|
| `Device.created_at` → `Device.registered_at` (3 sites) | `Backend/backend/app/routers/perisai_sign.py` |
| `Message.encrypted_payload` → `Message.ciphertext`; `Message.sent_at` → `Message.created_at`; decode stored bytes safely | `Backend/backend/app/routers/perisai_lab.py` |
| Lab request max `N` aligned with engine limit (1,048,576 → 65,535) | `Backend/backend/app/routers/perisai_lab.py` |
| Detached signature verification now accepts `title` and `artifact_type`, so valid signatures no longer return a false “TAMPERED” | `Backend/backend/app/routers/perisai_sign.py` |
| Classical fallback no longer reports `isHybridPqc = true` (silent downgrade mislabel removed) | `flutter_application_chat/lib/services/crypto_service.dart` |
| Crypto module/class docstrings now state clearly that the scheme is **not** FIPS 203/204 | `app/core/pqc.py`, `lib/services/pqc_service.dart` |
| Lab “hard problem” text corrected from X^256 to the actual X^64 prototype | `app/core/pqc.py` |

Verified after the fixes:
- `GET /api/v1/perisai/lab/audit` → **200** (was 500)
- `POST /api/v1/perisai/sign/artifacts` with `recipient_scope="agent"` → **200** (was 500)
- Detached `/verify` with title/type → **VALID**; tampered content → **TAMPERED_OR_INVALID**
- `N > 65535` → **422 validation error**, not a 500
- Flutter tests still **18/18**
- `GET /api/v1/perisai/lab/backends` → **200** with backend status and FIPS flags

---

## 2b. PQC backend abstraction added

The crypto calls now go through `Backend/backend/app/core/pqc_backend.py` instead of importing `app/core/pqc.py` directly.

| Backend | Selected with | Status |
|---|---|---|
| `custom` | `PQC_BACKEND=custom` (default) | Original prototype; works with the current Flutter client; **not FIPS 203/204** |
| `pqcrypto` | `PQC_BACKEND=pqcrypto` | Real ML-KEM-512/768/1024 and ML-DSA-44/65/87 via PQClean; **not CMVP-validated** |

What is wired:

- All crypto call sites in `auth.py`, `activation.py`, `devices.py`, `perisai_sign.py`, and `perisai_lab.py` now use the façade.
- Lab benchmark and RSA-vs-PQC simulation also use the active backend.
- `GET /api/v1/perisai/lab/backends` reports the configured backend, availability, and FIPS flags.
- Missing dependencies and unsupported operations return explicit API errors (`503` / `501`) instead of an unhandled `500`.
- The real backend rejects caller-supplied key-generation seeds. FIPS 203/204 key generation is randomized; silently ignoring a seed would make derived keys unrecoverable and break decryption.

Known migration limits while the Flutter client still uses the custom scheme:

- Custom and real keys/signatures are intentionally **not interchangeable**; tests confirm both directions are rejected.
- Server-derived admin/agent keys (from public IDs or the JWT secret) cannot be reproduced by a randomized FIPS backend. Those flows now fail with `PQC_OPERATION_UNSUPPORTED` when `pqcrypto` is selected.
- Real-backend artifact creation works when the client supplies its own ML-DSA signature and public key. The signature path was verified end-to-end against the live API.
- Full `pqcrypto` operation requires moving key generation and private-key storage to the device first (issues C2–C5 and C8 below).

Run the backend tests with:

```bash
cd Backend
python3 test_pqc_backend.py
```

---

## 3. Critical issues still open

### C1. The default crypto path is still not FIPS 203/204
The backend now supports real FIPS 203/204 through `PQC_BACKEND=pqcrypto`, but the **default remains `custom`** because the Flutter client only speaks the prototype wire format. `app/core/pqc.py` and `lib/services/pqc_service.dart` still use a fixed `n = 64`, `q = 3329` construction. All ML-KEM parameter sets use the same dimension; declared `k`/`eta` values are unused. The “ML-DSA” signature is Ed25519 over a custom transcript. Real FIPS implementations reject these keys/signatures in both directions (0/12 interop).
**Next step:** migrate the client to the real backend, then change the default.

### C2. Private KEM keys derivable from public data
`perisai_sign.py:111-125` derives keys from `device.public_device_key` or the public `identity_id`. Anyone with those public values can reconstruct the “private” KEM key. Verified by deriving and decapsulating inside the API container.

### C3. Admin signing keys derivable from the JWT secret
`perisai_sign.py:102-108` derives the admin signing key from `jwt_secret_key` + public `admin_id`. A forged admin signature verified successfully.

### C4. Recipient private key returned to sender
`perisai_sign.py:636-647` returns `kem_secret_key_b64` in the create-artifact response. Confirmed via API.

### C5. Private keys/recovery phrase in plaintext storage
`storage_service.dart:30-31` stores the identity JSON in `SharedPreferences`, including `devicePrivateKey`, `pqcKemPrivateKey`, `pqcDsaPrivateKey`, and `recoveryPhrase`. No secure storage dependency.

### C6. Ad-hoc hybrid combiner and optional signature
`crypto_service.dart:900` concatenates `X25519 || ML-KEM` before HKDF, without transcript binding. ML-DSA verification is computed but not enforced before decryption.

### C7. Hardcoded legacy message key
`crypto_service.dart:50,917-919` uses a static key (`field_secure_comm_default_key_32b`) for legacy encryption/decryption.

### C8. Server ignores client-registered PQC public keys
`perisai_sign.py` always derives its own KEM keypair and never uses `device.pqc_kem_public_key`, so the recipient cannot decrypt with its own on-device key.

---

## 4. Requirement snapshot

| Area | Status |
|---|---|
| Sheetphrase identity | Partial: local phrase + PBKDF2, but activation still requires a centralized server (conflicts with ID-001) |
| ML-KEM / ML-DSA | Both backends available; default `custom` is **not standards-compliant**, `pqcrypto` is FIPS 203/204 (not CMVP-validated) |
| Private keys local | Violated (C2–C5) |
| Vault file/text encryption | Works with AES-256-GCM; at-rest protection undermined by plaintext key storage |
| Offline outbox | Present client-side; statuses limited to `QUEUED` / `RELAY_ACCEPTED` |
| PERISAI-Sign | Works end-to-end; revocation and firmware signing work; crypto primitive non-compliant |
| PERISAI-Lab | Small RSA factoring works and disclaimer is present; **no Qiskit Aer and no QUBO solver** |
| Relay | Ciphertext-only message path works; backend still derives/returns private keys |
| Documentation | All six `MobileApp_and_Web/*.md` files contain **zero** PQC/PERISAI content |

---

## 5. Recommended next steps (in order)

1. **Migrate the Flutter client to `pqcrypto`** (or another reviewed PQC library) and validate against NIST ACVP vectors; then make `PQC_BACKEND=pqcrypto` the production default.
2. **Stop deriving user keys from public identifiers/JWT secrets.** Generate keys on-device; store private keys in Keychain/Keystore. This is required before the randomized real backend can replace the seeded prototype flows.
3. **Remove secret-key export** (`decryption_key_bundle`); decrypt locally on the recipient device.
4. **Adopt a reviewed hybrid combiner** (e.g. X-Wing) with transcript binding and explicit downgrade handling.
5. **Enforce signature verification** before returning plaintext.
6. **Remove the hardcoded legacy key** and migrate old messages.
7. **Implement or remove** the Qiskit/QUBO claims.
8. **Update SAD v2.0/PRD docs** with the PQC protocol, key lifecycle, threat model, and test vectors.
