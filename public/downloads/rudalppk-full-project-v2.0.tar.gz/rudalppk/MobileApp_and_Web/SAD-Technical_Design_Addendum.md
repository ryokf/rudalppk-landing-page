# SAD — Technical Design Addendum
## Secure Field Communication Platform

**Version:** 1.1  
**Document Type:** Architecture Design Supplement

---

# 1. Use Case Diagram

Diagram ini menggambarkan interaksi antara pengguna dan sistem.

```mermaid
flowchart LR
    U[Field Agent]

    subgraph System[Secure Communication Platform]
        A[Create Identity]
        B[Recover Identity]
        C[Manage Contacts]
        D[Send Encrypted Message]
        E[Receive Message]
        F[Create Group]
        G[Manage Group Members]
        H[Send Voice Note]
        I[Voice Call]
        J[Revoke Device]
    end

    U --> A
    U --> B
    U --> C
    U --> D
    U --> E
    U --> F
    U --> G
    U --> H
    U --> I
    U --> J
```

**Catatan:**
- Pengguna memiliki identitas kriptografis, bukan akun berbasis nomor telepon.
- Voice note dan voice call merupakan fitur pengembangan setelah messaging stabil.
- Device revocation menjadi bagian penting dari pengelolaan identitas.

# 2. Component Diagram

Diagram komponen menggambarkan pembagian tanggung jawab aplikasi.

```mermaid
flowchart TB
    subgraph Client[Flutter Mobile Client]
        UI[Presentation Layer]
        ID[Identity Manager]
        CRYPTO[Cryptographic Engine]
        CHAT[Chat Manager]
        MEDIA[Media Manager]
        LOCAL[Local Secure Storage]

        UI --> ID
        UI --> CHAT
        UI --> MEDIA
        ID --> CRYPTO
        CHAT --> CRYPTO
        MEDIA --> CRYPTO
        ID --> LOCAL
        CRYPTO --> LOCAL
    end

    subgraph Backend[Backend Infrastructure]
        API[FastAPI REST API]
        WS[WebSocket Relay]
        AUTH[Identity Verification]
        MSG[Message Service]
        GROUP[Group Service]
        SIGNAL[WebRTC Signaling]

        API --> AUTH
        API --> MSG
        API --> GROUP
        WS --> MSG
        API --> SIGNAL
    end

    subgraph Storage[Infrastructure Storage]
        DB[(PostgreSQL)]
        OBJ[(SeaweedFS)]
    end

    CHAT --> API
    CHAT --> WS
    MEDIA --> API
    MEDIA --> OBJ
    API --> DB
    MSG --> DB
    GROUP --> DB
```

**Prinsip arsitektur:**

1. Cryptographic Engine berada di sisi client.
2. Backend mengelola routing dan penyimpanan ciphertext.
3. Database tidak menyimpan private key pengguna.
4. Object Storage hanya menerima file media terenkripsi.
5. Signaling server mengatur koneksi, bukan membaca isi komunikasi.

# 3. Sequence Diagram — Direct Message

Alur ketika pengguna A mengirim pesan kepada pengguna B.

```mermaid
sequenceDiagram
    participant A as Client A
    participant API as FastAPI
    participant DB as PostgreSQL
    participant B as Client B

    A->>A: Compose message
    A->>A: Encrypt using E2EE
    A->>API: Submit ciphertext
    API->>DB: Store encrypted payload
    API-->>A: Message accepted
    API-->>B: Notify message available
    B->>API: Request pending message
    API->>DB: Retrieve ciphertext
    DB-->>API: Encrypted payload
    API-->>B: Return ciphertext
    B->>B: Decrypt locally
    B->>B: Display plaintext
```

**Security boundary:** Plaintext hanya tersedia di perangkat A sebelum enkripsi dan perangkat B setelah dekripsi.

# 4. Sequence Diagram — Identity Creation

```mermaid
sequenceDiagram
    participant U as User
    participant C as Flutter Client
    participant K as Secure Key Storage
    participant API as FastAPI
    participant DB as PostgreSQL

    U->>C: Create new identity
    C->>C: Generate cryptographic keys
    C->>C: Generate recovery material
    C->>K: Store private key securely
    C-->>U: Display recovery phrase
    U->>C: Confirm backup
    C->>API: Register public identity
    API->>DB: Store public identity
    DB-->>API: Registration successful
    API-->>C: Identity registered
```

Recovery phrase harus ditampilkan secara aman dan tidak dikirim ke backend. Mekanisme recovery harus menggunakan desain backup key yang terdefinisi, bukan sekadar mengirim phrase ke server.

# 5. Entity Relationship Diagram (ERD)

ERD awal untuk PostgreSQL.

```mermaid
erDiagram
    USERS ||--o{ DEVICES : owns
    USERS ||--o{ GROUP_MEMBERS : participates
    GROUPS ||--o{ GROUP_MEMBERS : contains
    CONVERSATIONS ||--o{ MESSAGES : contains
    USERS ||--o{ MESSAGES : sends
    DEVICES ||--o{ MESSAGES : originates
    MESSAGES ||--o| MEDIA_FILES : references
    USERS ||--o{ CONTACTS : maintains
    USERS ||--o{ CONVERSATIONS : participates

    USERS {
        uuid user_id PK
        string public_identity
        timestamp created_at
        boolean active
    }

    DEVICES {
        uuid device_id PK
        uuid user_id FK
        string public_device_key
        string device_status
        timestamp registered_at
    }

    CONTACTS {
        uuid contact_id PK
        uuid owner_id FK
        uuid contact_user_id FK
        string verification_status
        timestamp added_at
    }

    CONVERSATIONS {
        uuid conversation_id PK
        string conversation_type
        timestamp created_at
    }

    GROUPS {
        uuid group_id PK
        string group_name
        uuid conversation_id FK
        timestamp created_at
    }

    GROUP_MEMBERS {
        uuid membership_id PK
        uuid group_id FK
        uuid user_id FK
        string member_role
        timestamp joined_at
    }

    MESSAGES {
        uuid message_id PK
        uuid conversation_id FK
        uuid sender_id FK
        uuid device_id FK
        text ciphertext
        timestamp created_at
        timestamp expires_at
    }

    MEDIA_FILES {
        uuid media_id PK
        uuid message_id FK
        string storage_reference
        string content_type
        bigint file_size
    }
```

**Catatan desain database:**

- `public_identity` hanya menyimpan identitas publik.
- `public_device_key` bukan private key.
- `ciphertext` berisi data terenkripsi, bukan plaintext.
- `storage_reference` menunjuk ke objek terenkripsi pada SeaweedFS.
- Recovery phrase dan private key tidak boleh memiliki kolom penyimpanan di database.
- Struktur percakapan perlu diperluas dengan tabel participant agar percakapan personal maupun grup dapat memiliki keanggotaan yang konsisten.

# 6. Initial API Design

| Method | Endpoint | Function |
|---|---|---|
| POST | `/api/v1/identity` | Register public identity |
| GET | `/api/v1/identity/{id}` | Retrieve public identity |
| POST | `/api/v1/contacts` | Add contact |
| GET | `/api/v1/contacts` | List contacts |
| POST | `/api/v1/conversations` | Create conversation |
| GET | `/api/v1/conversations` | List conversations |
| POST | `/api/v1/messages` | Submit ciphertext |
| GET | `/api/v1/messages/pending` | Retrieve pending messages |
| POST | `/api/v1/groups` | Create group |
| POST | `/api/v1/media` | Upload encrypted media |

WebSocket:

```text
/ws/v1/relay
```

WebRTC signaling:

```text
/ws/v1/signaling
```

Endpoint di atas merupakan rancangan awal; autentikasi perangkat, otorisasi, validasi payload, rate limiting, dan skema key exchange harus ditentukan sebelum implementasi.

# 7. Architecture Decisions to Finalize

| Decision | Recommended Direction |
|---|---|
| Mobile platform | Android first |
| Identity | Locally generated cryptographic identity |
| Recovery | Recovery secret with secure key backup design |
| 1:1 encryption | Signal Protocol |
| Group encryption | Evaluate MLS |
| Backend | FastAPI |
| Database | PostgreSQL |
| Real-time transport | WebSocket |
| Voice | WebRTC |
| Media storage | SeaweedFS |

**End of Technical Design Addendum — Version 1.1**