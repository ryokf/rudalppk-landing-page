# Software Architecture Document (SAD)
# Secure Field Communication — Architecture Improvement

| Informasi | Detail |
|---|---|
| Project | Secure Field Communication |
| Document | Software Architecture Document |
| Version | 2.0 |
| Status | Draft — Proposed Improvement |
| Scope | Frontend Separation, Organization User Management, Group Chat |
| Previous Version | SAD v1.x |
| Prepared Date | 9 November 2026 |

---

# 1. Introduction

## 1.1 Purpose

Dokumen ini mendefinisikan perubahan arsitektur dan kebutuhan pengembangan Secure Field Communication berdasarkan hasil evaluasi implementasi aplikasi saat ini.

Aplikasi telah berhasil dijalankan dan ditampilkan melalui browser. Namun, masih terdapat beberapa keterbatasan pada pemisahan platform, manajemen pengguna, dan mekanisme komunikasi grup.

SAD v2.0 bertujuan untuk memberikan rancangan arsitektur baru yang memungkinkan:

1. Aplikasi Web dan Mobile beroperasi secara independen.
2. Organisasi memiliki kewenangan untuk mengelola pengguna.
3. Petugas lapangan hanya dapat menggunakan akun yang disediakan organisasi.
4. Komunikasi personal dan grup tersedia sebagai fitur terpisah.
5. Backend tetap menjadi pusat layanan autentikasi, manajemen identitas, dan komunikasi.

## 1.2 Scope

Improvement ini mencakup:

- Pemisahan aplikasi Web dan Mobile.
- Organization Management.
- User Provisioning dan Credential Generation.
- Authentication untuk end-user.
- Personal Chat.
- Group Chat.
- Conversation Management.
- Integrasi dengan backend Secure Field Communication yang sudah tersedia.

Improvement ini tidak bertujuan mengganti keseluruhan sistem E2EE, identitas kriptografis, atau mekanisme autentikasi perangkat yang telah dirancang pada SAD sebelumnya.

## 1.3 Current System Condition

Berdasarkan evaluasi implementasi:

| Area | Kondisi Saat Ini | Target Improvement |
|---|---|---|
| Browser | Aplikasi sudah dapat ditampilkan | Web application independen |
| Mobile | Masih berkaitan dengan konversi UI web | Mobile application independen |
| User Management | Belum memiliki pemisahan kewenangan organisasi | Dikelola organisasi melalui Web |
| User Registration | Belum sesuai model provisioning organisasi | End-user tidak dapat register mandiri |
| Personal Chat | Sudah menjadi bagian dari aplikasi | Tetap tersedia sebagai fitur utama |
| Group Chat | Belum tersedia secara memadai | Mendukung percakapan grup |
| Chat Navigation | Belum dipisahkan berdasarkan jenis percakapan | Personal dan Group memiliki tab tersendiri |

---

# 2. Architectural Goals

## 2.1 Primary Goals

### A. Frontend Independence

Web dan Mobile harus menjadi dua aplikasi dengan tanggung jawab dan antarmuka masing-masing.

Web ditujukan untuk organisasi dan administrator.

Mobile ditujukan untuk end-user atau petugas lapangan.

Keduanya menggunakan backend yang sama, tetapi tidak saling bergantung dalam proses rendering UI.

### B. Organization-Controlled User Management

Organisasi memiliki kendali terhadap pembuatan, pengelolaan, dan pencabutan akun pengguna.

End-user tidak memiliki akses ke fitur registrasi mandiri.

### C. Unified Communication Backend

Personal Chat dan Group Chat menggunakan infrastruktur komunikasi yang sama, tetapi memiliki struktur conversation dan membership yang sesuai dengan jenisnya.

### D. Security Preservation

Pemisahan aplikasi tidak boleh menghilangkan prinsip keamanan yang sudah dirancang sebelumnya:

- End-to-end encryption.
- Private key disimpan pada perangkat pengguna.
- Server tidak menerima private key.
- Device authentication menggunakan mekanisme kriptografis.
- Device revocation.
- Authorization berdasarkan identitas dan keanggotaan conversation.

## 2.2 Non-Goals

Hal-hal berikut tidak menjadi target utama improvement ini:

- Mengembangkan ulang seluruh protokol kriptografi.
- Mengganti teknologi database tanpa kebutuhan.
- Membangun voice call sebagai prioritas utama.
- Mengimplementasikan multi-device synchronization secara penuh.
- Mengembangkan mesh networking atau Wi-Fi Direct.
- Mengubah backend menjadi dua sistem yang terpisah.

---

# 3. Proposed System Architecture

## 3.1 High-Level Architecture

Arsitektur yang diusulkan menggunakan pendekatan independent frontend with shared backend.

```mermaid
flowchart TB
    subgraph CLIENT["Client Applications"]
        WEB["Organization Web Application"]
        MOBILE["Field Agent Mobile Application"]
    end

    subgraph BACKEND["Shared Backend Services"]
        API["FastAPI REST API"]
        WS["WebSocket Relay"]
        AUTH["Authentication & Authorization"]
        USER["Organization & User Management"]
        CHAT["Conversation Management"]
        MSG["Message Relay"]
    end

    subgraph STORAGE["Infrastructure"]
        DB[("PostgreSQL")]
        OBJ[("Object Storage")]
    end

    WEB --> API
    MOBILE --> API

    MOBILE <--> WS
    WEB --> AUTH

    API --> AUTH
    API --> USER
    API --> CHAT
    WS --> MSG

    AUTH --> DB
    USER --> DB
    CHAT --> DB
    MSG --> DB
    MSG --> OBJ
```

### Architecture Explanation

**Organization Web Application**

Digunakan oleh organisasi untuk:

- Login administrator.
- Mengelola pengguna.
- Membuat kredensial.
- Menonaktifkan pengguna.
- Membuat dan mengelola grup.
- Mengelola keanggotaan grup.

**Field Agent Mobile Application**

Digunakan oleh petugas lapangan untuk:

- Login menggunakan kredensial dari organisasi.
- Mengelola sesi perangkat.
- Mengirim dan menerima personal messages.
- Mengirim dan menerima group messages.
- Melihat daftar kontak dan grup.
- Mengelola percakapan sesuai hak akses.

**Shared Backend**

Backend menjadi pusat pengelolaan autentikasi, otorisasi, pengguna, percakapan, dan relay pesan.

Web dan Mobile tidak saling memanggil untuk melakukan operasi bisnis. Keduanya berkomunikasi melalui API backend.

## 3.2 Frontend Separation

Direkomendasikan pemisahan menjadi dua frontend project.

```text
secure-communication/
│
├── web/
│   ├── src/
│   ├── components/
│   ├── pages/
│   ├── services/
│   ├── auth/
│   └── ...
│
├── mobile/
│   ├── lib/
│   │   ├── core/
│   │   ├── features/
│   │   ├── services/
│   │   ├── models/
│   │   └── ...
│   └── ...
│
├── backend/
│   └── app/
│
├── docker-compose.yml
└── .env
```

Catatan:

- Struktur di atas merupakan target logical structure.
- Implementasi frontend dapat menggunakan teknologi yang berbeda.
- Web tidak boleh sekadar menjadi tampilan mobile yang diperbesar.
- Mobile tidak boleh sekadar menjadi hasil konversi tampilan web.
- Kedua frontend menggunakan kontrak API yang konsisten.

Pilihan teknologi yang disarankan:

| Component | Technology |
|---|---|
| Organization Web | Flutter Web atau frontend web independen |
| Field Agent Mobile | Flutter |
| Backend | FastAPI |
| Database | PostgreSQL |
| Real-time Communication | WebSocket |
| Containerization | Docker Compose |
| Object Storage | MinIO atau layanan kompatibel S3 |

---

# 4. Organization and User Management

## 4.1 Organizational User Model

Sistem menggunakan model organisasi sebagai pihak yang memiliki kewenangan untuk menyediakan akun pengguna.

Organisasi dapat memiliki beberapa administrator dan banyak petugas lapangan.

```mermaid
flowchart TB
    ORG["Organization"]
    ADMIN["Organization Administrator"]
    USER["Field Agent"]
    DEVICE["Registered Device"]

    ORG --> ADMIN
    ORG --> USER
    USER --> DEVICE
```

Hubungan:

- Satu organisasi dapat memiliki beberapa administrator.
- Satu organisasi dapat memiliki banyak petugas lapangan.
- Satu petugas dapat memiliki satu atau lebih perangkat sesuai kebijakan sistem.
- Administrator hanya dapat mengelola pengguna dalam organisasi yang menjadi tanggung jawabnya.

## 4.2 Role Definition

Sistem minimal memiliki dua kategori role.

| Role | Platform | Permissions |
|---|---|---|
| Organization Admin | Web | Mengelola pengguna, kredensial, dan grup |
| Field Agent | Mobile | Login dan menggunakan fitur komunikasi |

Role tambahan dapat diperkenalkan jika diperlukan, misalnya:

- Organization Owner.
- Organization Supervisor.
- Group Administrator.

Role tambahan tidak harus diimplementasikan pada tahap pertama.

## 4.3 User Provisioning

Pembuatan pengguna dilakukan melalui Organization Web Application.

End-user tidak memiliki endpoint registrasi mandiri.

### User Provisioning Flow

```mermaid
sequenceDiagram
    actor Admin
    participant Web
    participant API
    participant DB
    actor Agent
    participant Mobile

    Admin->>Web: Login
    Web->>API: Authenticate Admin
    API-->>Web: Admin Session

    Admin->>Web: Create Field Agent
    Web->>API: POST /organizations/users
    API->>API: Validate Admin Permission
    API->>DB: Create User and Credential
    DB-->>API: User Created
    API-->>Web: Provisioning Result

    Admin->>Agent: Deliver Activation Credential

    Agent->>Mobile: Enter Credential
    Mobile->>API: Activate Account
    API->>DB: Validate Credential
    API-->>Mobile: Account Activation Result
```

### Provisioning Requirements

1. Administrator membuat akun petugas.
2. Backend mengaitkan akun dengan organisasi.
3. Backend menghasilkan kredensial aktivasi.
4. Administrator menyampaikan kredensial kepada petugas melalui saluran yang sesuai.
5. Petugas menggunakan kredensial untuk mengaktifkan akun.
6. Setelah aktivasi, petugas dapat melakukan autentikasi perangkat.
7. Petugas tidak dapat membuat akun baru melalui aplikasi Mobile.

### Credential Design

Kredensial aktivasi sebaiknya memiliki karakteristik:

- Unik.
- Memiliki masa berlaku.
- Hanya dapat digunakan sekali.
- Tidak disimpan sebagai plaintext di database.
- Dapat dicabut oleh administrator.
- Terhubung dengan organisasi dan akun pengguna tertentu.

Kredensial aktivasi tidak boleh disamakan dengan private key Ed25519 atau recovery phrase.

Private key autentikasi perangkat tetap dibuat dan disimpan secara aman pada perangkat pengguna.

## 4.4 User Lifecycle

Status pengguna yang diusulkan:

| Status | Description |
|---|---|
| Pending | Akun telah dibuat tetapi belum diaktifkan |
| Active | Akun aktif dan dapat digunakan |
| Suspended | Akun sementara tidak dapat digunakan |
| Revoked | Akun dicabut oleh organisasi |

Perubahan status harus berdampak pada hak akses pengguna.

Sebagai contoh, akun yang suspended atau revoked tidak boleh memperoleh sesi baru.

Kebijakan terhadap sesi JWT yang masih berlaku juga harus diterapkan melalui pemeriksaan status akun dan perangkat pada protected API.

---

# 5. Communication Architecture

## 5.1 Conversation Classification

Sistem memiliki dua jenis conversation:

1. Personal Conversation.
2. Group Conversation.

Keduanya menggunakan entitas conversation yang sama dengan pembeda jenis conversation.

```mermaid
flowchart TB
    C["Conversation"]
    P["Personal Conversation"]
    G["Group Conversation"]

    C --> P
    C --> G

    P --> U1["Field Agent A"]
    P --> U2["Field Agent B"]

    G --> M1["Member A"]
    G --> M2["Member B"]
    G --> M3["Member C"]
    G --> MN["Member N"]
```

## 5.2 Mobile Navigation

Personal Chat dan Group Chat harus memiliki tab yang berbeda.

Proposed mobile navigation:

```text
+--------------------------------+
| Secure Field Communication     |
+--------------------------------+
|                                |
|       Conversation List        |
|                                |
+--------------------------------+
|  Personal  |  Groups  | Profile|
+--------------------------------+
```

### Personal Chat Tab

Menampilkan:

- Daftar personal conversations.
- Nama atau identitas kontak.
- Preview pesan terakhir yang aman untuk ditampilkan.
- Timestamp.
- Unread message indicator.

### Group Chat Tab

Menampilkan:

- Daftar grup yang diikuti pengguna.
- Nama grup.
- Jumlah anggota.
- Preview pesan terakhir.
- Unread message indicator.
- Status keanggotaan.

### Profile Tab

Menampilkan:

- Identitas pengguna.
- Informasi perangkat.
- Status akun.
- Pengaturan keamanan.
- Logout.

Tab Personal dan Groups harus memiliki state navigasi dan daftar percakapan masing-masing.

## 5.3 Personal Conversation

Personal Conversation melibatkan dua identitas.

Requirements:

- Hanya dua pihak yang dapat menjadi anggota conversation personal.
- Pesan dikirim melalui mekanisme relay backend.
- Payload pesan tetap berupa ciphertext.
- Pengguna yang tidak menjadi anggota tidak dapat membaca pesan.
- Status pengiriman dan penerimaan dapat dikelola melalui delivery receipts.

## 5.4 Group Conversation

Group Conversation memungkinkan beberapa pengguna berkomunikasi dalam satu ruang percakapan.

### Group Functional Requirements

| Feature | Description |
|---|---|
| Create Group | Membuat grup baru |
| Group Name | Memberikan nama grup |
| Add Member | Menambahkan pengguna |
| Remove Member | Mengeluarkan pengguna |
| Member List | Melihat anggota grup |
| Group Admin | Mengelola keanggotaan |
| Send Message | Mengirim pesan ke grup |
| Receive Message | Menerima pesan grup |
| Leave Group | Keluar dari grup |
| Group Metadata | Mengelola informasi grup |

### Group Creation Flow

```mermaid
sequenceDiagram
    actor Admin
    participant Mobile
    participant API
    participant DB

    Admin->>Mobile: Create Group
    Mobile->>API: POST /groups
    API->>API: Validate User
    API->>API: Validate Member Eligibility
    API->>DB: Create Group Conversation
    API->>DB: Add Creator as Group Admin
    API->>DB: Add Initial Members
    API-->>Mobile: Group Created
```

### Group Membership Rules

1. Setiap grup memiliki satu atau lebih administrator.
2. Administrator dapat menambahkan anggota.
3. Administrator dapat mengeluarkan anggota.
4. Anggota dapat meninggalkan grup.
5. Pengguna yang sudah keluar tidak dapat mengakses pesan baru.
6. Perubahan keanggotaan harus tercatat.
7. Perubahan anggota harus diikuti mekanisme perubahan atau rotasi kunci grup agar anggota yang dikeluarkan tidak dapat membaca pesan berikutnya.

### Group Encryption

Group Chat harus mempertahankan prinsip E2EE.

Backend hanya menjadi relay dan penyimpan ciphertext.

Server tidak boleh memiliki akses ke plaintext pesan atau private key pengguna.

Pengelolaan kunci grup harus menggunakan protokol yang sesuai dan telah ditinjau keamanannya. Implementasi group encryption tidak boleh dibuat sebagai algoritma kriptografi sendiri.

Pemilihan protokol dan mekanisme rotasi kunci perlu menjadi bagian dari technical implementation design sebelum Group Chat dianggap aman untuk produksi.

---

# 6. Database Architecture Improvement

## 6.1 Proposed Entity Relationship

Model database berikut merupakan usulan perluasan dari skema sebelumnya.

```mermaid
erDiagram
    ORGANIZATIONS ||--o{ IDENTITIES : owns
    ORGANIZATIONS ||--o{ ORGANIZATION_ADMINS : assigns
    ORGANIZATIONS ||--o{ USER_CREDENTIALS : issues

    IDENTITIES ||--o{ DEVICES : registers
    IDENTITIES ||--o{ CONVERSATION_MEMBERS : joins

    CONVERSATIONS ||--o{ CONVERSATION_MEMBERS : contains
    CONVERSATIONS ||--o{ MESSAGES : stores

    DEVICES ||--o{ MESSAGES : sends
    MESSAGES ||--o{ DELIVERY_RECEIPTS : tracks

    IDENTITIES {
        uuid id PK
        uuid organization_id FK
        string public_identity
        string identity_fingerprint
        string status
        timestamp created_at
    }

    ORGANIZATIONS {
        uuid id PK
        string organization_name
        string status
        timestamp created_at
    }

    ORGANIZATION_ADMINS {
        uuid id PK
        uuid organization_id FK
        uuid identity_id FK
        string role
    }

    USER_CREDENTIALS {
        uuid id PK
        uuid identity_id FK
        string credential_hash
        timestamp expires_at
        timestamp consumed_at
        timestamp created_at
    }

    DEVICES {
        uuid id PK
        uuid identity_id FK
        string device_name
        string auth_public_key
        string status
        timestamp revoked_at
    }

    CONVERSATIONS {
        uuid id PK
        string conversation_type
        string title
        timestamp created_at
    }

    CONVERSATION_MEMBERS {
        uuid id PK
        uuid conversation_id FK
        uuid identity_id FK
        string role
        timestamp joined_at
        timestamp left_at
    }

    MESSAGES {
        uuid id PK
        uuid conversation_id FK
        uuid sender_device_id FK
        bytea ciphertext
        string message_type
        timestamp created_at
    }

    DELIVERY_RECEIPTS {
        uuid id PK
        uuid message_id FK
        uuid device_id FK
        string status
        timestamp delivered_at
    }
```

## 6.2 Database Design Notes

### Organizations

Mewakili entitas organisasi yang memiliki pengguna.

### Organization Admins

Menghubungkan administrator dengan organisasi dan role yang dimilikinya.

### User Credentials

Menyimpan data kredensial aktivasi pengguna.

Kredensial disimpan dalam bentuk hash, bukan plaintext.

### Identities

Merepresentasikan identitas pengguna dalam sistem komunikasi.

Setiap identity harus terhubung dengan organisasi.

### Devices

Merepresentasikan perangkat yang digunakan oleh identity.

Mekanisme autentikasi perangkat dari SAD sebelumnya tetap dipertahankan.

### Conversations

Menjadi entitas utama untuk personal dan group chat.

Nilai `conversation_type` minimal:

- `direct`
- `group`

### Conversation Members

Menyimpan daftar anggota conversation dan role mereka.

Untuk direct conversation, harus terdapat tepat dua anggota aktif.

Untuk group conversation, jumlah anggota dapat lebih dari dua.

### Messages

Menyimpan ciphertext, bukan plaintext.

Perubahan skema harus tetap kompatibel dengan mekanisme relay dan delivery receipt sebelumnya.

---

# 7. API Architecture Improvement

Endpoint berikut merupakan kontrak API yang diusulkan. Endpoint aktual dapat disesuaikan dengan implementasi backend yang sudah berjalan.

## 7.1 Organization Management

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/v1/organizations` | Membuat organisasi |
| GET | `/api/v1/organizations/me` | Melihat informasi organisasi |
| PATCH | `/api/v1/organizations/me` | Memperbarui informasi organisasi |

Pembuatan organisasi dapat dibatasi untuk proses provisioning awal atau administrator sistem.

## 7.2 User Management

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/v1/organizations/users` | Membuat akun petugas |
| GET | `/api/v1/organizations/users` | Melihat daftar petugas |
| GET | `/api/v1/organizations/users/{id}` | Melihat detail petugas |
| PATCH | `/api/v1/organizations/users/{id}` | Memperbarui informasi/status |
| POST | `/api/v1/organizations/users/{id}/credentials` | Generate activation credential |
| POST | `/api/v1/organizations/users/{id}/revoke` | Mencabut akun |

Semua endpoint tersebut wajib memerlukan administrator authentication dan organization-level authorization.

## 7.3 User Activation and Authentication

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/v1/activation/verify` | Memvalidasi activation credential |
| POST | `/api/v1/activation/complete` | Menyelesaikan aktivasi |
| POST | `/api/v1/auth/challenge` | Meminta authentication challenge |
| POST | `/api/v1/auth/verify` | Memverifikasi device signature |
| GET | `/api/v1/me` | Mendapatkan identitas pengguna aktif |

Endpoint registrasi lama perlu dievaluasi dan dibatasi agar tidak dapat digunakan oleh end-user untuk membuat identity secara mandiri.

## 7.4 Personal Chat

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/v1/conversations/direct` | Membuat atau mendapatkan direct conversation |
| GET | `/api/v1/conversations/direct` | Melihat daftar personal chats |

## 7.5 Group Chat

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/v1/groups` | Membuat grup |
| GET | `/api/v1/groups` | Melihat grup pengguna |
| GET | `/api/v1/groups/{id}` | Detail grup |
| PATCH | `/api/v1/groups/{id}` | Memperbarui informasi grup |
| GET | `/api/v1/groups/{id}/members` | Melihat anggota |
| POST | `/api/v1/groups/{id}/members` | Menambahkan anggota |
| DELETE | `/api/v1/groups/{id}/members/{identity_id}` | Mengeluarkan anggota |
| POST | `/api/v1/groups/{id}/leave` | Keluar dari grup |

## 7.6 Message Relay

Endpoint pesan yang sudah ada tetap dipertahankan dengan penyesuaian authorization.

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/v1/messages` | Mengirim ciphertext |
| GET | `/api/v1/messages/pending` | Mengambil pesan tertunda |
| POST | `/api/v1/messages/{id}/ack` | Mengonfirmasi penerimaan |

Backend harus memvalidasi keanggotaan conversation sebelum menerima atau mengirimkan pesan.

---

# 8. Security and Authorization

## 8.1 Role-Based Access Control

Sistem menggunakan Role-Based Access Control (RBAC) yang dikombinasikan dengan organization-level authorization.

Contoh permission matrix:

| Action | Organization Admin | Field Agent |
|---|---|---|
| Login Web | Yes | No |
| Login Mobile | Policy-based | Yes |
| Create User | Yes | No |
| Generate Credential | Yes | No |
| Revoke User | Yes | No |
| View Organization Users | Yes | No |
| Create Personal Chat | No | Yes |
| Create Group | Organization policy | Yes, if permitted |
| Add Group Member | Organization policy | Group Admin |
| Send Message | No | Conversation Member |
| Read Message | No | Conversation Member |

Kebijakan akhir untuk pembuatan grup dan pengelolaan anggota perlu ditetapkan organisasi.

## 8.2 Authorization Rules

Setiap protected endpoint harus memeriksa:

1. JWT valid.
2. Device aktif.
3. Identity aktif.
4. Organization aktif.
5. User memiliki permission yang sesuai.
6. User merupakan anggota conversation jika mengakses resource komunikasi.

Backend tidak boleh hanya mempercayai `identity_id` atau `organization_id` yang dikirim melalui request body.

Informasi tersebut harus diperoleh dari authenticated context dan diverifikasi melalui database.

## 8.3 E2EE Preservation

Pemisahan Web dan Mobile tidak mengubah batas kepercayaan sistem.

Backend boleh mengetahui metadata yang diperlukan untuk routing, misalnya:

- Conversation ID.
- Sender Device ID.
- Recipient atau membership reference.
- Timestamp.
- Delivery status.

Backend tidak boleh mengetahui plaintext pesan atau private key.

Group membership changes harus memicu prosedur pengelolaan kunci grup yang sesuai.

---

# 9. Deployment Architecture

## 9.1 Deployment Model

Sistem menggunakan satu backend bersama dengan dua aplikasi frontend independen.

```mermaid
flowchart TB
    WEB["Organization Web"]
    MOBILE["Field Agent Mobile"]

    subgraph DOCKER["Docker Infrastructure"]
        API["FastAPI Backend"]
        DB[("PostgreSQL")]
        STORAGE[("Object Storage")]
    end

    WEB -->|HTTPS REST| API
    MOBILE -->|HTTPS REST| API
    MOBILE <-->|WSS| API

    API --> DB
    API --> STORAGE
```

## 9.2 Deployment Components

| Component | Deployment |
|---|---|
| Organization Web | Static web hosting or web container |
| Mobile | Android application package |
| Backend API | Docker container |
| PostgreSQL | Docker container with persistent volume |
| Object Storage | Docker container or external storage |
| WebSocket | Backend service |
| Reverse Proxy | Nginx or equivalent |

## 9.3 Environment Separation

Sistem harus memiliki konfigurasi environment yang terpisah:

- Development.
- Testing.
- Production.

Credential, JWT secret, database password, dan private configuration tidak boleh ditanamkan langsung dalam source code frontend.

---

# 10. Migration Strategy

Improvement harus dilakukan secara bertahap untuk mempertahankan backend dan data yang sudah berjalan.

## Phase 1 — Frontend Separation

Objectives:

- Memisahkan Web dan Mobile.
- Menghapus ketergantungan UI antarplatform.
- Menentukan kontrak API bersama.

Deliverables:

- Organization Web Application.
- Field Agent Mobile Application.
- Shared API integration.

## Phase 2 — Organization Management

Objectives:

- Membuat model organisasi.
- Membuat administrator role.
- Menghubungkan identity dengan organisasi.
- Mengimplementasikan organization authorization.

Deliverables:

- Organization table.
- Organization administrator management.
- Organization API.

## Phase 3 — User Provisioning

Objectives:

- Membuat akun petugas melalui Web.
- Menghasilkan activation credential.
- Menghilangkan registrasi mandiri untuk end-user.
- Mengintegrasikan proses aktivasi dengan device authentication.

Deliverables:

- User management dashboard.
- Credential generation.
- User activation flow.
- User suspension and revocation.

## Phase 4 — Personal and Group Chat Separation

Objectives:

- Memisahkan tab Personal dan Groups.
- Menyempurnakan direct conversation.
- Mengimplementasikan group conversation.
- Menambahkan group membership management.

Deliverables:

- Personal chat tab.
- Group chat tab.
- Group creation.
- Member management.
- Group message relay.

## Phase 5 — Group E2EE

Objectives:

- Mengimplementasikan protokol enkripsi grup.
- Mengelola perubahan keanggotaan.
- Menerapkan key rotation.
- Memastikan anggota yang dikeluarkan tidak dapat membaca pesan baru.

Deliverables:

- Group encryption integration.
- Group key lifecycle.
- Membership change security tests.

---

# 11. Acceptance Criteria

Improvement dianggap memenuhi kebutuhan apabila kriteria berikut tercapai.

## 11.1 Frontend Separation

- [ ] Web dapat dijalankan tanpa harus menjalankan Mobile.
- [ ] Mobile dapat dijalankan tanpa harus menjalankan Web.
- [ ] Web dan Mobile memiliki antarmuka yang dirancang sesuai kebutuhan masing-masing.
- [ ] Keduanya menggunakan backend yang sama.
- [ ] Perubahan UI Web tidak menyebabkan perubahan otomatis pada UI Mobile.

## 11.2 Organization Management

- [ ] Administrator dapat login ke Web.
- [ ] Administrator dapat membuat pengguna.
- [ ] Administrator dapat melihat daftar pengguna.
- [ ] Administrator dapat memperbarui status pengguna.
- [ ] Administrator tidak dapat mengelola organisasi lain tanpa permission.

## 11.3 User Provisioning

- [ ] End-user tidak dapat melakukan registrasi mandiri.
- [ ] Hanya organisasi yang berwenang membuat kredensial.
- [ ] Activation credential memiliki masa berlaku.
- [ ] Activation credential hanya dapat digunakan sekali.
- [ ] Pengguna dapat mengaktifkan akun melalui Mobile.
- [ ] Pengguna yang dicabut tidak dapat melakukan autentikasi baru.

## 11.4 Personal Chat

- [ ] Personal Chat memiliki tab tersendiri.
- [ ] Pengguna dapat memulai direct conversation.
- [ ] Pengguna dapat mengirim dan menerima pesan.
- [ ] Hanya anggota conversation yang dapat mengakses pesan.
- [ ] Pesan tetap menggunakan E2EE.

## 11.5 Group Chat

- [ ] Group Chat memiliki tab tersendiri.
- [ ] Pengguna yang memiliki permission dapat membuat grup.
- [ ] Group Admin dapat mengelola anggota.
- [ ] Anggota dapat mengirim dan menerima pesan.
- [ ] Pengguna yang keluar atau dikeluarkan tidak dapat mengakses pesan baru.
- [ ] Perubahan keanggotaan memicu mekanisme pengamanan kunci grup.

---

# 12. Risks and Considerations

| Risk | Impact | Mitigation |
|---|---|---|
| Web dan Mobile masih berbagi UI secara tidak terkontrol | Ketergantungan platform | Pisahkan frontend dan kontrak API |
| Credential activation bocor | Pengambilalihan akun | One-time credential, expiry, revocation |
| Admin mengakses organisasi lain | Pelanggaran isolasi data | Organization-level authorization |
| User revoked masih memiliki JWT aktif | Akses tidak sah | Validasi status device dan identity |
| Anggota grup lama masih memiliki group key | Kebocoran pesan berikutnya | Key rotation saat membership berubah |
| Database migration merusak data | Kehilangan data | Migration bertahap dan backup |
| Group message relay tidak memeriksa membership | Akses pesan tanpa izin | Server-side membership authorization |

---

# 13. Final Architectural Decisions

Keputusan arsitektur yang menjadi dasar implementasi SAD v2.0:

1. Web dan Mobile merupakan dua aplikasi independen.
2. Keduanya menggunakan shared backend.
3. Organisasi menjadi pihak yang memiliki kewenangan provisioning pengguna.
4. End-user tidak memiliki fitur registrasi mandiri.
5. Setiap pengguna memiliki identity yang terkait dengan organisasi.
6. Device authentication tetap menggunakan mekanisme Ed25519 dan JWT yang telah dirancang.
7. Personal Chat dan Group Chat merupakan dua kategori conversation berbeda.
8. Mobile menyediakan tab terpisah untuk Personal dan Group Chat.
9. Group Chat harus mendukung membership management.
10. Seluruh pesan tetap menggunakan prinsip E2EE.
11. Backend bertanggung jawab atas authorization dan message relay, bukan dekripsi pesan.
12. Perubahan sistem dilakukan secara bertahap tanpa menghapus data dan infrastruktur yang sudah berjalan.

---

# 14. Open Design Questions

Beberapa keputusan berikut masih membutuhkan konfirmasi sebelum implementasi final:

| Question | Design Decision Required |
|---|---|
| Organization onboarding | Apakah organisasi dapat mendaftar sendiri atau harus dibuat oleh system administrator? |
| Admin roles | Apakah hanya satu admin atau terdapat beberapa level administrator? |
| User credentials | Apakah aktivasi menggunakan username + temporary password, activation code, atau kombinasi keduanya? |
| Account ownership | Apakah satu petugas hanya boleh memiliki satu organisasi? |
| Group creation | Apakah semua petugas boleh membuat grup atau hanya administrator tertentu? |
| Group membership | Apakah grup hanya dapat berisi anggota dari organisasi yang sama? |
| Web communication | Apakah organisasi hanya mengelola akun dan grup atau juga dapat mengakses fitur komunikasi? |
| Group encryption | Protokol apa yang akan digunakan untuk group E2EE? |

Keputusan tersebut harus ditetapkan sebelum seluruh endpoint dan database schema dianggap final.

---

# 15. Conclusion

SAD v2.0 mengarahkan Secure Field Communication dari aplikasi komunikasi yang masih memiliki ketergantungan antarmuka menuju sistem komunikasi terorganisasi dengan pemisahan peran dan platform.

Perubahan utama terletak pada:

- Independent Web and Mobile Applications.
- Organization-Controlled User Provisioning.
- Centralized Backend Authorization.
- Separate Personal and Group Conversations.
- Secure Group Membership Management.

Dengan arsitektur ini, organisasi memiliki kontrol administratif terhadap pengguna, sedangkan petugas lapangan tetap memiliki pengalaman komunikasi yang sederhana melalui aplikasi Mobile.

Backend yang sudah berjalan tetap menjadi fondasi sistem sehingga improvement dapat dilakukan secara bertahap tanpa harus membangun ulang keseluruhan aplikasi.