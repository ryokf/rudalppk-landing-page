# PERISAI-Q --- Product Requirements Document (PRD)

**Document type:** Product Requirements Document\
**Product:** PERISAI-Q Post-Quantum Cryptosuite\
**Version:** 0.1 --- Development Baseline\
**Status:** Draft for engineering review\
**Source basis:** *PERISAI-Q: Post_Quantum_Cryptosuite* concept
presentation (11 pages)

> **Document note:** This PRD translates the supplied concept into
> development-oriented requirements. It preserves the concept's stated
> capabilities and targets. Items not specified in the source are marked
> **TBD** or **proposed for validation** rather than treated as
> established facts.

------------------------------------------------------------------------

## 1. Product overview

### 1.1 Product description

PERISAI-Q (Proteksi Enkripsi & Siber Anti-Infiltrasi Kuantum untuk
Operasi Lapangan) is a proposed modular, offline-capable post-quantum
cryptography platform for protecting tactical communications,
operational documents, digital command instructions, and IT/OT assets.

The concept combines:

1.  **PERISAI-Vault** --- encryption and local protection of files and
    tactical communications.
2.  **PERISAI-Sign** --- digital signing and verification of command
    instructions and OT/IoT firmware packages.
3.  **PERISAI-Lab** --- a local cryptographic audit and quantum-threat
    simulation environment.
4.  **Relay Integration** --- asynchronous forwarding of encrypted
    packages between users or teams.

The platform is intended to operate on standard laptops and mobile
devices, including in offline or low-bandwidth field conditions.

### 1.2 Product vision

Provide a locally controlled, auditable cryptographic protection suite
that can demonstrate and measure readiness for post-quantum threats
while supporting field operation without dependence on an external
quantum cloud service.

### 1.3 Product positioning

  -----------------------------------------------------------------------
  Position                            Description
  ----------------------------------- -----------------------------------
  Encryption tool                     Protects files and messages at rest
                                      and in transit using a proposed
                                      hybrid/PQC cryptographic design.

  Digital command integrity tool      Verifies the origin and integrity
                                      of signed command and firmware
                                      artifacts.

  Vulnerability auditor               Assesses legacy cryptographic
                                      configurations and provides a
                                      quantum-readiness testbed.
  -----------------------------------------------------------------------

### 1.4 Intended users

The concept identifies military and defense operations, including
personnel and teams operating in disconnected or bandwidth-constrained
environments.

Specific user roles, organizational hierarchy, authorization rules, and
deployment boundaries are **TBD** and must be confirmed with the product
owner.

------------------------------------------------------------------------

## 2. Problem statement

The concept identifies six problems:

1.  **Classical cryptographic risk:** RSA and ECC are exposed to future
    quantum attacks, including Shor's algorithm.
2.  **Harvest Now, Decrypt Later (HNDL):** intercepted ciphertext may be
    stored today and attacked when sufficiently capable quantum
    computers become available.
3.  **Long confidentiality lifetime:** sensitive operational information
    may require protection for decades.
4.  **Command-chain and OT/IoT risk:** command instructions and firmware
    updates may be spoofed or modified.
5.  **Limited independent audit capability:** organizations need tools
    to evaluate the readiness of legacy systems.
6.  **External infrastructure dependency:** reliance on foreign cloud
    services may create telemetry, availability, and
    information-sovereignty concerns.

### 2.1 Product response

PERISAI-Q is intended to address these problems through local key
management, post-quantum algorithms, signed command artifacts, offline
operation, a ciphertext-only relay model, and a local audit/simulation
laboratory.

------------------------------------------------------------------------

## 3. Goals and success measures

### 3.1 Product goals

-   Provide a usable workflow for generating local PQC identities and
    key material.
-   Encrypt and decrypt supported files and messages.
-   Verify digital signatures on commands and firmware artifacts.
-   Support offline use and store-and-forward synchronization.
-   Allow encrypted packages to be relayed without exposing plaintext to
    the relay.
-   Provide a laboratory for demonstrating classical cryptographic
    weaknesses and evaluating PQC configurations.
-   Provide audit information useful for crypto-agility and
    legacy-system readiness.

### 3.2 Success metrics stated in the concept

  ---------------------------------------------------------------------------
  Metric                              Concept target Measurement
                                                     clarification
  --------------------- ---------------------------- ------------------------
  Future                               10--20+ years Strategic target;
  confidentiality                                    requires a threat model
                                                     and cryptographic
                                                     review.

  Command and OT                     "Zero spoofing" Must be translated into
  integrity                                          measurable
                                                     signature-verification
                                                     and authorization tests.

  Continuous audit                    Continuous Lab Demonstrate repeatable
                                                     audits and retained
                                                     results.

  Performance                            Below 50 ms The concept does not
                                                     define operation,
                                                     payload size, device
                                                     class, or percentile.
                                                     Benchmark scope is TBD.

  Live demonstration     Classical RSA contrast with Demonstrate a bounded,
                                           PERISAI-Q reproducible test
                                                     scenario; do not imply
                                                     that a practical quantum
                                                     computer is being used.
  ---------------------------------------------------------------------------

### 3.3 MVP completion criteria

The concept's MVP consists of:

-   MVP-01: Sheetphrase-based PQC key generator.
-   MVP-02: PERISAI-Vault and PERISAI-Sign.
-   MVP-03: relay transmission integration.
-   MVP-04: live demonstration of a test-scale classical RSA attack
    using Qiskit/QUBO.
-   MVP-05: live demonstration of PQC protection.

A release is not considered production-ready solely because these
demonstrations work. Security review, key lifecycle design, recovery,
interoperability, and operational testing remain required.

------------------------------------------------------------------------

## 4. Scope

### 4.1 In scope

#### Identity and key management

-   Generate a local cryptographic seed using the proposed Sheetphrase
    concept.
-   Derive or generate PQC key pairs for the required cryptographic
    purposes.
-   Keep private keys on the user's device.
-   Exchange public keys between team members.
-   Provide a defined process for device loss, access revocation, and
    recovery.

#### PERISAI-Vault

-   Encrypt and decrypt tactical messages and files.
-   Support the file/media categories named in the concept: PDF
    documents, maps/coordinates, photographs, and voice notes.
-   Protect local stored files using a local vault.
-   Queue encrypted packages while offline.
-   Synchronize queued packages when connectivity returns.

#### PERISAI-Sign

-   Sign command documents and OT/IoT firmware/update packages.
-   Verify signatures locally using trusted public keys.
-   Reject modified or invalidly signed artifacts.
-   Record verification and command-chain audit events.

#### PERISAI-Lab

-   Demonstrate factoring of deliberately small/test RSA keys.
-   Use local Qiskit Aer simulation and QUBO modelling as described in
    the concept.
-   Scan configured legacy cryptographic parameters and produce a
    readiness assessment.
-   Visualize comparative properties of classical and PQC
    configurations.
-   Support crypto-agility experiments and training.

#### Relay integration

-   Accept encrypted packages for asynchronous forwarding.
-   Store and forward ciphertext without needing plaintext access.
-   Support REST API and/or CLI integration as described in the concept.

### 4.2 Out of scope for the initial MVP

The supplied concept does not define the following as implemented MVP
capabilities. They should not be assumed without separate approval:

-   A production military command-and-control system.
-   Direct control of weapons, vehicles, or safety-critical OT
    equipment.
-   A certified or accredited defense cryptographic product.
-   A production-scale quantum computer attack.
-   Guaranteed resistance to every present or future attack.
-   A centralized identity provider or cloud-based private-key custody.
-   A complete enterprise certificate authority or public-key
    infrastructure.
-   A specific mobile or desktop operating-system support matrix.
-   A specific relay hosting provider or deployment topology.

------------------------------------------------------------------------

## 5. Stakeholders and user roles

The concept does not provide a formal role model. The following roles
are **proposed for requirements discussion**, not confirmed
organizational roles.

  -----------------------------------------------------------------------
  Proposed role                       Primary needs
  ----------------------------------- -----------------------------------
  Field operator                      Encrypt/decrypt files and messages;
                                      verify signed instructions; operate
                                      offline.

  Commander / authorized signer       Sign command artifacts and
                                      distribute verification keys.

  Security administrator              Manage trusted public keys,
                                      revocation, policy, and audit
                                      records.

  Cryptographic auditor               Assess legacy configurations and
                                      review audit results.

  Lab/training operator               Run controlled attack
                                      demonstrations and PQC comparisons.

  Relay service operator              Maintain package delivery without
                                      access to plaintext or private
                                      keys.
  -----------------------------------------------------------------------

Role permissions, separation of duties, and approval workflows must be
specified before implementation.

------------------------------------------------------------------------

## 6. Functional requirements

Priority definitions: **P0** = required for the MVP; **P1** = important
follow-up; **TBD** = priority needs product-owner confirmation.

### 6.1 Identity and key management

  ---------------------------------------------------------------------------
  ID               Requirement                      Priority Acceptance
                                                             criteria
  ---------------- ------------------- --------------------- ----------------
  ID-001           The system shall                       P0 A user can
                   create a local                            create an
                   identity using the                        identity locally
                   Sheetphrase-based                         without a phone
                   workflow.                                 number, email
                                                             address, or
                                                             centralized
                                                             registration
                                                             server.

  ID-002           The system shall                       P0 The application
                   generate PQC key                          generates
                   material for key                          separate key
                   encapsulation and                         material for the
                   digital signatures.                       configured KEM
                                                             and signature
                                                             algorithms.

  ID-003           The system shall                       P0 A test peer can
                   support ML-KEM                            establish
                   (Kyber) for key                           matching shared
                   establishment.                            secret material
                                                             through the
                                                             implemented KEM
                                                             flow.

  ID-004           The system shall                       P0 A signature
                   support ML-DSA                            created by one
                   (Dilithium) for                           test identity
                   digital signatures.                       verifies with
                                                             its
                                                             corresponding
                                                             public key and
                                                             fails with an
                                                             unrelated key.

  ID-005           The system shall                       P0 Network
                   retain private keys                       inspection and
                   locally and shall                         automated tests
                   not transmit them                         show no
                   to the relay.                             private-key
                                                             material in
                                                             relay requests
                                                             or stored relay
                                                             records.

  ID-006           The system shall                       P0 Two test
                   support public-key                        identities can
                   exchange between                          exchange public
                   team members.                             keys and
                                                             establish a
                                                             secure session
                                                             according to the
                                                             selected
                                                             protocol.

  ID-007           The system shall                       P0 A revoked
                   provide a key                             identity/key is
                   revocation                                rejected by
                   procedure for lost                        clients that
                   devices or                                have received
                   compromised                               the updated
                   personnel.                                revocation
                                                             state.

  ID-008           The system shall                       P1 Recovery
                   define secure                             behavior is
                   recovery behavior                         documented and
                   for lost devices or                       tested; no
                   Sheetphrases.                             recovery
                                                             mechanism may
                                                             silently weaken
                                                             private-key
                                                             protection.
  ---------------------------------------------------------------------------

### 6.2 PERISAI-Vault

  -----------------------------------------------------------------------------------
  ID               Requirement                   Priority Acceptance criteria
  ---------------- ---------------- --------------------- ---------------------------
  VLT-001          The system shall                    P0 An authorized recipient can
                   encrypt and                            decrypt a valid package and
                   decrypt                                recover the original file
                   supported files.                       byte-for-byte.

  VLT-002          The system shall                    P0 A message can be sent as
                   encrypt and                            ciphertext and recovered
                   decrypt tactical                       only by an authorized
                   text messages.                         recipient.

  VLT-003          The system shall                    P0 PDF, image, coordinate/map
                   support the                            data, and voice-note test
                   media categories                       fixtures can be encrypted
                   identified in                          and decrypted.
                   the concept.                           

  VLT-004          The system shall                    P0 Stored vault content is
                   protect files                          encrypted at rest and
                   stored in the                          cannot be read as plaintext
                   local vault.                           without successful
                                                          authorization/decryption.

  VLT-005          The system shall                    P0 Modification of ciphertext,
                   use                                    nonce, or authentication
                   authenticated                          data causes
                   encryption for                         decryption/authentication
                   protected                              failure.
                   payloads.                              

  VLT-006          The system shall                    P0 A package created without
                   queue encrypted                        connectivity remains queued
                   packages when                          and is eligible for later
                   offline.                               synchronization.

  VLT-007          The system shall                    P0 Queued packages are
                   synchronize                            transmitted and delivery
                   queued packages                        state is updated without
                   when                                   re-encrypting them with
                   connectivity                           weaker protection.
                   returns.                               

  VLT-008          The system shall                    P1 The user can distinguish at
                   expose package                         least queued, transmitting,
                   status to the                          delivered/relayed, and
                   user.                                  failed states.
  -----------------------------------------------------------------------------------

### 6.3 PERISAI-Sign

  --------------------------------------------------------------------------
  ID               Requirement                     Priority Acceptance
                                                            criteria
  ---------------- ------------------ --------------------- ----------------
  SIG-001          The system shall                      P0 A valid
                   sign command                             signature
                   documents using                          verifies against
                   ML-DSA.                                  the expected
                                                            signer public
                                                            key.

  SIG-002          The system shall                      P0 A test firmware
                   sign OT/IoT                              package can be
                   firmware or update                       signed and
                   packages.                                verified before
                                                            acceptance.

  SIG-003          The system shall                      P0 Changing even
                   reject modified                          one bit in the
                   signed artifacts.                        signed content
                                                            causes signature
                                                            verification to
                                                            fail.

  SIG-004          The system shall                      P0 Verification
                   support offline                          succeeds or
                   signature                                fails using
                   verification.                            locally
                                                            available
                                                            trusted public
                                                            keys without
                                                            contacting a
                                                            server.

  SIG-005          The system shall                      P1 Audit records
                   record                                   include artifact
                   verification                             identifier,
                   outcomes.                                signer/key
                                                            identifier,
                                                            timestamp, and
                                                            verification
                                                            result.

  SIG-006          The system shall                      P0 A revoked signer
                   check                                    is not accepted
                   revocation/trust                         under the
                   status before                            configured
                   accepting an                             policy.
                   artifact when                            
                   revocation data is                       
                   available.                               
  --------------------------------------------------------------------------

### 6.4 PERISAI-Lab

  ----------------------------------------------------------------------------
  ID               Requirement                   Priority Acceptance criteria
  ---------------- ---------------- --------------------- --------------------
  LAB-001          The system shall                    P0 A documented
                   provide a local                        simulation scenario
                   quantum                                runs locally on a
                   simulation                             supported
                   environment                            development device.
                   based on Qiskit                        
                   Aer as proposed.                       

  LAB-002          The system shall                    P1 A documented QUBO
                   provide                                test case executes
                   QUBO-based                             and produces
                   modelling or                           reproducible output.
                   solver                                 
                   integration as                         
                   proposed.                              

  LAB-003          The system shall                    P0 The demonstration
                   demonstrate                            recovers the factors
                   factoring of                           for the defined test
                   deliberately                           fixture and clearly
                   small RSA test                         displays the test
                   keys.                                  key size.

  LAB-004          The system shall                    P0 UI and documentation
                   not represent                          identify the
                   small-key                              demonstration as a
                   simulation as a                        bounded educational
                   practical break                        simulation.
                   of production                          
                   RSA.                                   

  LAB-005          The system shall                    P1 A test configuration
                   assess                                 is scanned and
                   configured                             reported with
                   legacy                                 algorithm,
                   cryptographic                          key-size/parameter
                   parameters.                            information where
                                                          available, and
                                                          findings.

  LAB-006          The system shall                    P1 The user can view
                   visualize                              the selected
                   comparative                            comparison data and
                   classical/PQC                          its assumptions.
                   properties.                            

  LAB-007          The system shall                    P1 A completed audit
                   retain audit                           can be reopened or
                   results for                            exported with its
                   review.                                configuration and
                                                          timestamp.
  ----------------------------------------------------------------------------

### 6.5 Relay and interoperability

  ----------------------------------------------------------------------------
  ID               Requirement                   Priority Acceptance criteria
  ---------------- ---------------- --------------------- --------------------
  RLY-001          The relay shall                     P0 A client can submit
                   accept encrypted                       a valid ciphertext
                   packages for                           package and receive
                   asynchronous                           a package
                   forwarding.                            identifier/status.

  RLY-002          The relay shall                     P0 Relay processing
                   not require                            works using
                   plaintext or                           ciphertext and
                   private keys to                        routing metadata
                   forward                                only.
                   packages.                              

  RLY-003          The relay shall                     P0 Tests and log review
                   not expose                             find no plaintext
                   plaintext                              payloads or private
                   through logs,                          keys.
                   diagnostics, or                        
                   administrative                         
                   views.                                 

  RLY-004          The client shall                    P0 An intended
                   retrieve or                            recipient can
                   receive queued                         retrieve the
                   packages when                          encrypted package
                   connectivity is                        and decrypt it
                   available.                             locally.

  RLY-005          The system shall                    P1 A documented
                   provide an                             integration test can
                   integration                            submit and retrieve
                   interface                              a test package.
                   through REST API                       
                   and/or CLI.                            

  RLY-006          The system shall                    P1 Package transfer can
                   support                                resume or retry
                   low-bandwidth                          according to a
                   operation.                             documented protocol
                                                          without corrupting
                                                          package integrity.
  ----------------------------------------------------------------------------

------------------------------------------------------------------------

## 7. Non-functional requirements

  ------------------------------------------------------------------------
  ID                      Category                Requirement
  ----------------------- ----------------------- ------------------------
  NFR-001                 Offline operation       Core identity,
                                                  encryption/decryption,
                                                  signing, and local
                                                  verification workflows
                                                  should operate without
                                                  internet connectivity.

  NFR-002                 Data confidentiality    Plaintext and private
                                                  keys must remain on
                                                  authorized endpoints;
                                                  relay services handle
                                                  ciphertext only.

  NFR-003                 Integrity               Encrypted payloads and
                                                  signed artifacts must
                                                  fail closed when
                                                  authentication or
                                                  signature checks fail.

  NFR-004                 Performance             The concept states a
                                                  target below 50 ms. The
                                                  exact operation, payload
                                                  size, device class, and
                                                  measurement method must
                                                  be defined before this
                                                  becomes a release
                                                  requirement.

  NFR-005                 Resource use            The system is intended
                                                  for standard laptops and
                                                  mobile devices; minimum
                                                  CPU, memory, storage,
                                                  and battery requirements
                                                  are TBD.

  NFR-006                 Low bandwidth           Ciphertext and signature
                                                  sizes and
                                                  synchronization behavior
                                                  should be evaluated for
                                                  tactical low-bandwidth
                                                  networks.

  NFR-007                 Auditability            The implementation
                                                  should use open-source
                                                  components where
                                                  practical and maintain
                                                  reproducible build and
                                                  dependency records.

  NFR-008                 Portability             The concept targets
                                                  standard devices, but
                                                  supported OS and
                                                  architecture
                                                  combinations must be
                                                  explicitly selected and
                                                  tested.

  NFR-009                 Reliability             Interrupted transfers
                                                  must not result in
                                                  silently accepted
                                                  partial or corrupted
                                                  packages.

  NFR-010                 Usability               Field workflows should
                                                  clearly communicate
                                                  identity, recipient,
                                                  signature status,
                                                  encryption status, and
                                                  synchronization status.

  NFR-011                 Privacy                 Telemetry and diagnostic
                                                  output must not disclose
                                                  sensitive plaintext,
                                                  private keys, or
                                                  unnecessary operational
                                                  metadata.

  NFR-012                 Maintainability         Cryptographic algorithms
                                                  and parameters should be
                                                  replaceable through a
                                                  controlled
                                                  crypto-agility design.
  ------------------------------------------------------------------------

------------------------------------------------------------------------

## 8. User workflows

### 8.1 Initial identity setup

1.  User opens PERISAI-Q on a local device.
2.  User creates or enters the Sheetphrase-based identity input.
3.  The application generates the required local PQC key material.
4.  Private keys are stored locally under the approved protection
    mechanism.
5.  User exports or shares the relevant public-key information with
    authorized peers.
6.  The peer imports and validates the public-key information.

**Open design items:** Sheetphrase entropy and encoding, derivation
function, salt/context handling, backup, rate limiting, secure storage,
and identity binding are not specified by the concept.

### 8.2 Encrypt and send a file

1.  User selects a file in PERISAI-Vault.
2.  User selects the intended recipient(s).
3.  The application performs the approved key-establishment and
    symmetric-encryption workflow.
4.  The application creates an encrypted package with the metadata
    required for decryption and verification.
5.  If online, the package is submitted to the relay; if offline, it is
    queued locally.
6.  The recipient retrieves the package and decrypts it locally.

### 8.3 Sign and verify a command

1.  An authorized signer selects a command document or firmware package.
2.  PERISAI-Sign creates a digital signature.
3.  The signed artifact is distributed.
4.  The recipient verifies the signature using the trusted public key
    and local policy.
5.  Modified, invalid, or untrusted artifacts are rejected.
6.  The result is recorded in the audit trail.

### 8.4 Run a laboratory demonstration

1.  The operator selects a controlled test scenario.
2.  The lab runs a small-key classical RSA demonstration.
3.  The operator observes the simulation output and recovered test
    factors.
4.  The operator runs the corresponding PQC test scenario.
5.  The interface displays the results and clearly states the simulation
    limits.

------------------------------------------------------------------------

## 9. Data and information requirements

The concept implies the following logical data categories. Exact schemas
are not supplied.

  -----------------------------------------------------------------------
  Data category           Examples                Handling requirement
  ----------------------- ----------------------- -----------------------
  Local identity          Sheetphrase-derived     Keep sensitive input
                          identity metadata       and private material
                                                  local.

  Key material            ML-KEM and ML-DSA       Private keys remain on
                          private/public keys     endpoint; public keys
                                                  may be exchanged.

  Encrypted package       Ciphertext, nonce,      Relay may store and
                          algorithm/version       forward without
                          identifiers,            plaintext access.
                          recipient/key           
                          references              

  Signed artifact         Original artifact or    Verify before
                          package, signature,     operational acceptance.
                          signer key identifier   

  Revocation information  Revoked key/identity    Distribute and enforce
                          identifiers and status  according to defined
                          metadata                policy.

  Audit event             Action, timestamp,      Avoid logging plaintext
                          actor/key identifier,   or private key
                          result                  material.

  Lab result              Scenario, parameters,   Preserve enough context
                          tool versions, findings for reproducibility.
  -----------------------------------------------------------------------

The final package format, metadata schema, retention policy, and data
classification rules are **TBD**.

------------------------------------------------------------------------

## 10. Security and safety requirements

1.  Use reviewed cryptographic libraries and standardized algorithm
    implementations; do not implement cryptographic primitives from
    scratch.
2.  Keep key encapsulation, digital-signature, and symmetric-encryption
    purposes separate.
3.  Authenticate encrypted payloads and reject tampering.
4.  Protect private keys at rest using an explicitly selected platform
    mechanism.
5.  Do not transmit private keys or plaintext to the relay.
6.  Define key generation, rotation, revocation, backup, recovery, and
    destruction procedures.
7.  Bind public keys to verified identities; unauthenticated public-key
    exchange is vulnerable to substitution.
8.  Define replay protection, message ordering, expiry, and
    duplicate-delivery behavior.
9.  Treat relay metadata as potentially sensitive even when payloads are
    encrypted.
10. Treat the lab as a controlled simulation and audit environment, not
    as proof that all PQC systems are unbreakable.
11. Conduct independent cryptographic design review, code review,
    dependency review, and penetration testing before operational
    deployment.
12. Do not connect the MVP directly to safety-critical OT or
    weapon-control systems.

------------------------------------------------------------------------

## 11. Dependencies and constraints

### 11.1 Dependencies identified by the concept

-   NIST PQC algorithms ML-KEM and ML-DSA.
-   X25519 for the proposed hybrid key-establishment design.
-   AES-256-GCM for symmetric authenticated encryption.
-   IBM Qiskit Aer for local simulation.
-   QUBO modelling/solver capability.
-   Local laptop/mobile computing resources.
-   Relay service and REST API/CLI integration.

### 11.2 Constraints

-   Offline-first operation.
-   No requirement for phone number, email, or centralized registration
    in the proposed Sheetphrase identity flow.
-   No private-key custody by the relay.
-   Low-bandwidth field communication.
-   Open-source and auditable implementation preference.

### 11.3 Technical validation required

The concept names ML-KEM-768/1024, X25519, AES-256-GCM, and ML-DSA but
does not define a complete interoperable protocol. The engineering team
must specify algorithm versions, parameter sets, key derivation,
transcript binding, domain separation, nonce management, serialization,
and downgrade behavior before implementation.

The concept's statement that a Sheetphrase can directly provide a
high-strength seed must also be validated. A human-memorable phrase is
not automatically high entropy. A reviewed password-based derivation or
a securely generated random seed may be required.

------------------------------------------------------------------------

## 12. Risks and mitigations

  -----------------------------------------------------------------------
  Risk                    Impact                  Mitigation / action
  ----------------------- ----------------------- -----------------------
  Weak or predictable     Identity/key compromise Define entropy
  Sheetphrase                                     requirements and a
                                                  reviewed derivation or
                                                  random-seed process.

  Unauthenticated         Man-in-the-middle       Define identity binding
  public-key exchange     attack                  and out-of-band or
                                                  organizational key
                                                  verification.

  Incorrect hybrid        Security failure        Use a reviewed protocol
  construction            despite strong          design and
                          primitives              cryptographic library;
                                                  obtain independent
                                                  review.

  Lost device/private key Loss of access or       Define backup,
                          unauthorized access     recovery, revocation,
                                                  and re-enrollment
                                                  procedures.

  Stale revocation state  Revoked key may still   Define revocation
  while offline           be trusted              freshness policy and
                                                  fail-safe behavior for
                                                  high-risk actions.

  Relay metadata leakage  Operational information Minimize metadata,
                          disclosure              protect transport,
                                                  access-control relay
                                                  records, and define
                                                  retention.

  Oversold quantum        Misleading security     Label simulations and
  demonstration           claims                  test-key sizes clearly;
                                                  separate simulation
                                                  from real quantum
                                                  capability.

  Performance target not  Failed acceptance or    Define benchmark
  reproducible            field usability         hardware, operation,
                                                  payload size, and
                                                  percentile.

  OT integration causes   Operational or physical Keep MVP in
  unsafe behavior         impact                  test/sandbox
                                                  environments; require
                                                  separate safety and
                                                  authorization review.

  Algorithm or library    Interoperability and    Version protocol suites
  changes                 maintenance issues      and implement
                                                  controlled
                                                  crypto-agility.
  -----------------------------------------------------------------------

------------------------------------------------------------------------

## 13. Acceptance and release gates

### MVP gate

-   Local identity and PQC key generation demonstrated.
-   File/message encryption and decryption demonstrated.
-   Signature creation and verification demonstrated.
-   Tampered content is rejected.
-   Offline queue and later relay synchronization demonstrated.
-   Relay cannot access plaintext or private keys.
-   Controlled RSA test-key simulation demonstrated.
-   PQC demonstration clearly distinguishes algorithmic protection from
    simulation limitations.
-   Basic audit results are available.

### Pre-operational gate

-   Cryptographic protocol design reviewed independently.
-   Key lifecycle, identity binding, revocation, and recovery fully
    specified.
-   Threat model and security requirements approved.
-   Supported platform matrix and performance benchmarks documented.
-   Relay privacy and metadata risks assessed.
-   Security testing and failure-mode testing completed.
-   OT integration separately assessed and authorized.

------------------------------------------------------------------------

## 14. Open questions requiring product-owner decisions

1.  Which platforms are mandatory for the first release: desktop,
    Android, iOS, or all?
2.  Is the MVP a standalone application, a reusable security engine/API,
    or both?
3.  What is the exact Sheetphrase format and how is identity enrollment
    authenticated?
4.  How are public keys authenticated and associated with real
    users/roles?
5.  What is the approved recovery process if a device or Sheetphrase is
    lost?
6.  Which hybrid protocol is intended: X25519 plus ML-KEM in a reviewed
    combiner, or another defined construction?
7.  Which ML-KEM and ML-DSA parameter sets and implementation versions
    are required?
8.  What are the relay's authentication, authorization, retention, and
    availability requirements?
9.  What payload sizes and radio/network constraints must be supported?
10. What exactly must complete in less than 50 ms?
11. Which legacy systems and configuration sources must PERISAI-Lab
    audit?
12. What is the intended scope of OT/IoT integration for the MVP?
13. What audit-log retention, export, and tamper-evidence requirements
    apply?
14. What security certification, organizational approval, or compliance
    framework is required?

------------------------------------------------------------------------

## 15. Traceability to the supplied concept

  Concept presentation                          PRD sections
  --------------------------------------------- ----------------
  Page 1 --- Product identity and positioning   1
  Page 2 --- Problems to solve                  2
  Page 3 --- Product niche and capabilities     1, 3, 4
  Page 4 --- Sheetphrase identity workflow      6.1, 8.1, 11.3
  Page 5 --- High-level architecture            4, 6.5
  Page 6 --- PERISAI-Vault                      6.2, 8.2
  Page 7 --- PERISAI-Sign                       6.3, 8.3
  Page 8 --- PERISAI-Lab                        6.4, 8.4
  Page 9 --- Operational requirements           7, 10, 11
  Page 10 --- MVP                               3.3, 13
  Page 11 --- Success metrics                   3.2

------------------------------------------------------------------------

## 16. Glossary

-   **PQC:** Post-Quantum Cryptography.
-   **ML-KEM:** Module-Lattice-Based Key-Encapsulation Mechanism;
    identified in the concept with Kyber.
-   **ML-DSA:** Module-Lattice-Based Digital Signature Algorithm;
    identified in the concept with Dilithium.
-   **HNDL:** Harvest Now, Decrypt Later.
-   **OT/IoT:** Operational Technology / Internet of Things.
-   **KEM:** Key Encapsulation Mechanism.
-   **QUBO:** Quadratic Unconstrained Binary Optimization.
-   **Relay:** A service that forwards encrypted packages between
    clients.
-   **Crypto-agility:** The ability to change cryptographic algorithms
    and parameters through controlled configuration and protocol
    evolution.
-   **Sheetphrase:** The local identity phrase concept used by
    PERISAI-Q; its exact format and cryptographic derivation remain to
    be specified.
