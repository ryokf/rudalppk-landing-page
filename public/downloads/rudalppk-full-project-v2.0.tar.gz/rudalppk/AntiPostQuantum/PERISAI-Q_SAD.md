# PERISAI-Q --- Software Architecture Document (SAD)

**Document type:** Software Architecture Document\
**Product:** PERISAI-Q Post-Quantum Cryptosuite\
**Version:** 0.1 --- Development Baseline\
**Status:** Draft for architecture and security review\
**Source basis:** *PERISAI-Q: Post_Quantum_Cryptosuite* concept
presentation (11 pages)

> **Architecture note:** This SAD translates the supplied concept into a
> development-oriented logical architecture. It does not claim that the
> design has been implemented or cryptographically validated. Protocol
> details absent from the concept are explicitly marked as decisions
> required before implementation.

------------------------------------------------------------------------

## 1. Purpose and scope

This document describes the proposed software architecture for
PERISAI-Q: a modular, offline-capable post-quantum cryptography suite
for tactical file/message protection, command and firmware signing, and
cryptographic auditing/simulation.

It covers:

-   Logical system decomposition.
-   Component responsibilities and boundaries.
-   Data flows and trust boundaries.
-   Proposed cryptographic processing flows.
-   Local storage and relay responsibilities.
-   Offline synchronization.
-   Audit and simulation architecture.
-   Security, deployment, and operational considerations.
-   Decisions that must be resolved before implementation.

It does not specify a production-ready cryptographic protocol or certify
the system for military/OT deployment.

------------------------------------------------------------------------

## 2. Architecture drivers

### 2.1 Functional drivers

1.  Local identity and PQC key generation using the Sheetphrase concept.
2.  Hybrid/PQC key establishment and authenticated symmetric encryption.
3.  File and message protection at rest and in transit.
4.  ML-DSA digital signatures for commands and firmware artifacts.
5.  Offline queueing and later synchronization.
6.  Ciphertext-only relay integration.
7.  Local quantum simulation, legacy audit, and PQC visualization.
8.  REST API and/or CLI interoperability.

### 2.2 Quality attribute drivers

  -----------------------------------------------------------------------
  Attribute                           Architectural implication
  ----------------------------------- -----------------------------------
  Confidentiality                     Private keys and plaintext stay on
                                      endpoints; relay receives
                                      ciphertext only.

  Integrity/authenticity              Authenticated encryption and
                                      digital signature verification are
                                      mandatory.

  Offline capability                  Core cryptographic operations and
                                      verification cannot depend on relay
                                      availability.

  Low bandwidth                       Transfer protocol needs bounded
                                      metadata, retry/resume behavior,
                                      and explicit package sizing.

  Portability                         Cryptographic engine should be
                                      separated from UI and
                                      platform-specific storage.

  Auditability                        Components, dependencies, protocol
                                      versions, and audit events should
                                      be inspectable.

  Crypto-agility                      Algorithm suites and package
                                      formats require explicit versioning
                                      and migration paths.

  Performance                         Expensive operations and payload
                                      encryption should be measured
                                      separately.
  -----------------------------------------------------------------------

------------------------------------------------------------------------

## 3. Architecture overview

### 3.1 Logical architecture

``` mermaid
flowchart LR
    U[Field User / Authorized Operator] --> UI[Tactical Interface Layer]

    UI --> ID[Identity & Key Management]
    UI --> V[PERISAI-Vault]
    UI --> S[PERISAI-Sign]
    UI --> L[PERISAI-Lab]

    ID --> CE[PERISAI-Q Crypto Engine]
    V --> CE
    S --> CE

    CE --> KS[Local Key Store]
    V --> LS[Encrypted Local Vault]
    V --> OQ[Offline Outbox / Sync Queue]
    S --> AL[Local Audit Log]
    L --> SIM[Qiskit Aer / QUBO Simulation]
    L --> AUD[Legacy Crypto Audit]

    OQ --> RA[Relay Adapter / REST API / CLI]
    RA <--> R[Ciphertext Relay Service]
    R --> RA
    RA --> IQ[Inbound Encrypted Queue]
    IQ --> V

    ID --> AL
    V --> AL
    CE --> AL
    L --> AL
```

The diagram represents logical responsibilities, not a required
programming-language or deployment choice.

### 3.2 Four modules from the concept

  -----------------------------------------------------------------------
  Concept module                      Architecture responsibility
  ----------------------------------- -----------------------------------
  Module 1 --- Tactical Interface     Operator-facing vault, signing, and
  Layer                               audit workflows.

  Module 2 --- PERISAI-Q Crypto       Hybrid/PQC key establishment and
  Engine                              symmetric authenticated encryption.

  Module 3 --- Quantum Audit & Sim    Qiskit Aer/QUBO simulation, legacy
  Lab                                 assessment, and visualization.

  Module 4 --- Relay Integration &    Asynchronous forwarding of
  API                                 encrypted packages.
  -----------------------------------------------------------------------

### 3.3 Supporting internal services

The implementation should separate the four conceptual modules into
testable internal services:

-   Identity and key management.
-   Local key store abstraction.
-   Cryptographic suite/protocol adapter.
-   Encrypted vault storage.
-   Offline outbox/inbox and synchronization manager.
-   Signature and trust verification service.
-   Revocation/trust-state manager.
-   Audit event service.
-   Lab execution and report service.

These are proposed internal boundaries to make the concept
implementable; the source presentation does not prescribe them as
separate processes.

------------------------------------------------------------------------

## 4. Component design

### 4.1 Tactical Interface Layer

**Responsibilities** - Provide workflows for identity setup and peer
management. - Allow file/message selection and encryption. - Show local
vault contents and package status. - Provide signing and verification
interfaces. - Present lab scenarios, audit findings, and visualizations.

**Constraints** - The UI must not implement cryptographic primitives. -
Sensitive values such as Sheetphrase input and plaintext should not be
written to ordinary logs. - The UI should display clear success/failure
states and avoid treating a queued message as delivered.

**Interfaces** - Calls local application services. - Does not
communicate directly with the relay except through the Relay Adapter.

### 4.2 Identity & Key Management

**Responsibilities** - Create a local PERISAI-Q identity using the
Sheetphrase workflow. - Request KEM and signature key generation from
the crypto engine. - Store private keys through the Local Key Store
abstraction. - Export/import public-key records. - Track key
identifiers, algorithm suite, creation time, and status. - Apply
revocation/trust information.

**Important design constraint**

The concept says the seed is generated from a Sheetphrase and then used
to derive PQC keys. It does not specify a safe derivation design. The
implementation must not assume a human-memorable phrase has sufficient
entropy. The following must be designed and reviewed:

-   Phrase format and entropy policy.
-   Random salt and context separation.
-   Password-based derivation or random seed generation strategy.
-   Independent derivation domains for KEM and signature key generation.
-   Key backup and recovery.
-   Resistance to offline guessing.
-   Identity authentication and public-key binding.

A single generic seed should not be reused directly as multiple
algorithm private keys. Use algorithm-defined key generation and
reviewed derivation procedures.

### 4.3 PERISAI-Q Crypto Engine

**Responsibilities** - Encapsulate cryptographic library calls behind a
stable interface. - Provide KEM operations using ML-KEM. - Support the
proposed X25519 + ML-KEM hybrid key-establishment design after protocol
review. - Derive symmetric session keys using a reviewed KDF. -
Encrypt/decrypt payloads using AES-256-GCM as proposed. - Sign/verify
artifacts using ML-DSA. - Enforce algorithm-suite and package-version
checks.

**Proposed algorithm roles from the concept**

  Primitive            Intended role
  -------------------- -----------------------------------------------------------
  X25519               Classical component of proposed hybrid key establishment.
  ML-KEM-768/1024      Post-quantum key encapsulation component.
  AES-256-GCM          Symmetric authenticated payload encryption.
  ML-DSA (Dilithium)   Digital signing and verification.

**Protocol warning**

The presentation lists algorithms but does not define a complete secure
hybrid protocol. The engineering design must select a reviewed hybrid
construction and specify:

-   Exact algorithm standards and parameter sets.
-   How X25519 and ML-KEM shared secrets are combined.
-   KDF, salt, context, and domain separation.
-   Authenticated transcript and peer identity binding.
-   Nonce generation and uniqueness for AES-GCM.
-   Associated authenticated data.
-   Key confirmation and failure behavior.
-   Version negotiation and downgrade prevention.
-   Serialization and canonical encoding.
-   Replay protection and message identifiers.

Do not create a custom combination by simply concatenating secrets or
inventing a protocol without cryptographic review.

### 4.4 PERISAI-Vault

**Responsibilities** - Accept plaintext files/messages from the UI. -
Obtain recipient/session key material through the crypto engine. -
Encrypt payloads and create a versioned encrypted package. - Store local
encrypted content. - Place outgoing packages in the offline outbox. -
Decrypt received packages only on an authorized endpoint. - Report
authentication/decryption failures.

**Supported content categories from the concept** - PDF operational
documents. - Maps and coordinate data. - Intelligence photographs. -
Tactical voice notes. - Text messages.

The concept does not define file-size limits, streaming behavior, or
maximum recipient count. These require product decisions.

### 4.5 PERISAI-Sign

**Responsibilities** - Hash and sign command documents or firmware
packages using ML-DSA. - Attach signature and signer/key metadata to a
signed artifact. - Verify signatures against locally trusted public
keys. - Check key status/revocation according to local policy. - Reject
altered, invalid, or untrusted artifacts. - Record verification events.

**Important boundary**

A valid signature proves that the signed content corresponds to a
signing key. It does not, by itself, prove that the signer was
authorized to issue a particular command. Authorization policy, signer
role, command scope, expiry, and target-device rules must be defined
separately.

The MVP should verify artifacts in a test environment. Direct execution
or installation of firmware and commands on safety-critical OT equipment
is outside this architecture baseline.

### 4.6 PERISAI-Lab

**Responsibilities** - Launch controlled local Qiskit Aer simulation
scenarios. - Provide QUBO model/solver integration where selected. -
Demonstrate factoring of deliberately small RSA test keys. - Scan
configured legacy cryptographic parameters. - Compare selected classical
and PQC properties. - Produce reproducible audit/simulation reports.

**Execution boundary** - Lab workloads must be isolated from production
key stores and operational message workflows. - Demonstration keys and
payloads must be synthetic. - A successful small RSA test-key
demonstration must not be represented as breaking production RSA. -
Simulation results must include scenario parameters, tool versions, and
limitations.

**Legacy audit limitation**

The concept says the lab scans legacy cryptographic parameters but does
not define discovery mechanisms, supported platforms, or scanner
permissions. Initial implementation should accept explicitly supplied
configuration data or scan a narrowly defined test environment until
scope is approved.

### 4.7 Relay Integration & API

**Responsibilities** - Submit encrypted packages to the relay. -
Retrieve packages addressed to the local identity. - Maintain delivery
state and retry behavior. - Support asynchronous store-and-forward
operation. - Provide REST API and/or CLI integration.

**Relay trust model** - Relay is untrusted for confidentiality. - Relay
does not receive private keys. - Relay does not need plaintext to
forward a package. - Relay metadata may still reveal sender/recipient
identifiers, timing, size, and communication patterns.

The phrase "zero-knowledge relay" in the concept should be treated as an
architectural goal, not a formal zero-knowledge cryptographic proof. The
more precise requirement is that the relay is not entrusted with
plaintext or endpoint private keys.

------------------------------------------------------------------------

## 5. Data architecture

### 5.1 Logical data stores

  -----------------------------------------------------------------------
  Store                   Location                Contents
  ----------------------- ----------------------- -----------------------
  Local Key Store         Endpoint                Private keys, protected
                                                  identity material, key
                                                  metadata.

  Public Identity Store   Endpoint and peer       Public keys, key
                          exchange                identifiers, identity
                                                  binding and trust
                                                  state.

  Local Vault             Endpoint                Encrypted files and
                                                  encrypted message
                                                  records.

  Outbox                  Endpoint                Encrypted packages
                                                  awaiting transmission.

  Inbox                   Endpoint                Received encrypted
                                                  packages awaiting
                                                  processing.

  Audit Store             Endpoint                Security and
                                                  operational event
                                                  records.

  Lab Results Store       Endpoint                Simulation scenarios,
                                                  configuration
                                                  snapshots, and audit
                                                  reports.

  Relay Store             Relay server            Ciphertext packages,
                                                  routing metadata, and
                                                  delivery state only.
  -----------------------------------------------------------------------

### 5.2 Proposed encrypted package structure

The following is a logical proposal, not a source-defined wire format:

``` json
{
  "format_version": "TBD",
  "suite_id": "TBD",
  "message_id": "TBD",
  "sender_key_id": "TBD",
  "recipient_key_id": "TBD",
  "created_at": "TBD",
  "expires_at": "TBD",
  "kem_encapsulation": "TBD",
  "hybrid_key_context": "TBD",
  "aead_nonce": "TBD",
  "ciphertext": "TBD",
  "authentication_tag": "TBD",
  "signature": "TBD"
}
```

The final structure must be specified with canonical serialization,
field validation, size limits, version negotiation, and cryptographic
review. Do not assume every field above is necessary or that this exact
JSON representation should be used in production.

### 5.3 Data classification

At minimum, distinguish:

-   **Secret:** Sheetphrase inputs, private keys, plaintext protected
    files/messages, session secrets.
-   **Sensitive metadata:** sender/recipient identifiers, operational
    timestamps, file sizes, routing data, audit events.
-   **Public cryptographic data:** public keys and published algorithm
    identifiers.
-   **Demonstration data:** synthetic RSA test keys, simulated payloads,
    lab output.

The organization must define formal classification labels and retention
policies.

------------------------------------------------------------------------

## 6. Key workflows and sequence diagrams

### 6.1 Local identity and key setup

``` mermaid
sequenceDiagram
    actor User
    participant UI as Tactical UI
    participant ID as Identity Manager
    participant CE as Crypto Engine
    participant KS as Local Key Store

    User->>UI: Create local identity
    UI->>ID: Submit Sheetphrase input
    ID->>CE: Request approved key generation
    CE-->>ID: KEM and signature key pairs
    ID->>KS: Store protected private keys
    ID-->>UI: Identity and public-key records
    UI-->>User: Display setup result
```

The exact seed derivation and storage mechanism must be approved before
this flow is implemented.

### 6.2 Encrypt and send a package

``` mermaid
sequenceDiagram
    actor Sender
    participant UI as Tactical UI
    participant Vault as PERISAI-Vault
    participant CE as Crypto Engine
    participant OQ as Outbox / Sync Manager
    participant Relay as Relay Service

    Sender->>UI: Select file/message and recipient
    UI->>Vault: Encrypt request
    Vault->>CE: Establish key and encrypt payload
    CE-->>Vault: Encapsulation data and ciphertext
    Vault->>OQ: Save encrypted package
    OQ-->>UI: Queued status
    OQ->>Relay: Submit ciphertext package
    Relay-->>OQ: Package ID / relay status
    OQ-->>UI: Update transmission status
    UI-->>Sender: Show current package state
```

The relay submission may occur later if the endpoint is offline.

### 6.3 Receive and decrypt a package

``` mermaid
sequenceDiagram
    actor Recipient
    participant Relay as Relay Service
    participant Inbox as Inbound Queue
    participant Vault as PERISAI-Vault
    participant CE as Crypto Engine
    participant KS as Local Key Store

    Recipient->>Relay: Request pending packages
    Relay-->>Inbox: Encrypted package
    Inbox->>Vault: Process package
    Vault->>KS: Resolve local recipient private key
    Vault->>CE: Decapsulate and authenticate/decrypt
    CE-->>Vault: Plaintext or verification failure
    Vault-->>Recipient: Display result
```

Plaintext must not be sent back to the relay.

### 6.4 Sign and verify a command

``` mermaid
sequenceDiagram
    actor Signer
    participant UI as Tactical UI
    participant Sign as PERISAI-Sign
    participant CE as Crypto Engine
    participant KS as Local Key Store
    actor Receiver

    Signer->>UI: Select command/firmware artifact
    UI->>Sign: Sign request
    Sign->>KS: Load authorized signing key
    Sign->>CE: Create ML-DSA signature
    CE-->>Sign: Signature
    Sign-->>UI: Signed artifact
    UI-->>Receiver: Distribute signed artifact
    Receiver->>Sign: Verify artifact
    Sign->>CE: Verify signature
    CE-->>Sign: Valid / invalid
    Sign-->>Receiver: Verification result
```

Signer authorization and command-policy checks are separate from
cryptographic signature verification.

### 6.5 Lab demonstration

``` mermaid
sequenceDiagram
    actor Operator
    participant UI as Lab UI
    participant Lab as PERISAI-Lab
    participant Sim as Qiskit Aer / QUBO
    participant Report as Results Store

    Operator->>UI: Select test scenario
    UI->>Lab: Start controlled simulation
    Lab->>Sim: Execute bounded test
    Sim-->>Lab: Simulation output
    Lab->>Report: Store parameters and results
    Lab-->>UI: Display findings and limitations
```

------------------------------------------------------------------------

## 7. Trust boundaries and threat considerations

### 7.1 Trust boundaries

``` mermaid
flowchart TB
    subgraph ENDPOINT["Endpoint trust boundary"]
        UI[User Interface]
        ID[Identity and Key Manager]
        CE[Crypto Engine]
        KS[(Protected Key Store)]
        VAULT[(Encrypted Vault)]
        LAB[Isolated Lab]
        UI --> ID
        UI --> CE
        UI --> VAULT
        CE --> KS
        UI --> LAB
    end

    subgraph NETWORK["Untrusted network"]
        NET[Radio / Internet / Intermittent Link]
    end

    subgraph RELAY["Relay trust boundary — untrusted for plaintext"]
        API[Relay API]
        STORE[(Ciphertext Queue)]
        API --> STORE
    end

    ENDPOINT --> NET --> RELAY
    RELAY --> NET
```

### 7.2 Threats and controls

  -----------------------------------------------------------------------
  Threat                              Architectural control
  ----------------------------------- -----------------------------------
  Passive interception                Encrypt payloads before
                                      transmission.

  HNDL                                Use a reviewed PQC/hybrid
                                      key-establishment protocol.

  Ciphertext modification             AEAD authentication and strict
                                      failure handling.

  Command/firmware tampering          ML-DSA signatures and verification
                                      before acceptance.

  Public-key substitution             Authenticated
                                      identity-to-public-key binding.

  Lost/stolen endpoint                Protected local key storage,
                                      revocation, and recovery
                                      procedures.

  Relay compromise                    Keep plaintext and private keys off
                                      the relay; minimize metadata.

  Replay or duplicate delivery        Unique message IDs, expiry, replay
                                      state, and idempotent handling.

  Stale offline trust state           Define revocation freshness and
                                      fail-safe policy.

  Malicious lab input                 Isolate simulation workloads and
                                      use synthetic test material.

  Dependency compromise               Pin, audit, and update
                                      cryptographic dependencies under
                                      controlled release processes.
  -----------------------------------------------------------------------

### 7.3 Security principles

-   Endpoint-held private keys.
-   Local cryptographic operations.
-   Authenticated encryption.
-   Signature verification before artifact acceptance.
-   Least privilege and explicit trust.
-   No plaintext relay processing.
-   Versioned cryptographic suites.
-   Auditable and reproducible builds.
-   Fail closed on cryptographic validation failure.

------------------------------------------------------------------------

## 8. Offline synchronization architecture

### 8.1 Outbox/inbox model

The endpoint maintains:

-   **Outbox:** encrypted packages waiting to be sent or retried.
-   **Inbox:** packages received from the relay and waiting for local
    processing.
-   **Sync state:** package identifier, attempt count, last attempt,
    next retry, and current state.

Suggested states:

``` text
CREATED
  -> ENCRYPTED
  -> QUEUED
  -> UPLOADING
  -> RELAY_ACCEPTED
  -> AVAILABLE_TO_RECIPIENT
  -> RETRIEVED
  -> DECRYPTED

Failure branches:
  UPLOADING -> RETRY_PENDING
  RETRY_PENDING -> UPLOADING
  Any validation failure -> REJECTED
```

The exact relay acknowledgements and meaning of delivery states must be
agreed. A relay acceptance must not be shown as proof that a recipient
has decrypted or read the message.

### 8.2 Synchronization requirements

-   Retry safely after network interruption.
-   Prevent duplicate processing.
-   Verify package integrity after transfer.
-   Preserve encrypted packages until a defined deletion policy permits
    removal.
-   Avoid storing plaintext in synchronization queues.
-   Expose current state to the user.
-   Support low-bandwidth and intermittent connectivity.

------------------------------------------------------------------------

## 9. API and integration architecture

### 9.1 Client-to-relay interface

The concept calls for lightweight REST API and/or CLI integration. Exact
endpoint paths and schemas are TBD.

A possible logical API surface is:

  -----------------------------------------------------------------------
  Operation                           Purpose
  ----------------------------------- -----------------------------------
  Submit package                      Upload ciphertext and routing
                                      metadata.

  List pending packages               List packages available to a
                                      recipient identity.

  Retrieve package                    Download a ciphertext package.

  Acknowledge package                 Update relay delivery/processing
                                      state.

  Query package status                Return relay-side state.

  Publish revocation update           Distribute signed revocation
                                      information, subject to approved
                                      trust design.
  -----------------------------------------------------------------------

These are conceptual operations, not finalized endpoint contracts.

### 9.2 Relay responsibilities

The relay may: - Authenticate clients and enforce access to queues. -
Store and forward opaque encrypted packages. - Track package identifiers
and delivery state. - Enforce quotas, expiry, and retention. - Provide
operational health information.

The relay must not: - Hold endpoint private keys. - Decrypt protected
payloads. - Log plaintext. - Claim to verify the truth or authorization
of a command solely from transport metadata.

Transport security and relay authentication are still required;
end-to-end encryption does not remove the need to protect the
network/API.

------------------------------------------------------------------------

## 10. Deployment architecture

### 10.1 Endpoint deployment

The concept expects standard laptops and mobile devices and emphasizes
offline operation. A suitable logical deployment is:

-   Tactical UI installed on each endpoint.
-   Crypto Engine and identity services local to the endpoint.
-   Protected local key store.
-   Encrypted local vault.
-   Local outbox/inbox and audit store.
-   PERISAI-Lab available on designated audit/training endpoints.

The supported operating systems, packaging formats, hardware
requirements, and platform secure-storage APIs are **TBD**.

### 10.2 Relay deployment

A relay server is an optional network service for asynchronous package
forwarding:

-   REST API or equivalent transport interface.
-   Ciphertext queue/storage.
-   Routing and delivery metadata.
-   Authentication and authorization.
-   Monitoring and retention controls.

The relay must be deployable without access to endpoint private keys or
plaintext.

### 10.3 Lab deployment

Qiskit Aer and QUBO workloads run locally according to the concept. Lab
execution should be separated logically and, where practical, at
process/container permission boundaries from operational identity and
vault components.

------------------------------------------------------------------------

## 11. Technology mapping from the concept

  -----------------------------------------------------------------------
  Concern                 Technology named in     Architecture usage
                          concept                 
  ----------------------- ----------------------- -----------------------
  Post-quantum key        ML-KEM (Kyber),         Establish shared key
  encapsulation           including 768/1024      material.
                          variants                

  Classical hybrid        X25519                  Classical component of
  component                                       proposed hybrid key
                                                  establishment.

  Symmetric encryption    AES-256-GCM             Authenticated payload
                                                  encryption.

  Digital signatures      ML-DSA (Dilithium)      Sign and verify
                                                  commands/firmware.

  Quantum simulation      IBM Qiskit Aer          Local simulation
                                                  scenarios.

  Optimization model      QUBO                    Lab modelling/solver
                                                  capability.

  Integration             REST API / CLI          Relay and
                                                  existing-system
                                                  integration.
  -----------------------------------------------------------------------

The concept does not select programming languages, UI frameworks,
databases, relay infrastructure, cryptographic library implementations,
or mobile packaging technology. Those choices require a separate
technology decision record.

------------------------------------------------------------------------

## 12. Performance and capacity

The concept states a target of less than 50 milliseconds for encryption
and verification on standard laptop/mobile devices.

This is not yet a testable requirement. Define separate benchmarks for:

-   Key generation.
-   KEM encapsulation and decapsulation.
-   Hybrid secret derivation.
-   AES-GCM encryption/decryption by payload size.
-   ML-DSA signing and verification.
-   Package serialization and parsing.
-   Relay upload/download, measured separately from local cryptography.
-   Lab simulation, which should not be conflated with field
    cryptographic latency.

Every benchmark must specify device model/CPU, operating system, library
version, algorithm parameter set, payload size, warm/cold state, and
percentile or repetition method.

The architecture should stream large files where appropriate rather than
requiring all plaintext and ciphertext to reside in memory
simultaneously. The actual file-size target is TBD.

------------------------------------------------------------------------

## 13. Observability and audit

### 13.1 Audit events

Potential events include:

-   Identity created or imported.
-   Public key imported or trust state changed.
-   Key generated, rotated, revoked, or retired.
-   File/message encrypted or decrypted.
-   Signature created or verified.
-   Artifact rejected.
-   Package queued, submitted, retrieved, or failed.
-   Lab scenario started and completed.
-   Legacy audit started and completed.

### 13.2 Audit data

An event may include: - Event identifier. - Timestamp and local clock
context. - Event type. - Local actor or key identifier. -
Artifact/package identifier. - Algorithm-suite/version identifier. -
Result and error category.

Do not include Sheetphrase values, private keys, session secrets, or
plaintext payloads. Audit records themselves may expose sensitive
operational metadata and therefore require access control, integrity
protection, and a retention policy.

------------------------------------------------------------------------

## 14. Failure handling

  -----------------------------------------------------------------------
  Failure                             Expected behavior
  ----------------------------------- -----------------------------------
  Invalid Sheetphrase or identity     Reject setup/unlock and avoid
  input                               revealing secret material.

  Key generation failure              Do not create a partially trusted
                                      identity; report failure and clean
                                      temporary material.

  Unknown recipient key               Refuse encryption or require
                                      explicit, authenticated key
                                      enrollment.

  KEM/decapsulation failure           Reject package; do not return
                                      partial plaintext.

  AEAD authentication failure         Reject package and record a safe
                                      error event.

  Invalid signature                   Reject artifact and record
                                      verification failure.

  Revoked or untrusted signer         Reject according to policy; do not
                                      silently bypass.

  Relay unavailable                   Retain ciphertext in outbox and
                                      retry according to policy.

  Partial/corrupt transfer            Do not mark package complete; retry
                                      or reject.

  Stale revocation data               Apply an explicitly defined policy;
                                      high-risk operations may need to
                                      fail closed.

  Lab process failure                 Isolate failure from vault/signing
                                      workflows and preserve diagnostic
                                      context without secrets.
  -----------------------------------------------------------------------

------------------------------------------------------------------------

## 15. Testing strategy

### 15.1 Unit testing

-   Key-management state transitions.
-   Package encoding/decoding.
-   KEM and signature adapter behavior.
-   AEAD tamper detection.
-   Revocation and trust policy.
-   Queue state transitions.

### 15.2 Integration testing

-   Two local endpoints exchanging public keys.
-   Encrypt/decrypt across two endpoints.
-   Sign/verify across two endpoints.
-   Offline queue and later synchronization.
-   Relay storage and retrieval without plaintext.
-   REST/CLI interoperability.

### 15.3 Security testing

-   Ciphertext and metadata tampering.
-   Invalid, substituted, and revoked public keys.
-   Replay and duplicate package handling.
-   Private-key and plaintext leakage in logs/network/storage.
-   Local storage access control.
-   Dependency and supply-chain review.
-   Fuzzing of package parsers and API inputs.

### 15.4 Lab validation

-   Reproducible small RSA test-key scenarios.
-   Qiskit Aer and QUBO execution records.
-   Clear distinction between simulation and real-world quantum
    capability.
-   Comparison output tied to explicit parameters and assumptions.

### 15.5 Performance testing

Use the operation-specific benchmarks defined in Section 12. Do not
claim the overall system meets the 50 ms target based on a single
primitive microbenchmark.

------------------------------------------------------------------------

## 16. Architecture decisions required

The following decisions are blockers for a secure implementation
baseline:

  -----------------------------------------------------------------------------
  ID                      Decision                 Why it matters
  ----------------------- ------------------------ ----------------------------
  ADR-001                 Define Sheetphrase       Determines whether
                          entropy, derivation, and identity/key generation is
                          recovery                 safe and recoverable.

  ADR-002                 Select exact PQC         Required for
                          standards, parameter     interoperability and
                          sets, and library        supportability.
                          versions                 

  ADR-003                 Specify the hybrid       Ad hoc combination can
                          X25519 + ML-KEM protocol undermine security.

  ADR-004                 Specify KDF, domain      Prevents ambiguous or unsafe
                          separation, transcript   session-key derivation.
                          binding, and key         
                          confirmation             

  ADR-005                 Define AES-GCM nonce     Nonce reuse can compromise
                          strategy and package     confidentiality/integrity.
                          format                   

  ADR-006                 Define                   Prevents public-key
                          identity-to-public-key   substitution and
                          authentication           impersonation.

  ADR-007                 Define key storage,      Required for endpoint
                          backup, rotation,        compromise and lifecycle
                          revocation, and          management.
                          destruction              

  ADR-008                 Define relay             Required for secure and
                          authentication, API,     reliable store-and-forward.
                          metadata, retention, and 
                          quotas                   

  ADR-009                 Define replay, expiry,   Required for reliable
                          ordering, and duplicate  command/message delivery.
                          handling                 

  ADR-010                 Select target platforms  Determines storage APIs,
                          and packaging            cryptographic dependencies,
                                                   and testing matrix.

  ADR-011                 Define PERISAI-Lab scope Prevents lab tooling from
                          and isolation            affecting operational
                                                   components.

  ADR-012                 Define the \<50 ms       Makes the performance target
                          benchmark precisely      measurable.
  -----------------------------------------------------------------------------

------------------------------------------------------------------------

## 17. Implementation sequence

A dependency-aware implementation sequence is proposed below. It is a
recommendation, not a schedule from the source presentation.

### Phase 0 --- Security and protocol design

-   Resolve ADR-001 through ADR-009.
-   Select reviewed cryptographic libraries.
-   Define threat model and package format.
-   Establish test vectors and interoperability fixtures.

### Phase 1 --- Local cryptographic foundation

-   Build Crypto Engine adapter.
-   Implement identity and local key-store interfaces.
-   Implement key generation, KEM, KDF, AEAD, and signature operations
    using selected reviewed libraries.
-   Add unit tests and failure handling.

### Phase 2 --- PERISAI-Vault and PERISAI-Sign

-   Build local file/message encryption.
-   Build local vault.
-   Build sign/verify workflows.
-   Add tamper detection and audit events.

### Phase 3 --- Offline and relay

-   Implement outbox/inbox.
-   Implement relay API and ciphertext storage.
-   Add retries, duplicate handling, package status, and integration
    tests.

### Phase 4 --- PERISAI-Lab

-   Integrate Qiskit Aer and selected QUBO tooling.
-   Implement bounded RSA test-key demonstration.
-   Implement initial legacy configuration audit.
-   Add reproducible reports and clear simulation limitations.

### Phase 5 --- Hardening and validation

-   Conduct independent cryptographic review.
-   Run security, privacy, performance, and interoperability tests.
-   Validate offline and low-bandwidth behavior.
-   Review platform-specific key storage.
-   Keep OT integration outside production until separately authorized
    and assessed.

------------------------------------------------------------------------

## 18. Assumptions and limitations

### 18.1 Assumptions

-   The first implementation is a prototype/MVP, not a certified
    operational defense product.
-   Core cryptographic operations occur on user endpoints.
-   Relay is untrusted for plaintext confidentiality.
-   Lab demonstrations use synthetic and deliberately small test
    material.
-   The named cryptographic algorithms are intended roles from the
    concept and require precise standards/library selection.

### 18.2 Limitations in the supplied concept

The source presentation does not specify: - Programming language or
framework. - Supported operating systems and device models. - Database
or local storage technology. - Relay server implementation or hosting. -
Exact Sheetphrase format and derivation. - Full hybrid key-establishment
protocol. - Package wire format. - Authentication and authorization
model. - Key recovery and revocation distribution protocol. - File-size
and user/team capacity. - Exact performance benchmark methodology. -
Formal security certification requirements.

These are open architecture decisions, not details that should be
invented during implementation.

------------------------------------------------------------------------

## 19. Traceability to the supplied concept

  -----------------------------------------------------------------------
  Concept presentation                SAD sections
  ----------------------------------- -----------------------------------
  Page 3 --- Product modules and      3, 4, 11
  technologies                        

  Page 4 --- Sheetphrase identity     4.2, 6.1, 16
  workflow                            

  Page 5 --- High-level architecture  3, 4

  Page 6 --- Vault and hybrid         4.3, 4.4, 6.2
  encryption                          

  Page 7 --- Signing and OT integrity 4.5, 6.4

  Page 8 --- Audit and simulation lab 4.6, 6.5

  Page 9 --- Offline, low bandwidth,  8, 9, 10
  interoperability, revocation        

  Page 10 --- MVP                     17

  Page 11 --- Success metrics         12, 15
  -----------------------------------------------------------------------

------------------------------------------------------------------------

## 20. Glossary

-   **AEAD:** Authenticated Encryption with Associated Data.
-   **AES-GCM:** AES in Galois/Counter Mode.
-   **KDF:** Key Derivation Function.
-   **KEM:** Key Encapsulation Mechanism.
-   **ML-KEM:** Module-Lattice-Based Key-Encapsulation Mechanism.
-   **ML-DSA:** Module-Lattice-Based Digital Signature Algorithm.
-   **PQC:** Post-Quantum Cryptography.
-   **Qiskit Aer:** Local quantum circuit simulation framework named in
    the concept.
-   **QUBO:** Quadratic Unconstrained Binary Optimization.
-   **OT/IoT:** Operational Technology / Internet of Things.
-   **Relay:** A service that forwards encrypted packages between
    endpoints.
-   **Sheetphrase:** PERISAI-Q's proposed local identity phrase concept.
-   **Crypto-agility:** Controlled ability to change algorithms,
    parameters, and protocol versions.
