﻿rule AEGIS_GUARD_Auth_Branch_Tamper {
    meta:
        source = "PA-T3-PRD-001 (SelfRecover)"
        standard = "ISO/IEC 27037"
        seal = "BLAKE3 + SHA-256"
    strings:
        $auth_jne_patch = { 75 ?? ?? ?? }
    condition:
        $auth_jne_patch
}
