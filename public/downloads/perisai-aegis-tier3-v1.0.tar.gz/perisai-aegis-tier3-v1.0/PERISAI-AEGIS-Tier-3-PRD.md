# PERISAI-AEGIS --- Tier 3

## AEGIS-GUARD Product Requirements Document (PRD)

**Document ID:** PA-T3-PRD-001\
**Version:** 1.0\
**Status:** Product Baseline --- Draft for Review\
**Scope:** Tier 3 only: System Runtime & Self-Healing DFIR (AEGIS-GUARD
Framework)\
**Primary source:** *Proposal Inovasi Teknologi Pertahanan Siber ---
PERISAI-AEGIS*, especially Sections 2--6 and the integrated architecture
description (PDF pages 4--8).

------------------------------------------------------------------------

## 1. Product summary

**AEGIS-GUARD** is Tier 3 of PERISAI-AEGIS. It is intended to protect
authorized application binaries, monitor defined runtime integrity
signals, preserve forensic evidence when tampering is detected, and
attempt controlled recovery using Reed-Solomon parity.

Tiers 1 and 2 are already developed and are outside this document's
feature scope. AEGIS-GUARD may package or protect their authorized
binaries, but this PRD does not redefine their functionality.

## 2. Problem statement

The proposal identifies physical access and binary modification as a
threat to field systems. Its example is an attacker modifying an
authentication instruction byte (`0x74` JE to `0x75` JNE) to bypass a
login check.

The proposal's desired response is to: 1. Detect a binary or runtime
integrity anomaly. 2. Freeze execution. 3. Capture and seal evidence
before repair. 4. Reconstruct eligible damage using Reed-Solomon parity.
5. Resume the application after successful restoration. 6. Preserve
evidence for extraction and review by a DFIR laboratory.

## 3. Product vision

Provide a deployable protection layer for supported application binaries
that combines package protection, runtime integrity monitoring,
Capture-Then-Heal evidence handling, and independently verified
recovery.

## 4. Target users

  -----------------------------------------------------------------------
  User                                Need
  ----------------------------------- -----------------------------------
  Build/release engineer              Package an authorized binary and
                                      produce a verifiable protected
                                      artifact

  System administrator                Deploy and operate protected
                                      binaries on supported endpoints

  Security engineer                   Configure integrity policy and
                                      review security events

  DFIR analyst                        Receive sealed evidence with
                                      metadata, captured bytes, and
                                      candidate YARA rule

  Incident responder                  Determine whether recovery is safe
                                      or endpoint must remain quarantined

  Technical evaluator                 Reproduce the proposal's tampering
                                      and recovery demonstration
  -----------------------------------------------------------------------

## 5. Goals

-   Provide a Rust-based CLI Builder for supported binaries.
-   Encrypt the protected payload using AES-256-GCM as specified in the
    proposal.
-   Generate Reed-Solomon parity over GF(2\^8).
-   Verify package authenticity and integrity before execution.
-   Monitor defined runtime integrity signals.
-   Detect the proposal's controlled disk-patch scenario.
-   Freeze/isolate execution when a configured integrity anomaly is
    detected.
-   Capture `evidence_metadata.json`, `injected_payload.bin`, and
    `rule_generated.yar` where applicable.
-   Seal evidence using BLAKE3 and SHA-256.
-   Reconstruct a candidate artifact within configured correction
    limits.
-   Verify the candidate against an independent trusted reference.
-   Resume only after successful verification; otherwise quarantine.
-   Export evidence for authorized DFIR analysis.

## 6. Non-goals

-   Rebuilding Tier 1 or Tier 2.
-   Implementing messaging, relay, Sheetphrase, ML-KEM, or ML-DSA
    features.
-   Supporting every executable format or Linux distribution at launch.
-   Hiding execution from endpoint security products or administrators.
-   Disabling security tools, bypassing monitoring, or creating covert
    persistence.
-   Automatically trusting or distributing generated YARA rules.
-   Claiming that all arbitrary binary modifications can be repaired.
-   Claiming formal ISO/IEC 27037 compliance based only on hash
    generation.
-   Using the framework against software or systems without
    authorization.

## 7. Product modules

### 7.1 AEGIS CLI Builder

The Builder packages an authorized application binary into the
AEGIS-GUARD package structure.

**Expected outputs** - Rust bootstrap stub. - AES-256-GCM encrypted
payload. - Reed-Solomon parity material. - Package manifest and
integrity/authenticity information.

### 7.2 Bootstrap Stub Loader

Validates package metadata, platform compatibility, and payload
authentication before handing execution to the supported runtime
adapter.

### 7.3 Active RASP Watchdog

Monitors defined integrity events. The proposal names checksum
anomalies, debugger attachment, `ptrace`, and `LD_PRELOAD` manipulation.

### 7.4 Automated Forensic Vault

Creates an isolated evidence package with the three proposal-named
artifacts and dual hash seals.

### 7.5 Reed-Solomon Recovery Engine

Uses configured parity data to reconstruct an eligible candidate
artifact. Recovery is not considered successful until the candidate
passes independent trusted verification.

## 8. Functional requirements

Priority: **P0** = required for Tier 3 MVP; **P1** = important
follow-on; **P2** = future enhancement.

### 8.1 Builder and packaging

  -----------------------------------------------------------------------
  ID                Priority          Requirement       Acceptance
                                                        criteria
  ----------------- ----------------- ----------------- -----------------
  T3-FR-001         P0                Builder accepts   A supported test
                                      an authorized     binary can be
                                      application       selected and
                                      binary.           packaged.

  T3-FR-002         P0                Builder validates Unsupported input
                                      target format and is rejected with
                                      platform.         a clear
                                                        diagnostic.

  T3-FR-003         P0                Builder produces  Output contains
                                      a Rust bootstrap  the expected stub
                                      package.          and versioned
                                                        package
                                                        structure.

  T3-FR-004         P0                Builder encrypts  Valid package
                                      the payload using authenticates;
                                      AES-256-GCM.      modified
                                                        ciphertext or
                                                        metadata fails
                                                        validation.

  T3-FR-005         P0                Builder generates Parity metadata
                                      Reed-Solomon      and shards are
                                      parity over       generated and
                                      GF(2\^8).         validated.

  T3-FR-006         P0                Builder creates a Manifest records
                                      package manifest. package ID,
                                                        target, payload
                                                        metadata, parity
                                                        parameters, and
                                                        builder version.

  T3-FR-007         P0                Builder verifies  Newly created
                                      its output.       package passes an
                                                        independent
                                                        verification step
                                                        before
                                                        deployment.

  T3-FR-008         P1                Builder supports  Build inputs and
                                      repeatable build  tool versions are
                                      records.          recorded
                                                        sufficiently to
                                                        reproduce or
                                                        investigate a
                                                        package.
  -----------------------------------------------------------------------

### 8.2 Bootstrap and runtime

  ---------------------------------------------------------------------------------------
  ID                Priority          Requirement                Acceptance criteria
  ----------------- ----------------- -------------------------- ------------------------
  T3-FR-009         P0                Loader validates package   Invalid or modified
                                      manifest before execution. manifest causes
                                                                 execution refusal.

  T3-FR-010         P0                Loader                     Authentication failure
                                      authenticates/decrypts the prevents execution.
                                      payload.                   

  T3-FR-011         P0                Loader checks platform     Unsupported
                                      compatibility.             OS/architecture/kernel
                                                                 profile is reported and
                                                                 execution is refused or
                                                                 follows a documented
                                                                 safe fallback.

  T3-FR-012         P0                Runtime records the        Logs identify the
                                      execution mode.            supported execution
                                                                 adapter used without
                                                                 exposing secrets.

  T3-FR-013         P1                Linux runtime may use the  Capability is detected
                                      proposal's                 and validated on the
                                      `memfd_create`/`fexecve`   declared Linux profile;
                                      approach.                  execution remains
                                                                 visible to authorized
                                                                 security controls.

  T3-FR-014         P0                Runtime does not silently  Any failed validation
                                      bypass protection on       results in a clear
                                      error.                     failure or quarantine
                                                                 state.
  ---------------------------------------------------------------------------------------

### 8.3 Active RASP watchdog

  ---------------------------------------------------------------------------
  ID                Priority          Requirement           Acceptance
                                                            criteria
  ----------------- ----------------- --------------------- -----------------
  T3-FR-015         P0                Watchdog monitors     A known test
                                      configured integrity  integrity
                                      signals.              mismatch produces
                                                            a structured
                                                            event.

  T3-FR-016         P0                Watchdog detects the  The test
                                      controlled binary     alteration `0x74`
                                      patch fixture.        → `0x75` at the
                                                            configured
                                                            fixture offset is
                                                            detected.

  T3-FR-017         P1                Watchdog supports     Controlled test
                                      debugger-attachment   attachment is
                                      detection scenarios.  detected on the
                                                            declared platform
                                                            where supported.

  T3-FR-018         P1                Watchdog identifies   Controlled
                                      configured            environment test
                                      `LD_PRELOAD`          emits the
                                      manipulation.         expected
                                                            integrity event.

  T3-FR-019         P0                Watchdog sends events Event includes
                                      to the response       process/package
                                      coordinator.          reference,
                                                            trigger type,
                                                            timestamp, and
                                                            observation
                                                            details.

  T3-FR-020         P0                Watchdog response is  Detection does
                                      policy-controlled.    not cause
                                                            unlogged or
                                                            uncontrolled
                                                            destructive
                                                            actions.
  ---------------------------------------------------------------------------

### 8.4 Capture-Then-Heal and Forensic Vault

  ----------------------------------------------------------------------------------
  ID                Priority          Requirement                 Acceptance
                                                                  criteria
  ----------------- ----------------- --------------------------- ------------------
  T3-FR-021         P0                System enters a safe        Controlled tamper
                                      execution state after a     test triggers the
                                      qualifying anomaly.         configured
                                                                  freeze/isolation
                                                                  behavior.

  T3-FR-022         P0                Evidence capture occurs     Test proves that
                                      before repair.              no repair write
                                                                  occurs before
                                                                  evidence
                                                                  capture/sealing
                                                                  completes.

  T3-FR-023         P0                Vault creates               File validates
                                      `evidence_metadata.json`.   against the
                                                                  versioned schema
                                                                  and includes
                                                                  event, PID,
                                                                  UID/GID where
                                                                  available, offset,
                                                                  byte diff,
                                                                  timestamp, and
                                                                  recovery status.

  T3-FR-024         P0                Vault captures              Captured bytes
                                      `injected_payload.bin` when match the defined
                                      reliable.                   test fixture;
                                                                  unavailable bytes
                                                                  are explicitly
                                                                  marked
                                                                  unavailable.

  T3-FR-025         P0                Vault creates               Rule passes syntax
                                      `rule_generated.yar` as a   validation and
                                      candidate.                  matches the
                                                                  controlled test
                                                                  fixture.

  T3-FR-026         P0                Vault calculates BLAKE3 and Recomputed hashes
                                      SHA-256 hashes.             match the sealed
                                                                  manifest.

  T3-FR-027         P0                Evidence package is         Recovery cannot
                                      isolated from recovery      overwrite the
                                      writes.                     original sealed
                                                                  evidence.

  T3-FR-028         P1                Evidence package can be     Exported package
                                      exported.                   contains manifest
                                                                  and artifacts;
                                                                  hashes still
                                                                  validate.

  T3-FR-029         P1                Evidence access/export is   Authorized access
                                      audited.                    and export events
                                                                  are recorded.
  ----------------------------------------------------------------------------------

### 8.5 Reed-Solomon recovery

  -----------------------------------------------------------------------
  ID                Priority          Requirement       Acceptance
                                                        criteria
  ----------------- ----------------- ----------------- -----------------
  T3-FR-030         P0                Recovery engine   Invalid or
                                      validates parity  mismatched parity
                                      metadata.         data is rejected.

  T3-FR-031         P0                Recovery engine   Engine
                                      assesses          distinguishes
                                      correction        supported damage
                                      capacity.         from
                                                        beyond-capacity
                                                        damage.

  T3-FR-032         P0                Recovery writes   Original suspect
                                      to a separate     artifact remains
                                      candidate         unchanged.
                                      artifact.         

  T3-FR-033         P0                Recovery          Controlled test
                                      reconstructs      fixture is
                                      known corruption  reconstructed to
                                      within configured match the trusted
                                      capacity.         original.

  T3-FR-034         P0                Recovery          Candidate
                                      candidate is      mismatch prevents
                                      checked against   resume.
                                      an independent    
                                      trusted           
                                      reference.        

  T3-FR-035         P0                Beyond-capacity   No execution
                                      or unverifiable   resumes when
                                      recovery is       reconstruction or
                                      quarantined.      verification
                                                        fails.

  T3-FR-036         P1                Recovery report   Report includes
                                      records           parity
                                      parameters and    configuration,
                                      outcome.          detected damage,
                                                        candidate result,
                                                        and verification
                                                        result.
  -----------------------------------------------------------------------

### 8.6 Quarantine and operations

  -------------------------------------------------------------------------
  ID                Priority          Requirement       Acceptance criteria
  ----------------- ----------------- ----------------- -------------------
  T3-FR-037         P0                System supports a Failed
                                      quarantine state. evidence/recovery
                                                        verification leaves
                                                        the application
                                                        unable to resume
                                                        through the
                                                        protected path.

  T3-FR-038         P0                Operator can      UI/CLI shows
                                      inspect incident  detection,
                                      status.           evidence, recovery,
                                                        and quarantine
                                                        states.

  T3-FR-039         P1                Authorized        Export is recorded
                                      operator can      and does not mutate
                                      export an         evidence.
                                      incident bundle.  

  T3-FR-040         P1                Release from      Release action is
                                      quarantine        authenticated and
                                      requires an       audited.
                                      explicit          
                                      authorized        
                                      action.           
  -------------------------------------------------------------------------

## 9. Non-functional requirements

  ------------------------------------------------------------------------
  ID                      Category                Requirement
  ----------------------- ----------------------- ------------------------
  T3-NFR-001              Memory safety           Rust components must use
                                                  safe Rust by default;
                                                  unsafe blocks require
                                                  justification and
                                                  review.

  T3-NFR-002              Integrity               Package, evidence, and
                                                  recovered candidate
                                                  integrity must be
                                                  independently
                                                  verifiable.

  T3-NFR-003              Forensic preservation   Original suspect
                                                  artifact and sealed
                                                  evidence must not be
                                                  overwritten by recovery.

  T3-NFR-004              Fail-safe               Invalid package,
                                                  incomplete evidence,
                                                  invalid parity, or
                                                  failed verification
                                                  results in
                                                  refusal/quarantine.

  T3-NFR-005              Portability             Support is limited to
                                                  explicitly tested
                                                  OS/kernel/architecture
                                                  profiles.

  T3-NFR-006              Auditability            Security-relevant
                                                  actions and operator
                                                  actions are recorded
                                                  without secrets.

  T3-NFR-007              Performance             Freeze, capture,
                                                  hashing, and recovery
                                                  are measured
                                                  independently.

  T3-NFR-008              Maintainability         Package format, evidence
                                                  schema, and module
                                                  interfaces are
                                                  versioned.

  T3-NFR-009              Least privilege         Builder, runtime,
                                                  evidence, and recovery
                                                  operations use minimum
                                                  required permissions.

  T3-NFR-010              Transparency            Runtime remains
                                                  observable to authorized
                                                  endpoint security and
                                                  system administrators.
  ------------------------------------------------------------------------

## 10. Proposal performance targets

The proposal reports the following figures. They must be treated as
**benchmark targets/claims to reproduce**, not guaranteed acceptance
thresholds until tested on a declared platform.

  ----------------------------------------------------------------------------
  Metric                             Proposal figure Acceptance measurement
  --------------------- ---------------------------- -------------------------
  Atomic freeze                              \< 1 ms Detection-to-safe-state
                                                     latency; report
                                                     p50/p95/p99

  Evidence                                   \< 5 ms Include capture,
  isolation/capture                                  metadata, hashes, and
                                                     storage behavior

  Reed-Solomon                               14.2 ms State binary size, parity
  restoration                                        parameters, and
                                                     corruption pattern

  Recovery tolerance                         20--30% Demonstrate exact code
                                                     parameters and
                                                     error/erasure patterns
  ----------------------------------------------------------------------------

If correctness and evidence integrity conflict with a timing target,
correctness and evidence integrity take precedence.

## 11. User journeys

### 11.1 Package an application

1.  Build/release engineer selects an authorized application binary.
2.  Builder checks format and target compatibility.
3.  Builder encrypts payload and generates parity.
4.  Builder writes package manifest.
5.  Builder verifies the package.
6.  Operator deploys the package to the selected endpoint.

**Success:** Package is authenticated, versioned, and deployable on the
declared platform.

### 11.2 Detect and preserve evidence

1.  Protected application is running under the configured integrity
    policy.
2.  Test operator modifies the controlled test binary fixture.
3.  Watchdog detects the integrity mismatch.
4.  Coordinator enters the safe state.
5.  Forensic Vault captures metadata and available suspicious bytes.
6.  Vault creates a candidate YARA rule.
7.  Vault seals evidence with BLAKE3 and SHA-256.
8.  Incident status becomes `evidence_sealed`.

**Success:** Evidence is captured and sealed before any repair changes
the suspect artifact.

### 11.3 Recover a damaged binary

1.  Recovery engine validates package and parity metadata.
2.  Engine checks whether damage is within configured correction
    capacity.
3.  Engine writes reconstructed candidate separately.
4.  Candidate is compared to an independently protected trusted
    reference.
5.  If verification succeeds, the coordinator may authorize resume.
6.  If verification fails, the system remains quarantined.

**Success:** Only a verified candidate can be resumed; original evidence
remains intact.

## 12. MVP definition

The Tier 3 MVP should focus on a single controlled Linux target and a
purpose-built test binary.

### MVP deliverables

-   Rust CLI Builder for the selected binary format.
-   AES-256-GCM protected payload packaging.
-   Reed-Solomon parity generation and verification over GF(2\^8).
-   Bootstrap package validation.
-   Runtime integrity check for the controlled test binary.
-   Capture-Then-Heal state machine.
-   Forensic Vault with the three proposal-named artifacts.
-   BLAKE3 and SHA-256 evidence manifest.
-   Recovery to a separate candidate.
-   Independent post-recovery verification.
-   Quarantine behavior.

### Explicitly deferred

-   Broad support for arbitrary binaries.
-   Multiple Linux distributions and CPU architectures.
-   Generalized production deployment to relay daemons and mobile
    endpoints.
-   Automated YARA distribution to an enterprise fleet.
-   Advanced runtime monitoring beyond the defined MVP test signals.

## 13. MVP acceptance checklist

### Builder

-   [ ] Supported test binary can be packaged.
-   [ ] Unsupported format is rejected.
-   [ ] AES-256-GCM authentication is verified.
-   [ ] Reed-Solomon parity is generated and checked.
-   [ ] Manifest records platform, package, and parity parameters.

### Runtime and detection

-   [ ] Package validation happens before execution.
-   [ ] Invalid payload authentication prevents execution.
-   [ ] Known test binary modification is detected.
-   [ ] Detection event is delivered to the coordinator.
-   [ ] Safe-state/freeze behavior is observable and logged.

### Forensics

-   [ ] Evidence capture precedes repair.
-   [ ] `evidence_metadata.json` validates.
-   [ ] `injected_payload.bin` matches controlled fixture bytes where
    available.
-   [ ] `rule_generated.yar` passes syntax and fixture tests.
-   [ ] BLAKE3 and SHA-256 hashes validate.
-   [ ] Evidence remains unchanged after recovery.

### Recovery

-   [ ] Within-capacity corruption is reconstructed.
-   [ ] Candidate is written separately from suspect original.
-   [ ] Candidate matches independent trusted reference.
-   [ ] Beyond-capacity damage is rejected.
-   [ ] Failed verification leaves application quarantined.

## 14. Risks and dependencies

  ---------------------------------------------------------------------------
  Risk/dependency         Impact                      Required mitigation
  ----------------------- --------------------------- -----------------------
  "Zero-code-change"      Builder may not support all Declare supported
  compatibility is broad  binaries                    formats and platform
                                                      profiles

  Runtime facilities vary Execution/monitoring may    Capability detection
  by kernel               fail on some endpoints      and tested
                                                      compatibility matrix

  `ptrace` restrictions   Watchdog may not operate as Select and validate
  vary                    described on every target   monitor model for MVP
                                                      platform

  AES-GCM nonce/key       Payload                     Define key source,
  lifecycle unspecified   confidentiality/integrity   nonce uniqueness,
                          risk                        rotation, and failure
                                                      behavior

  Reed-Solomon tolerance  May imply unsupported       Specify code parameters
  stated as a percentage  recovery guarantees         and test exact error
                                                      patterns

  Evidence capture        Evidence may be incomplete  Prioritize complete
  latency target is       if timing dominates         capture and report
  aggressive                                          measured latency

  Hashes alone do not     Forensic claims may be      Define access, time
  establish chain of      overstated                  source, acquisition,
  custody                                             manifest protection,
                                                      and custody procedure

  YARA output may produce Poor rule quality or        Mark as candidate and
  false positives         operational disruption      require analyst
                                                      validation

  Automatic healing can   Loss of investigative value Enforce
  destroy evidence                                    Capture-Then-Heal
                                                      invariant and separate
                                                      candidate output
  ---------------------------------------------------------------------------

## 15. Roadmap

This Tier 3 roadmap is derived from the proposal's Phase 1--3 plan and
scoped to AEGIS-GUARD.

  -------------------------------------------------------------------------
  Phase                   Proposal timeline       Tier 3 work
  ----------------------- ----------------------- -------------------------
  Phase 1 --- PoC & Lab   2026 Q1--Q2             Rust wrapper PoC, package
  Integration                                     encryption, Reed-Solomon
                                                  experiments, evidence
                                                  format and capture
                                                  workflow

  Phase 2 --- Cyber Range 2026 Q3--Q4             Controlled red-team
                                                  tamper tests, YARA
                                                  validation, SIEM
                                                  connector prototype,
                                                  performance/portability
                                                  testing

  Phase 3 --- Military    2027 Q1--Q2             Controlled endpoint
  Pilot                                           pilot, operational SOP,
                                                  evidence handling and
                                                  readiness assessment
  -------------------------------------------------------------------------

Dates are proposal dates and should be re-baselined against actual
project progress.

## 16. Release readiness

AEGIS-GUARD Tier 3 is ready for a controlled MVP demonstration when: -
The target platform and supported binary format are declared. - Package
verification and payload authentication work. - Integrity detection
reproduces the controlled patch scenario. - Evidence is captured and
sealed before repair. - Evidence files and hashes validate. - Recovery
succeeds only within defined limits. - Independent verification gates
resume. - Failed capture/recovery paths quarantine safely. - Performance
results are reproducible and disclosed with test conditions. - All tests
are performed on authorized, isolated fixtures.

------------------------------------------------------------------------

**End of Tier 3 PRD**
